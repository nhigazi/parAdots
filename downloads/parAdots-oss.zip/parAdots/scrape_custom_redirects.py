"""
Pardot Custom Redirect Scraper — v5 API + browser hybrid
=========================================================
API:     objects/custom-redirects, objects/campaigns,
         objects/folders, objects/tracker-domains
Browser: one read-page visit per redirect (no screenshots) for:
           - completion_actions
           - prospect_count

Output:
  pardot_custom_redirects.json
  pardot_custom_redirects.csv

Usage:
  python3 scrape_custom_redirects.py
"""

from __future__ import annotations

import csv
import json
import os
import re
import sys

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time via utils.output_path()
OUTPUT_CSV  = ""
SCREENSHOTS = ""   # set at run() time via utils.output_path()

CSV_HEADERS = ["id", "name", "destination_url", "vanity_url_path", "tracked_url", "tracker_domain", "campaign", "folder", "is_archived", "completion_actions", "prospect_count", "usage", "created_at", "updated_at"]


REDIRECT_FIELDS = [
    "id", "name",
    "destinationUrl",
    "vanityUrlPath",
    "campaignId", "folderId",
    "trackerDomainId",

    "createdAt", "updatedAt",
]

TRACKER_LOOKUP_FIELDS  = ("id", "domain")
CAMPAIGN_LOOKUP_FIELDS = ("id", "name")
FOLDER_LOOKUP_FIELDS   = ("id", "name")


def shape_redirect(
    redirect: dict,
    trackers: dict,
    campaigns: dict,
    folders: dict,
) -> dict:
    rid = str(redirect.get("id"))
    tracker_domain = (trackers.get(redirect.get("trackerDomainId")) or {}).get("domain", "")
    vanity_path    = redirect.get("vanityUrlPath") or ""
    # Build full tracked URL: https://<tracker_domain>/<vanityUrlPath>
    tracked_url = f"https://{tracker_domain}/{vanity_path}" if tracker_domain and vanity_path else ""
    return {
        "id":                  rid,
        "name":                redirect.get("name", ""),
        "destination_url":     redirect.get("destinationUrl", "") or "",
        "vanity_url_path":     vanity_path,
        "tracked_url":         tracked_url,
        "tracker_domain":      tracker_domain,
        "campaign":            (campaigns.get(redirect.get("campaignId")) or {}).get("name", ""),
        "folder":              (folders.get(redirect.get("folderId")) or {}).get("name", ""),
        "is_archived":         bool(redirect.get("isArchived")),
        "created_at":          redirect.get("createdAt", "") or "",
        "updated_at":          redirect.get("updatedAt", "") or "",
        # Filled by browser pass
        "completion_actions":  [],
        "prospect_count":      None,
        "usage":               [],
    }


# Set True after the UI-language guard passes on the first redirect visited
# in a run — see _extract_browser_data() / utils.assert_english_ui.
_LANGUAGE_VERIFIED = False


def _extract_browser_data(page, redirect_id: str, redirect_name: str = "") -> tuple[list[str], int | None, list[dict]]:
    """Visit /customUrl/read/id/{id}, take a screenshot, extract completion_actions,
    prospect_count, and usage (see utils.extract_usage_inline)."""
    url = f"{utils.PARDOT_HOME}/customUrl/read/id/{redirect_id}"
    try:
        page.goto(url, wait_until="networkidle", timeout=15000)
    except Exception:
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=12000)
        except Exception as e:
            print(f"   ⚠️  Could not load redirect {redirect_id}: {e}")
            return [], None, []

    page.wait_for_timeout(1000)
    safe_name = re.sub(r'[^\w\-]', '_', redirect_name)[:50] if redirect_name else redirect_id
    utils.screenshot(page, f"{SCREENSHOTS}/redirect_{redirect_id}_{safe_name}.png")

    try:
        body_text = page.evaluate("() => document.body.innerText") or ""
    except Exception:
        return [], None, []

    lines = [l.strip() for l in body_text.splitlines() if l.strip()]

    # UI language guard — check ONCE per run, on the first redirect visited.
    # Let it propagate uncaught; callers must not swallow it as a per-item
    # scrape failure. See utils.assert_english_ui. Custom Redirects have no
    # bilingual fallback anywhere in this scraper (unlike scrape_dynamic_lists.py),
    # so a non-English UI would otherwise silently read as "no usage" instead
    # of an error — extract_usage_inline() below matches the heading text
    # "Usage" literally, with no German/etc. variant.
    global _LANGUAGE_VERIFIED
    if not _LANGUAGE_VERIFIED:
        utils.assert_english_ui(
            lines, f"Pardot customUrl detail page (id {redirect_id})",
            fix_hint=(
                "the scraping user's Salesforce/Pardot UI language must be English "
                "for Usage detection to work (Salesforce Setup → Users → this user → "
                "Language & Locale, or the Pardot user's Account Settings)."
            ),
        )
        _LANGUAGE_VERIFIED = True

    # Usage: no tab, no fixed selector — see utils.extract_usage_inline. Safe
    # to call regardless of where completion_actions parsing lands below; it
    # does its own DOM query, doesn't switch tabs, and doesn't depend on the
    # innerText already captured.
    usage = utils.extract_usage_inline(page)

    # Prospect count: pagination footer renders "of N" in last ~20 lines
    prospect_count: int | None = None
    for line in reversed(lines[-20:]):
        m = re.match(r'^of\s+([\d,]+)$', line)
        if m:
            prospect_count = int(m.group(1).replace(",", ""))
            break

    # Completion actions: between "Completion Actions" heading and the next
    # major section ("Prospects", "Usages", end of page, or a known heading)
    ACTIONS_HEADING   = "completion actions"
    STOP_HEADINGS     = {"prospects", "usages", "redirect details", "overview"}

    actions_idx = stop_idx = None
    for i, line in enumerate(lines):
        ll = line.lower()
        if actions_idx is None and ll == ACTIONS_HEADING:
            actions_idx = i
        elif actions_idx is not None and stop_idx is None and ll in STOP_HEADINGS:
            stop_idx = i
            break

    if actions_idx is None:
        return [], prospect_count, usage

    end_idx = stop_idx if stop_idx is not None else len(lines)
    noise   = {"there are no actions", "no completion actions"}
    completion_actions = [
        line.replace("\t", ": ")
        for line in lines[actions_idx + 1 : end_idx]
        if line and line.lower() not in noise
    ]
    return completion_actions, prospect_count, usage


def export_csv(results: list[dict]) -> None:
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow([
            "#", "Name", "ID",
            "Destination URL", "Tracked URL", "Vanity URL Path",
            "Tracker Domain",
            "Campaign", "Folder",
            "Is Archived",
            "Completion Actions", "Prospect Count",
            "Usage Count", "Usage",
            "Created At", "Updated At",
        ])
        for i, r in enumerate(results, 1):
            usage = r.get("usage") or []
            w.writerow([
                i,
                r["name"], r["id"],
                r.get("destination_url", ""),
                r.get("tracked_url", ""),
                r.get("vanity_url_path", ""),
                r.get("tracker_domain", ""),
                r.get("campaign", ""),
                r.get("folder", ""),
                r.get("is_archived", ""),
                "\n".join(r.get("completion_actions", [])),
                "" if r.get("prospect_count") is None else r["prospect_count"],
                len(usage),
                "; ".join(f"{u.get('type','')}: {u.get('name','')}" for u in usage),
                r.get("created_at", ""),
                r.get("updated_at", ""),
            ])
    print(f"✅ Exported {OUTPUT_CSV} ({len(results)} rows)")


def run(page=None, client: pardot_api.PardotClient | None = None,
        update: bool = False, max_age_days: int = 7, refresh_limit: int = 25,
        allow_prune: bool = False, dry_run: bool = False) -> None:
    global OUTPUT_JSON, OUTPUT_CSV, SCREENSHOTS
    OUTPUT_JSON = utils.output_path("pardot_custom_redirects.json")
    OUTPUT_CSV  = utils.output_path("pardot_custom_redirects.csv")
    SCREENSHOTS = utils.output_path("screenshots", "custom_redirects")
    print("\n🚀 Pardot Custom Redirect Scraper (v5 API + browser hybrid)")
    print("=" * 57)

    kind = "custom_redirects"
    started_at = utils.now_iso()
    ok_ids = set()

    # ── Tier B: Load previous output & set up API + aging gating ────────────────
    cached: dict[str, dict] = {}
    if update:
        cached = utils.load_previous_output(kind)
        cached_hash = utils.manifest_entry(f"scrape_{kind}").get("shape_hash")
        if cached_hash and cached_hash != utils.shape_hash(CSV_HEADERS):
            print("   ⚠️  Output shape changed — ignoring cache, full scrape this run")
            cached = {}
        print(f"   [update] {len(cached)} cached record(s)")

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    print("📚 Pre-loading reference data...")
    trackers  = pardot_api.lookup_map(client, "objects/tracker-domains", TRACKER_LOOKUP_FIELDS)
    campaigns = pardot_api.lookup_map(client, "objects/campaigns",       CAMPAIGN_LOOKUP_FIELDS)
    folders   = pardot_api.lookup_map(client, "objects/folders",         FOLDER_LOOKUP_FIELDS)
    print(f"   ✅ {len(trackers)} tracker(s) / {len(campaigns)} campaign(s) / {len(folders)} folder(s)")

    print("📋 Fetching custom redirects...")
    api_redirects: list[dict] = []
    api_error = False
    try:
        for redirect in pardot_api.paged_get(client, "objects/custom-redirects", fields=REDIRECT_FIELDS):
            api_redirects.append(shape_redirect(redirect, trackers, campaigns, folders))
    except Exception:
        api_error = True
    sweep_verified = not api_error
    api_redirects.sort(key=lambda r: int(r.get("id", 0)) if str(r.get("id", "")).isdigit() else str(r.get("id", "")))
    print(f"   ✅ {len(api_redirects)} custom redirect(s)\n")

    # ── Tier B: Determine which redirects to visit (API updatedAt + aging sweep) ─
    current_ids = {r["id"] for r in api_redirects}
    stale = utils.stale_ids(kind, current_ids, max_age_days=max_age_days,
                            limit=refresh_limit) if update else set()

    def should_visit_redirect(rid: str, api_record: dict) -> bool:
        if not update:
            return True
        if rid not in cached:
            return True
        if rid in stale:
            return True
        cached_updated = cached.get(rid, {}).get("updated_at", "")
        api_updated = api_record.get("updated_at", "")
        return cached_updated != api_updated

    results: list[dict] = []
    if page is not None:
        print(f"🌐 Browser pass — completion actions + prospect counts + usage ({len(api_redirects)} redirect(s))...")
        utils.reset_screenshots(SCREENSHOTS)
        for r in api_redirects:
            rid = r["id"]
            if update and rid in cached and not should_visit_redirect(rid, r):
                print(f"   [{rid}] {r['name']} [cached]")
                fresh = utils.merge_record_fields(cached.get(rid, {}), r, ["prospect_count", "completion_actions", "usage"])
                results.append(fresh)
                continue

            try:
                actions, count, usage = _extract_browser_data(page, rid, r["name"])
            except utils.UnexpectedUILanguageError as e:
                print(str(e))
                sys.exit(1)
            r["completion_actions"] = actions
            r["prospect_count"]     = count
            r["usage"]              = usage
            label      = f"{count} prospects" if count is not None else "count unavailable"
            action_str = f"{len(actions)} action(s)" if actions else "no actions"
            usage_str  = f"{len(usage)} usage(s)" if usage else "unused"
            print(f"   ✅ {r['name']} — {action_str}, {label}, {usage_str}")
            results.append(r)
            ok_ids.add(rid)
        print()
    else:
        print("⚠️  No browser page — completion_actions, prospect_count, and usage left empty.\n")
        results = api_redirects

    # ── Tier B: Merge cached + prune deleted ────────────────────────────────────
    merged = utils.merge_records(cached.values() if update else [], {r["id"]: r for r in results})
    prev = utils.manifest_entry(f"scrape_{kind}")
    record_count = prev.get("record_count", len(merged))
    merged, pruned = utils.apply_prune(
        merged, current_ids, sweep_verified=sweep_verified,
        record_count=record_count, allow_prune=allow_prune
    )

    merged.sort(key=lambda r: int(r.get("id", 0)) if str(r.get("id", "")).isdigit() else str(r.get("id", "")))
    if dry_run:
        print(f"   [dry-run] would visit {len(ok_ids)} of {len(current_ids)} record(s)")
        print(f"   [dry-run] would merge {len(results)}, prune {len(pruned)}")
        print(f"   [dry-run] no files written")
    else:
        with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
            json.dump(merged, f, ensure_ascii=False, indent=2)
        print(f"✅ Saved {OUTPUT_JSON} ({len(merged)} custom redirects)")
        export_csv(merged)

        if update and ok_ids:
            utils.mark_scraped(kind, ok_ids)
            utils.write_manifest(f"scrape_{kind}", started_at=started_at,
                                shape_hash_val=utils.shape_hash(CSV_HEADERS), record_count=len(merged))


def main() -> None:
    utils.load_org_config()
    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
