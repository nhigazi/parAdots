# parAdots setup — Windows (PowerShell)
$ErrorActionPreference = "Stop"; Set-Location $PSScriptRoot
Write-Host "== parAdots setup =="
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw "python not found on PATH" }
python -m venv .venv
$py = ".\.venv\Scripts\python.exe"
& $py -m pip install --upgrade pip | Out-Null
& $py -m pip install -r requirements.txt
try { & $py -m playwright install chromium } catch { Write-Host "   (skipped Playwright)" }
if (Get-Command npm -ErrorAction SilentlyContinue) { try { npm install --no-audit --no-fund | Out-Null } catch { Write-Host "   (npm optional)" } }
if (-not (Test-Path configs\demo.env)) { Copy-Item .env.template configs\demo.env }
if (-not (Test-Path .active-org)) { "demo" | Out-File -Encoding ascii -NoNewline .active-org }
Write-Host ""; Write-Host "== Done. Run: .\.venv\Scripts\python.exe viewer.py  → http://localhost:8765 =="
