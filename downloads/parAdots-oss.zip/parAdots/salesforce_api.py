"""
Salesforce REST API Client
===========================
Thin wrapper around the Salesforce REST API v59.0 for use by the
SF-side analysis scrapers in this project.

Auth model — two interchangeable paths
---------------------------------------
1. SF CLI token (preferred — client_from_cli)
   Reads the access token + instance URL from `sf org display --json`.
   This is the same auth the SF Org Explorer (viewer.py) uses: browser
   login incl. MFA, no Connected App. It decouples the SF scrapers from
   the Pardot Playwright session — they no longer die if the Pardot login
   breaks, and no browser needs to stay open.

2. Pardot browser session token (legacy — client_from_page)
   Reuses extract_access_token() from pardot_api.py. The sid cookie /
   Bearer token from the logged-in Playwright session works for both
   Pardot v5 and SF REST. Kept as a fallback.

Key capabilities:
  soql()          — Execute a SOQL query, auto-paginate via nextRecordsUrl
  soql_count()    — COUNT() query returning a single integer (cheap)
  describe()      — SObject field metadata (field names, types, picklists)
  rest_get()      — Raw GET against any /services/data/v59.0/{path}
  discover_consent_fields() — auto-detect opt-in/consent fields from
                    describe metadata, so new orgs need no hand-tuned env
  resolve_consent_fields()  — env override → describe discovery → defaults

Configuration via env:
  SF_LOGIN_URL        — e.g. https://your-org.my.salesforce.com
  SF_API_VERSION      — default v59.0
  OPTIN_FIELDS        — comma-separated custom opt-in field API names
  CONSENT_BRANDS      — comma-separated brand codes, e.g. ACM,GLB,GLB_CH,INI
"""

from __future__ import annotations

import json as _json
import logging
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from typing import Any, Iterator
from urllib.parse import urlparse, urljoin

import requests
from dotenv import load_dotenv
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

import pardot_api   # reuse extract_access_token + make_session

logger = logging.getLogger(__name__)

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))

DEFAULT_TIMEOUT = 30
RETRY_TOTAL     = 3
RETRY_BACKOFF   = 1.0
RETRY_STATUSES  = (429, 500, 502, 503, 504)

# Org-specific config — bound at import, refreshed by refresh_config().
# utils.load_org_config() calls it so per-org values win even when this
# module was imported first (standalone scrapers import it at the top).
SF_LOGIN_URL: str = ""
SF_API_VERSION: str = "v59.0"
SF_HOST: str = ""
# Pardot-related custom field names — override in .env if your instance differs
CONSENT_BRANDS: list[str] = []
# True when OPTIN_FIELDS / OPTIN_TIMESTAMP_FIELDS were pinned in .env.
# When False, scrapers may auto-discover consent fields via describe().
OPTIN_FIELDS_EXPLICIT: bool = False
OPTIN_TIMESTAMP_EXPLICIT: bool = False
OPTIN_FIELDS: list[str] = []
OPTIN_TIMESTAMP_FIELDS: list[str] = []


# Default opt-in field names derived from brand codes
def _default_optin_fields() -> list[str]:
    raw = os.getenv("OPTIN_FIELDS", "")
    if raw:
        return [f.strip() for f in raw.split(",") if f.strip()]
    return [f"Optin_Double_{b}__c" for b in CONSENT_BRANDS]

# Default consent timestamp field names
def _default_timestamp_fields() -> list[str]:
    raw = os.getenv("OPTIN_TIMESTAMP_FIELDS", "")
    if raw:
        return [f.strip() for f in raw.split(",") if f.strip()]
    return [f"Optin_Double_Timestamp_{b}__c" for b in CONSENT_BRANDS]


def refresh_config() -> None:
    """Re-read org config from os.environ."""
    global SF_LOGIN_URL, SF_API_VERSION, SF_HOST, CONSENT_BRANDS
    global OPTIN_FIELDS_EXPLICIT, OPTIN_TIMESTAMP_EXPLICIT, OPTIN_FIELDS, OPTIN_TIMESTAMP_FIELDS
    SF_LOGIN_URL   = os.getenv("SF_LOGIN_URL", "").rstrip("/")
    SF_API_VERSION = os.getenv("SF_API_VERSION", "v59.0")
    # Derive the REST base from SF_LOGIN_URL — handles both
    # https://login.salesforce.com and https://org.my.salesforce.com
    SF_HOST = urlparse(SF_LOGIN_URL).netloc if SF_LOGIN_URL else ""
    CONSENT_BRANDS = [
        b.strip() for b in os.getenv("CONSENT_BRANDS", "ACM,GLB,GLB_CH,INI").split(",") if b.strip()
    ]
    OPTIN_FIELDS_EXPLICIT    = bool(os.getenv("OPTIN_FIELDS", "").strip())
    OPTIN_TIMESTAMP_EXPLICIT = bool(os.getenv("OPTIN_TIMESTAMP_FIELDS", "").strip())
    OPTIN_FIELDS           = _default_optin_fields()
    OPTIN_TIMESTAMP_FIELDS = _default_timestamp_fields()


refresh_config()


# ── Client ────────────────────────────────────────────────────────────────────

@dataclass
class SalesforceClient:
    access_token: str
    instance_url: str          # e.g. https://your-org.my.salesforce.com
    api_version:  str
    session:      requests.Session

    @property
    def base_url(self) -> str:
        return f"{self.instance_url}/services/data/{self.api_version}"

    def headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type":  "application/json",
        }


def _make_session() -> requests.Session:
    sess = requests.Session()
    retry = Retry(
        total=RETRY_TOTAL,
        backoff_factor=RETRY_BACKOFF,
        status_forcelist=RETRY_STATUSES,
        allowed_methods=frozenset(["GET"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=10)
    sess.mount("https://", adapter)
    return sess


def _resolve_instance_url(page, token: str) -> str:
    """
    Determine the org's My Domain instance URL.
    Priority:
      1. SF_LOGIN_URL env var (if it's already a My Domain URL)
      2. /id endpoint on login.salesforce.com using the token
      3. Current page URL
    """
    # If SF_LOGIN_URL is already a My Domain, use it
    if SF_LOGIN_URL and "salesforce.com" in SF_LOGIN_URL and "login.salesforce.com" not in SF_LOGIN_URL:
        return SF_LOGIN_URL

    # Try to get instance URL from the identity endpoint
    try:
        resp = requests.get(
            "https://login.salesforce.com/services/oauth2/userinfo",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            urls = data.get("urls", {})
            rest = urls.get("rest", "")
            if rest:
                # rest looks like "https://org.my.salesforce.com/services/data/v{version}/"
                base = rest.split("/services/")[0]
                return base
    except Exception:
        pass

    # Fall back to current page URL
    try:
        current = page.url
        parsed = urlparse(current)
        if "force.com" in parsed.netloc or "salesforce.com" in parsed.netloc:
            return f"{parsed.scheme}://{parsed.netloc}"
    except Exception:
        pass

    return SF_LOGIN_URL


def client_from_page(page) -> SalesforceClient:
    """Extract token from a logged-in Playwright page and return a SalesforceClient."""
    if not SF_LOGIN_URL:
        logger.error("SF_LOGIN_URL not set in .env")
        sys.exit(1)
    token        = pardot_api.extract_access_token(page)
    instance_url = _resolve_instance_url(page, token)
    logger.info(f"SF instance: {instance_url}")
    return SalesforceClient(
        access_token=token,
        instance_url=instance_url,
        api_version=SF_API_VERSION,
        session=_make_session(),
    )


# ── SF CLI auth (preferred — no Pardot session needed) ──────────────────────────

def _sf_cli() -> str | None:
    """Path to the `sf` (or legacy `sfdx`) CLI, or None if not installed."""
    return shutil.which("sf") or shutil.which("sfdx")


def sf_env() -> dict:
    """
    Environment for SF CLI subprocesses with the auto-update notice disabled.

    The oclif "update available" warning can be printed to stdout on some sf
    versions, which corrupts `--json` parsing. Disabling it (and tolerant
    parsing in _extract_json) makes token extraction robust.
    """
    env = os.environ.copy()
    env.setdefault("SF_AUTOUPDATE", "false")
    env.setdefault("SF_DISABLE_AUTOUPDATE", "true")
    env.setdefault("SFDX_DISABLE_AUTOUPDATE", "true")
    env.setdefault("SF_CLI_DISABLE_AUTOUPDATE", "true")
    return env


def _extract_json(raw: str) -> str:
    """
    Return the JSON substring of CLI output, tolerating a leading warning
    line (e.g. 'Warning: @salesforce/cli update available…') before the body.
    """
    raw = (raw or "").strip()
    candidates = [i for i in (raw.find("{"), raw.find("[")) if i != -1]
    start = min(candidates) if candidates else -1
    return raw[start:] if start > 0 else raw


def _sf_json(cmd: list[str]) -> tuple[dict | None, str | None]:
    """Run an `sf ... --json` command and return (result, error)."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20, env=sf_env())
    except Exception as e:
        return None, f"{' '.join(cmd)} failed: {e}"
    raw = _extract_json(r.stdout)
    if not raw:
        return None, f"no output from {' '.join(cmd)}: {(r.stderr or '').strip()[:200]}"
    try:
        data = _json.loads(raw)
    except _json.JSONDecodeError:
        return None, f"invalid JSON from {' '.join(cmd)}: {raw[:200]}"
    if data.get("status", 0) != 0 or "result" not in data:
        return None, data.get("message") or data.get("name") or raw[:200]
    return data["result"], None


def _cli_org_display(alias: str | None) -> tuple[str | None, str | None, str | None]:
    """
    Return (access_token, instance_url, error) for an authenticated SF CLI org.

    As of recent `sf` CLI versions, `sf org display` redacts accessToken
    ("[REDACTED] Use 'sf org auth show-access-token' to view") — so
    instanceUrl comes from `org display` and the real token from the
    dedicated `sf org auth show-access-token` command.
    """
    cli = _sf_cli()
    if not cli:
        return None, None, "SF CLI (sf/sfdx) not found — install with: brew install sf"

    display_cmd = [cli, "org", "display", "--json"]
    token_cmd   = [cli, "org", "auth", "show-access-token", "--json"]
    if alias:
        display_cmd += ["--target-org", alias]
        token_cmd   += ["--target-org", alias]

    display_res, err = _sf_json(display_cmd)
    if err:
        return None, None, err
    url = (display_res.get("instanceUrl") or "").rstrip("/")

    token_res, err = _sf_json(token_cmd)
    if err:
        return None, None, err
    # Strip ALL whitespace (not just ends) — guards against INVALID_AUTH_HEADER.
    token = "".join((token_res.get("accessToken") or "").split())
    if not token:
        return None, None, "accessToken missing in sf org auth show-access-token output"
    if not url:
        return None, None, "instanceUrl missing in sf org display output"
    logger.debug(f"SF auth successful for {url}")
    return token, url, None


def _resolve_cli_alias(alias: str | None) -> str | None:
    """
    Decide which org identifier to hand to `sf org display`.

    Priority:
      1. explicit alias argument
      2. SF_CLI_ALIAS env
      3. SF_USERNAME env (sf accepts the username as a target-org)
      4. None → sf uses its configured default org
    """
    return (
        alias
        or os.getenv("SF_CLI_ALIAS", "").strip()
        or os.getenv("SF_USERNAME", "").strip()
        or None
    )


def cli_available() -> bool:
    """True if the SF CLI is installed (cheap PATH check, no subprocess)."""
    return _sf_cli() is not None


def client_from_cli(alias: str | None = None) -> SalesforceClient:
    """
    Build a SalesforceClient from the SF CLI token — no Pardot login required.

    Raises RuntimeError with a readable message if the CLI is missing or the
    org is not authenticated; callers may catch this to fall back to
    client_from_page().
    """
    resolved = _resolve_cli_alias(alias)
    token, url, err = _cli_org_display(resolved)
    if err:
        target = resolved or "(default org)"
        raise RuntimeError(f"SF CLI auth failed for {target}: {err}")
    logger.info(f"SF instance (CLI): {url}")
    return SalesforceClient(
        access_token=token,
        instance_url=url,
        api_version=SF_API_VERSION,
        session=_make_session(),
    )


# ── SOQL ──────────────────────────────────────────────────────────────────────

def soql(client: SalesforceClient, query: str) -> Iterator[dict]:
    """
    Execute a SOQL SELECT query and yield every record, auto-paginating
    via nextRecordsUrl. Do NOT use for COUNT() queries — use soql_count().
    """
    url    = f"{client.base_url}/query"
    params = {"q": query}

    while True:
        resp = client.session.get(
            url, headers=client.headers(), params=params, timeout=DEFAULT_TIMEOUT,
        )
        if resp.status_code != 200:
            logger.warning(f"SOQL failed with HTTP {resp.status_code}")
            return

        body = resp.json()
        for record in body.get("records", []):
            yield record

        next_url = body.get("nextRecordsUrl")
        if not next_url:
            break
        # nextRecordsUrl is a path like /services/data/v59.0/query/01g...
        url    = f"{client.instance_url}{next_url}"
        params = {}   # already encoded in the URL


def soql_count(client: SalesforceClient, query: str) -> int:
    """
    Execute a COUNT() SOQL query and return the integer total.
    query must be of the form: SELECT COUNT() FROM SObject [WHERE ...]
    """
    url  = f"{client.base_url}/query"
    resp = client.session.get(
        url, headers=client.headers(),
        params={"q": query}, timeout=DEFAULT_TIMEOUT,
    )
    if resp.status_code != 200:
        logger.warning(f"COUNT query failed with HTTP {resp.status_code}")
        return -1
    return resp.json().get("totalSize", -1)


def soql_all(client: SalesforceClient, query: str) -> list[dict]:
    """Return all records from a SOQL query as a list."""
    return list(soql(client, query))


# ── Object metadata + describe cache ────────────────────────────────────────────
#
# Both the SF scrapers (optin_sync, field_mapping, …) and the SF Org Explorer in
# viewer.py describe the same SObjects (Lead, Contact, …) repeatedly. A describe
# call is expensive and the schema barely changes within a session, so we cache:
#
#   • in-memory, keyed by instance_url + sobject — safe for the long-lived,
#     multi-org viewer process (no cross-org bleed)
#   • on disk under utils.OUTPUT_DIR (output/{org}/sf_describe_cache.json) when an
#     org output dir is configured — survives across separate scraper runs
#
# Use describe(..., force=True) to bypass the cache, or clear_describe_cache().

_DESCRIBE_MEM: dict[str, dict] = {}            # "{instance_url}|{sobject}" → describe
_DESCRIBE_DISK_LOADED: set[str] = set()        # cache file paths already merged in
DESCRIBE_CACHE_FILENAME = "sf_describe_cache.json"


def _describe_cache_path() -> str | None:
    """Disk cache path under the active org's OUTPUT_DIR, or None if unset."""
    try:
        import utils
        out = getattr(utils, "OUTPUT_DIR", "")
    except Exception:
        out = ""
    if not out:
        return None
    return os.path.join(out, DESCRIBE_CACHE_FILENAME)


def _mem_key(client: SalesforceClient, sobject: str) -> str:
    return f"{client.instance_url}|{sobject}"


def _load_disk_cache(client: SalesforceClient) -> None:
    """Merge the on-disk cache for this org into memory once per process/path."""
    path = _describe_cache_path()
    if not path or path in _DESCRIBE_DISK_LOADED:
        return
    _DESCRIBE_DISK_LOADED.add(path)
    if not os.path.exists(path):
        return
    try:
        with open(path, encoding="utf-8") as f:
            data = _json.load(f)
    except Exception:
        return
    # File is {instance_url: {sobject: describe}}
    for inst, objs in (data.items() if isinstance(data, dict) else []):
        for sobj, desc in (objs.items() if isinstance(objs, dict) else []):
            _DESCRIBE_MEM.setdefault(f"{inst}|{sobj}", desc)


def _save_disk_cache(client: SalesforceClient, sobject: str, desc: dict) -> None:
    path = _describe_cache_path()
    if not path:
        return
    try:
        data = {}
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                data = _json.load(f) or {}
        if not isinstance(data, dict):
            data = {}
        data.setdefault(client.instance_url, {})[sobject] = desc
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            _json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        pass   # cache is best-effort — never fail the caller


def clear_describe_cache() -> None:
    """Drop the in-memory describe cache (disk file is left intact)."""
    _DESCRIBE_MEM.clear()
    _DESCRIBE_DISK_LOADED.clear()


def describe(
    client: SalesforceClient, sobject: str,
    use_cache: bool = True, force: bool = False,
) -> dict | None:
    """
    Return the full SObject describe result (fields, relationships, etc.).

    Cached in-memory (and on disk under OUTPUT_DIR) unless force=True or
    use_cache=False. Only successful (non-None) results are cached.
    """
    key = _mem_key(client, sobject)
    if use_cache and not force:
        if key in _DESCRIBE_MEM:
            return _DESCRIBE_MEM[key]
        _load_disk_cache(client)
        if key in _DESCRIBE_MEM:
            return _DESCRIBE_MEM[key]

    url  = f"{client.base_url}/sobjects/{sobject}/describe"
    resp = client.session.get(url, headers=client.headers(), timeout=DEFAULT_TIMEOUT)
    if resp.status_code == 404:
        return None
    if resp.status_code != 200:
        logger.warning(f"Describe {sobject} failed with HTTP {resp.status_code}")
        return None

    desc = resp.json()
    if use_cache and desc is not None:
        _DESCRIBE_MEM[key] = desc
        _save_disk_cache(client, sobject, desc)
    return desc


def field_names(client: SalesforceClient, sobject: str) -> set[str]:
    """Return the set of API field names for an SObject."""
    d = describe(client, sobject)
    if not d:
        return set()
    return {f["name"] for f in d.get("fields", [])}


def rest_get(client: SalesforceClient, path: str, params: dict | None = None) -> Any:
    """
    Raw GET against /services/data/{version}/{path}.
    Returns parsed JSON or None on error.
    """
    url  = f"{client.base_url}/{path.lstrip('/')}"
    resp = client.session.get(
        url, headers=client.headers(), params=params or {}, timeout=DEFAULT_TIMEOUT,
    )
    if resp.status_code != 200:
        logger.warning(f"REST GET {path} failed with HTTP {resp.status_code}")
        return None
    return resp.json()


def object_exists(client: SalesforceClient, sobject: str) -> bool:
    """Return True if the SObject exists in this org."""
    return describe(client, sobject) is not None


# ── Consent-field discovery (describe drives the scraper) ───────────────────────

_CONSENT_KEYWORDS = (
    "optin", "opt_in", "consent", "einwillig", "newsletter", "dsgvo", "gdpr", "double",
)
_SOURCE_KEYWORDS  = ("source", "channel", "quelle", "herkunft")
_TS_DROP_TOKENS   = {"timestamp", "date", "time", "ts", "datetime", "dt"}


def _norm_tokens(api_name: str) -> list[str]:
    base = re.sub(r"__c$", "", api_name, flags=re.I)
    return [t for t in re.split(r"[_\W]+", base) if t]


def _is_consent_name(api_name: str) -> bool:
    low = api_name.lower()
    return any(k in low for k in _CONSENT_KEYWORDS)


def _brand_key(api_name: str) -> str:
    """
    Reduce a consent field name to its brand suffix so opt-in and timestamp
    fields can be paired. Optin_Double_GLB_CH__c → 'GLB_CH'.
    """
    drop = set(_CONSENT_KEYWORDS) | set(_SOURCE_KEYWORDS) | _TS_DROP_TOKENS
    toks = [
        t for t in _norm_tokens(api_name)
        if t.lower() not in drop and not any(k in t.lower() for k in _CONSENT_KEYWORDS)
    ]
    return "_".join(toks).upper()


def discover_consent_fields(
    client: SalesforceClient, sobjects: tuple[str, ...] = ("Lead", "Contact")
) -> dict:
    """
    Scan Lead/Contact describe metadata for consent-related custom fields and
    classify them by type. Returns:
        {
          'optin_fields':     [bool fields, sorted],
          'timestamp_fields': [date/datetime fields, sorted],
          'source_fields':    [acquisition-channel fields, sorted],
          'pairs':            [{brand, optin_field, timestamp_field}, ...],
          'all_fields':       {name: {type, objects}},
        }
    Pairing matches an opt-in field to a timestamp field by shared brand key.
    """
    found: dict[str, dict] = {}
    for obj in sobjects:
        d = describe(client, obj)
        if not d:
            continue
        for f in d.get("fields", []):
            name = f.get("name", "")
            if not name.endswith("__c") or not _is_consent_name(name):
                continue
            rec = found.setdefault(name, {"type": f.get("type", ""), "objects": set()})
            rec["objects"].add(obj)

    optin_fields, timestamp_fields, source_fields = [], [], []
    for name, rec in found.items():
        low = name.lower()
        if rec["type"] in ("datetime", "date"):
            timestamp_fields.append(name)
        elif any(k in low for k in _SOURCE_KEYWORDS):
            source_fields.append(name)
        elif rec["type"] == "boolean":
            optin_fields.append(name)

    ts_by_brand: dict[str, str] = {}
    for t in timestamp_fields:
        ts_by_brand.setdefault(_brand_key(t), t)

    pairs = []
    for o in sorted(optin_fields):
        bk = _brand_key(o)
        pairs.append({
            "brand":           bk or o,
            "optin_field":     o,
            "timestamp_field": ts_by_brand.get(bk, ""),
        })

    return {
        "optin_fields":     sorted(optin_fields),
        "timestamp_fields": sorted(timestamp_fields),
        "source_fields":    sorted(source_fields),
        "pairs":            pairs,
        "all_fields":       {n: {"type": r["type"], "objects": sorted(r["objects"])}
                             for n, r in found.items()},
    }


def resolve_consent_fields(
    client: SalesforceClient | None = None,
) -> tuple[list[str], list[str], list[str]]:
    """
    Return (brands, optin_fields, timestamp_fields), index-aligned.

    Precedence:
      1. OPTIN_FIELDS pinned in .env  → trust the operator's config
      2. describe discovery (when a client is available and fields are found)
      3. brand-derived defaults from CONSENT_BRANDS

    This lets a new org work with zero hand-tuning while still honouring an
    explicit .env override when the instance uses non-standard names.
    """
    if OPTIN_FIELDS_EXPLICIT or client is None:
        return CONSENT_BRANDS, OPTIN_FIELDS, OPTIN_TIMESTAMP_FIELDS

    try:
        disc = discover_consent_fields(client)
    except Exception as e:
        logger.warning(f"Consent-field discovery failed: {e}; using defaults")
        return CONSENT_BRANDS, OPTIN_FIELDS, OPTIN_TIMESTAMP_FIELDS

    if disc["pairs"]:
        brands = [p["brand"]           for p in disc["pairs"]]
        optin  = [p["optin_field"]     for p in disc["pairs"]]
        ts     = [p["timestamp_field"] for p in disc["pairs"]]
        logger.info(f"Discovered {len(optin)} consent field(s) via describe: {', '.join(optin)}")
        return brands, optin, ts

    logger.info("No consent fields discovered; using brand-derived defaults")
    return CONSENT_BRANDS, OPTIN_FIELDS, OPTIN_TIMESTAMP_FIELDS
