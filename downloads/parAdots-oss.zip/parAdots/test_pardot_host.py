"""
Pardot Host Guard
==================
Prod orgs live on pi.pardot.com, demo/training orgs on pi.demo.pardot.com.
The host comes from PARDOT_HOME in configs/{org}.env — never from a literal.

- No Python/viewer code hardcodes the prod host (only utils.DEFAULT_PARDOT_HOME)
- load_org_config() switches utils + pardot_api to the org's host
- PARDOT_API_BASE and PARDOT_HOME can't drift onto different hosts
"""

import os
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

import pytest

import pardot_api
import utils

BASE = Path(__file__).parent
DEMO_HOME = "https://pi.demo.pardot.com"

# A quoted literal (incl. f-strings / JS template strings) starting with the
# prod host. Comments and docstrings mentioning it in prose are fine.
_LITERAL = re.compile(r"""["'`](https?://)?pi\.pardot\.com""")
_ALLOWED = {
    ("utils.py",    'DEFAULT_PARDOT_HOME = "https://pi.pardot.com"'),
    ("viewer.html", "const DEFAULT_PARDOT_HOME = 'https://pi.pardot.com';"),
}


def _code_files():
    yield from sorted(p for p in BASE.glob("*.py") if not p.name.startswith("test_"))
    yield BASE / "viewer.html"


def test_no_hardcoded_pardot_host():
    hits = []
    for path in _code_files():
        for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if _LITERAL.search(line) and (path.name, line.strip()) not in _ALLOWED:
                hits.append(f"{path.name}:{n}: {line.strip()}")
    assert not hits, "Hardcoded Pardot host — use utils.PARDOT_HOME / pardot_url():\n" + "\n".join(hits)


@pytest.fixture
def demo_org(tmp_path, monkeypatch):
    """A throwaway configs/_hosttest.env pointing at the demo host."""
    cfg = BASE / "configs" / "_hosttest.env"
    cfg.write_text(f"SF_LOGIN_URL=https://demo.my.salesforce.com/\nPARDOT_HOME={DEMO_HOME}\n"
                   "PARDOT_BUSINESS_UNIT_ID=0UvDEMO\n")
    for var in ("PARDOT_HOME", "PARDOT_API_BASE", "SF_LOGIN_URL", "PARDOT_BUSINESS_UNIT_ID"):
        monkeypatch.delenv(var, raising=False)
    try:
        yield utils.load_org_config("_hosttest")
    finally:
        cfg.unlink()
        out = BASE / "output" / "_hosttest"
        if out.exists() and not any(out.iterdir()):
            out.rmdir()
        for var in ("PARDOT_HOME", "PARDOT_API_BASE", "SF_LOGIN_URL", "PARDOT_BUSINESS_UNIT_ID"):
            os.environ.pop(var, None)
        utils.PARDOT_HOME = utils.DEFAULT_PARDOT_HOME
        pardot_api.refresh_config()


def test_load_org_config_switches_host(demo_org):
    assert utils.PARDOT_HOME == DEMO_HOME
    assert utils.pardot_url("/form/read/id/5") == DEMO_HOME + "/form/read/id/5"
    # pardot_api was imported before load_org_config() — it must still follow
    assert pardot_api.PARDOT_API_BASE == DEMO_HOME + "/api/v5"
    assert pardot_api.PARDOT_BU_ID == "0UvDEMO"
    assert pardot_api.SF_HOST == "demo.my.salesforce.com"


def test_api_base_and_app_host_match(demo_org):
    assert urlparse(pardot_api.PARDOT_API_BASE).netloc == urlparse(utils.PARDOT_HOME).netloc


def test_is_pardot_url_respects_active_host(demo_org):
    assert utils.is_pardot_url("https://pi.demo.pardot.com/form/forms", "/form")
    assert not utils.is_pardot_url("https://pi.pardot.com/form/forms")
    assert not utils.is_pardot_url("https://x.my.salesforce.com/?startURL=pi.demo.pardot.com")


def test_empty_pardot_home_falls_back_to_prod(monkeypatch):
    # The viewer's credential form writes "PARDOT_HOME=" when left blank
    monkeypatch.setenv("PARDOT_HOME", "")
    monkeypatch.delenv("PARDOT_API_BASE", raising=False)
    try:
        pardot_api.refresh_config()
        assert pardot_api.PARDOT_API_BASE == "https://pi.pardot.com/api/v5"
    finally:
        monkeypatch.undo()
        pardot_api.refresh_config()
