"""
Shared utilities for all Pardot scrapers.
"""

import csv
import getpass
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse
from dotenv import load_dotenv

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))

load_dotenv(dotenv_path=os.path.join(_BASE_DIR, ".env"))

SF_LOGIN_URL       = os.getenv("SF_LOGIN_URL", "https://login.salesforce.com/")
SF_USERNAME        = os.getenv("SF_USERNAME", "")
DEFAULT_PARDOT_HOME = "https://pi.pardot.com"
# Pardot app host — prod orgs use the default, demo/training orgs set
# PARDOT_HOME=https://pi.demo.pardot.com in their configs/{org}.env.
# Read it at runtime (utils.PARDOT_HOME / pardot_url()), never copy it into
# a module-level constant: load_org_config() refreshes it per org.
PARDOT_HOME        = (os.getenv("PARDOT_HOME") or DEFAULT_PARDOT_HOME).rstrip("/")

# ── Org / output-dir config ───────────────────────────────────────────────────

ACTIVE_ORG = ""   # set by load_org_config()
OUTPUT_DIR = ""   # set by load_org_config()


def _org_from_argv() -> Optional[str]:
    """
    `--org NAME` / `--org=NAME` from the command line, if present. Lets every
    standalone scraper honour --org without its own argparse — before this,
    scrapers that call load_org_config() with no argument silently ignored
    --org and used .active-org. Unknown args are left alone.
    """
    import argparse
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--org")
    args, _ = parser.parse_known_args(sys.argv[1:])
    return (args.org or "").strip() or None


def load_org_config(org_name: Optional[str] = None) -> str:
    """
    Load org-specific credentials and configure OUTPUT_DIR.

    Priority order:
      1. org_name argument  (e.g. from a script's own --org flag)
      2. --org on sys.argv  (any standalone scraper, no argparse needed)
      3. .active-org file   (persistent default written by set_org.py)
      4. root .env only     (OUTPUT_DIR = output/default)

    Sets os.environ AND refreshes this module's constants so any module
    imported *after* this call sees the correct values.

    Returns the resolved org name.
    """
    global ACTIVE_ORG, OUTPUT_DIR, SF_LOGIN_URL, SF_USERNAME, PARDOT_HOME

    if org_name is None:
        org_name = _org_from_argv()

    if org_name is None:
        active_file = os.path.join(_BASE_DIR, ".active-org")
        if os.path.exists(active_file):
            with open(active_file) as f:
                org_name = f.read().strip() or None

    if org_name:
        config_path = os.path.join(_BASE_DIR, "configs", f"{org_name}.env")
        if not os.path.exists(config_path):
            print(f"❌  Org config not found: configs/{org_name}.env")
            print(f"    Available orgs: {', '.join(_list_orgs())}")
            print(f"    Create one or run: python3 set_org.py --list")
            sys.exit(1)
        load_dotenv(dotenv_path=config_path, override=True)
        ACTIVE_ORG = org_name
    else:
        ACTIVE_ORG = "default"

    # Refresh module-level constants from the (now updated) environment
    SF_LOGIN_URL   = os.getenv("SF_LOGIN_URL", "https://login.salesforce.com/")
    SF_USERNAME    = os.getenv("SF_USERNAME", "")
    PARDOT_HOME    = (os.getenv("PARDOT_HOME") or DEFAULT_PARDOT_HOME).rstrip("/")

    # pardot_api binds its config at import; a standalone scraper imports it
    # before calling load_org_config(), so push the active org's values in.
    for mod in ("pardot_api", "salesforce_api"):
        if mod in sys.modules:
            sys.modules[mod].refresh_config()

    sf_host = urlparse(SF_LOGIN_URL).netloc or SF_LOGIN_URL or "—"
    print(f"🌐 Org: {ACTIVE_ORG}  ·  SF: {sf_host}  ·  Pardot: {urlparse(PARDOT_HOME).netloc}")

    OUTPUT_DIR = os.path.join(_BASE_DIR, "output", ACTIVE_ORG)
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    return ACTIVE_ORG


def pardot_url(path: str = "") -> str:
    """Absolute URL on the active org's Pardot host, e.g. pardot_url("/form/read/id/5")."""
    if path and not path.startswith("/"):
        path = "/" + path
    return PARDOT_HOME + path


def is_pardot_url(url: str, path: str = "") -> bool:
    """True if url is on the active org's Pardot host (and under path, if given)."""
    parsed = urlparse(url or "")
    if parsed.netloc.lower() != urlparse(PARDOT_HOME).netloc.lower():
        return False
    return parsed.path.lower().startswith(path.lower()) if path else True


def select_view_and_wait(page, view_select, value, timeout=15000) -> bool:
    """
    Pick a Pardot list-view <select> option and wait until the table is
    actually re-rendered. Pardot swaps the whole <table> via Ajax ~0.3–1 s
    after the change event; networkidle can return before that, so reading
    right away returns the PREVIOUS view's rows (e.g. a persisted "Dynamic
    Lists" view read as "All Current Lists"). Returns False if no fresh table
    showed up in time — callers must treat that pass as unverified.
    """
    try:
        if view_select.eval_on_selector("option:checked", "o => o.value") == value:
            return True          # already on this view — no change event, no reload
    except Exception:
        pass
    page.evaluate("() => document.querySelectorAll('table').forEach(t => t.dataset.pdStale = '1')")
    view_select.select_option(value=value)
    try:
        page.wait_for_function(
            "() => Array.from(document.querySelectorAll('table')).some(t => !t.dataset.pdStale)",
            timeout=timeout,
        )
    except Exception:
        return False
    try:
        page.wait_for_load_state("networkidle", timeout=5000)
    except Exception:
        pass
    return True


def output_path(*parts: str) -> str:
    """
    Return an absolute path under OUTPUT_DIR, creating parent dirs as needed.

    Usage:
        output_path("pardot_forms.json")
        output_path("screenshots", "forms")
    """
    if not OUTPUT_DIR:
        raise RuntimeError(
            "Call utils.load_org_config() before using output_path(). "
            "Add it to your script's main() or run_all.py."
        )
    path = os.path.join(OUTPUT_DIR, *parts)
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    return path


def _list_orgs() -> list[str]:
    """Return names of available org configs (without the .env extension)."""
    configs_dir = os.path.join(_BASE_DIR, "configs")
    if not os.path.isdir(configs_dir):
        return []
    return sorted(
        f[:-4] for f in os.listdir(configs_dir)
        if f.endswith(".env") and not f.startswith(".")
    )

_sf_password = None  # populated once at runtime via prompt


def get_password() -> str:
    """Prompt for the Salesforce password once per process; return cached value."""
    global _sf_password
    if not _sf_password:
        _sf_password = getpass.getpass(f"🔑 Salesforce password for {SF_USERNAME}: ")
    return _sf_password


def get_sf_access_token() -> tuple:
    """
    Obtain a Salesforce access token via JWT bearer flow.

    Requires in .env:
        SF_CLIENT_ID          – Connected App consumer key
        SF_PRIVATE_KEY_FILE   – path to PEM private key file, OR
        SF_PRIVATE_KEY        – PEM private key as a string (\\n-escaped)

    Returns (access_token, instance_url) or (None, None) on failure.
    """
    import requests
    import time as _time

    client_id        = os.getenv("SF_CLIENT_ID", "")
    private_key_file = os.getenv("SF_PRIVATE_KEY_FILE", "")
    private_key_str  = os.getenv("SF_PRIVATE_KEY", "")

    if not client_id:
        print("⚠️  SF_CLIENT_ID not set — skipping API token (will use browser only)")
        return None, None

    if not private_key_file and not private_key_str:
        print("⚠️  No SF_PRIVATE_KEY_FILE or SF_PRIVATE_KEY — skipping API token (will use browser only)")
        return None, None

    try:
        import jwt as _jwt
    except ImportError:
        print("⚠️  PyJWT not installed (pip install PyJWT cryptography) — skipping API token")
        return None, None

    if private_key_file:
        key_path = os.path.join(_BASE_DIR, private_key_file) if not os.path.isabs(private_key_file) else private_key_file
        with open(key_path) as f:
            private_key = f.read()
    else:
        private_key = private_key_str.replace("\\n", "\n")

    now = int(_time.time())
    payload = {
        "iss": client_id,
        "sub": SF_USERNAME,
        "aud": SF_LOGIN_URL.rstrip("/"),
        "exp": now + 300,
    }

    try:
        assertion = _jwt.encode(payload, private_key, algorithm="RS256")
    except Exception as e:
        print(f"⚠️  JWT signing failed: {e}")
        return None, None

    token_url = SF_LOGIN_URL.rstrip("/") + "/services/oauth2/token"
    try:
        resp = requests.post(token_url, data={
            "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
            "assertion":  assertion,
        }, timeout=30)
    except Exception as e:
        print(f"⚠️  JWT token request network error: {e}")
        return None, None

    if resp.status_code != 200:
        print(f"⚠️  JWT token request failed ({resp.status_code}): {resp.text[:200]}")
        return None, None

    data = resp.json()
    return data.get("access_token"), data.get("instance_url")

_SF_SESSION_SELECTORS = [
    ".slds-global-header", "#brandBand", "one-app-nav-bar",
    "a[title='App Launcher']", ".appLauncher", "one-app-launcher-header",
]
_MFA_KEYWORDS = ("login", "identity", "verification", "challenge", "mfa", "two-factor")


def _clear_orphaned_profile_lock(profile_dir):
    """
    Kill any Chrome process still holding this project's profile dir and
    remove Chrome's Singleton* files.

    If a previous run's Python process was killed forcefully (Ctrl+C twice,
    IDE stop button, terminal closed) rather than exiting normally, the
    `finally: context.close()` in each script's main() never runs and Chrome
    is left running, holding SingletonLock. The next launch then aborts with
    "Failed to create a ProcessSingleton ... File exists". Safe to clear here
    because profile_dir is always this project's own dedicated profile, never
    the user's real day-to-day Chrome.
    """
    lock_path = os.path.join(profile_dir, "SingletonLock")
    if not os.path.islink(lock_path) and not os.path.exists(lock_path):
        return

    try:
        pids = subprocess.check_output(
            ["pgrep", "-f", f"user-data-dir={profile_dir}"], text=True
        ).split()
    except subprocess.CalledProcessError:
        pids = []

    for pid in pids:
        try:
            os.kill(int(pid), 9)
        except (ProcessLookupError, PermissionError):
            pass

    for name in ("SingletonLock", "SingletonCookie", "SingletonSocket"):
        try:
            os.remove(os.path.join(profile_dir, name))
        except FileNotFoundError:
            pass


def launch_context(pw, **kwargs):
    """
    Launch a Playwright-managed, per-org persistent Chrome profile.

    Uses launch_persistent_context() rather than launch()+new_context():
    the latter opens Chromium's own initial default window in addition to
    the window Playwright creates for the new context, which shows up as
    two browser windows opening in quick succession even though only one
    ends up under Playwright's control. A persistent context is the only
    context from the start, so no stray window is created.

    The profile directory (cookies, localStorage, IndexedDB, etc.) lives
    under configs/{org}_chrome_profile/ and persists across runs, so a
    session that already passed MFA stays logged in on the next run.

    Uses channel="chrome" (the real, installed Google Chrome) rather than
    Playwright's bundled "Chrome for Testing" build. Background (DEVLOG
    2026-08-11): Chrome-for-Testing's Info.plist has no
    NSBluetoothAlwaysUsageDescription, and macOS 26's TCC framework SIGKILLs
    the process outright the moment anything touches a Bluetooth API — this
    is an OS-level probe Chrome makes on startup regardless of the
    WebBluetooth *web* feature flag we disable below, so that flag alone
    doesn't prevent it. An earlier fix patched Chrome-for-Testing's
    Info.plist + re-signed it ad-hoc before every launch, but that patch
    silently failed to take effect on at least one real run (still
    crashed). Real, Google-signed Chrome already declares the Bluetooth
    usage description properly, so it doesn't hit this crash at all —
    no plist patching needed. This is a different Chrome installation
    from whatever profile you browse in day to day; --user-data-dir below
    always points at this project's own profile_dir, never your real one.
    """
    org_slug = ACTIVE_ORG or "default"
    profile_dir = os.path.join(_BASE_DIR, "configs", f"{org_slug}_chrome_profile")
    os.makedirs(profile_dir, exist_ok=True)

    # Legacy per-org storage_state.json from the older cookie-only approach —
    # imported once into the persistent profile below, then left alone.
    legacy_state_path = os.path.join(_BASE_DIR, "configs", f"{org_slug}.storage_state.json")

    launch_kwargs = {
        "headless": False,
        "channel": "chrome",
        "args": [
            "--disable-features=WebBluetooth",
            "--no-first-run",
            "--no-default-browser-check",
        ],
    }
    launch_kwargs.update(kwargs)
    is_fresh_profile = not os.listdir(profile_dir)

    _clear_orphaned_profile_lock(profile_dir)

    ctx = pw.chromium.launch_persistent_context(profile_dir, **launch_kwargs)

    if is_fresh_profile and os.path.exists(legacy_state_path):
        try:
            with open(legacy_state_path) as f:
                legacy_state = json.load(f)
            if legacy_state.get("cookies"):
                ctx.add_cookies(legacy_state["cookies"])
        except Exception:
            pass

    original_close = ctx.close
    def _close():
        try:
            original_close()
        except Exception:
            pass
    ctx.close = _close
    return ctx


def validate_credentials():
    if not SF_USERNAME:
        print("❌ Missing SF_USERNAME in .env")
        sys.exit(1)


def _click_salesforce_login_if_prompted(page):
    for selector in [
        "a:has-text('Log in with Salesforce')",
        "button:has-text('Log in with Salesforce')",
        "a:has-text('Login with Salesforce')",
        "button:has-text('Login with Salesforce')",
        "[data-id='sfdc'] a",
        "a[href*='salesforce'][href*='login']",
    ]:
        try:
            el = page.query_selector(selector)
            if el and el.is_visible():
                print("   🔗 Pardot login prompt — clicking 'Log in with Salesforce'...")
                before_url = page.url
                el.click()
                try:
                    page.wait_for_function(
                        f"() => window.location.href !== {repr(before_url)}",
                        timeout=15000,
                    )
                except Exception:
                    pass
                try:
                    page.wait_for_load_state("domcontentloaded", timeout=10000)
                except Exception:
                    pass
                return
        except Exception:
            continue


def _sf_authenticated(page):
    """Return True only when Salesforce UI elements confirm a live session."""
    for s in _SF_SESSION_SELECTORS:
        try:
            if page.query_selector(s):
                return True
        except Exception:
            pass
    return False

PARDOT_DASHBOARD_SELECTORS = [
    "nav",
    "#navigation",
    ".nav-item",
    "a[href*='/content']",
    "a[href*='/automation']",
    "a[href*='/email']",
    "a[href*='/landingPage']",
    "a[href*='/form']",
    "a[href*='/list']",
]


def pardot_dashboard_ready(page):
    """Return True when the Pardot UI appears loaded enough to start scraping."""
    try:
        if page.query_selector(", ".join(PARDOT_DASHBOARD_SELECTORS)):
            return True
    except Exception:
        pass

    try:
        title = page.title().lower()
        if "pardot" in title and "login" not in title:
            return True
    except Exception:
        pass

    try:
        body_text = page.evaluate("() => document.body?.innerText || ''").lower()
        if "pardot" in body_text and "login" not in body_text:
            return True
    except Exception:
        pass

    return False


def login(page):
    """Log into Salesforce first, wait for full page load + MFA, then navigate to Pardot."""
    print(f"🔐 Navigating to Salesforce ({SF_LOGIN_URL})...")
    page.goto(SF_LOGIN_URL, wait_until="domcontentloaded", timeout=30000)
    page.wait_for_timeout(3000)

    # Pre-fill username if the login form is present
    try:
        page.fill("#username", SF_USERNAME)
    except Exception:
        pass

    print("   Waiting for Salesforce login, verification code, and MFA (up to 3 min)...")
    for _ in range(90):
        page.wait_for_timeout(2000)
        url = page.url.lower()
        # Already landed on Pardot
        if is_pardot_url(url) and "login" not in url:
            print("   ✅ Already on Pardot")
            return
        # On Salesforce/Lightning and past all auth/MFA screens — require actual UI to be rendered.
        # After MFA the browser lands on *.lightning.force.com, not salesforce.com.
        _SF_HOSTS = ("salesforce.com", "force.com")
        if any(h in url for h in _SF_HOSTS) and not any(k in url for k in _MFA_KEYWORDS) and "login" not in url:
            if _sf_authenticated(page):
                print("   ✅ Salesforce authenticated")
                break
    else:
        print("⚠️  Timed out waiting for Salesforce — proceeding anyway.")

    print("   Navigating to Pardot...")
    navigate(page, PARDOT_HOME, timeout=30000)
    page.wait_for_timeout(3000)
    _click_salesforce_login_if_prompted(page)

    print("   Waiting for Pardot dashboard to fully load...")
    for _ in range(30):
        page.wait_for_timeout(2000)
        url = page.url.lower()
        if is_pardot_url(url) and "login" not in url:
            try:
                page.wait_for_load_state("networkidle", timeout=5000)
            except Exception:
                pass
            if pardot_dashboard_ready(page):
                break
    else:
        print("⚠️  Timed out waiting for Pardot dashboard — proceeding anyway.")

    print("   ✅ Logged in\n")


def navigate(page, url, timeout=15000):
    """Navigate with networkidle fallback to domcontentloaded."""
    try:
        page.goto(url, wait_until="networkidle", timeout=timeout)
    except Exception:
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=timeout)
        except Exception:
            pass


# ── Prospect-section filter ────────────────────────────────────────────────────
#
# Pardot's form / handler / email / landing-page / automation / asset read
# pages all show a "Prospects" table at the bottom (and sometimes a "Usages"
# section beneath it) — paginated, view-filterable, with per-prospect rows.
# We never want that bleeding into the extracted output of any scraper:
#   • It's PII / prospect-level data that has no business in a settings dump.
#   • The pagination/filter chrome (View:, Date Range:, Filter:, Tools, Page X
#     of Y, Showing N) clutters CSV fields that should be clean.
#   • Per the project rule: total prospect count may be useful eventually,
#     but no other prospect detail belongs in this analyzer's output.
#
# truncate_at_prospects() takes either a list of lines or a single text blob
# and returns the same shape, cut at the first prospect-section heading.

PROSPECT_SECTION_MARKERS = ("prospects", "usages")


def truncate_at_prospects(text_or_lines):
    """
    Cut a page-text blob (or list of stripped lines) at the first
    "Prospects" or "Usages" heading, returning the same shape.

    Accepts:
        - str  → returns str (joined by \\n)
        - list → returns list

    Matching is case-insensitive, exact, and also catches forms like
    "Prospects (123)" with a trailing count.
    """
    if isinstance(text_or_lines, str):
        truncated = truncate_at_prospects(text_or_lines.splitlines())
        return "\n".join(truncated)

    out = []
    for raw in text_or_lines:
        ll = raw.strip().lower()
        if ll in PROSPECT_SECTION_MARKERS:
            break
        # Also catch e.g. "prospects (123)" with a count suffix
        if any(ll.startswith(marker + " (") for marker in PROSPECT_SECTION_MARKERS):
            break
        out.append(raw)
    return out


class UnexpectedUILanguageError(RuntimeError):
    """
    Raised when a scraped page's UI text doesn't look English.

    Background (2026-07-02, globex): several scrapers extract data by
    matching hardcoded English headings/labels in `document.body.innerText`
    (e.g. "Dynamic List Rules", "Total Prospects", "Completion Actions").
    When a tenant's Salesforce user language is set to something else
    (confirmed: German, on pages served through the Lightning "Account
    Engagement" wrapper rather than classic pi.pardot.com chrome), those
    matches silently fail — producing empty fields or, worse, misclassified
    data (dynamic lists written out as static) — with no error at all.

    Guessing translations for every possible tenant language is a losing
    game and risks new silent-wrong-match bugs. Instead: detect early that
    the UI isn't English and stop the whole scrape run with a clear,
    actionable message, rather than continuing to produce data that looks
    complete but silently isn't.
    """
    pass


# Chrome/label text that should be present on ANY successfully loaded
# Pardot/Salesforce record detail page, in English, regardless of which
# object (list, form handler, field, ...) is being viewed or what state
# that specific record is in. Deliberately generic + always-present rather
# than conditional (e.g. NOT "Dynamic List Rules", which only appears on
# dynamic lists) so this doesn't false-positive on legitimately different
# record states.
#
# "created"/"updated" (bare, no "at"/"by") are needed alongside the longer
# forms: Custom Redirect detail pages label these fields "Created"/"Updated"
# rather than "Created At"/"Updated At" (confirmed live, Acme, 2026-09-10,
# while adding the language guard to scrape_custom_redirects.py — that
# scraper had never had this guard before, so the label-format difference
# had gone unnoticed). Keep the longer forms too, since they're more
# specific and other object types do use them.
ENGLISH_UI_MARKERS = ("created at", "updated at", "updated by", "created", "updated")


def assert_english_ui(lines: list, page_description: str = "this page", fix_hint: str = "") -> None:
    """
    Raise UnexpectedUILanguageError if none of ENGLISH_UI_MARKERS appear in
    `lines` (already-split, stripped page text lines — see get_page_text /
    innerText). Call this ONCE near the start of a scrape run (first detail
    page visited), not per item — if the language is wrong, it's wrong for
    every subsequent item too, so failing fast saves time and avoids writing
    a full CSV of silently-empty/misclassified data.

    Callers should let this exception propagate out of their per-item
    try/except blocks (don't swallow it as a generic scrape failure) so the
    whole run stops instead of limping on item-by-item.

    `fix_hint`, if given, replaces the generic "set the scraping user's
    Salesforce language/locale to English" line with a caller-specific one
    — useful when a scraper relies on matching an English-only heading with
    no bilingual fallback (e.g. extract_usage_inline()'s "Usage" heading
    search), where a silent language mismatch would be read as "0 usages"
    rather than an obvious empty field, and the generic hint alone doesn't
    make clear this is a required precondition, not a bug.
    """
    lowered = [l.strip().lower() for l in lines if l.strip()]
    if any(marker in line for line in lowered for marker in ENGLISH_UI_MARKERS):
        return  # English confirmed
    sample = " | ".join(lowered[:15])
    fix_line = fix_hint or "set the scraping user's Salesforce language/locale to English,"
    raise UnexpectedUILanguageError(
        f"\n⛔ UI LANGUAGE CHECK FAILED on {page_description}\n"
        f"   None of the expected English labels {ENGLISH_UI_MARKERS} were found.\n"
        f"   This scraper only supports an English-language Pardot/Salesforce UI —\n"
        f"   a non-English tenant silently produces empty or misclassified fields\n"
        f"   instead of an error (confirmed bug 2026-07-02: globex's German UI\n"
        f"   zeroed out dynamic-list classification and prospect counts).\n"
        f"   Fix: {fix_line}\n"
        f"   then re-run. First lines seen on the page:\n   {sample}\n"
    )


def get_page_text(page, filter_prospects: bool = True):
    """
    Return the full visible text of the current page.

    By default, the prospect-section filter is applied (see
    truncate_at_prospects). Pass filter_prospects=False to get the raw
    body text — only useful for probe/debug scripts.
    """
    try:
        text = page.evaluate("() => document.body.innerText")
    except Exception:
        return ""
    if not text:
        return ""
    return truncate_at_prospects(text) if filter_prospects else text


def screenshot(page, path):
    """Take a screenshot, creating parent directories as needed."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        page.screenshot(path=path)
    except Exception:
        pass


def reset_screenshots(directory):
    """
    Delete all .png files in *directory* and ensure the directory exists.

    Called at the start of each scraper's run() so a fresh run never carries
    stale captures from a previous run.  Subdirectories and non-.png files
    are left untouched.  Safe to call when the directory does not yet exist.
    """
    if not directory:
        return
    if os.path.isdir(directory):
        removed = 0
        for entry in os.listdir(directory):
            full = os.path.join(directory, entry)
            if os.path.isfile(full) and entry.lower().endswith(".png"):
                try:
                    os.remove(full)
                    removed += 1
                except OSError:
                    pass
        if removed:
            print(f"   🧹 Cleared {removed} previous screenshot(s) from {directory}/")
    else:
        os.makedirs(directory, exist_ok=True)


def save_json(data, filepath):
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"   ✅ JSON saved to {filepath}")


def save_csv(rows, headers, filepath):
    with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(headers)
        for row in rows:
            writer.writerow(row)
    print(f"   ✅ CSV  saved to {filepath}")


def collect_ids_from_page(page, url_pattern):
    """
    Collect (id, name) pairs by matching href links against url_pattern.
    url_pattern example: r'/automation/read/id/(\\d+)'
    Returns list of {"id": str, "name": str}.
    """
    import re
    items = []
    seen = set()
    anchors = page.query_selector_all("a[href]")
    for a in anchors:
        href = a.get_attribute("href") or ""
        m = re.search(url_pattern, href)
        if m:
            item_id = m.group(1)
            name = a.inner_text().strip()
            if item_id not in seen and name:
                seen.add(item_id)
                items.append({"id": item_id, "name": name})
    if not items:
        import re as _re
        html = page.content()
        for m in _re.finditer(url_pattern, html):
            item_id = m.group(1)
            if item_id not in seen:
                seen.add(item_id)
                items.append({"id": item_id, "name": f"Item {item_id}"})
    return items


def scroll_to_bottom(page, steps=5):
    for _ in range(steps):
        try:
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(800)
        except Exception:
            break


# Pardot list pages show 50 rows; pagination appears bottom-right.
# Call this after the first page is already loaded and collected.
# Returns how many additional items were found across all subsequent pages.
def paginate_collect(page, url_pattern, seen, max_pages=50):
    """
    Click the 'Next' button (bottom-right Pardot pagination) repeatedly,
    collecting new IDs on each page.  Stops when no Next button is found
    or no new items appear.

    Args:
        page        – Playwright page object (already on a list page)
        url_pattern – regex pattern with one capture group for the numeric ID
        seen        – set of already-collected IDs (mutated in place)
        max_pages   – safety cap on page iterations

    Returns:
        (list of newly found items, hit_max_pages flag)
    """
    import re as _re
    new_items = []
    hit_max_pages = False
    NEXT_SELECTORS = [
        "a:has-text('Next')",
        "a:has-text('›')",
        "a:has-text('»')",
        "[aria-label='Next page']",
        "[aria-label='Next']",
        ".next a",
        "a[rel='next']",
    ]

    for page_idx in range(max_pages - 1):
        # Find the Next button
        next_btn = None
        for sel in NEXT_SELECTORS:
            try:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    next_btn = btn
                    break
            except Exception:
                continue

        if not next_btn:
            break

        try:
            next_btn.click()
            try:
                page.wait_for_load_state("networkidle", timeout=8000)
            except Exception:
                page.wait_for_timeout(1000)
        except Exception:
            break

        # Collect IDs on new page
        page_items = collect_ids_from_page(page, url_pattern)
        added = 0
        for item in page_items:
            if item["id"] not in seen:
                seen.add(item["id"])
                new_items.append(item)
                added += 1

        if added == 0:
            break  # no new content — we've reached the end

        # Check if we hit max_pages (would have next_btn on next iteration but we stop)
        if page_idx + 1 >= max_pages - 1:
            hit_max_pages = True

    return new_items, hit_max_pages


# ── Usage extraction (Lists / Fields / Form Handlers / Custom Redirects) ────
#
# Pardot shows a "Usage" table on five object types' detail pages, listing
# which other automations (Engagement Studio programs, Automation Rules,
# other Lists, Form Handlers, Custom Redirects) reference this record. It's
# the only place Pardot itself exposes asset-to-asset relationships — every
# other cross-reference in this project is inferred from free text.
#
# Two different UI patterns exist, confirmed live against Acme (2026-09-10)
# using both used and unused sample records of each object type — two
# earlier assumptions about this (made without live verification) turned
# out wrong for different reasons, so don't "simplify" this without
# re-checking against a real record first:
#
#   Pattern A — Tab-based (Static Lists, Dynamic Lists):
#     a[href='#usage'] must be clicked; content then lives in #usage.
#     Empty case renders a literal placeholder ROW: "No other objects use
#     this object." — must be filtered out, not treated as a real usage.
#
#   Pattern B — Inline, conditionally rendered (Custom Fields, Form
#     Handlers, Custom Redirects): no tab, no fixed selector. A heading
#     (e.g. <h2>) with a dynamically-generated id (e.g.
#     "usage1789064844_0_h2") contains the text "Usage"; stripping the
#     "_h2" suffix from that id gives the id of the surrounding widget
#     container ("usage1789064844_0"), which holds the table, the "Show
#     rows" <select>, and the Previous/Next controls — the same widget
#     structure Pattern A uses inside its #usage tab panel, just not
#     wrapped in a tab. Empty case: the whole heading + widget is ABSENT
#     from the DOM — there is no placeholder text, unlike Pattern A.
#
# Both extract_usage_tab() and extract_usage_inline() return the same shape:
#   [{"type": str, "name": str, "url": str, "id": str|None, "status": str}]
# (the "status" key is present only when the source table has a Status
# column — Dynamic Lists' Usage table has one, Static Lists' doesn't).
# `id` is parsed from the row's link when the URL matches a recognizable
# Pardot record pattern — analyze_cross_references.py should join on this
# ID instead of fuzzy-matching names.

_USAGE_PLACEHOLDER = "no other objects use this object."

_USAGE_ROW_JS = r"""(scopeSelector) => {
    const scope = document.querySelector(scopeSelector);
    if (!scope) return [];
    const table = scope.tagName === 'TABLE' ? scope : scope.querySelector('table');
    if (!table) return [];
    const headerRow = table.querySelector('thead tr') || table.querySelector('tr');
    const headers = headerRow
        ? Array.from(headerRow.querySelectorAll('th, td')).map(h => h.innerText.trim().toLowerCase())
        : [];
    const typeCol   = headers.findIndex(h => h.includes('type') || h.includes('typ'));
    const nameCol   = headers.findIndex(h => h.includes('name'));
    const statusCol = headers.findIndex(h => h.includes('status'));
    const bodyRows  = Array.from(table.querySelectorAll('tbody tr'));
    const rows = bodyRows.length ? bodyRows : Array.from(table.querySelectorAll('tr')).slice(headerRow ? 1 : 0);

    return rows.map(row => {
        const cells = Array.from(row.querySelectorAll('td'));
        if (!cells.length) return null;
        const typeCell   = typeCol >= 0 && cells[typeCol] ? cells[typeCol] : cells[0];
        const nameCell   = nameCol >= 0 && cells[nameCol] ? cells[nameCol] : (cells[1] || cells[0]);
        const statusCell = statusCol >= 0 ? cells[statusCol] : null;
        const type   = typeCell ? typeCell.innerText.trim() : '';
        const name   = nameCell ? nameCell.innerText.trim() : '';
        const link   = nameCell ? nameCell.querySelector('a[href]') : null;
        const url    = link ? link.href : '';
        const status = statusCell ? statusCell.innerText.trim() : '';
        return (type || name) ? { type, name, url, status } : null;
    }).filter(Boolean);
}"""

# Finds the "Usage" heading (Pattern B only) and returns the id of its
# surrounding widget container — see the Pattern B note above. Returns null
# if no "Usage" heading exists on the page (the documented empty case for
# Fields/Form Handlers/Custom Redirects, not an error).
_USAGE_INLINE_CONTAINER_JS = r"""() => {
    const headings = Array.from(document.querySelectorAll('h1,h2,h3,h4,legend'))
        .filter(el => el.innerText.trim() === 'Usage');
    if (!headings.length) return null;
    const h = headings[0];

    const guess = (h.id || '').replace(/_h2$/, '');
    if (guess) {
        const el = document.getElementById(guess);
        if (el && el.querySelector('table')) return guess;
    }

    // Fallback for markup that doesn't follow the "..._h2" id convention:
    // walk up from the heading until an ancestor containing a table shows up.
    let node = h.parentElement;
    for (let i = 0; i < 6 && node; i++) {
        if (node.querySelector('table')) {
            if (!node.id) node.id = '__usage_container_probe__';
            return node.id;
        }
        node = node.parentElement;
    }
    return null;
}"""

_USAGE_ID_PATTERNS = [
    re.compile(r'/list/read/id/(\d+)'),
    re.compile(r'/formHandler/read/id/(\d+)'),
    re.compile(r'/customUrl/read/id/(\d+)'),
    re.compile(r'/prospectFieldCustom/read/id/(\d+)'),
    re.compile(r'/prospectFieldDefault/read/id/(\d+)'),
    re.compile(r'/engagementStudio/studio#/(\d+)'),
    re.compile(r'/automationRule/(?:read|edit)/id/(\d+)'),
    re.compile(r'/id/(\d+)'),  # generic fallback — keep last, least specific
]


def _usage_id_from_url(url: str):
    """Parse the Pardot record ID out of a Usage row's link, or None."""
    if not url:
        return None
    for pattern in _USAGE_ID_PATTERNS:
        m = pattern.search(url)
        if m:
            return m.group(1)
    return None


def _clean_usage_rows(raw_rows: list) -> list:
    """Shared post-processing for both patterns: drop the 'No other objects
    use this object.' placeholder row (Pattern A's empty-case marker — see
    module note above), dedupe, and parse the record ID out of each URL."""
    seen = set()
    out = []
    for r in raw_rows:
        type_ = (r.get("type") or "").strip()
        name  = (r.get("name") or "").strip()
        if type_.lower() == _USAGE_PLACEHOLDER or name.lower() == _USAGE_PLACEHOLDER:
            continue
        url = r.get("url") or ""
        key = (type_, name, url)
        if key in seen:
            continue
        seen.add(key)
        row = {"type": type_, "name": name, "url": url, "id": _usage_id_from_url(url)}
        status = (r.get("status") or "").strip()
        if status:
            row["status"] = status
        out.append(row)
    return out


# Shared "Next" selectors — same list every listing-page helper in this
# module uses (see paginate_collect above).
_NEXT_SELECTORS = [
    "a:has-text('Next')",
    "a:has-text('›')",
    "a:has-text('»')",
    "[aria-label='Next page']",
    "[aria-label='Next']",
    ".next a",
    "a[rel='next']",
]


def _paginate_usage_table(page, scope_selector: str, max_pages: int = 20) -> list:
    """
    Shared pagination core for both Usage patterns: bump the "Show rows"
    <select> to its max option, then read + click Next within
    `scope_selector` until nothing new appears or max_pages is hit.
    """
    try:
        page.wait_for_selector(f"{scope_selector} table, {scope_selector}", timeout=6000)
    except Exception:
        page.wait_for_timeout(800)

    try:
        rows_select = page.query_selector(f"{scope_selector} select")
        if rows_select:
            opts = rows_select.eval_on_selector_all("option", "els => els.map(o => o.value)")
            if opts:
                rows_select.select_option(value=opts[-1])
                page.wait_for_timeout(600)
    except Exception:
        pass

    rows = []
    seen_keys = set()
    page_num = 0
    while True:
        page_num += 1
        try:
            raw = page.evaluate(_USAGE_ROW_JS, scope_selector)
        except Exception:
            raw = []

        new_rows = 0
        for r in raw:
            key = (r.get("type", ""), r.get("name", ""), r.get("url", ""))
            if key not in seen_keys:
                seen_keys.add(key)
                rows.append(r)
                new_rows += 1

        if page_num >= max_pages:
            break

        next_btn = None
        for sel in _NEXT_SELECTORS:
            try:
                btn = page.query_selector(f"{scope_selector} {sel}")
            except Exception:
                btn = None
            if btn and btn.is_visible():
                next_btn = btn
                break

        if not next_btn or new_rows == 0:
            break
        try:
            next_btn.click()
            page.wait_for_timeout(800)
        except Exception:
            break

    return rows


def extract_usage_tab(page, max_pages: int = 20) -> list:
    """
    Pattern A — Static/Dynamic Lists. Click the Usage tab (a[href='#usage'])
    and read its (possibly paginated) table.

    Call this after navigating to the record's detail page — tab order
    relative to e.g. the Details tab doesn't matter. Returns [] on any
    failure rather than raising, so a broken Usage tab on one record
    doesn't take down the whole scrape run.
    """
    try:
        page.click("a[href='#usage']")
    except Exception as e:
        print(f"     ⚠️  Usage tab click failed: {e}")
        return []
    try:
        raw_rows = _paginate_usage_table(page, "#usage", max_pages=max_pages)
    except Exception as e:
        print(f"     ⚠️  Usage tab read failed: {e}")
        raw_rows = []
    return _clean_usage_rows(raw_rows)


def extract_usage_inline(page, max_pages: int = 20) -> list:
    """
    Pattern B — Custom Fields, Form Handlers, Custom Redirects. No tab: find
    the "Usage" heading and read its (possibly paginated) table, or return
    [] if the heading is absent (the confirmed 0-usages case for these three
    object types — not an error, see module note above).

    Call ONLY on an English-language UI (gate with assert_english_ui first)
    — the heading is matched by the exact English text "Usage".
    """
    try:
        container_id = page.evaluate(_USAGE_INLINE_CONTAINER_JS)
    except Exception:
        container_id = None
    if not container_id:
        return []
    try:
        raw_rows = _paginate_usage_table(page, f"#{container_id}", max_pages=max_pages)
    except Exception as e:
        print(f"     ⚠️  Usage section read failed: {e}")
        raw_rows = []
    return _clean_usage_rows(raw_rows)


# ── Update Mode: State Management and Helpers ─────────────────────────────────

def now_iso():
    """Return current time in ISO 8601 format with timezone."""
    return datetime.now(timezone.utc).astimezone().isoformat()


def shape_hash(headers: tuple) -> str:
    """Return a stable short hash of CSV headers tuple."""
    h = hashlib.sha256(str(headers).encode()).hexdigest()
    return h[:8]


def load_previous_output(kind: str, key: str = "id") -> dict:
    """
    Load previous output JSON file and return as dict indexed by key.

    Args:
        kind: e.g. "forms", "dynamic_content", "static_lists"
        key: field name to use as dict key (default "id")

    Returns:
        {key_value: record} or {} if file doesn't exist

    Raises:
        ValueError if any record lacks the key field
        ValueError if duplicate key values are found
    """
    if os.path.sep in kind or kind.endswith(".json"):
        raise ValueError(f"load_previous_output() expects a kind, got a path: {kind!r}")
    json_path = output_path(f"pardot_{kind}.json")
    if not os.path.exists(json_path):
        return {}

    try:
        with open(json_path, "r", encoding="utf-8") as f:
            records = json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}

    if not isinstance(records, list):
        return {}

    result = {}
    for record in records:
        if not isinstance(record, dict):
            continue
        if key not in record:
            raise ValueError(f"Record lacks required key '{key}': {record}")
        key_val = str(record[key])
        if key_val in result:
            raise ValueError(f"Duplicate key value '{key_val}' in previous output")
        result[key_val] = record

    return result


def known_ids(kind: str, key: str = "id") -> set:
    """Return set of known IDs from previous output."""
    return set(load_previous_output(kind, key).keys())


def merge_record_fields(cached: dict, fresh: dict, cached_fields: list) -> dict:
    """
    Return fresh with only cached_fields back-filled from cached where fresh has no value.

    Fresh always wins for every field NOT in cached_fields.
    Only called when a detail visit was skipped (not failed).
    """
    result = fresh.copy()
    for field in cached_fields:
        if field not in result or result[field] in ("", None, []):
            if field in cached:
                result[field] = cached[field]
    return result


def merge_records(existing: list, fresh_by_id: dict, order_key: str = "id") -> list:
    """
    Upsert fresh_by_id into existing, returning list sorted by order_key.
    Does NOT prune — pruning is a separate, guarded call.
    """
    merged_dict = {}
    for record in existing:
        if order_key in record:
            merged_dict[str(record[order_key])] = record

    for rid, record in fresh_by_id.items():
        key_val = str(record.get(order_key, rid))
        if str(rid) != key_val:
            raise ValueError(
                f"fresh_by_id key {rid!r} does not match record {order_key}={key_val!r}"
            )
        merged_dict[key_val] = record

    result = list(merged_dict.values())
    result.sort(key=lambda r: int(r.get(order_key, 0)) if str(r.get(order_key, "")).isdigit() else str(r.get(order_key, "")))
    return result


def apply_prune(
    merged: list,
    all_current_ids: set,
    *,
    sweep_verified: bool,
    record_count: int,
    max_prune_pct: int = 10,
    min_prune_floor: int = 2,
    allow_prune: bool = False
) -> tuple:
    """
    Prune records not in all_current_ids, with guards against over-pruning.

    Returns (kept_records, pruned_ids).

    Args:
        merged: list of merged records
        all_current_ids: set of IDs that currently exist in Pardot
        sweep_verified: True only if the cheap sweep passed sanity checks
        record_count: baseline record count from manifest (for %age calculation)
        max_prune_pct: maximum % of records to prune without --allow-prune
        min_prune_floor: absolute floor for prune count check (single deletes OK)
        allow_prune: override to permit larger prunes
    """
    if not sweep_verified:
        print("   ⚠️  Sweep verification failed — refusing to prune (no records will be deleted)")
        return merged, []

    to_prune = set()
    for record in merged:
        rid = str(record.get("id", ""))
        if rid and rid not in all_current_ids:
            to_prune.add(rid)

    if not to_prune:
        return merged, []

    prune_pct = 100 * len(to_prune) / max(record_count, 1)
    if len(to_prune) > min_prune_floor and prune_pct > max_prune_pct and not allow_prune:
        print(f"   ❌ Prune would remove {len(to_prune)} record(s) "
              f"({prune_pct:.1f}% > {max_prune_pct}%) — refusing without --allow-prune")
        return merged, []

    kept = [r for r in merged if str(r.get("id", "")) not in to_prune]
    return kept, list(to_prune)


def stale_ids(kind: str, all_ids: set, max_age_days: int = 7, limit: int = None) -> set:
    """
    Read freshness_{kind}.json and return IDs never recorded or older than max_age_days.
    Returns oldest first, capped at limit.
    """
    freshness_path = output_path("_state", f"freshness_{kind}.json")
    freshness = {}
    if os.path.exists(freshness_path):
        try:
            with open(freshness_path, "r", encoding="utf-8") as f:
                freshness = json.load(f)
        except (json.JSONDecodeError, IOError):
            freshness = {}

    cutoff_iso = now_iso()
    candidates = []

    for rid in all_ids:
        rid_str = str(rid)
        if rid_str not in freshness:
            candidates.append((rid_str, "never"))
        else:
            candidates.append((rid_str, freshness[rid_str]))

    candidates.sort(key=lambda x: x[1])
    stale = set()
    for rid, last_scrape in candidates:
        if limit and len(stale) >= limit:
            break
        if last_scrape == "never":
            stale.add(rid)
        else:
            try:
                last_dt = datetime.fromisoformat(last_scrape)
                cutoff_dt = datetime.fromisoformat(cutoff_iso)
                age_days = (cutoff_dt - last_dt).days
                if age_days >= max_age_days:
                    stale.add(rid)
            except ValueError:
                stale.add(rid)

    return stale


def read_manifest() -> dict:
    """Read _state/manifest.json and return the manifest dict, or {} if missing."""
    manifest_path = output_path("_state", "manifest.json")
    if not os.path.exists(manifest_path):
        return {"schema": 1, "scrapers": {}}
    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {"schema": 1, "scrapers": {}}


def manifest_entry(scraper: str) -> dict:
    """Return the manifest entry for a scraper, or {} if absent."""
    return read_manifest().get("scrapers", {}).get(scraper, {})


def write_manifest(scraper: str, *, started_at: str, shape_hash_val: str, record_count: int):
    """Write manifest entry for a scraper (called on success)."""
    manifest = read_manifest()
    manifest["scrapers"][scraper] = {
        "last_success_started_at": started_at,
        "shape_hash": shape_hash_val,
        "record_count": record_count,
    }
    manifest_path = output_path("_state", "manifest.json")
    _atomic_write(manifest, manifest_path, json.dump)


def mark_scraped(kind: str, ids: set):
    """Record successful scrapes in freshness_{kind}.json for aging sweep."""
    freshness_path = output_path("_state", f"freshness_{kind}.json")
    freshness = {}
    if os.path.exists(freshness_path):
        try:
            with open(freshness_path, "r", encoding="utf-8") as f:
                freshness = json.load(f)
        except (json.JSONDecodeError, IOError):
            freshness = {}

    now = now_iso()
    for rid in ids:
        freshness[str(rid)] = now

    _atomic_write(freshness, freshness_path, json.dump)


def _atomic_write(data, filepath: str, write_func):
    """Atomic write: write to .tmp, then os.replace(), retain one .bak."""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    tmp_path = filepath + ".tmp"
    bak_path = filepath + ".bak"

    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            if write_func == json.dump:
                json.dump(data, f, indent=2, ensure_ascii=False)
            else:
                write_func(data, f)

        if os.path.exists(filepath):
            if os.path.exists(bak_path):
                try:
                    os.remove(bak_path)
                except OSError:
                    pass
            os.replace(filepath, bak_path)

        os.replace(tmp_path, filepath)
    except Exception:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        raise


def save_json_atomic(data, filepath: str):
    """Save JSON atomically (write to .tmp, then replace, keep .bak)."""
    _atomic_write(data, filepath, json.dump)
    print(f"   ✅ JSON saved to {filepath}")


def save_csv_atomic(rows, headers, filepath: str):
    """Save CSV atomically."""
    def write_csv(data, fh):
        writer = csv.writer(fh, quoting=csv.QUOTE_ALL)
        writer.writerow(headers)
        for row in data:
            writer.writerow(row)

    _atomic_write(rows, filepath, write_csv)
    print(f"   ✅ CSV  saved to {filepath}")
