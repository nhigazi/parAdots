#!/usr/bin/env python3
"""
parAdots Icon-Generator
=======================
Erzeugt fuer JEDE im Viewer verwendete Komponente eine eigenstaendige SVG-Datei
in branding/icons/. Jede Datei enthaelt den pa-grad Gradienten inline und ist
damit ohne den Viewer-Kontext (z.B. per <img>) nutzbar.

Quelle der bestehenden Pfade: ICON_PATHS-Objekt in viewer.html (wird geparst,
damit keine Handabschrift-Fehler entstehen). Fehlende Icons werden hier im
gleichen Tabler-Linienstil ergaenzt.

Aufruf:  python branding/generate_icons.py
"""
import re
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent          # .../parAdots
VIEWER = BASE / 'viewer.html'
OUT = BASE / 'branding' / 'icons'

# ── 1. Bestehende Pfade aus viewer.html extrahieren ─────────────────────────
def extract_existing():
    html = VIEWER.read_text(encoding='utf-8')
    m = re.search(r'const ICON_PATHS\s*=\s*\{(.*?)\n\};', html, re.DOTALL)
    if not m:
        raise SystemExit('ICON_PATHS block not found in viewer.html')
    block = m.group(1)
    icons = {}
    # jeder Eintrag: 'name':[ '...','...' ],
    for entry in re.finditer(r"'([a-z0-9-]+)'\s*:\s*\[(.*?)\]", block, re.DOTALL):
        name = entry.group(1)
        paths = re.findall(r"'([^']*)'", entry.group(2))
        icons[name] = paths
    return icons

# ── 2. Fehlende Icons (Tabler-Linienstil, viewBox 24) ───────────────────────
NEW_ICONS = {
    'adjustments': [
        'M4 10a2 2 0 1 0 4 0a2 2 0 0 0 -4 0', 'M6 4v4', 'M6 12v8',
        'M10 16a2 2 0 1 0 4 0a2 2 0 0 0 -4 0', 'M12 4v10', 'M12 18v2',
        'M16 7a2 2 0 1 0 4 0a2 2 0 0 0 -4 0', 'M18 4v1', 'M18 9v11',
    ],
    'award': [
        'M12 9m-6 0a6 6 0 1 0 12 0a6 6 0 1 0 -12 0',
        'M12 15l3.4 5.89l1.598 -3.233l3.598 .232l-3.4 -5.889',
        'M6.802 12l-3.4 5.89l3.598 -.233l1.598 3.232l3.4 -5.889',
    ],
    'browser': [
        'M4 4m0 1a1 1 0 0 1 1 -1h14a1 1 0 0 1 1 1v14a1 1 0 0 1 -1 1h-14a1 1 0 0 1 -1 -1z',
        'M4 8h16', 'M8 4v4',
    ],
    'code': ['M7 8l-4 4l4 4', 'M17 8l4 4l-4 4', 'M14 4l-4 16'],
    'folder': [
        'M5 4h4l3 3h7a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2',
    ],
    'layout': [
        'M4 4m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z',
        'M4 10h16', 'M10 4v16',
    ],
    'mail-forward': [
        'M12 18h-7a2 2 0 0 1 -2 -2v-10a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v6',
        'M3 6l9 6l9 -6', 'M15 18h6', 'M18 15l3 3l-3 3',
    ],
    'photo': [
        'M15 8h.01',
        'M3 6a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v12a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3v-12z',
        'M3 16l5 -5c.928 -.893 2.072 -.893 3 0l5 5',
        'M14 14l1 -1c.928 -.893 2.072 -.893 3 0l3 3',
    ],
    'user-check': [
        'M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0',
        'M6 21v-2a4 4 0 0 1 4 -4h4', 'M15 19l2 2l4 -4',
    ],
    'users': [
        'M9 7m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0',
        'M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2',
        'M16 3.13a4 4 0 0 1 0 7.75', 'M21 21v-2a4 4 0 0 0 -3 -3.85',
    ],
    'users-group': [
        'M10 13a2 2 0 1 0 4 0a2 2 0 0 0 -4 0',
        'M8 21v-1a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v1',
        'M15 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0', 'M17 10h2a2 2 0 0 1 2 2v1',
        'M5 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0', 'M3 13v-1a2 2 0 0 1 2 -2h2',
    ],
    # ── Prozess-Tab spezifische Icons ───────────────────────────────
    'refresh': [
        'M20 11a8.1 8.1 0 0 0 -15.5 -2m-.5 -4v4h4',
        'M4 13a8.1 8.1 0 0 0 15.5 2m.5 4v-4h-4',
    ],
    'rotate': ['M4.05 11a8 8 0 1 1 .5 4m-.5 5v-5h5'],
    'file-text': [
        'M14 3v4a1 1 0 0 0 1 1h4',
        'M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z',
        'M9 9l1 0', 'M9 13l6 0', 'M9 17l6 0',
    ],
    'plus': ['M12 5l0 14', 'M5 12l14 0'],
    'trash': [
        'M4 7l16 0', 'M10 11l0 6', 'M14 11l0 6',
        'M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12',
        'M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3',
    ],
    'external-link': [
        'M12 6h-6a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-6',
        'M11 13l9 -9', 'M15 4h5v5',
    ],
    'target': [
        'M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0',
        'M12 12m-5 0a5 5 0 1 0 10 0a5 5 0 1 0 -10 0',
        'M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0',
    ],
    'sparkles': [
        'M16 18a2 2 0 0 1 2 2a2 2 0 0 1 2 -2a2 2 0 0 1 -2 -2a2 2 0 0 1 -2 2z',
        'M4 7a3 3 0 0 1 3 3a3 3 0 0 1 3 -3a3 3 0 0 1 -3 -3a3 3 0 0 1 -3 3z',
        'M14 4a1 1 0 0 1 1 1a1 1 0 0 1 1 -1a1 1 0 0 1 -1 -1a1 1 0 0 1 -1 1z',
    ],
    'user-plus': [
        'M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0',
        'M6 21v-2a4 4 0 0 1 4 -4h4', 'M16 19h6', 'M19 16v6',
    ],
    'user-minus': [
        'M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0',
        'M6 21v-2a4 4 0 0 1 4 -4h4', 'M16 19h6',
    ],
    'alert-triangle': [
        'M12 9v4',
        'M10.363 3.591l-8.106 13.534a1.914 1.914 0 0 0 1.636 2.871h16.214a1.914 1.914 0 0 0 1.636 -2.87l-8.106 -13.536a1.914 1.914 0 0 0 -3.274 0z',
        'M12 16h.01',
    ],
    'tool': [
        'M7 10h3v-3l-3.5 -3.5a6 6 0 0 1 8 8l6 6a2 2 0 0 1 -3 3l-6 -6a6 6 0 0 1 -8 -8l3.5 3.5',
    ],
}

# ── 3. SVG-Datei bauen (eigenstaendig, mit Gradient) ────────────────────────
GRAD = (
    '<defs><linearGradient id="pa-grad" gradientUnits="userSpaceOnUse" '
    'x1="2" y1="2" x2="22" y2="22">'
    '<stop offset="0" stop-color="#0e2841"/>'
    '<stop offset="1" stop-color="#17a589"/>'
    '</linearGradient></defs>'
)

def build_svg(paths):
    body = ''.join(f'<path d="{d}"/>' for d in paths)
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" '
        'fill="none" stroke="url(#pa-grad)" stroke-width="2" '
        'stroke-linecap="round" stroke-linejoin="round">'
        f'{GRAD}{body}</svg>\n'
    )

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    existing = extract_existing()
    all_icons = {**existing, **NEW_ICONS}
    for name, paths in sorted(all_icons.items()):
        (OUT / f'{name}.svg').write_text(build_svg(paths), encoding='utf-8')
    # Manifest fuer schnellen Zugriff / Doku
    manifest = {
        'count': len(all_icons),
        'from_viewer': sorted(existing.keys()),
        'added': sorted(NEW_ICONS.keys()),
        'icons': sorted(all_icons.keys()),
    }
    (OUT / 'icons.json').write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
    print(f'{len(all_icons)} Icons geschrieben nach {OUT}')
    print(f'  bestehend: {len(existing)}   neu: {len(NEW_ICONS)}')
    return all_icons

if __name__ == '__main__':
    main()
