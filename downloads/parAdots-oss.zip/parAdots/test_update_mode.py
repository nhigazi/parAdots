"""
Update Mode Test Suite
=======================
Comprehensive tests for update mode gating, merging, and state management.
- merge_records() & merge_record_fields()
- apply_prune() with deletion detection
- stale_ids() aging sweep
- shape_hash() determinism
- Failed visit handling with cached fallback
"""

import json
import os
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

import pytest

import utils

# ────────────────────────────────────────────────────────────────────────────────

class TestMergeRecords:
    """Verify merge_records() correctly combines cached and freshly scraped data."""

    def test_merge_simple_new_record(self):
        """New record not in cache is included as-is."""
        cached = []
        fresh = {"item1": {"id": "1", "name": "Item 1", "count": 10}}
        result = utils.merge_records(cached, fresh)
        assert result == [{"id": "1", "name": "Item 1", "count": 10}]

    def test_merge_overwrites_cache(self):
        """Fresh record overrides cached version (same ID)."""
        cached = [{"id": "1", "name": "Old Name", "count": 5}]
        fresh = {"item1": {"id": "1", "name": "New Name", "count": 10}}
        result = utils.merge_records(cached, fresh)
        assert len(result) == 1
        assert result[0]["name"] == "New Name"
        assert result[0]["count"] == 10

    def test_merge_keeps_uncached_fresh_records(self):
        """Records only in fresh dict are preserved."""
        cached = [{"id": "1", "name": "Item 1"}]
        fresh = {"1": {"id": "1", "name": "Item 1"}, "2": {"id": "2", "name": "Item 2"}}
        result = utils.merge_records(cached, fresh)
        ids = [r["id"] for r in result]
        assert sorted(ids) == ["1", "2"]


class TestMergeRecordFields:
    """Verify merge_record_fields() selectively caches fields."""

    def test_preserve_cached_fields(self):
        """Cached fields from old record are kept."""
        cached = {"id": "1", "name": "Item", "count": 100, "fresh_field": "old"}
        fresh = {"id": "1", "name": "Item Updated", "fresh_field": "new"}
        cached_fields = ["count"]
        result = utils.merge_record_fields(cached, fresh, cached_fields)
        assert result["count"] == 100  # from cache
        assert result["fresh_field"] == "new"  # from fresh

    def test_empty_cached_fields_uses_fresh(self):
        """When no fields are designated cached, fresh wins."""
        cached = {"id": "1", "count": 999}
        fresh = {"id": "1", "count": 10}
        result = utils.merge_record_fields(cached, fresh, [])
        assert result["count"] == 10


class TestApplyPrune:
    """Verify apply_prune() safely removes deleted records."""

    def test_prune_deleted_records(self):
        """Records not in current_ids are removed."""
        merged = [
            {"id": "1", "name": "Item 1"},
            {"id": "2", "name": "Item 2"},
            {"id": "3", "name": "Item 3"},
        ]
        current_ids = {"1", "3"}  # "2" is deleted
        result, pruned = utils.apply_prune(merged, current_ids, sweep_verified=True, record_count=3)
        ids = [r["id"] for r in result]
        assert sorted(ids) == ["1", "3"]
        assert pruned == 1

    def test_prune_safety_limit(self):
        """Prune refuses to remove >10% (unless allow_prune=True)."""
        merged = [{"id": str(i), "name": f"Item {i}"} for i in range(1, 11)]  # 10 records
        current_ids = {"1"}  # 9 out of 10 deleted = 90%
        with pytest.raises(ValueError, match="prune.*exceed.*10%"):
            utils.apply_prune(merged, current_ids, sweep_verified=True, record_count=10, allow_prune=False)

    def test_prune_allow_override(self):
        """With allow_prune=True, can remove >10%."""
        merged = [{"id": str(i), "name": f"Item {i}"} for i in range(1, 11)]
        current_ids = {"1"}
        result, pruned = utils.apply_prune(merged, current_ids, sweep_verified=True, record_count=10, allow_prune=True)
        assert pruned == 9
        assert len(result) == 1


class TestStaleIds:
    """Verify stale_ids() correctly identifies aged records."""

    def test_stale_ids_by_age(self):
        """Records last scraped >max_age_days ago are stale."""
        now = utils.now_iso()
        old_date = (datetime.fromisoformat(now) - timedelta(days=14)).isoformat()
        recent_date = (datetime.fromisoformat(now) - timedelta(days=3)).isoformat()

        cached = {
            "1": {"id": "1", "_last_scraped_at": old_date},
            "2": {"id": "2", "_last_scraped_at": recent_date},
        }
        manifest = {
            "freshness_generic": {
                "1": old_date,
                "2": recent_date,
            }
        }
        # Mock read_manifest to return our test data
        original_read = utils.read_manifest
        utils.read_manifest = lambda: manifest

        result = utils.stale_ids(cached, max_age_days=7)
        utils.read_manifest = original_read

        assert "1" in result
        assert "2" not in result


class TestShapeHash:
    """Verify shape_hash() produces consistent hashes."""

    def test_shape_hash_deterministic(self):
        """Same field list produces same hash."""
        fields1 = ["id", "name", "count"]
        fields2 = ["id", "name", "count"]
        assert utils.shape_hash(fields1) == utils.shape_hash(fields2)

    def test_shape_hash_order_matters(self):
        """Different order produces different hash."""
        fields1 = ["id", "name", "count"]
        fields2 = ["name", "id", "count"]
        assert utils.shape_hash(fields1) != utils.shape_hash(fields2)

    def test_shape_hash_empty(self):
        """Empty field list produces a hash (not an error)."""
        hash_val = utils.shape_hash([])
        assert isinstance(hash_val, str)
        assert len(hash_val) > 0


class TestKnownIds:
    """Verify known_ids() extracts IDs from records."""

    def test_known_ids_extraction(self):
        """Extract 'id' field from all records."""
        records = [
            {"id": "1", "name": "Item 1"},
            {"id": "2", "name": "Item 2"},
            {"id": "3", "name": "Item 3"},
        ]
        result = utils.known_ids(records)
        assert sorted(result) == ["1", "2", "3"]

    def test_known_ids_missing_id(self):
        """Records without 'id' field are skipped."""
        records = [
            {"id": "1", "name": "Item 1"},
            {"name": "Item 2"},  # missing id
            {"id": "3", "name": "Item 3"},
        ]
        result = utils.known_ids(records)
        assert sorted(result) == ["1", "3"]


class TestLoadPreviousOutput:
    """Verify load_previous_output() correctly reads cached JSON."""

    def test_load_missing_file_returns_empty_dict(self):
        """If file doesn't exist, return empty dict."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "nonexistent.json")
            original_output_path = utils.output_path

            def mock_output_path(name):
                return path

            utils.output_path = mock_output_path
            result = utils.load_previous_output(path)
            utils.output_path = original_output_path

            assert result == {}

    def test_load_valid_json(self):
        """Load and index valid JSON file by ID."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.json")
            data = [{"id": "1", "name": "Item 1"}, {"id": "2", "name": "Item 2"}]
            with open(path, "w") as f:
                json.dump(data, f)

            result = utils.load_previous_output(path)
            assert "1" in result
            assert result["1"]["name"] == "Item 1"


class TestFailedVisitHandling:
    """Verify gating behavior when detail-page scrape fails."""

    def test_failed_visit_keeps_cached(self):
        """If scraper fails to fetch detail, merge uses cached record."""
        cached = {"id": "1", "name": "Item", "details": "cached_data"}
        fresh_api = {"id": "1", "name": "Item"}
        cached_fields = ["details"]

        result = utils.merge_record_fields(cached, fresh_api, cached_fields)
        assert result["details"] == "cached_data"

    def test_no_cache_fallback_partial_record(self):
        """Without cache, partial record from API is better than empty."""
        api_record = {"id": "1", "name": "Item"}
        result = utils.merge_record_fields({}, api_record, [])
        assert result["id"] == "1"
        assert result["name"] == "Item"


class TestManifestStateManagement:
    """Verify manifest and freshness tracking."""

    def test_write_and_read_manifest(self):
        """Write manifest, then read it back."""
        with tempfile.TemporaryDirectory() as tmpdir:
            state_dir = os.path.join(tmpdir, "_state")
            os.makedirs(state_dir, exist_ok=True)

            original_state_dir = utils.STATE_DIR
            utils.STATE_DIR = state_dir

            utils.write_manifest("test_scraper", started_at="2024-01-01T10:00:00", shape_hash_val="abc123", record_count=42)
            manifest = utils.read_manifest()

            utils.STATE_DIR = original_state_dir

            assert "scrape_test_scraper" in manifest
            assert manifest["scrape_test_scraper"]["record_count"] == 42
            assert manifest["scrape_test_scraper"]["shape_hash"] == "abc123"

    def test_mark_scraped_updates_freshness(self):
        """mark_scraped() updates freshness tracking for specific IDs."""
        with tempfile.TemporaryDirectory() as tmpdir:
            state_dir = os.path.join(tmpdir, "_state")
            os.makedirs(state_dir, exist_ok=True)

            original_state_dir = utils.STATE_DIR
            utils.STATE_DIR = state_dir

            ids_to_mark = {"1", "2", "3"}
            utils.mark_scraped("test_scraper", ids_to_mark)
            manifest = utils.read_manifest()

            utils.STATE_DIR = original_state_dir

            assert "freshness_test_scraper" in manifest
            for fid in ids_to_mark:
                assert fid in manifest["freshness_test_scraper"]


class TestAtomicWrites:
    """Verify atomic write machinery (_atomic_write, save_json_atomic, save_csv_atomic)."""

    def test_atomic_write_creates_backup(self):
        """Atomic write creates .bak backup of previous file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.json")

            # Write initial file
            utils.save_json_atomic([{"id": "1", "v": 1}], path)
            assert os.path.exists(path)

            # Write new file — should create .bak
            utils.save_json_atomic([{"id": "1", "v": 2}], path)
            bak_path = path + ".bak"
            assert os.path.exists(bak_path)

            # Verify .bak contains original
            with open(bak_path) as f:
                backup_data = json.load(f)
            assert backup_data[0]["v"] == 1

    def test_atomic_write_failure_preserves_original(self):
        """If write fails, original file remains untouched."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.json")

            # Write initial file
            original = [{"id": "1", "v": 1}]
            utils.save_json_atomic(original, path)

            # Attempt to write invalid data (should not crash but verify behavior)
            try:
                with open(path, "r") as f:
                    content_before = f.read()
            except Exception:
                pass

            # Verify file still exists and has content
            assert os.path.exists(path)


# ────────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
