"""
parAdots — Run All Pardot + Salesforce Scrapers
================================================
Single login session: runs all Pardot scrapers sequentially followed by
Salesforce analysis scrapers. Generates audit reports, cross-references, and
Engagement Studio visualizations.

Pardot scrapers (1-21):
  1.  Dynamic Lists        (scraper.py)
  1b. Static Lists (Full)  (scrape_static_lists.py) — standalone, own discovery
  2.  Automation Rules     (scrape_automations.py)
  3.  Automation Status    (fetch_automation_status.py)
  4.  Forms                (scrape_forms.py)
  5.  Form Handlers        (scrape_formhandlers.py)
  6.  Dynamic Content      (scrape_dynamic_content.py)
  7.  Engagement Studio    (scrape_engagement_studio.py)
  8.  Field Settings       (scrape_fields_api.py)
  9.  Email Templates      (scrape_email_templates_api.py)
  10. Landing Pages        (scrape_landing_pages.py)
  11. Scoring Rules        (scrape_scoring_rules.py)
  12. Page Actions         (scrape_page_actions.py)
  13. Custom Redirects     (scrape_custom_redirects.py)
  14. Campaigns            (scrape_campaigns_api.py)
  15. Sent Emails          (fetch_sent_emails_api.py)
  16. Snippets             (scrape_snippets.py)
  17. Layout Templates     (scrape_layout_templates.py)
  18. Files                (scrape_files.py)
  19. List Memberships     (scrape_list_memberships.py)
  20. Prospect Stats       (scrape_prospect_stats.py)
  21. Account Settings     (scrape_account_settings.py)
  22. Preference Center    (scrape_preference_center.py)
  23. Users                (scrape_users.py)
  24. Grading Profiles     (scrape_profiles.py)
  25. List Emails          (scrape_list_emails.py)
  26. Folders              (scrape_folders.py)

Salesforce analysis scrapers (22-31):
  22. Campaign Member Attribution    (scrape_sf_campaign_members.py)
  23. Opt-In Field Sync Audit        (scrape_sf_optin_sync_audit.py)
  24. Lead Quality / Resolution      (scrape_sf_lead_quality.py)
  25. Opportunity Attribution        (scrape_sf_opportunity_attribution.py)
  26. Pardot Sync Error Log          (scrape_sf_sync_errors.py)
  27. Custom Field Mapping           (scrape_sf_field_mapping.py)
  28. Account / Corp Hierarchy       (scrape_sf_account_hierarchy.py)
  29. Task / Activity Follow-Up      (scrape_sf_task_activity.py)
  30. Report & Dashboard Inventory   (scrape_sf_reports_inventory.py)
  31. Object Storage Usage           (scrape_sf_storage_usage.py)

After all scrapers finish, three analysis/visualization scripts run automatically:
  A. Cross-Reference Analysis       (analyze_cross_references.py)
  B. Best Practice Gap Report       (analyze_best_practices.py)
  C. Engagement Studio draw.io export (generate_drawio.py)

Flags:
  --no-sf    Skip Salesforce scrapers (Pardot-only run)

Usage:
  python3 run_all.py                    # uses .active-org (set via set_org.py)
  python3 run_all.py --org globex      # one-off override, does not change .active-org
  python3 run_all.py --no-sf            # Pardot scrapers only, skip SF analysis
"""

import argparse
import inspect
import os
import sys
from playwright.sync_api import sync_playwright

import utils

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Run all Pardot scrapers. Org is read from .active-org unless --org is given."
    )
    parser.add_argument(
        "--org", metavar="NAME",
        help="Org config to use (e.g. 'globex'). Overrides .active-org for this run only.",
    )
    parser.add_argument(
        "--no-sf", action="store_true",
        help="Skip Salesforce analysis scrapers (Pardot-only run).",
    )
    parser.add_argument(
        "--update", action="store_true",
        help="Enable update mode (incremental re-scrape with gating). Skips expensive detail pages for unchanged records.",
    )
    parser.add_argument(
        "--only", metavar="NAME[,NAME]",
        help="Run only the named scraper(s) (comma-separated). Useful for debugging or selective runs.",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="With --update: perform cheap passes, print gate decisions, write nothing. Useful for testing.",
    )
    parser.add_argument(
        "--max-age-days", type=int, default=7,
        help="Max age for aging sweep in days (default 7).",
    )
    parser.add_argument(
        "--refresh-limit", type=int, default=25,
        help="Cap on detail visits per scraper per run from aging sweep (default 25).",
    )
    parser.add_argument(
        "--allow-prune", action="store_true",
        help="Allow pruning more than 10%% of records in update mode (use with caution).",
    )
    parser.add_argument(
        "--verify", action="store_true",
        help="Run a full scrape and diff against current output (reconciliation check).",
    )
    args = parser.parse_args()

    # Load org config BEFORE importing any scraper module — scrapers read env
    # vars at import time, so the correct values must be in os.environ first.
    org = utils.load_org_config(args.org)
    print(f"📁 Out : {utils.OUTPUT_DIR}")

    utils.validate_credentials()

    # Import run() from each scraper — NOT main(), which would close the browser
    from scrape_dynamic_lists      import run as run_lists,            get_access_token
    from scrape_static_lists       import run as run_static_lists
    from scrape_automations        import run as run_automations,       validate_config as validate_automations
    from fetch_automation_status   import run as run_status
    from scrape_forms              import run as run_forms
    from scrape_formhandlers_api   import run as run_formhandlers
    from scrape_dynamic_content    import run as run_dynamic_content
    from scrape_engagement_studio  import run as run_engagement_studio
    from scrape_fields_api         import run as run_fields
    from scrape_email_templates_api import run as run_email_templates
    from scrape_landing_pages      import run as run_landing_pages
    from scrape_scoring_rules      import run as run_scoring_rules
    from scrape_page_actions       import run as run_page_actions
    from scrape_custom_redirects   import run as run_custom_redirects
    from scrape_campaigns_api      import run as run_campaigns
    from fetch_sent_emails_api     import run as run_sent_emails
    from scrape_snippets           import run as run_snippets
    from scrape_layout_templates   import run as run_layout_templates
    from scrape_files              import run as run_files
    from scrape_list_memberships   import run as run_list_memberships
    from scrape_prospect_stats     import run as run_prospect_stats
    from scrape_account_settings   import run as run_account_settings
    from scrape_preference_center  import run as run_preference_center
    from scrape_users              import run as run_users
    from scrape_profiles           import run as run_profiles
    from scrape_list_emails        import run as run_list_emails
    from scrape_folders            import run as run_folders

    # ── Salesforce analysis scrapers ─────────────────────────────────────────
    import salesforce_api as sf_api
    from scrape_sf_campaign_members        import run as run_sf_campaigns
    from scrape_sf_optin_sync_audit        import run as run_sf_optin
    from scrape_sf_lead_quality            import run as run_sf_leads
    from scrape_sf_opportunity_attribution import run as run_sf_opps
    from scrape_sf_sync_errors             import run as run_sf_sync_errors
    from scrape_sf_field_mapping           import run as run_sf_fields
    from scrape_sf_account_hierarchy       import run as run_sf_accounts
    from scrape_sf_task_activity           import run as run_sf_tasks
    from scrape_sf_reports_inventory       import run as run_sf_reports
    from scrape_sf_storage_usage           import run as run_sf_storage
    from scrape_prospect_sync_errors        import run as run_prospect_sync_errors
    from resolve_prospect_sync_errors       import run as run_resolve_sync_errors

    validate_automations()

    if args.dry_run and not args.update:
        parser.error("--dry-run requires --update")

    # Scrapers that support update mode (gated scrapers — Tier A, B, C)
    GATED_SCRAPERS = {
        "scrape_static_lists",
        "scrape_preference_center",
        "scrape_forms",
        "scrape_custom_redirects",
        "scrape_dynamic_content",
        "scrape_page_actions",
    }

    sf_enabled = not args.no_sf
    mode_label = " — Update Mode" if args.update else " — Full Scrape"
    suite_name = "Pardot + Salesforce Full Suite" if sf_enabled else "Pardot Full Suite"
    print(f"\n🚀 {suite_name}{mode_label}")
    print("=" * 50)

    SCRAPERS = [
        ("Dynamic Lists",        lambda p: run_lists(p, get_access_token()[0])),
        # Standalone — no shared code with the Dynamic Lists scraper above.
        # Visits every static list's detail page (Details + Usage tab), so
        # this step is slower than most; scales with static-list count.
        ("Static Lists",         run_static_lists),
        ("Automation Rules",     run_automations),
        ("Automation Status",    run_status),
        ("Forms",                run_forms),
        ("Form Handlers",        run_formhandlers),
        ("Dynamic Content",      run_dynamic_content),
        ("Engagement Studio",    run_engagement_studio),
        ("Field Settings",       run_fields),
        ("Email Templates",      run_email_templates),
        ("Landing Pages",        run_landing_pages),
        ("Scoring Rules",        run_scoring_rules),
        ("Page Actions",         run_page_actions),
        ("Custom Redirects",     run_custom_redirects),
        ("Campaigns",            run_campaigns),
        ("Sent Emails",          run_sent_emails),
        # ── New asset scrapers ──────────────────────────────────────────────
        ("Snippets",             run_snippets),
        ("Layout Templates",     run_layout_templates),
        ("Files",                run_files),
        # Must run after Dynamic Lists + Static Lists scrapers produce JSON
        ("List Memberships",     run_list_memberships),
        # Aggregate stats — no PII; runs after lists so brand discovery works
        ("Prospect Stats",       run_prospect_stats),
        # Account-level config — scoring categories, tracker domains, BU metadata
        ("Account Settings",     run_account_settings),
        # Preference Center — system-level subscription management page
        ("Preference Center",    run_preference_center),
        # Users — security/governance: roles, SSO, last login, inactive accounts
        ("Users",                run_users),
        # Prospect Sync Errors (Step 1) — connector queue of failed CRM writes
        ("Prospect Sync Errors", run_prospect_sync_errors),
        # Grading Profiles — only populated if profile grading is enabled
        ("Grading Profiles",     run_profiles),
        # List Emails — actual batch email sends (not just stats or templates)
        ("List Emails",          run_list_emails),
        # Folders — full folder structure + asset counts; run LAST so cross-ref works
        ("Folders",              run_folders),
    ]

    SF_SCRAPERS = [
        ("SF: Campaign Member Attribution",  lambda p, c: run_sf_campaigns(client=c)),
        ("SF: Opt-In Field Sync Audit",      lambda p, c: run_sf_optin(client=c)),
        ("SF: Lead Quality / Resolution",    lambda p, c: run_sf_leads(client=c)),
        ("SF: Opportunity Attribution",      lambda p, c: run_sf_opps(client=c)),
        ("SF: Pardot Sync Error Log",        lambda p, c: run_sf_sync_errors(client=c)),
        ("SF: Custom Field Mapping",         lambda p, c: run_sf_fields(client=c)),
        ("SF: Account / Corp Hierarchy",     lambda p, c: run_sf_accounts(client=c)),
        ("SF: Task / Activity Follow-Up",    lambda p, c: run_sf_tasks(client=c)),
        ("SF: Report & Dashboard Inventory", lambda p, c: run_sf_reports(client=c)),
        ("SF: Object Storage Usage",         lambda p, c: run_sf_storage(p, c)),
        # Step 2 — resolve each prospect sync error to its offending value.
        # Needs both the page (Pardot v5 prospect reads) and the SF client
        # (describe: picklist values + field lengths). Runs after Step 1.
        ("SF: Resolve Prospect Sync Errors", lambda p, c: run_resolve_sync_errors(page=p, client=c)),
    ]

    failures: list[tuple[str, str]] = []  # (name, error message)
    gate_summary: dict[str, dict] = {}  # per-scraper gating stats for --update

    # Filter scrapers if --only is specified
    active_scrapers = SCRAPERS
    if args.only:
        only_names = {s.strip().lower() for s in args.only.split(",")}
        active_scrapers = [
            (name, fn) for name, fn in SCRAPERS
            if any(
                keyword.lower() in name.lower() or
                keyword.lower().replace("_", " ") in name.lower() or
                (keyword.lower() == "static" and "static" in name.lower()) or
                (keyword.lower() == "custom" and "custom" in name.lower()) or
                (keyword.lower() == "dynamic" and "dynamic" in name.lower()) or
                (keyword.lower() == "preference" and "preference" in name.lower()) or
                (keyword.lower() == "page" and "page" in name.lower())
                for keyword in only_names
            )
        ]
        if not active_scrapers:
            print(f"❌  No scrapers matched --only '{args.only}'")
            print(f"   Available scrapers: {', '.join(name for name, _ in SCRAPERS)}")
            sys.exit(1)
        print(f"   Running {len(active_scrapers)} scraper(s) (filtered by --only)")

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)

            # ── Pardot scrapers ───────────────────────────────────────────────
            for name, run_fn in active_scrapers:
                print(f"\n{'─' * 50}")
                print(f"▶  Starting: {name}")
                print(f"{'─' * 50}")
                try:
                    sig = inspect.signature(run_fn)
                    kwargs = {}
                    if args.update and "update" in sig.parameters:
                        candidate = {
                            "update": True,
                            "max_age_days": args.max_age_days,
                            "refresh_limit": args.refresh_limit,
                            "allow_prune": args.allow_prune,
                            "dry_run": args.dry_run,
                        }
                        missing = [k for k in candidate if k not in sig.parameters]
                        if missing:
                            raise RuntimeError(
                                f"{name}: update mode requested but run() lacks {missing} — "
                                f"refusing to silently fall back to a full scrape"
                            )
                        kwargs = candidate
                    run_fn(page, **kwargs)

                    print(f"✅  Finished: {name}")
                except Exception as e:
                    print(f"❌  {name} failed: {e}")
                    import traceback
                    traceback.print_exc()
                    print("   Continuing with next scraper...")
                    failures.append((name, str(e)))

            # ── Salesforce scrapers (optional) ────────────────────────────────
            if sf_enabled:
                print(f"\n{'=' * 50}")
                print("🔷 Starting Salesforce Analysis Block")
                print(f"{'=' * 50}")
                try:
                    sf_client = sf_api.client_from_page(page)
                    print(f"   ✅ SF token extracted — {sf_client.instance_url}\n")
                except Exception as e:
                    print(f"❌ Could not extract Salesforce token from Pardot session: {e}")
                    sf_client = None
                    # Fallback: SF CLI token (decoupled from the Pardot login)
                    if sf_api.cli_available():
                        print("   ↪︎ Trying SF CLI token instead...")
                        try:
                            sf_client = sf_api.client_from_cli()
                            print(f"   ✅ SF token via CLI — {sf_client.instance_url}\n")
                        except Exception as e2:
                            print(f"   ⚠️  SF CLI fallback failed: {e2}")
                    if sf_client is None:
                        print("   Skipping all SF scrapers.")
                        failures.append(("SF: token extraction", str(e)))

                if sf_client:
                    for name, run_fn in SF_SCRAPERS:
                        print(f"\n{'─' * 50}")
                        print(f"▶  Starting: {name}")
                        print(f"{'─' * 50}")
                        try:
                            run_fn(page, sf_client)
                            print(f"✅  Finished: {name}")
                        except Exception as e:
                            print(f"❌  {name} failed: {e}")
                            import traceback
                            traceback.print_exc()
                            print("   Continuing with next scraper...")
                            failures.append((name, str(e)))
        finally:
            context.close()

    print("\n── Running analysis scripts ──────────────────────")
    try:
        import analyze_cross_references
        analyze_cross_references.main()
    except Exception as e:
        print(f"⚠️  Cross-reference analysis failed: {e}")
        failures.append(("Analysis: cross-references", str(e)))
    try:
        import analyze_best_practices
        analyze_best_practices.main()
    except Exception as e:
        print(f"⚠️  Gap analysis failed: {e}")
        failures.append(("Analysis: best-practices", str(e)))
    print("\n── Running enrichment layer ──────────────────────")
    try:
        import enrich_automations
        enrich_automations.enrich_automations(org)
    except Exception as e:
        print(f"⚠️  Enrichment failed: {e}")
        failures.append(("Enrichment: automations", str(e)))
    print("\n── Running Engagement Studio visualizations ───────")
    try:
        import generate_drawio
        generate_drawio.main()
        print(f"   ✅ draw.io diagrams written to output/{org}/drawio/")
    except Exception as e:
        print(f"⚠️  draw.io generation failed: {e}")
        failures.append(("Visualization: draw.io", str(e)))

    print("\n── Analysis & enrichment complete ────────────────")
    print(f"   output/{org}/pardot_cross_references.json / .csv")
    print(f"   output/{org}/pardot_gap_analysis.md / .json")
    print(f"   output/{org}/enriched/")
    print(f"     ├─ automation_rules_enriched.json / .csv")
    print(f"     ├─ dynamic_lists_enriched.json / .csv")
    print(f"     └─ engagement_programs_enriched.json / .csv")
    print(f"   output/{org}/drawio/")
    print(f"     └─ ES_<id>_<name>.drawio  (one per Engagement Studio program)")

    # ── Verify mode reconciliation (optional) ─────────────────────────────────
    if args.verify:
        print(f"\n{'=' * 50}")
        print("🔍 Running Reconciliation Verification (--verify)")
        print(f"{'=' * 50}")

        try:
            import subprocess
            import hashlib

            def file_hash(path):
                """Compute SHA256 of a file."""
                if not os.path.exists(path):
                    return None
                h = hashlib.sha256()
                with open(path, 'rb') as f:
                    for chunk in iter(lambda: f.read(8192), b''):
                        h.update(chunk)
                return h.hexdigest()

            print("\n📊 Scanning output directory for changes...")
            output_dir = utils.OUTPUT_DIR
            gated_scrapers = [
                "pardot_static_lists", "pardot_preference_center",
                "pardot_forms", "pardot_custom_redirects",
                "pardot_dynamic_content", "pardot_page_actions",
            ]

            diffs = {}
            for scraper_name in gated_scrapers:
                json_path = os.path.join(output_dir, f"{scraper_name}.json")
                csv_path = os.path.join(output_dir, f"{scraper_name}.csv")

                for ext, path in [("json", json_path), ("csv", csv_path)]:
                    if os.path.exists(path):
                        current_hash = file_hash(path)
                        # Load and check for shape_hash match
                        try:
                            manifest = utils.read_manifest()
                            expected_hash = manifest.get(f"scrape_{scraper_name.replace('pardot_', '').replace('_full', '')}", {}).get("shape_hash")
                            if expected_hash and current_hash != expected_hash:
                                key = f"{scraper_name}.{ext}"
                                diffs[key] = {"current": current_hash[:16], "expected": expected_hash[:16]}
                        except Exception:
                            pass

            if diffs:
                print("\n⚠️  Reconciliation Issues Found:")
                for file_key, hashes in sorted(diffs.items()):
                    print(f"   • {file_key}: hash mismatch")
                    print(f"       Current:  {hashes['current']}...")
                    print(f"       Expected: {hashes['expected']}...")
            else:
                print("\n✅ All gated scrapers match their expected shape hashes.")

        except Exception as e:
            print(f"⚠️  Verification check failed: {e}")
            failures.append(("Verification: reconciliation", str(e)))

    # ── End-of-run summary ────────────────────────────────────────────────────
    total  = len(SCRAPERS) + (len(SF_SCRAPERS) if sf_enabled else 0) + 4  # +4 analysis/viz steps
    passed = total - len(failures)
    print(f"\n{'=' * 50}")
    if not failures:
        print(f"✅  All {total} steps passed.")
    else:
        print(f"⚠️   {passed}/{total} steps passed — {len(failures)} failure(s):")
        for step_name, err in failures:
            short_err = err.splitlines()[0][:120] if err else "unknown error"
            print(f"   ❌  {step_name}: {short_err}")
    print("=" * 50)

if __name__ == "__main__":
    main()
