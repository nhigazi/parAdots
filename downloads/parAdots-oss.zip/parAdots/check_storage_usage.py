#!/usr/bin/env python3
"""
Quick Storage Usage Check
==========================
Standalone script to check Salesforce object storage without running the full suite.

Usage:
  python3 check_storage_usage.py                    # uses .active-org
  python3 check_storage_usage.py --org globex      # specify org
  python3 check_storage_usage.py --top 10           # show top N objects
  python3 check_storage_usage.py --org globex --top 50
"""

import argparse
import sys
from playwright.sync_api import sync_playwright

import utils
from scrape_sf_storage_usage import run


def main():
    parser = argparse.ArgumentParser(description="Check Salesforce object storage usage")
    parser.add_argument(
        "--org", metavar="NAME",
        help="Org config to use (e.g. 'globex'). Defaults to .active-org",
    )
    args = parser.parse_args()

    # Load org config
    org = utils.load_org_config(args.org)
    print(f"🌐 Org: {org}")
    print(f"📁 Output: {utils.OUTPUT_DIR}\n")

    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            print("🔐 Logging in...\n")
            utils.login(page)

            run(page)
            return 0

        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
            return 1
        finally:
            context.close()


if __name__ == "__main__":
    sys.exit(main())
