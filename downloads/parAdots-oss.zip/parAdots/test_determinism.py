#!/usr/bin/env python3
"""
Determinism baseline test for update mode.

Runs scrapers twice without update mode and verifies byte-identical output.
This ensures sorting fixes produce stable, deterministic output.

Usage:
  python3 test_determinism.py [--full]

Without --full: tests only the 6 gated scrapers (quick: ~10 min with Pardot access).
With --full: tests all Pardot scrapers (slow: ~60 min with Pardot access).
"""

import argparse
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

import utils

def sha256_file(path: str) -> str:
    """Compute SHA256 hash of a file."""
    sha256_hash = hashlib.sha256()
    with open(path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


def snapshot_output_dir(output_dir: str) -> dict:
    """Take a snapshot of all JSON/CSV files in output_dir."""
    snapshot = {}
    if not os.path.isdir(output_dir):
        return snapshot

    for fname in os.listdir(output_dir):
        if fname.endswith(('.json', '.csv')) and not fname.endswith('.bak'):
            fpath = os.path.join(output_dir, fname)
            if os.path.isfile(fpath):
                snapshot[fname] = sha256_file(fpath)
    return snapshot


def compare_snapshots(snap1: dict, snap2: dict, run_num: int) -> bool:
    """Compare two snapshots and report differences."""
    all_files = set(snap1.keys()) | set(snap2.keys())
    changes = []

    for fname in sorted(all_files):
        hash1 = snap1.get(fname, "MISSING")
        hash2 = snap2.get(fname, "MISSING")

        if hash1 != hash2:
            changes.append(fname)
            print(f"   ⚠️  {fname}: hash mismatch")
            if hash1 == "MISSING":
                print(f"       ↪︎ Run 1: missing, Run {run_num}: present")
            elif hash2 == "MISSING":
                print(f"       ↪︎ Run 1: {hash1[:16]}..., Run {run_num}: missing")
            else:
                print(f"       ↪︎ Run 1: {hash1[:16]}..., Run {run_num}: {hash2[:16]}...")

    if not changes:
        print(f"   ✅ All outputs byte-identical (run {run_num})")
        return True
    else:
        print(f"   ❌ {len(changes)} file(s) differ (run {run_num})")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="Test determinism: run scrapers twice and compare outputs."
    )
    parser.add_argument(
        "--full", action="store_true",
        help="Test all Pardot scrapers (slow). Default: test 6 gated scrapers only (fast)."
    )
    parser.add_argument(
        "--org", metavar="NAME",
        help="Org to test (default: read from .active-org)."
    )
    args = parser.parse_args()

    org = utils.load_org_config(args.org)
    output_dir = utils.OUTPUT_DIR
    print(f"\n🧪 Determinism Baseline Test")
    print(f"{'=' * 50}")
    print(f"Org: {org}")
    print(f"Output: {output_dir}")

    # Gated scrapers (Tier A, B, C) — fast subset for initial validation
    # Use display names from run_all.py SCRAPERS list
    gated_scrapers = [
        "static",
        "preference",
        "forms",
        "custom",
        "dynamic",
        "page",
    ]

    test_mode = "GATED (6 scrapers)" if not args.full else "FULL (all Pardot scrapers)"
    print(f"Mode: {test_mode}\n")

    if not args.full:
        print("Running gated scrapers twice to verify determinism...\n")
        run_cmd = f"python3 run_all.py --only {','.join(gated_scrapers)} --no-sf"
    else:
        print("Running full Pardot suite twice to verify determinism...\n")
        run_cmd = "python3 run_all.py --no-sf"

    # Run 1
    print("📍 Run 1...")
    snap1 = snapshot_output_dir(output_dir)

    # Backup output before run 2
    backup_dir = os.path.join(output_dir, ".determinism_backup_run1")
    if os.path.exists(backup_dir):
        shutil.rmtree(backup_dir)
    shutil.copytree(output_dir, backup_dir, ignore=shutil.ignore_patterns('*.bak'))
    print(f"   ✅ Snapshot 1 taken ({len(snap1)} files)")
    print(f"   ↪︎ Backup saved to {backup_dir}")

    # Run 2 (will overwrite output_dir)
    print("\n📍 Run 2 (this will take a while with browser...)...")
    print("   (Running scrapers — please wait...)")
    result = os.system(run_cmd)

    if result != 0:
        print(f"\n❌ Scraper run failed with exit code {result}")
        sys.exit(1)

    snap2 = snapshot_output_dir(output_dir)
    print(f"   ✅ Snapshot 2 taken ({len(snap2)} files)")

    # Compare
    print("\n📊 Comparing snapshots...\n")
    identical = compare_snapshots(snap1, snap2, 2)

    if identical:
        print(f"\n{'=' * 50}")
        print("✅ DETERMINISM BASELINE PASSED")
        print("Sorting fixes produce stable, byte-identical output.")
        print("Safe to proceed with update mode implementation.")
        print(f"{'=' * 50}\n")

        # Cleanup backup
        if os.path.exists(backup_dir):
            shutil.rmtree(backup_dir)
        return 0
    else:
        print(f"\n{'=' * 50}")
        print("❌ DETERMINISM BASELINE FAILED")
        print("Output is not byte-identical between runs.")
        print(f"Backup of Run 1 saved at: {backup_dir}")
        print("Investigate differences before proceeding.")
        print(f"{'=' * 50}\n")
        return 1


if __name__ == "__main__":
    sys.exit(main())
