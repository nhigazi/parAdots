"""
Pardot Page Actions / Website Tracking Scraper
================================================
Scrapes page actions configured in Pardot:
  - Page URL / pattern
  - Completion actions (score change, list add, notification)
  - Score delta

Page actions fire when a tracked prospect visits a URL matching the pattern.
Absence of page actions = no behavioral website intent signals in scoring.

Output:
  pardot_page_actions.json
  pardot_page_actions.csv

Usage (standalone):
  python3 scrape_page_actions.py
"""

import re
import time
from playwright.sync_api import sync_playwright

import utils

OUTPUT_JSON = ""   # set at run() time via utils.output_path()
OUTPUT_CSV  = ""
SCREENSHOTS = ""
CSV_HEADERS = ["id", "name", "tracked_url", "score_delta", "completion_actions", "campaign", "raw_text_snippet"]

# Confirmed detail URL pattern: /pageAction/read/id/{id}
DETAIL_PATH = "/pageAction/read/id/{id}"

LIST_PATHS = [
    "/pageAction/index",
    "/pageAction",
]


def discover_page_actions(page):
    print("\n🌐 Discovering page actions...")
    seen = set()
    items = []

    for list_path in LIST_PATHS:
        list_url = utils.pardot_url(list_path)
        utils.navigate(page, list_url)
        utils.scroll_to_bottom(page, steps=3)
        utils.screenshot(page, f"{SCREENSHOTS}/page_actions_list.png")

        # Check page text rather than URL for a genuine "not found"
        text = utils.get_page_text(page, filter_prospects=False)
        if "page not found" in text.lower() and list_path != LIST_PATHS[-1]:
            continue

        found = utils.collect_ids_from_page(page, r'/pageAction/read/id/(\d+)')
        for item in found:
            if item["id"] not in seen:
                seen.add(item["id"])
                items.append(item)

        if items:
            break

    # Pagination
    hit_max_pages = False
    if items:
        page_num = 2
        while page_num <= 15:
            next_btn = None
            for sel in ["a:has-text('Next')", "a:has-text('›')", ".next a", "a[rel='next']"]:
                try:
                    btn = page.query_selector(sel)
                    if btn and btn.is_visible():
                        next_btn = btn
                        break
                except Exception:
                    continue
            if not next_btn:
                break
            try:
                next_btn.click()
                page.wait_for_timeout(2000)
            except Exception:
                break
            new_items = utils.collect_ids_from_page(page, r'/pageAction/read/id/(\d+)')
            added = sum(1 for i in new_items if i["id"] not in seen and not seen.add(i["id"]))
            if added:
                items.extend(i for i in new_items if i["id"] in seen)
            else:
                break
            page_num += 1
            if page_num > 15:
                hit_max_pages = True

    sweep_verified = not hit_max_pages
    print(f"   ✅ Found {len(items)} page action(s)")
    return items, sweep_verified


def scrape_page_action(page, pa_id, pa_name):
    url = utils.pardot_url(DETAIL_PATH.format(id=pa_id))
    utils.navigate(page, url)
    utils.screenshot(page, f"{SCREENSHOTS}/pa_{pa_id}.png")

    # filter_prospects=False: the sidebar nav "Prospects" item would otherwise
    # truncate the page text before any page-action content is reached.
    text = utils.get_page_text(page, filter_prospects=False)

    if "page not found" in text.lower():
        return None

    lines = [l.strip() for l in text.splitlines() if l.strip()]

    def extract_field(keywords, stop_before=("completion actions", "prospects", "usages")):
        """
        Return the value associated with the first line matching any keyword.
        Pardot detail pages use a two-column layout rendered as separate lines:
          Label
          Value
        so we return lines[i+1] when no colon-separated value is found on the
        matched line itself.  We stop scanning at section boundaries.
        """
        for i, line in enumerate(lines):
            ll = line.lower()
            if any(sb in ll for sb in stop_before) and ll not in keywords:
                # Only stop if we're AT a section heading, not a matching label
                if ll in stop_before:
                    break
            if any(kw.lower() == ll or kw.lower() in ll for kw in keywords):
                # Colon-separated on same line: "Name: Test Page action"
                if ":" in line:
                    val = line.split(":", 1)[1].strip()
                    if val:
                        return val[:300]
                # Value on next line
                if i + 1 < len(lines):
                    nxt = lines[i + 1].strip()
                    # Skip if next line looks like another label (short, no digits, Title Case)
                    if nxt and not nxt.lower().startswith(tuple(keywords)):
                        return nxt[:300]
        return ""

    def extract_completion_actions(lines):
        """
        Collect all action lines under the 'Completion Actions' heading,
        stopping at 'Prospects' or 'Usages'.
        """
        in_section = False
        actions = []
        for line in lines:
            ll = line.lower()
            if ll == "completion actions":
                in_section = True
                continue
            if in_section:
                if ll in ("prospects", "usages") or ll.startswith("prospects ("):
                    break
                if line:
                    actions.append(line)
        return "; ".join(actions) if actions else ""

    tracked_url     = extract_field(["page url", "url", "page address"])
    score_delta     = extract_field(["score change", "score delta", "score", "points"])
    completion_acts = extract_completion_actions(lines)
    campaign        = extract_field(["campaign"])

    return {
        "id":                pa_id,
        "name":              pa_name,
        "tracked_url":       tracked_url,
        "score_delta":       score_delta,
        "completion_actions": completion_acts,
        "campaign":          campaign,
        "raw_text_snippet":  "\n".join(lines[:25]),
    }


def run(page, update: bool = False, max_age_days: int = 7, refresh_limit: int = 25,
        allow_prune: bool = False, dry_run: bool = False):
    global OUTPUT_JSON, OUTPUT_CSV, SCREENSHOTS
    OUTPUT_JSON = utils.output_path("pardot_page_actions.json")
    OUTPUT_CSV  = utils.output_path("pardot_page_actions.csv")
    SCREENSHOTS = utils.output_path("screenshots", "page_actions")
    utils.reset_screenshots(SCREENSHOTS)

    kind = "page_actions"
    started_at = utils.now_iso()
    ok_ids = set()

    # ── Tier C: Load previous output & set up ID-based gating ────────────────────
    cached: dict[str, dict] = {}
    if update:
        cached = utils.load_previous_output(kind)
        cached_hash = utils.manifest_entry(f"scrape_{kind}").get("shape_hash")
        if cached_hash and cached_hash != utils.shape_hash(CSV_HEADERS):
            print("   ⚠️  Output shape changed — ignoring cache, full scrape this run")
            cached = {}
        print(f"   [update] {len(cached)} cached record(s)")

    items, sweep_verified = discover_page_actions(page)

    if not items:
        print("⚠️  No page actions found — website behavioral tracking is a best-practice gap.")
        utils.save_json([], OUTPUT_JSON)
        utils.save_csv([], ["#", "Name", "ID", "Tracked URL", "Score Delta",
                            "Completion Actions", "Campaign"], OUTPUT_CSV)
        return

    # ── Tier C: Determine which items to visit (ID-based + aging sweep) ─────────
    current_ids = {item["id"] for item in items}
    stale = utils.stale_ids(kind, current_ids, max_age_days=max_age_days,
                            limit=refresh_limit) if update else set()
    to_visit = current_ids if not update else (current_ids - set(cached.keys())) | stale

    print(f"\n🔍 Processing {len(items)} page action(s): {len(to_visit)} visit(s), {len(items)-len(to_visit)} cached...")
    results = []
    for i, item in enumerate(items, 1):
        item_id = item["id"]
        item_name = item.get('name', item_id)
        print(f"   [{i}/{len(items)}] {item_name}", end="")

        if update and item_id not in to_visit:
            print(" [cached]")
            fresh = utils.merge_record_fields(cached.get(item_id, {}), item, [])
            results.append(fresh)
            continue

        print()
        if item.get("url"):
            # Already parsed from list page (no detail page available)
            results.append({
                "id":                item["id"],
                "name":              item.get("name", ""),
                "tracked_url":       item.get("url", ""),
                "score_delta":       item.get("score_delta", ""),
                "completion_actions": "",
                "campaign":          "",
                "raw_text_snippet":  item.get("name", ""),
            })
        else:
            data = scrape_page_action(page, item_id, item_name)
            if data:
                results.append(data)
        ok_ids.add(item_id)
        time.sleep(0.5)

    # ── Tier C: Merge cached + prune deleted ────────────────────────────────────
    merged = utils.merge_records(cached.values() if update else [], {r["id"]: r for r in results})
    prev = utils.manifest_entry(f"scrape_{kind}")
    record_count = prev.get("record_count", len(merged))
    merged, pruned = utils.apply_prune(
        merged, current_ids, sweep_verified=True,
        record_count=record_count, allow_prune=allow_prune
    )

    merged.sort(key=lambda r: int(r.get("id", 0)) if str(r.get("id", "")).isdigit() else str(r.get("id", "")))
    if dry_run:
        print(f"   [dry-run] would visit {len(to_visit)} of {len(current_ids)} record(s)")
        print(f"   [dry-run] would merge {len(results)}, prune {len(pruned)}")
        print(f"   [dry-run] no files written")
    else:
        utils.save_json(merged, OUTPUT_JSON)

        rows = [
            [i + 1, r["name"], r["id"], r["tracked_url"],
             r["score_delta"], r["completion_actions"], r["campaign"]]
            for i, r in enumerate(merged)
        ]
        utils.save_csv(
            rows,
            ["#", "Name", "ID", "Tracked URL", "Score Delta", "Completion Actions", "Campaign"],
            OUTPUT_CSV,
        )

        if update and ok_ids:
            utils.mark_scraped(kind, ok_ids)
            utils.write_manifest(f"scrape_{kind}", started_at=started_at,
                                shape_hash_val=utils.shape_hash(CSV_HEADERS), record_count=len(merged))

    print(f"\n✅ Page actions scrape complete — {len(merged)} action(s).")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    print("\n🚀 Pardot Page Actions Scraper")
    print("=" * 45)

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
