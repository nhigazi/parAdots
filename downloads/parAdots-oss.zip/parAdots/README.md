# parAdots — Pardot & Salesforce Audit Suite

*Multi-org compliance & architecture analysis for Pardot (Marketing Cloud Account Engagement).*

parAdots scrapes, maps and analyses Pardot and Salesforce configurations across one or more
orgs. It discovers gaps, visualises automation flows, tracks asset dependencies and renders
everything in a local single-file dashboard.

> **Demo included.** After setup, the viewer ships with a synthetic `demo` org so you can
> explore the UI immediately, without connecting to any real Pardot/Salesforce account.

## What it does
- **30+ scrapers** for Pardot (lists, automation rules, forms, form handlers, email templates,
  landing pages, scoring rules, Engagement Studio, custom redirects, campaigns, sent emails,
  snippets, files, fields, users, preference centers, page actions …) and Salesforce (campaign
  attribution, opt-in sync audits, lead quality, opportunity attribution, sync errors, field
  mapping, account hierarchy, task activity, reports inventory, storage usage).
- **Cross-reference analysis**, **best-practice gap report**, **opt-in/DOI/opt-out process detection**.
- **Engagement Studio visualisation** (interactive flowchart + draw.io export).
- **Local dashboard** (`viewer.py` + `viewer.html`) — boards, cockpit, notes/todos, fully offline.

## Requirements
Python 3.10+, Node.js 18+ (optional), Google Chrome, optional Salesforce CLI (`sf`).

## Quick start

**One-click (recommended):** double-click **`parAdots.command`** (macOS) or
**`parAdots.bat`** (Windows). The first start installs everything automatically and
then opens the dashboard at <http://localhost:8765>; every later start opens straight away.

> macOS: on the very first launch, right-click `parAdots.command` → **Open** once to get
> past Gatekeeper. Windows: if SmartScreen warns, choose **More info → Run anyway**.

**Manual / Linux:**
```bash
cd parAdots
./setup.sh            # macOS / Linux   (Windows: .\setup.ps1)
python3 viewer.py     # → http://localhost:8765  (bundled `demo` org)
```
See **[QUICKSTART.md](QUICKSTART.md)** to connect your own org.

## Configuration
Each org is a file `configs/<org>.env` (never committed — see `.env.template`). Switch with
`python3 set_org.py <org>` or per run with `--org <org>`. Nothing is sent anywhere except your
own Salesforce/Pardot org.

## Disclaimer
parAdots automates a logged-in Salesforce/Pardot browser session and calls the Pardot/Salesforce
APIs on your behalf. Use it **only** with orgs you are authorised to access and in line with
Salesforce's terms of service and your data-protection obligations. Provided "as is" (see LICENSE).

## License
MIT — see [LICENSE](LICENSE).
