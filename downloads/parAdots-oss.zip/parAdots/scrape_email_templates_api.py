"""
Pardot Email Template Scraper — v5 API  (replaces scrape_email_templates.py)
=============================================================================
Pulls all email templates from /api/v5/objects/email-templates and enriches
each record with:

  • Sender/reply-to config (senderOptions, replyToOptions) from per-record read
  • Full HTML + plain-text body (htmlMessage, textMessage) from per-record read
  • Template type flags: isOneToOneEmail, isAutoResponderEmail, isDripEmail,
    isListEmail
  • Folder name resolved from /api/v5/objects/folders
  • Campaign name resolved from /api/v5/objects/campaigns
  • Tracker domain from /api/v5/objects/tracker-domains
  • Full audit trail: createdAt, updatedAt

Two-pass approach:
  Pass 1 — paged_get() lists all templates (no HTML body in list responses).
  Pass 2 — get_one() fetches each template individually for body content
            and sender/reply-to details.

Output:
  pardot_email_templates.json
  pardot_email_templates.csv

Usage (standalone):
  python3 scrape_email_templates_api.py

Called from run_all.py:
  from scrape_email_templates_api import run
  run(page=page)     # page is a logged-in Playwright Page
  run(client=client) # if you already have a PardotClient
"""

from __future__ import annotations

import csv
import json
import sys

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time via utils.output_path()
OUTPUT_CSV  = ""

# Fields available in the list (paged) response
LIST_FIELDS = [
    "id", "name", "subject",
    "folderId", "campaignId", "trackerDomainId",
    "isOneToOneEmail", "isAutoResponderEmail", "isDripEmail", "isListEmail",
    "createdAt", "updatedAt",
]

# Fields to request on the per-record detail read.
# htmlMessage / textMessage are only available on individual reads, not the list endpoint.
# senderOptions / replyToOptions are documented in the v5 spec but not exposed by this instance.
DETAIL_FIELDS = ["id", "htmlMessage", "textMessage"]

FOLDER_FIELDS   = ["id", "name"]
CAMPAIGN_FIELDS = ["id", "name"]
TRACKER_FIELDS  = ["id", "domain"]


# ── Helpers ───────────────────────────────────────────────────────────────────

def _str(v) -> str:
    return "" if v is None else str(v)


def _type_flags(tmpl: dict) -> str:
    """Summarise the four boolean type flags into a human-readable string."""
    mapping = [
        ("isListEmail",        "List Email"),
        ("isDripEmail",        "Drip / Engagement Studio"),
        ("isAutoResponderEmail", "Auto-Responder"),
        ("isOneToOneEmail",    "One-to-One"),
    ]
    active = [label for key, label in mapping if tmpl.get(key)]
    return "; ".join(active) if active else "Unknown"


def _sender_info(detail: dict) -> tuple[str, str, str]:
    """
    Extract (from_name, from_email, reply_to) from senderOptions /
    replyToOptions.

    The v5 API returns these as objects:
      senderOptions  = {"type": "specific", "name": "...", "address": "..."}
      replyToOptions = {"type": "specific", "address": "..."}

    NOTE: senderOptions / replyToOptions are NOT returned by this Pardot
    instance's v5 API.  Callers should prefer _sender_info_from_page() which
    scrapes the classic UI detail page instead.
    """
    sender = detail.get("senderOptions") or {}
    reply  = detail.get("replyToOptions") or {}
    from_name  = _str(sender.get("name", ""))
    from_email = _str(sender.get("address", ""))
    reply_to   = _str(reply.get("address", ""))
    return from_name, from_email, reply_to


TEMPLATE_DETAIL_PATH = "/emailTemplate/read/id/{id}"


def _sender_info_from_page(page, tmpl_id: str) -> tuple[str, str, str]:
    """
    Scrape sender and reply-to info from the classic Pardot UI detail page at
    /emailTemplate/read/id/{id}.

    The page renders:
      Sender    1. Prospect's Account Owner
                2. General User: Globex Riesa GmbH <info@newsletter.example.com>
      Reply-To  1. General Address: <info@example.com>

    We collect all text lines under 'Sender' and 'Reply-To' headings.
    filter_prospects=False because the sidebar nav "Prospects" item would
    otherwise truncate the page text before any template content is reached.
    """
    import utils as _utils
    url = utils.pardot_url(TEMPLATE_DETAIL_PATH.format(id=tmpl_id))
    _utils.navigate(page, url)
    text = _utils.get_page_text(page, filter_prospects=False)
    lines = [l.strip() for l in text.splitlines() if l.strip()]

    sender_lines: list[str] = []
    reply_lines:  list[str] = []
    SECTION_LABELS = {"name", "folder", "sender", "reply-to", "subject",
                      "tracker domain", "link", "layout template", "form fields",
                      "submit button text", "always display form", "tags",
                      "created at", "updated at", "created by", "updated by",
                      "message", "html", "text"}

    mode = None
    for line in lines:
        ll = line.lower()
        if ll == "sender":
            mode = "sender"
            continue
        if ll in ("reply-to", "reply to"):
            mode = "reply"
            continue
        # Any other known label resets mode
        if ll in SECTION_LABELS and ll not in ("sender", "reply-to", "reply to"):
            mode = None
            continue
        if mode == "sender" and line:
            sender_lines.append(line)
        elif mode == "reply" and line:
            reply_lines.append(line)

    from_name  = ""
    from_email = ""
    reply_to   = ""

    # Parse sender lines: "1. General User: Name <email@domain.com>"
    # or "1. Prospect's Account Owner"
    import re as _re
    email_re = _re.compile(r'<([^>]+@[^>]+)>')
    name_re  = _re.compile(r'(?:General User|Specific User):\s*(.+?)(?:\s*<|$)', _re.IGNORECASE)

    for s_line in sender_lines:
        em = email_re.search(s_line)
        nm = name_re.search(s_line)
        if em and not from_email:
            from_email = em.group(1).strip()
        if nm and not from_name:
            from_name = nm.group(1).strip()
        if not from_name and not em:
            # e.g. "1. Prospect's Account Owner"
            clean = _re.sub(r'^\d+\.\s*', '', s_line).strip()
            if clean:
                from_name = clean

    for r_line in reply_lines:
        em = email_re.search(r_line)
        if em and not reply_to:
            reply_to = em.group(1).strip()
        if not reply_to:
            # e.g. "1. General Address: info@example.com"
            clean = _re.sub(r'^\d+\.\s*(?:General Address|Specific Address):\s*', '', r_line, flags=_re.IGNORECASE).strip()
            if clean and "@" in clean:
                reply_to = clean

    return from_name, from_email, reply_to


# ── Shaping ───────────────────────────────────────────────────────────────────

def shape_template(
    tmpl: dict,
    detail: dict,
    folder_map: dict,
    campaign_map: dict,
    tracker_map: dict,
    sender_info: tuple[str, str, str] | None = None,
) -> dict:
    tmpl_id = str(tmpl.get("id", ""))

    folder_name   = (folder_map.get(tmpl.get("folderId"))   or {}).get("name", "")
    campaign_name = (campaign_map.get(tmpl.get("campaignId")) or {}).get("name", "")
    tracker_domain = (tracker_map.get(tmpl.get("trackerDomainId")) or {}).get("domain", "")

    # Prefer browser-scraped sender info (API doesn't expose senderOptions for this instance)
    if sender_info is not None:
        from_name, from_email, reply_to = sender_info
    else:
        from_name, from_email, reply_to = _sender_info(detail)

    html_body  = detail.get("htmlMessage")  or ""
    text_body  = detail.get("textMessage")  or ""

    return {
        "id":              tmpl_id,
        "name":            tmpl.get("name", ""),
        "subject":         tmpl.get("subject", "") or "",
        "from_name":       from_name,
        "from_email":      from_email,
        "reply_to":        reply_to,
        "folder":          folder_name,
        "campaign":        campaign_name,
        "tracker_domain":  tracker_domain,
        "types":           _type_flags(tmpl),
        "is_list_email":         bool(tmpl.get("isListEmail")),
        "is_drip_email":         bool(tmpl.get("isDripEmail")),
        "is_autoresponder_email": bool(tmpl.get("isAutoResponderEmail")),
        "is_one_to_one_email":   bool(tmpl.get("isOneToOneEmail")),
        "html_body":       html_body,
        "text_body":       text_body,
        "html_body_chars": len(html_body),
        "created_at":      tmpl.get("createdAt", "") or "",
        "updated_at":      tmpl.get("updatedAt", "") or "",
    }


# ── Export ────────────────────────────────────────────────────────────────────

def export_csv(results: list[dict]) -> None:
    headers = [
        "#", "Name", "ID", "Subject",
        "From Name", "From Email", "Reply-To",
        "Folder", "Campaign", "Tracker Domain",
        "Types",
        "HTML Body (chars)",
        "Created At", "Updated At",
    ]
    rows = [
        [
            i + 1,
            r["name"], r["id"], r["subject"],
            r["from_name"], r["from_email"], r["reply_to"],
            r["folder"], r["campaign"], r["tracker_domain"],
            r["types"],
            r["html_body_chars"],
            r["created_at"], r["updated_at"],
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    """
    Entry point for both standalone use and run_all.py integration.

    Pass either:
      page   – a logged-in Playwright Page (token extracted automatically)
      client – an already-built PardotClient (skips browser entirely)
    """
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_email_templates.json")
    OUTPUT_CSV  = utils.output_path("pardot_email_templates.csv")

    print("\n🚀 Pardot Email Template Scraper (v5 API)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    # Pre-load lookup tables — one request each, resolved client-side
    print("📁 Pre-loading folders...")
    folder_map = pardot_api.lookup_map(client, "objects/folders", fields=FOLDER_FIELDS)
    print(f"   ✅ {len(folder_map)} folder(s)")

    print("📋 Pre-loading campaigns...")
    campaign_map = pardot_api.lookup_map(client, "objects/campaigns", fields=CAMPAIGN_FIELDS)
    print(f"   ✅ {len(campaign_map)} campaign(s)")

    print("🌐 Pre-loading tracker domains...")
    tracker_map = pardot_api.lookup_map(client, "objects/tracker-domains", fields=TRACKER_FIELDS)
    print(f"   ✅ {len(tracker_map)} tracker domain(s)")

    # Pass 1: list all templates
    print("\n📧 Fetching email templates (list pass)...")
    templates = list(pardot_api.paged_get(client, "objects/email-templates", fields=LIST_FIELDS))
    print(f"   ✅ {len(templates)} email template(s) found")

    if not templates:
        print("⚠️  No email templates returned — check credentials and business unit ID.")
        with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
            json.dump([], f)
        export_csv([])
        return

    # Determine whether we have a browser page available for sender scraping
    has_page = page is not None

    # Pass 2: fetch per-template detail for HTML body + sender config
    print(f"\n🔍 Fetching detail for {len(templates)} template(s) (body + sender info)...")
    if has_page:
        print("   Browser available — will also scrape sender/reply-to from classic UI.")
    else:
        print("   ⚠️  No browser page — sender/reply-to fields will be empty (API doesn't expose them).")
    results = []
    skipped = 0
    for i, tmpl in enumerate(templates, 1):
        tmpl_id   = tmpl.get("id")
        tmpl_name = tmpl.get("name", f"template_{tmpl_id}")
        print(f"   [{i}/{len(templates)}] {tmpl_name} (id: {tmpl_id})")

        detail = pardot_api.get_one(
            client, "objects/email-templates", tmpl_id, fields=DETAIL_FIELDS,
        )
        if detail is None:
            print(f"     ⚠️  detail read returned None — skipping")
            skipped += 1
            continue

        # Scrape sender/reply-to from classic UI (API doesn't expose these fields)
        sender_info = None
        if has_page:
            try:
                sender_info = _sender_info_from_page(page, str(tmpl_id))
            except Exception as e:
                print(f"     ⚠️  Browser sender scrape failed: {e}")

        results.append(shape_template(tmpl, detail, folder_map, campaign_map, tracker_map,
                                      sender_info=sender_info))

    # Export
    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n✅ Saved {OUTPUT_JSON} ({len(results)} template(s))")
    export_csv(results)

    if skipped:
        print(f"⚠️  {skipped} template(s) skipped (detail read failed)")

    print(f"\n✅ Email template scrape complete — {len(results)} captured, {skipped} skipped.")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()
    print("\n🚀 Pardot Email Template Scraper (v5 API)")
    print("=" * 45)

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
