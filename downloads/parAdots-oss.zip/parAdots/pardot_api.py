"""
Pardot v5 API client
=====================
Thin wrapper around the Pardot Account Engagement v5 REST API.

Auth model — browser-session token reuse
----------------------------------------
After a Playwright MFA login (the same flow utils.login() already drives),
Salesforce hands the browser a session that doubles as an OAuth Bearer
token. We lift that token straight out of the session and call the
Pardot v5 API with it.

That means:
  • No Connected App needed (no SF_CLIENT_ID / SF_CLIENT_SECRET).
  • No OAuth password grant (which Salesforce is restricting and which
    fails outright when MFA is enforced).
  • The only env vars required are PARDOT_BUSINESS_UNIT_ID and the same
    SF_LOGIN_URL / SF_USERNAME that utils.login() already uses.

Two extraction strategies (the first one that works wins):
  1. Read the `sid` cookie from the Salesforce domain. The session ID is
     a valid Bearer token for /services/data/* and for Pardot v5.
  2. Attach a network listener and capture the first `Authorization:
     Bearer …` header sent by the Lightning UI when we nudge it to a
     route that makes API calls.

Used by:
  scrape_forms_api.py, scrape_formhandlers_api.py,
  scrape_campaigns_api.py, scrape_fields_api.py
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from typing import Any, Iterable, Iterator
from urllib.parse import urlparse

import requests
from dotenv import load_dotenv
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))

# ── Config from env ───────────────────────────────────────────────────────────

# Bound at import, refreshed by refresh_config() — utils.load_org_config()
# calls it so per-org values win even when this module was imported first.
SF_LOGIN_URL    = ""
PARDOT_BU_ID    = ""
PARDOT_API_BASE = ""
SF_HOST         = ""


def refresh_config() -> None:
    """Re-read org config from os.environ. PARDOT_API_BASE defaults to
    PARDOT_HOME + /api/v5 so a demo org only has to set PARDOT_HOME."""
    global SF_LOGIN_URL, PARDOT_BU_ID, PARDOT_API_BASE, SF_HOST
    from utils import DEFAULT_PARDOT_HOME
    SF_LOGIN_URL    = os.getenv("SF_LOGIN_URL", "").rstrip("/")
    PARDOT_BU_ID    = os.getenv("PARDOT_BUSINESS_UNIT_ID", "")
    pardot_home     = (os.getenv("PARDOT_HOME") or DEFAULT_PARDOT_HOME).rstrip("/")
    PARDOT_API_BASE = (os.getenv("PARDOT_API_BASE") or pardot_home + "/api/v5").rstrip("/")
    # Salesforce host derived from SF_LOGIN_URL — used to filter cookies and
    # to nudge Lightning into making an API call so we can capture a token.
    SF_HOST = urlparse(SF_LOGIN_URL).netloc if SF_LOGIN_URL else ""


refresh_config()

DEFAULT_PAGE_SIZE = 200      # v5 max; minimizes round trips
DEFAULT_TIMEOUT   = 30       # seconds per HTTP call
RETRY_TOTAL       = 3
RETRY_BACKOFF     = 1.0      # 1s, 2s, 4s
RETRY_STATUSES    = (429, 500, 502, 503, 504)


# ── Client + session plumbing ────────────────────────────────────────────────

@dataclass
class PardotClient:
    """Carries the access token and a retry-enabled session."""
    access_token: str
    business_unit_id: str
    session: requests.Session

    def headers(self) -> dict:
        return {
            "Authorization":           f"Bearer {self.access_token}",
            "Pardot-Business-Unit-Id": self.business_unit_id,
            "Content-Type":            "application/json",
        }


def _validate_env() -> None:
    missing = [name for name, val in [
        ("SF_LOGIN_URL", SF_LOGIN_URL),
        ("PARDOT_BUSINESS_UNIT_ID", PARDOT_BU_ID),
    ] if not val or "your-" in val or "your_" in val or "0Uv000000000000" in val]
    if missing:
        print(f"❌ Missing/placeholder values in .env: {', '.join(missing)}")
        sys.exit(1)


def make_session() -> requests.Session:
    """Return a `requests.Session` with retry/backoff for transient failures."""
    sess = requests.Session()
    retry = Retry(
        total=RETRY_TOTAL,
        backoff_factor=RETRY_BACKOFF,
        status_forcelist=RETRY_STATUSES,
        allowed_methods=frozenset(["GET", "POST"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=20, pool_maxsize=20)
    sess.mount("https://", adapter)
    sess.mount("http://", adapter)
    return sess

# ── Token extraction from a logged-in browser session ────────────────────────

def _token_from_sid_cookie(page) -> str | None:
    """
    Strategy 1: read the `sid` cookie from the Salesforce domain.

    Salesforce session IDs are interchangeable with OAuth access tokens
    for REST API purposes — and that includes Pardot v5 when the
    Pardot-Business-Unit-Id header is set.
    """
    try:
        cookies = page.context.cookies()
    except Exception as e:
        print(f"   ⚠️  Could not read cookies: {e}")
        return None

    candidates = []
    for c in cookies:
        if c.get("name") != "sid":
            continue
        domain = (c.get("domain") or "").lstrip(".").lower()
        if SF_HOST and (domain == SF_HOST.lower() or domain.endswith(".salesforce.com")):
            candidates.append(c)

    if not candidates:
        return None
    # Prefer the cookie that matches the configured SF_HOST exactly
    candidates.sort(key=lambda c: 0 if (c.get("domain") or "").lstrip(".").lower() == SF_HOST.lower() else 1)
    return candidates[0].get("value")


def _token_from_network_intercept(page, timeout_ms: int = 15000) -> str | None:
    """
    Strategy 2: attach a request listener, nudge Lightning to make an API
    call, and grab the Authorization: Bearer header off the wire.

    Used when the sid cookie can't be read for any reason (custom domain
    isolation, cookie partitioning, etc.).
    """
    captured: dict[str, str] = {}

    def on_request(request):
        if captured.get("token"):
            return
        auth = request.headers.get("authorization") or request.headers.get("Authorization")
        if auth and auth.lower().startswith("bearer "):
            value = auth.split(" ", 1)[1].strip()
            # Skip obviously bogus values (e.g. literal placeholders)
            if value and "null" not in value.lower() and len(value) > 20:
                captured["token"] = value

    page.on("request", on_request)
    try:
        # Lightning home triggers /aura, /lightning/services calls with Bearer auth
        page.goto(f"{SF_LOGIN_URL}/lightning/page/home", wait_until="domcontentloaded", timeout=timeout_ms)
        # Give Lightning a moment to fire its bootstrap API calls
        page.wait_for_timeout(3000)
    except Exception as e:
        print(f"   ⚠️  Network-intercept navigation failed: {e}")
    finally:
        try:
            page.remove_listener("request", on_request)
        except Exception:
            pass

    return captured.get("token")


def extract_access_token(page) -> str:
    """
    Pull a Salesforce Bearer token out of a logged-in Playwright Page.

    Caller must have driven the browser through Salesforce login + MFA
    already (e.g. via utils.login(page)).
    """
    token = _token_from_sid_cookie(page)
    if token:
        print(f"   🔑 Token captured (sid cookie, len={len(token)})")
        return token

    print("   ↪︎ sid cookie unavailable — falling back to network interception")
    token = _token_from_network_intercept(page)
    if token:
        print(f"   🔑 Token captured (network intercept, len={len(token)})")
        return token

    print("❌ Could not extract a Salesforce access token from the browser session.")
    print("   The browser may not be fully authenticated. Re-check the login flow.")
    sys.exit(2)


def client_from_page(page) -> PardotClient:
    """
    One-call setup: validate env, extract token from a logged-in page,
    return a ready-to-use PardotClient.
    """
    _validate_env()
    token = extract_access_token(page)
    return PardotClient(
        access_token=token,
        business_unit_id=PARDOT_BU_ID,
        session=make_session(),
    )


def client_from_token(token: str) -> PardotClient:
    """
    Build a client from a token you already have (e.g. captured earlier
    in the run, or provided out-of-band for tests).
    """
    _validate_env()
    return PardotClient(
        access_token=token,
        business_unit_id=PARDOT_BU_ID,
        session=make_session(),
    )

# ── Paged GET ────────────────────────────────────────────────────────────────

def paged_get(
    client: PardotClient,
    endpoint: str,
    fields: Iterable[str] | None = None,
    extra_params: dict | None = None,
    page_size: int = DEFAULT_PAGE_SIZE,
) -> Iterator[dict]:
    """
    Yield every record from a paged v5 endpoint.

    Args:
        client:       Authenticated PardotClient
        endpoint:     Endpoint path under /api/v5 (e.g. "objects/forms")
        fields:       Field names to request. v5 ignores fields not asked for,
                      so this keeps responses small.
        extra_params: Filters or sort params (e.g. {"folderId": 42}).
        page_size:    Records per page (max 200).

    Yields:
        Each record dict in turn. Caller never sees the pagination cursor.
    """
    url    = f"{PARDOT_API_BASE}/{endpoint.lstrip('/')}"
    params = dict(extra_params or {})
    if fields:
        params["fields"] = ",".join(fields)
    params["limit"] = page_size  # v5 calls it `limit` for some endpoints; harmless if ignored

    next_token: str | None = None
    # fields value to carry into continuation pages (list-emails requires it;
    # others are fine without, but it's harmless to include it).
    fields_param = params.get("fields")

    while True:
        # Some v5 endpoints reject nextPageToken combined with limit or filter
        # params (list-emails returns 400). On continuation pages send only
        # nextPageToken + fields (fields is required by list-emails even then).
        if next_token:
            page_params: dict = {"nextPageToken": next_token}
            if fields_param:
                page_params["fields"] = fields_param
        else:
            page_params = dict(params)

        resp = client.session.get(
            url,
            headers=client.headers(),
            params=page_params,
            timeout=DEFAULT_TIMEOUT,
        )
        if resp.status_code != 200:
            print(f"⚠️  GET {endpoint} failed ({resp.status_code}): {resp.text[:300]}")
            return

        body = resp.json()
        for item in body.get("values", []):
            yield item

        next_token = body.get("nextPageToken")
        if not next_token:
            return


def get_one(
    client: PardotClient,
    endpoint: str,
    item_id: str | int,
    fields: Iterable[str] | None = None,
) -> dict | None:
    """Fetch a single record by ID. Returns the record dict or None."""
    url    = f"{PARDOT_API_BASE}/{endpoint.lstrip('/')}/{item_id}"
    params = {"fields": ",".join(fields)} if fields else {}

    resp = client.session.get(
        url, headers=client.headers(), params=params, timeout=DEFAULT_TIMEOUT,
    )
    if resp.status_code == 404:
        return None
    if resp.status_code != 200:
        print(f"⚠️  GET {endpoint}/{item_id} failed ({resp.status_code}): {resp.text[:200]}")
        return None
    return resp.json()


def lookup_map(
    client: PardotClient,
    endpoint: str,
    fields: Iterable[str],
    key: str = "id",
) -> dict[Any, dict]:
    """
    Pre-load every record from `endpoint` into a {key: record} dict.

    Use for join targets — folders, campaigns, tracker domains, layouts —
    so each form/handler doesn't trigger its own HTTP call to resolve a name.
    """
    return {item.get(key): item for item in paged_get(client, endpoint, fields=fields)}

# ── Filter helpers ───────────────────────────────────────────────────────────

def with_filter(field: str, op: str, value: Any) -> dict:
    """
    Build a v5 filter param. v5 syntax is `{field}{Op}={value}`, e.g.
      formId=42                  → with_filter("form", "Id", 42)
      idGreaterThan=100          → with_filter("id", "GreaterThan", 100)
    """
    return {f"{field}{op}": value}
