"""
Pardot Field Settings Scraper — v5 API + UI safety net for sync_behavior
=========================================================================
Pulls prospect / account / opportunity field metadata from the v5 API
and the Salesforce describe call, in the same JSON/CSV shape as the
browser-based scrape_fields.py.

Sources:
  - Prospect custom fields → /api/v5/objects/custom-fields
  - Prospect default fields → SF Lead object describe (built-in fields)
  - Account custom fields → /api/v5/objects/account-custom-fields *
  - Opportunity fields → SF Opportunity describe (Pardot doesn't expose them)
  - Sync Behavior (priority on conflict) → UI safety net per prospect field

  * Endpoint name may differ in your org; if the call 404s the script keeps
    going and reports `0 account field(s)`. Adjust ACCOUNT_FIELDS_ENDPOINT
    below if your tenant uses a different path.

Sync Behavior safety net
------------------------
The v5 API exposes raw CRM-managed flags but doesn't surface the human-
readable "Use Salesforce's value / Use Pardot's value / Use most recently
updated record's value" sentence that the legacy scraper captured. To keep
parity we do a single targeted UI visit per field:

  • Custom prospect fields → /prospectFieldCustom/read/id/{id}
    (IDs come straight from the v5 response — no extra discovery needed.)
  • Default prospect fields → /prospectFieldDefault/read/id/{id}
    (IDs discovered from /prospectField in one list-page load, then matched
    back to the SF-describe rows by field name.)

The safety net runs automatically when a Playwright `page` is provided. Set
`fill_sync_behavior=False` on run() to skip it (pure API, no browser visits).

Output (compatible with the original):
  pardot_fields.json
  pardot_fields.csv

Usage:
  python3 scrape_fields_api.py
"""

from __future__ import annotations

import csv
import json
import os
import re
import sys

from playwright.sync_api import sync_playwright

import pardot_api
import utils


OUTPUT_JSON = ""   # set at run() time via utils.output_path()
OUTPUT_CSV  = ""

# Tweak if your tenant uses a different account-fields endpoint.
ACCOUNT_FIELDS_ENDPOINT = "objects/account-custom-fields"

# Custom prospect-field columns we care about. v5 exposes more than the
# legacy scraper captured; we keep the legacy schema plus a few bonus fields.
CUSTOM_FIELD_FIELDS = [
    "id", "name",
    "fieldId",
    "type",
    "salesforceId",
    "isRecordMultipleResponses",
    "createdAt", "updatedAt",
]


def shape_custom_field(rec: dict, section: str = "Custom") -> dict:
    """Convert a v5 custom-fields record into the legacy field shape."""
    sf_field = ""
    sf_id    = rec.get("salesforceId") or ""
    # The legacy scraper stored the SF field *label* / *API name* string.
    # v5 only gives us the Salesforce custom field ID; that's still the
    # most reliable handle for cross-reference. The legacy raw label
    # was scraped out of the UI and isn't reproducible from the API.
    if sf_id:
        sf_field = sf_id

    values = rec.get("values") or []
    if isinstance(values, str):
        # Some tenants return a newline-joined string instead of a list
        values = [v.strip() for v in values.splitlines() if v.strip()]

    return {
        "section":         section,
        "name":            rec.get("name", "") or "",
        "pardot_field_id": str(rec.get("id", "")) if rec.get("id") is not None else "",
        "api_name":        rec.get("fieldId", "") or "",
        "type":            rec.get("type", "") or "",
        "sf_field":        sf_field,
        # v5 doesn't surface sync-behavior on custom fields. Leave blank
        # rather than fabricate. Legacy users who depend on it can keep
        # running scrape_fields.py for that single column.
        "sync_behavior":   "",
        "sync_raw":        "",
        "field_values":    list(values),
        # Filled by the UI safety net below (_fill_sync_behavior_from_ui),
        # same visit as sync_behavior — see utils.extract_usage_inline.
        "usage":           [],
        "updated_at":      rec.get("updatedAt", "") or "",
    }


def fetch_sf_describe(client: pardot_api.PardotClient, sobject: str) -> list[dict]:
    """
    Call /sobjects/<name>/describe on Salesforce REST.
    Returns the `fields` list (or [] on failure).
    """
    url = f"{pardot_api.SF_LOGIN_URL}/services/data/v60.0/sobjects/{sobject}/describe"
    resp = client.session.get(
        url,
        headers={
            "Authorization": f"Bearer {client.access_token}",
            "Content-Type":  "application/json",
        },
        timeout=pardot_api.DEFAULT_TIMEOUT,
    )
    if resp.status_code != 200:
        print(f"⚠️  Describe({sobject}) failed ({resp.status_code}): {resp.text[:200]}")
        return []
    return resp.json().get("fields", [])


def shape_default_prospect_from_sf(field: dict) -> dict:
    """
    Map a Salesforce describe-result field into our legacy field shape,
    used when we want default-prospect rows without the v5 prospect-fields
    endpoint (which is inconsistently available across tenants).
    """
    return {
        "section":         "Default",
        "name":            field.get("label", "") or "",
        "pardot_field_id": "",
        "api_name":        field.get("name", "") or "",
        "type":            field.get("type", "") or "",
        "sf_field":        field.get("name", "") or "",
        "sync_behavior":   "",
        "sync_raw":        "",
        "field_values":    [pv["value"] for pv in field.get("picklistValues", []) if pv.get("value")],
        "usage":           [],
        "updated_at":      "",
    }


def scrape_prospect_fields(
    client: pardot_api.PardotClient,
    page=None,
    fill_sync_behavior: bool = True,
    fill_usage: bool = True,
) -> list[dict]:
    """
    Custom prospect fields from v5 + default prospect fields from SF describe.

    If `page` is provided and `fill_sync_behavior` and/or `fill_usage` is
    True, also visit each field's UI read page to capture the Sync Behavior
    sentence and/or Usage (v5 exposes neither). Both ride the same page
    visit — set `fill_usage=False` to skip only the extra DOM work (heading
    search + pagination) usage detection adds per field, e.g. for a tenant
    with hundreds of custom fields where that's worth trimming; the sync
    behavior fill still happens on the same visit either way.
    """
    fields: list[dict] = []

    print("📋 Fetching custom prospect fields (Pardot v5)...")
    for rec in pardot_api.paged_get(
        client, "objects/custom-fields", fields=CUSTOM_FIELD_FIELDS,
    ):
        fields.append(shape_custom_field(rec, section="Custom"))
    custom_count = len(fields)
    print(f"   ✅ {custom_count} custom prospect field(s)")

    print("📋 Fetching default prospect fields (SF describe of Lead/Contact)...")
    # Pardot Prospect fields mirror SF Lead — describe Lead and tag rows as 'Default'.
    # Adjust to 'Contact' if your org maps prospects to Contact instead.
    for f in fetch_sf_describe(client, "Lead"):
        if f.get("custom"):
            continue  # custom fields are already covered above
        fields.append(shape_default_prospect_from_sf(f))
    default_count = len(fields) - custom_count
    print(f"   ✅ {default_count} default prospect field(s)")

    if page is not None and (fill_sync_behavior or fill_usage):
        _fill_sync_behavior_from_ui(page, fields, fill_sync_behavior=fill_sync_behavior, fill_usage=fill_usage)
    elif fill_sync_behavior or fill_usage:
        print("   ↪︎ Skipping sync_behavior/usage fill — no Playwright page provided.")

    return fields

# ── Sync Behavior UI safety net ──────────────────────────────────────────────

# Set True after the UI-language guard passes on the first field visited in
# a run — see _fetch_field_info_from_ui() / utils.assert_english_ui. Needed
# even for fields that only want sync_behavior: _get_value_from_lines()
# below matches the literal English "Sync Behavior" label with no bilingual
# fallback, so a non-English UI was already silently producing empty
# sync_behavior before this guard existed — not just a usage-detection risk.
_LANGUAGE_VERIFIED = False

# Section keywords used by both legacy and new logic to know when a value
# block has ended.
_SECTION_KEYS = (
    "name", "field id", "field api name", "type", "default mail merge",
    "values", "salesforce.com field", "crm field name", "sync behavior",
    "record multiple", "tags", "created at", "updated at", "created by", "updated by",
)


def _is_section_heading(line: str) -> bool:
    ll = line.lower()
    return any(ll.startswith(k) for k in _SECTION_KEYS)


def _get_value_from_lines(lines: list[str], key: str) -> str:
    """Find a tab-separated or next-line value for `key` in body text lines."""
    for i, line in enumerate(lines):
        if line.lower().startswith(key.lower()):
            parts = line.split("\t", 1)
            if len(parts) > 1 and parts[1].strip():
                return parts[1].strip()
            for j in range(i + 1, min(i + 4, len(lines))):
                if lines[j].strip() and not _is_section_heading(lines[j]):
                    return lines[j].strip()
    return ""


def _parse_sync_behavior(raw: str) -> str:
    """Reduce 'If values differ when data is synced: Use X' → 'Use X'."""
    raw = raw.strip()
    if not raw or "differ" not in raw.lower():
        return raw
    m = re.search(r":\s*(.+)$", raw)
    return m.group(1).strip() if m else raw


def _extract_values_from_lines(lines: list[str]) -> list[str]:
    """Collect all option lines listed under the 'Values' section heading."""
    values = []
    in_values = False
    for line in lines:
        ll = line.lower()
        if ll == "values":
            in_values = True
            continue
        if in_values:
            # Stop at any other section heading
            if any(ll.startswith(k) for k in _SECTION_KEYS if k != "values"):
                break
            values.append(line)
    return values


def _fetch_field_info_from_ui(page, url: str, fill_usage: bool = True) -> tuple[str, str, list[str], list[dict]]:
    """Visit a field read page, return (parsed_sync_behavior, raw_sync_text,
    field_values, usage). `usage` is [] when fill_usage=False — see
    utils.extract_usage_inline for the extraction itself and its documented
    "heading absent = 0 usages" semantics."""
    try:
        page.goto(url, wait_until="domcontentloaded", timeout=15000)
    except Exception:
        pass
    page.wait_for_timeout(600)
    try:
        body = page.evaluate("document.body.innerText") or ""
    except Exception:
        return "", "", [], []

    lines  = [l.strip() for l in body.splitlines() if l.strip()]

    # UI language guard — check ONCE per run, on the first field visited.
    # Let it propagate uncaught; callers must not swallow it as a per-item
    # scrape failure. See utils.assert_english_ui and the module note above.
    global _LANGUAGE_VERIFIED
    if not _LANGUAGE_VERIFIED:
        utils.assert_english_ui(
            lines, f"Pardot field detail page ({url})",
            fix_hint=(
                "the scraping user's Salesforce/Pardot UI language must be English "
                "for Sync Behavior and Usage detection to work (Salesforce Setup → "
                "Users → this user → Language & Locale, or the Pardot user's "
                "Account Settings)."
            ),
        )
        _LANGUAGE_VERIFIED = True

    raw    = _get_value_from_lines(lines, "Sync Behavior")
    values = _extract_values_from_lines(lines)
    usage  = utils.extract_usage_inline(page) if fill_usage else []
    return _parse_sync_behavior(raw), raw, values, usage


def _discover_default_field_ids(page) -> dict[str, str]:
    """
    Visit /prospectField once, harvest the default field read links.
    Returns {field_name_lowercase: pardot_field_id} for matching back to
    the SF-describe rows by name.
    """
    print("   ↪︎ Discovering default field IDs from /prospectField ...")
    try:
        page.goto(f"{utils.PARDOT_HOME}/prospectField",
                  wait_until="networkidle", timeout=25000)
    except Exception:
        try:
            page.goto(f"{utils.PARDOT_HOME}/prospectField",
                      wait_until="domcontentloaded", timeout=20000)
        except Exception:
            pass
    page.wait_for_timeout(2000)

    name_to_id: dict[str, str] = {}
    try:
        anchors = page.query_selector_all("a[href*='/prospectFieldDefault/read/id/']")
        for a in anchors:
            href = a.get_attribute("href") or ""
            m = re.search(r"/prospectFieldDefault/read/id/(\d+)", href)
            if not m:
                continue
            name = (a.inner_text() or "").strip().lower()
            if name and name not in name_to_id:
                name_to_id[name] = m.group(1)
    except Exception as e:
        print(f"   ⚠️  Default field discovery failed: {e}")
    print(f"   ✅ Discovered IDs for {len(name_to_id)} default field(s)")
    return name_to_id


def _fill_sync_behavior_from_ui(
    page, fields: list[dict],
    fill_sync_behavior: bool = True,
    fill_usage: bool = True,
) -> None:
    """
    Mutate `fields` in place: visit each field's UI read page and populate
    sync_behavior / sync_raw (if fill_sync_behavior) and usage (if
    fill_usage) — see utils.extract_usage_inline. Both ride the same page
    visit; fill_usage only controls the extra per-field DOM work usage
    detection adds (heading search + pagination on multi-page usage tables).

    Customs use the Pardot ID from the v5 record (`pardot_field_id`).
    Defaults use IDs discovered from the prospect-field list page, matched
    back by name (case-insensitive).
    """
    customs  = [f for f in fields if f["section"] == "Custom"  and f.get("pardot_field_id")]
    defaults = [f for f in fields if f["section"] == "Default" and not f.get("pardot_field_id")]

    what = " + ".join(filter(None, ["sync_behavior" if fill_sync_behavior else "", "usage" if fill_usage else ""]))
    print(f"\n🛟  {what} safety net — visiting {len(customs)} custom + {len(defaults)} default field page(s)")

    # ── Custom fields — straightforward, IDs from API ────────────────────────
    for i, f in enumerate(customs, 1):
        url = f"{utils.PARDOT_HOME}/prospectFieldCustom/read/id/{f['pardot_field_id']}"
        sb, raw, values, usage = _fetch_field_info_from_ui(page, url, fill_usage=fill_usage)
        if fill_sync_behavior:
            f["sync_behavior"] = sb
            f["sync_raw"]      = raw
            if values:
                f["field_values"] = values
        if fill_usage:
            f["usage"] = usage
        if i % 20 == 0:
            print(f"   [custom {i:03d}/{len(customs)}] ...")
    if customs:
        print(f"   ✅ Visited {len(customs)} custom field(s)")

    # ── Default fields — discover IDs from UI, match by name ─────────────────
    if not defaults:
        return

    name_to_id = _discover_default_field_ids(page)
    if not name_to_id:
        print("   ⚠️  No default field IDs found — leaving defaults blank")
        return

    matched = 0
    for i, f in enumerate(defaults, 1):
        # The SF describe gives us label and api_name. Pardot's UI list shows
        # the label, so match by label first, fall back to api_name.
        candidates = [f.get("name", ""), f.get("api_name", "")]
        fid = None
        for cand in candidates:
            cand_lc = cand.strip().lower()
            if cand_lc and cand_lc in name_to_id:
                fid = name_to_id[cand_lc]
                break
        if not fid:
            continue
        url = f"{utils.PARDOT_HOME}/prospectFieldDefault/read/id/{fid}"
        sb, raw, values, usage = _fetch_field_info_from_ui(page, url, fill_usage=fill_usage)
        if fill_sync_behavior:
            f["sync_behavior"] = sb
            f["sync_raw"]      = raw
            if values:
                f["field_values"] = values
        if fill_usage:
            f["usage"] = usage
        # Now we have the Pardot field ID too — store it for the CSV column
        f["pardot_field_id"] = fid
        matched += 1
        if i % 20 == 0:
            print(f"   [default {i:03d}/{len(defaults)}] ...")
    print(f"   ✅ Visited {matched}/{len(defaults)} default field(s) "
          f"({len(defaults) - matched} could not be matched by name)")


def scrape_account_fields(client: pardot_api.PardotClient) -> list[dict]:
    """
    Try the Pardot account custom-fields endpoint. If it 404s in this tenant,
    fall back to an SF Account describe so the output isn't empty.
    """
    print("\n📋 Fetching account custom fields (Pardot v5)...")
    fields: list[dict] = []
    try:
        for rec in pardot_api.paged_get(
            client, ACCOUNT_FIELDS_ENDPOINT, fields=CUSTOM_FIELD_FIELDS,
        ):
            shaped = shape_custom_field(rec, section="Custom")
            fields.append(shaped)
    except Exception as e:
        print(f"   ⚠️  {ACCOUNT_FIELDS_ENDPOINT} not reachable: {e}")

    if fields:
        print(f"   ✅ {len(fields)} account field(s) via Pardot")
        return fields

    print("   ↪︎ Falling back to SF Account describe...")
    for f in fetch_sf_describe(client, "Account"):
        if f.get("custom"):
            fields.append({
                "section":         "Custom",
                "name":            f.get("label", "") or "",
                "pardot_field_id": "",
                "api_name":        f.get("name", "") or "",
                "type":            f.get("type", "") or "",
                "sf_field":        f.get("name", "") or "",
                "sync_behavior":   "",
                "sync_raw":        "",
                "field_values":    [pv["value"] for pv in f.get("picklistValues", []) if pv.get("value")],
                "usage":           [],  # no UI visit for Account/Opportunity fields — see module note
                "updated_at":      "",
            })
    print(f"   ✅ {len(fields)} account field(s) via SF describe")
    return fields


def scrape_opportunity_fields(client: pardot_api.PardotClient) -> list[dict]:
    """Pardot v5 doesn't expose opportunity fields — pull from SF describe."""
    print("\n📋 Fetching opportunity fields (SF describe)...")
    fields = []
    for f in fetch_sf_describe(client, "Opportunity"):
        if f.get("custom"):
            fields.append({
                "section":         "Custom",
                "name":            f.get("label", "") or "",
                "pardot_field_id": "",
                "api_name":        f.get("name", "") or "",
                "type":            f.get("type", "") or "",
                "sf_field":        f.get("name", "") or "",
                "sync_behavior":   "",
                "sync_raw":        "",
                "field_values":    [pv["value"] for pv in f.get("picklistValues", []) if pv.get("value")],
                "usage":           [],  # no UI visit for Account/Opportunity fields — see module note
                "updated_at":      "",
            })
    print(f"   ✅ {len(fields)} custom opportunity field(s)")
    return fields


def export_json(results: list[dict]) -> None:
    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    total = sum(len(obj["fields"]) for obj in results)
    print(f"✅ Saved {OUTPUT_JSON} ({total} fields across {len(results)} object(s))")


_SYNC_SHORT = {
    "use salesforce's value":                      "SF wins",
    "use pardot's value":                          "Pardot wins",
    "use account engagement's value":              "Pardot wins",
    "use most recently updated record's value":    "Most Recent",
    "use most recently updated":                   "Most Recent",
}

def _shorten_sync(raw: str) -> str:
    return _SYNC_SHORT.get(raw.strip().lower(), raw.strip()) if raw.strip() else ""


def export_csv(results: list[dict]) -> None:
    headers = [
        "Object", "Section", "Field Name", "API Name",
        "Type", "Salesforce Field", "Sync Behavior",
        "Field Values", "Usage Count", "Usage",
        "Pardot Field ID", "Updated At",
    ]

    # Sort: Custom before Default within each object, then alphabetical by name
    section_order = {"Custom": 0, "Default": 1}
    rows = []
    for obj in results:
        sorted_fields = sorted(
            obj["fields"],
            key=lambda f: (section_order.get(f["section"], 9), (f["name"] or "").lower()),
        )
        for field in sorted_fields:
            values = field.get("field_values", [])
            usage  = field.get("usage") or []
            rows.append({
                "Object":          obj["object"],
                "Section":         field["section"],
                "Field Name":      field["name"],
                "API Name":        field["api_name"],
                "Type":            field["type"],
                "Salesforce Field": field["sf_field"],
                "Sync Behavior":   _shorten_sync(field.get("sync_behavior", "")),
                "Field Values":    " | ".join(values) if values else "",
                "Usage Count":     len(usage),
                "Usage":           "; ".join(f"{u.get('type','')}: {u.get('name','')}" for u in usage),
                "Pardot Field ID": field["pardot_field_id"],
                "Updated At":      field["updated_at"],
            })

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
        w.writeheader()
        prev_obj = None
        for row in rows:
            # Blank separator row between objects for visual grouping
            if prev_obj and row["Object"] != prev_obj:
                w.writerow({h: "" for h in headers})
            w.writerow(row)
            prev_obj = row["Object"]

    total = sum(len(obj["fields"]) for obj in results)
    print(f"✅ Saved {OUTPUT_CSV} ({total} rows)")


def run(
    page=None,
    client: pardot_api.PardotClient | None = None,
    fill_sync_behavior: bool = True,
    fill_usage: bool = True,
) -> None:
    """
    Two call modes:
      - run(page=page)              → extract token + use the same page for
                                      the sync_behavior/usage safety net.
      - run(client=client)          → API-only; sync_behavior/usage stay empty.
      - run(page=p, client=c)       → reuse a token captured earlier AND
                                      keep the safety net running.

    Set `fill_sync_behavior=False` and/or `fill_usage=False` to skip either
    part of the safety net even when a page is available (pure-API fast
    path; the corresponding field(s) come out empty). Both ride the same
    per-field page visit — see scrape_prospect_fields().
    """
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_fields.json")
    OUTPUT_CSV  = utils.output_path("pardot_fields.csv")

    print("\n🚀 Pardot Field Settings Scraper (v5 API + UI safety net)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    results = []

    print("\n" + "=" * 50)
    print("OBJECT: Prospect Fields")
    print("=" * 50)
    try:
        prospect_fields = scrape_prospect_fields(
            client,
            page=page,
            fill_sync_behavior=fill_sync_behavior,
            fill_usage=fill_usage,
        )
    except utils.UnexpectedUILanguageError as e:
        print(str(e))
        sys.exit(1)
    results.append({"object": "Prospect", "fields": prospect_fields})

    print("\n" + "=" * 50)
    print("OBJECT: Account Fields")
    print("=" * 50)
    results.append({"object": "Account", "fields": scrape_account_fields(client)})

    print("\n" + "=" * 50)
    print("OBJECT: Opportunity Fields")
    print("=" * 50)
    results.append({"object": "Opportunity", "fields": scrape_opportunity_fields(client)})

    print()
    export_json(results)
    export_csv(results)


def main() -> None:
    utils.load_org_config()
    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
