"""
Fetch running/paused status for each automation rule from the list page,
then merge it into pardot_automation_rules.json and re-export the CSV.
"""

import json, os, re, sys
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright

import utils

JSON_FILE = ""   # set at run() time via utils.output_path()
CSV_FILE  = ""

# ── Auth ──────────────────────────────────────────────────────────────────────

def login(page):
    print(f"🔐 Logging into {utils.SF_LOGIN_URL}...")
    page.goto(utils.SF_LOGIN_URL)
    page.wait_for_timeout(2000)
    try:
        page.fill("#username", utils.SF_USERNAME)
        page.fill("#password", utils.get_password())
        page.click("#Login")
    except Exception:
        pass

    # Wait for MFA approval (30 s) — require Salesforce UI to be rendered
    print("   Waiting for MFA approval (approve on your device)...")
    SF_SESSION_SELECTORS = [
        ".slds-global-header", "#brandBand", "one-app-nav-bar",
        "a[title='App Launcher']", ".appLauncher", "one-app-launcher-header",
    ]
    MFA_KEYWORDS = ("login", "identity", "verification", "challenge", "mfa", "two-factor")
    for _ in range(15):   # 15 × 2 s = 30 s
        page.wait_for_timeout(2000)
        url = page.url.lower()
        if utils.is_pardot_url(url) and "login" not in url:
            break
        if "salesforce.com" in url and not any(k in url for k in MFA_KEYWORDS):
            def sf_ui_present():
                for s in SF_SESSION_SELECTORS:
                    try:
                        if page.query_selector(s):
                            return True
                    except Exception:
                        pass
                return False
            if sf_ui_present():
                break
    else:
        print("⚠️  Timed out waiting for MFA — proceeding anyway.")

    print("   Navigating to Pardot...")
    page.goto(utils.PARDOT_HOME, wait_until="networkidle", timeout=20000)
    page.wait_for_timeout(2000)
    _click_salesforce_login_if_prompted(page)

    print("   Waiting for Pardot dashboard...")
    for _ in range(15):
        page.wait_for_timeout(2000)
        url = page.url.lower()
        if utils.is_pardot_url(url) and "login" not in url:
            if utils.pardot_dashboard_ready(page):
                break
    else:
        print("⚠️  Timed out waiting for dashboard — proceeding anyway.")

    print("   ✅ Logged in")


def _click_salesforce_login_if_prompted(page):
    """Click 'Log in with Salesforce' if Pardot shows its login chooser page."""
    for selector in [
        "a:has-text('Log in with Salesforce')",
        "button:has-text('Log in with Salesforce')",
        "a:has-text('Login with Salesforce')",
        "button:has-text('Login with Salesforce')",
        "[data-id='sfdc'] a",
        "a[href*='salesforce'][href*='login']",
    ]:
        try:
            el = page.query_selector(selector)
            if el and el.is_visible():
                print("   🔗 Pardot login prompt detected — clicking 'Log in with Salesforce'...")
                before_url = page.url
                el.click()
                try:
                    page.wait_for_function(
                        f"() => window.location.href !== {repr(before_url)}",
                        timeout=15000,
                    )
                except Exception:
                    pass
                page.wait_for_timeout(3000)
                return
        except Exception:
            continue

# ── Fetch status from list page ───────────────────────────────────────────────

def fetch_statuses(page):
    """
    Returns dict {rule_id: "Running"|"Paused"|"Unknown"}
    The automation list page shows a status badge/icon per row.
    We look at the row containing each rule's link and check for
    Status text or icon classes: 'running'/'active'/'paused'/'inactive'.
    """
    print("\n📋 Loading automation list page...")
    page.goto(utils.PARDOT_HOME + "/automation", wait_until="networkidle", timeout=20000)
    page.wait_for_timeout(3000)

    # Scroll to load all rows
    for _ in range(6):
        try:
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(800)
        except Exception:
            break

    page.screenshot(path="screenshots/automations/status_list_page.png", full_page=True)

    statuses = {}

    # Strategy 1: extract full table HTML and parse rows
    html = page.content()

    # Try to find table rows with id links and status
    # Pardot list tables typically have <tr> with an anchor + a status <td>
    rows = page.query_selector_all("tr")
    for row in rows:
        text = (row.inner_text() or "").lower()
        href_el = row.query_selector("a[href*='/automation/read/id/']")
        if not href_el:
            continue
        href = href_el.get_attribute("href") or ""
        m = re.search(r'/automation/read/id/(\d+)', href)
        if not m:
            continue
        rule_id = m.group(1)

        # Determine status from row text or icon
        status = _parse_status_from_row(row, text)
        statuses[rule_id] = status
        print(f"   {rule_id}: {status}")

    if not statuses:
        print("   ⚠️  No statuses found via rows — trying full-page text extraction")
        statuses = _fallback_status(page)

    print(f"\n   ✅ Fetched status for {len(statuses)} rules")
    return statuses

def _parse_status_from_row(row, text_lower):
    # Pardot shows "[Paused]" badge in the name cell for paused rules.
    # Active/running rules have no badge — absence means Running.
    # Avoid generic "active"/"running" keyword checks: they produce false
    # positives when rule names contain those words (e.g. "IsActive").
    if "[paused]" in text_lower:
        return "Paused"
    return "Running"

def _fallback_status(page):
    """
    Dump full body text and try to pair rule IDs with status words nearby.
    """
    statuses = {}
    # Try reading each rule's detail page for a status indicator
    data = json.load(open(JSON_FILE, encoding="utf-8"))
    print("   Checking each rule detail page for status indicator...")
    for r in data:
        rule_id = r["id"]
        url = f"{utils.PARDOT_HOME}/automation/read/id/{rule_id}"
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=12000)
            page.wait_for_timeout(1500)
            body = page.evaluate("document.body.innerText") or ""
            # Drop the Prospects / Usages tables — a prospect named "Active"
            # would otherwise false-positive the status detection below.
            body = utils.truncate_at_prospects(body)
            body_lower = body.lower()
            if any(w in body_lower for w in ["running", "active"]):
                statuses[rule_id] = "Running"
            elif any(w in body_lower for w in ["paused", "inactive"]):
                statuses[rule_id] = "Paused"
            else:
                # Check page title bar / action buttons
                # "Pause" button = currently Running; "Start" button = currently Paused
                has_pause_btn = bool(page.query_selector(
                    "a:has-text('Pause'), button:has-text('Pause')"
                ))
                has_start_btn = bool(page.query_selector(
                    "a:has-text('Start'), button:has-text('Start')"
                ))
                if has_pause_btn:
                    statuses[rule_id] = "Running"
                elif has_start_btn:
                    statuses[rule_id] = "Paused"
                else:
                    statuses[rule_id] = "Unknown"
            print(f"   {rule_id} ({r['name'][:40]}): {statuses[rule_id]}")
        except Exception as e:
            print(f"   ⚠️  {rule_id}: error — {e}")
            statuses[rule_id] = "Unknown"
    return statuses

# ── Merge & export ────────────────────────────────────────────────────────────

def merge_and_export(statuses):
    data = json.load(open(JSON_FILE, encoding="utf-8"))
    for r in data:
        r["status"] = statuses.get(r["id"], "Unknown")

    with open(JSON_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"\n✅ Updated {JSON_FILE} with status field")

    # Re-export CSV — sections are already clean \n-separated strings from scrape_automations.py
    import csv

    def get_val(text, *keys):
        for line in text.splitlines():
            for key in keys:
                if line.lower().startswith(key.lower()):
                    parts = line.split(" → ", 1)
                    return parts[1].strip() if len(parts) > 1 else ""
        return ""

    with open(CSV_FILE, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(["#", "Rule Name", "Rule ID", "Status", "Match Type",
                    "Repeat", "Real-time",
                    "Prospects Matched",
                    "Rules (Criteria)", "Actions"])
        for i, r in enumerate(data, 1):
            s = r["sections"]
            match_type = get_val(s["content"], "Match Type")
            repeat     = get_val(s["content"], "Repeat")
            real_time  = "Yes" if "real-time" in s["content"].lower() else "No"
            w.writerow([
                i, r["name"], r["id"], r.get("status", "Unknown"),
                match_type, repeat, real_time,
                r.get("prospect_count", ""),
                s["rules"],
                s["actions"],
            ])

    print(f"✅ Updated {CSV_FILE} with Status column")

# ── Run (browser-agnostic entry point) ───────────────────────────────────────

def run(page):
    """Fetch statuses and re-export — no browser lifecycle management."""
    global JSON_FILE, CSV_FILE
    JSON_FILE = utils.output_path("pardot_automation_rules.json")
    CSV_FILE  = utils.output_path("pardot_automation_rules.csv")
    statuses = fetch_statuses(page)
    merge_and_export(statuses)

# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    utils.load_org_config()
    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=100)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            login(page)
            run(page)
        finally:
            context.close()
