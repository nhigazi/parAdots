"""
Pardot User Scraper — v5 API
==============================
Pulls all Pardot users from /api/v5/objects/users.

Security/governance focus (revised 2026-07-02 — see below):
  • Which users have admin or marketing-admin roles?
  • Are there deleted/recycled accounts?

Fixed 2026-07-02: LIST_FIELDS had 4 field names that don't exist on the v5
`objects/users` object — `lastName`, `isActive`, `isSsoUser`, `lastLoginAt`.
A single invalid field 400s the whole request; pardot_api.paged_get()
swallows that silently, so this scraper also produced a false "0 users"
(same failure mode as scrape_list_emails.py and scrape_folders.py, same
06-30 batch). Confirmed against the official docs:
https://developer.salesforce.com/docs/marketing/pardot/guide/user-v5.html

IMPORTANT — capability loss, not just a rename: the v5 User object simply
does not expose Active/Inactive status, SSO vs. password login, or last
login time at all. The original "governance" pitch of this scraper (stale
accounts, SSO audit, never-logged-in users) is NOT achievable via this
endpoint — there is no known v5 substitute. What IS available: email,
firstName, username, jobTitle, role, roleName, isDeleted (recycle bin),
salesforceId, createdAt/updatedAt, createdBy/updatedBy. Flags reduced
accordingly; re-add SSO/last-login only if a different endpoint is found.

Captured fields:
  id, email, firstName, username, jobTitle, role, roleName,
  isDeleted, salesforceId, createdAt, updatedAt

Output:
  pardot_users.json
  pardot_users.csv

Usage (standalone):
  python3 scrape_users.py

Called from run_all.py:
  from scrape_users import run
  run(page=page)
"""

from __future__ import annotations

import csv
import sys
from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""

LIST_FIELDS = [
    "id", "email", "firstName", "username", "jobTitle",
    "role", "roleName", "isDeleted",
    "salesforceId", "createdAt", "updatedAt",
]


# ── Shaping ───────────────────────────────────────────────────────────────────

def shape_user(u: dict) -> dict:
    role         = u.get("roleName", "") or u.get("role", "") or ""
    is_admin     = "admin" in role.lower()
    is_deleted   = bool(u.get("isDeleted", False))

    flags = []
    if is_deleted:
        flags.append("DELETED")
    if is_admin:
        flags.append("ADMIN")

    return {
        "id":              str(u.get("id", "")),
        "email":           u.get("email", "") or "",
        "first_name":      u.get("firstName", "") or "",
        "username":        u.get("username", "") or "",
        "job_title":       u.get("jobTitle", "") or "",
        "role":            role,
        "is_admin":        is_admin,
        "is_deleted":      is_deleted,
        "salesforce_id":   u.get("salesforceId") or "",
        "created_at":      u.get("createdAt", "") or "",
        "updated_at":      u.get("updatedAt", "") or "",
        "flags":           " | ".join(flags),
    }


# ── Export ────────────────────────────────────────────────────────────────────

def export_csv(results: list[dict]) -> None:
    headers = [
        "#", "Email", "First Name", "Username", "Job Title", "Role",
        "Admin", "Deleted",
        "Salesforce ID", "Created At", "Flags",
    ]
    rows = [
        [
            i + 1,
            r["email"],
            r["first_name"],
            r["username"],
            r["job_title"],
            r["role"],
            "Yes" if r["is_admin"] else "No",
            "Yes" if r["is_deleted"] else "No",
            r["salesforce_id"],
            r["created_at"],
            r["flags"],
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_users.json")
    OUTPUT_CSV  = utils.output_path("pardot_users.csv")

    print("\n👤 Pardot User Scraper (v5 API)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    print("📋 Fetching users...")
    users_raw = list(pardot_api.paged_get(client, "objects/users", fields=LIST_FIELDS))
    print(f"   ✅ {len(users_raw)} user(s) found")

    if not users_raw:
        utils.save_json([], OUTPUT_JSON)
        export_csv([])
        return

    results = [shape_user(u) for u in users_raw]
    utils.save_json(results, OUTPUT_JSON)
    export_csv(results)

    # ── Summary / flags ───────────────────────────────────────────────────────
    # Note: Active/Inactive, SSO, and last-login are NOT available on the v5
    # User object — dropped from this scraper (see module docstring).
    admins    = [r for r in results if r["is_admin"]]
    deleted   = [r for r in results if r["is_deleted"]]

    print(f"\n── User summary ─────────────────────────")
    print(f"   Total users      : {len(results)}")
    print(f"   Admins           : {len(admins)}")
    print(f"   Deleted (recycle bin): {len(deleted)}")

    if admins:
        print(f"\n   🔑 Admin users:")
        for r in admins:
            print(f"      • {r['email']} ({r['role']})")

    print(f"\n✅ User scrape complete — {len(results)} user(s).")


# ── Standalone ────────────────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
