"""
Pardot Automation Rule Scraper
================================
Navigates to each automation rule's read page, scrolls through the full page,
takes 3 screenshots (top / rules / actions), and extracts 3 content sections:

  1. CONTENT  – match type + repetition settings
  2. RULES    – filter criteria (field / operator / value)
  3. ACTIONS  – what happens when rules match

URL format confirmed: <PARDOT_HOME>/automation/read/id/<id>
No tab clicking needed — full page loads at once.

Usage:
  python3 scrape_automations.py
"""

import json, os, re, sys, time
import requests
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright

import utils

OUTPUT_FILE = ""   # set at run() time via utils.output_path()
SCREENSHOTS = ""

# ── Validate ──────────────────────────────────────────────────────────────────

def validate_config():
    if not utils.SF_USERNAME:
        print("❌ Missing SF_USERNAME in .env")
        sys.exit(1)


# ── Discover automation rules ─────────────────────────────────────────────────

def discover_automations(page):
    print("\n📋 Discovering automation rules...")
    rules = []
    seen = set()

    try:
        page.goto(utils.PARDOT_HOME + "/automation", wait_until="networkidle", timeout=20000)
    except Exception:
        page.goto(utils.PARDOT_HOME + "/automation", wait_until="domcontentloaded", timeout=20000)

    # Scroll to load all rows
    for _ in range(5):
        try:
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(800)
        except Exception:
            break

    # Screenshot the list page for reference
    page.screenshot(path=f"{SCREENSHOTS}/automation_list.png", full_page=True)

    # Collect rows: id, name, and prospect_count from the list table.
    # The link is in the NAME cell; PROSPECTS MATCHED is the next cell.
    row_data = page.evaluate("""() => {
        return Array.from(document.querySelectorAll('a[href*="/automation/read/id/"]'))
            .map(link => {
                const href = link.getAttribute('href');
                const m = href.match(/\\/automation\\/read\\/id\\/(\\d+)/);
                if (!m) return null;
                const row = link.closest('tr');
                if (!row) return null;
                const cells = Array.from(row.querySelectorAll('td'));
                const linkCell = link.closest('td');
                const idx = cells.indexOf(linkCell);
                const prospectsCell = cells[idx + 1];
                const repeatCell    = cells[idx + 2];
                // Pardot shows "[Paused]" badge in the name cell for paused rules.
                // Active/running rules have no status badge — absence means Running.
                const rowText = row.innerText || '';
                const status  = rowText.toLowerCase().includes('[paused]') ? 'Paused' : 'Running';
                return {
                    id:              m[1],
                    name:            link.innerText.trim(),
                    prospect_count:  prospectsCell ? prospectsCell.innerText.trim() : '',
                    repeat_list:     repeatCell    ? repeatCell.innerText.trim()    : '',
                    status:          status,
                };
            }).filter(r => r && r.id && r.name);
    }""")
    for row in row_data:
        if row["id"] not in seen:
            seen.add(row["id"])
            rules.append(row)

    # Fallback: parse HTML for IDs if anchors weren't found
    if not rules:
        html = page.content()
        for m in re.finditer(r'/automation/read/id/(\d+)', html):
            rule_id = m.group(1)
            if rule_id not in seen:
                seen.add(rule_id)
                rules.append({"id": rule_id, "name": f"Rule {rule_id}"})

    # Paginate — Pardot shows 50 items per page
    extra, _ = utils.paginate_collect(page, r'/automation/read/id/(\d+)', seen)
    rules.extend(extra)

    print(f"   ✅ Found {len(rules)} automation rule(s)")
    return rules

# ── Scrape a single automation rule ──────────────────────────────────────────

def scrape_rule(page, rule_id, rule_name):
    url = f"{utils.PARDOT_HOME}/automation/read/id/{rule_id}"
    try:
        page.goto(url, wait_until="networkidle", timeout=15000)
    except Exception:
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=15000)
        except Exception:
            pass
    try:
        page.wait_for_selector("h2.additional-fields, .automation-detail, #content",
                               timeout=8000)
    except Exception:
        pass

    # ── Screenshot 1: Top of page (name, status, match type, repetition) ──────
    page.evaluate("window.scrollTo(0, 0)")
    page.wait_for_timeout(500)
    page.screenshot(path=f"{SCREENSHOTS}/rule_{rule_id}_1_top.png")

    # ── Scroll to middle — rules section ──────────────────────────────────────
    page.evaluate("""() => {
        const el = Array.from(document.querySelectorAll('*')).find(
            e => e.innerText && e.innerText.trim().startsWith('Rules') && e.children.length > 1
        );
        if (el) el.scrollIntoView({ behavior: 'instant', block: 'start' });
        else window.scrollTo(0, document.body.scrollHeight * 0.4);
    }""")
    page.wait_for_timeout(500)
    page.screenshot(path=f"{SCREENSHOTS}/rule_{rule_id}_2_rules.png")

    # ── Scroll to bottom — actions section ────────────────────────────────────
    page.evaluate("""() => {
        const el = Array.from(document.querySelectorAll('*')).find(
            e => e.innerText && e.innerText.trim().startsWith('Actions')
        );
        if (el) el.scrollIntoView({ behavior: 'instant', block: 'start' });
        else window.scrollTo(0, document.body.scrollHeight);
    }""")
    page.wait_for_timeout(500)
    page.screenshot(path=f"{SCREENSHOTS}/rule_{rule_id}_3_actions.png")

    # ── Extract metadata via page text ───────────────────────────────────────
    try:
        full_text = page.evaluate("() => document.body.innerText")
    except Exception:
        return {"content": "", "rules": "", "actions": ""}

    lines = [l.strip() for l in full_text.splitlines() if l.strip()]

    contents_idx = next((i for i, l in enumerate(lines) if l.lower() == "contents"), None)
    rules_idx    = next((i for i, l in enumerate(lines)
                         if l.lower() == "rules"
                         and (contents_idx is None or i > contents_idx)), None)

    c_start = (contents_idx + 1) if contents_idx is not None else 0
    c_end   = rules_idx if rules_idx is not None else len(lines)
    content_meta_lines = lines[c_start:c_end]

    KNOWN_LABELS = {
        "name", "description", "match type", "repetition", "repeat",
        "status", "real-time", "is active", "created at", "updated at",
        "created by", "updated by",
    }
    formatted_meta = []
    i = 0
    while i < len(content_meta_lines):
        line = content_meta_lines[i]
        if "\t" in line:
            formatted_meta.append(line.replace("\t", " → "))
            i += 1
        elif i + 1 < len(content_meta_lines) and content_meta_lines[i + 1].split("\t")[0].lower() not in KNOWN_LABELS:
            formatted_meta.append(f"{line} → {content_meta_lines[i + 1]}")
            i += 2
        else:
            formatted_meta.append(line)
            i += 1
    content_text = "\n".join(formatted_meta).strip()

    # ── DOM-based extraction for Rules and Actions ────────────────────────────
    # Pardot renders section headings as <h2 class="additional-fields"> with
    # the next sibling being <table class="table-bordered"> for that section.
    try:
        dom_sections = page.evaluate("""() => {
            function tableRows(table) {
                if (!table) return [];
                const rows = [];
                for (const tr of table.querySelectorAll('tr')) {
                    const cells = Array.from(tr.querySelectorAll('td'));
                    if (cells.length < 2) continue;
                    const left  = cells[0].innerText.replace(/\\s+/g, ' ').trim();
                    const right = cells[1].innerText.replace(/\\s+/g, ' ').trim();
                    if (left && right) rows.push(left + '\\t' + right);
                }
                return rows;
            }

            function nextSiblingTable(el) {
                let sib = el ? el.nextElementSibling : null;
                while (sib) {
                    if (sib.tagName === 'TABLE') return sib;
                    const inner = sib.querySelector('table');
                    if (inner) return inner;
                    sib = sib.nextElementSibling;
                }
                return null;
            }

            function extractSection(headingText) {
                const heading = Array.from(document.querySelectorAll('h2.additional-fields'))
                    .find(h => h.textContent.trim().toLowerCase() === headingText.toLowerCase());
                return tableRows(nextSiblingTable(heading)).join('\\n');
            }

            return {
                rules:   extractSection('Rules'),
                actions: extractSection('Actions'),
            };
        }""")
    except Exception:
        dom_sections = {"rules": "", "actions": ""}

    return {
        "content": content_text,
        "rules":   (dom_sections.get("rules")   or "").strip(),
        "actions": (dom_sections.get("actions") or "").strip(),
    }

# ── Export to CSV ─────────────────────────────────────────────────────────────

def export_csv(results):
    import csv, re
    csv_path = "pardot_automation_rules.csv"

    def get_val(text, *keys):
        for line in text.splitlines():
            for key in keys:
                if line.lower().startswith(key.lower()):
                    parts = line.split(" → ", 1)
                    return parts[1].strip() if len(parts) > 1 else ""
        return ""

    def get_match_type(content):
        # "Match Type → Match all/any" or embedded "… Match Type\tMatch all/any"
        m = re.search(r'match type[\s\t→]+(match (?:all|any))', content, re.IGNORECASE)
        return m.group(1) if m else get_val(content, "Match Type")

    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(["#", "Rule Name", "Rule ID", "Status",
                         "Match Type", "Repeat", "Real-time",
                         "Prospect Count",
                         "Rules (Criteria)", "Actions"])
        for i, r in enumerate(results, 1):
            s = r["sections"]
            match_type = get_match_type(s["content"])
            repeat     = get_val(s["content"], "Repeat")
            real_time  = "Yes" if "real-time" in s["content"].lower() else "No"
            writer.writerow([
                i,
                r["name"],
                r["id"],
                r.get("status", ""),
                match_type,
                repeat,
                real_time,
                r.get("prospect_count", ""),
                (f"[{match_type}]\n" + s["rules"]) if s["rules"] else "",
                s["actions"],
            ])
    print(f"   ✅ CSV saved to {csv_path}")

# ── Run (browser-agnostic entry point) ───────────────────────────────────────

def run(page):
    """Discover, scrape, and export — no browser lifecycle management."""
    global OUTPUT_FILE, SCREENSHOTS
    OUTPUT_FILE = utils.output_path("pardot_automation_rules.json")
    SCREENSHOTS = utils.output_path("screenshots", "automations")
    utils.reset_screenshots(SCREENSHOTS)
    results = []
    rules = discover_automations(page)

    if not rules:
        print("❌ No automation rules found.")
        return

    print(f"\n🔍 Scraping {len(rules)} automation rule(s)...")
    for i, rule in enumerate(rules, 1):
        print(f"   [{i}/{len(rules)}] {rule['name']} (id: {rule['id']})")
        scraped = scrape_rule(page, rule["id"], rule["name"])
        results.append({
            "id":              rule["id"],
            "name":            rule["name"],
            "status":          rule.get("status", "Running"),
            "prospect_count":  rule.get("prospect_count", ""),
            "sections": {
                "content": scraped["content"],
                "rules":   scraped["rules"],
                "actions": scraped["actions"],
            },
        })
        time.sleep(1)

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"\n✅ JSON saved to {OUTPUT_FILE}")

    export_csv(results)

    print("\n── Summary ──────────────────────────────────────")
    for r in results:
        print(f"\n📋 {r['name']} (id: {r['id']})")
        if r["sections"]["content"]:
            print(f"   CONTENT : {r['sections']['content'][:80]}")
        if r["sections"]["rules"]:
            print(f"   RULES   : {r['sections']['rules'][:80]}")
        if r["sections"]["actions"]:
            print(f"   ACTIONS : {r['sections']['actions'][:80]}")

    print(f"\n💡 Screenshots saved in: {SCREENSHOTS}/")
    print(f"   3 per rule: _1_top.png  _2_rules.png  _3_actions.png")

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    utils.load_org_config()
    validate_config()
    print("\n🚀 Pardot Automation Rule Scraper")
    print("=" * 45)

    with sync_playwright() as pw:
        context = utils.launch_context(pw)
        page    = context.new_page()
        try:
            utils.login(page)
            run(page)
        finally:
            context.close()

if __name__ == "__main__":
    main()
