"""
SF Scraper 7 — Account / Corporation Hierarchy
================================================
Queries Account records to validate the brand/Corporation structure
that Pardot's segmentation logic depends on.

Captures:
  • Account count by Corporation__c / Name pattern (ACM/GLB/INI)
  • Country and billing country distribution per brand
  • Accounts with no associated Contacts (dead accounts Pardot can't target)
  • Accounts with Contact but no opt-in (marketing gap)
  • Z_CRM_Language__c distribution on Contacts per Account group

This validates whether Corporation field values in Pardot actually map
to Account names in SF — mismatches explain why the brand filter in
scrape_prospect_stats.py may return unexpected counts.

Output:
  sf_account_hierarchy.json
  sf_account_hierarchy.csv

Called from run_sf.py / run_all.py:
  from scrape_sf_account_hierarchy import run
  run(page=page)
"""
from __future__ import annotations
import csv, json, sys
import salesforce_api as sf
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""


def run(page=None, client: sf.SalesforceClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("sf_account_hierarchy.json")
    OUTPUT_CSV  = utils.output_path("sf_account_hierarchy.csv")

    print("\n🚀 SF Scraper 7 — Account / Corporation Hierarchy")
    print("=" * 50)

    if client is None:
        if page is None:
            print("❌ Need page or client"); sys.exit(1)
        client = sf.client_from_page(page)

    account_fields = sf.field_names(client, "Account")
    contact_fields = sf.field_names(client, "Contact")

    has_corp_acct = "Corporation__c" in account_fields
    has_corp_cont = "Corporation__c" in contact_fields
    has_lang_cont = "Z_CRM_Language__c" in contact_fields

    # ── Account overview ──────────────────────────────────────────────────────
    print("🏢 Account overview...")
    total_accts = sf.soql_count(client, "SELECT COUNT() FROM Account")
    no_contacts = sf.soql_count(client,
        "SELECT COUNT() FROM Account WHERE NumberOfEmployees = null "
        "AND (SELECT Id FROM Contacts) = null"
    ) if "NumberOfEmployees" in account_fields else sf.soql_count(client,
        "SELECT COUNT() FROM Account WHERE Id NOT IN "
        "(SELECT AccountId FROM Contact WHERE AccountId != null)"
    )
    print(f"   Total accounts       : {total_accts:,}")
    print(f"   Accounts no contacts : {no_contacts:,}")

    # ── Account by Industry ───────────────────────────────────────────────────
    print("\n🏭 Account breakdown by Industry...")
    industry_rows = sf.soql_all(client,
        "SELECT Industry, COUNT(Id) cnt FROM Account GROUP BY Industry ORDER BY COUNT(Id) DESC LIMIT 20"
    )
    industry_dist = [{"industry": (r.get("Industry") or "(blank)"),
                      "count": r.get("cnt") or r.get("expr0") or 0} for r in industry_rows]
    for i in industry_dist[:8]:
        print(f"   {i['industry']:<35} {i['count']:,}")

    # ── Account by Billing Country ────────────────────────────────────────────
    print("\n🌍 Account breakdown by BillingCountry...")
    country_rows = sf.soql_all(client,
        "SELECT BillingCountry, COUNT(Id) cnt FROM Account "
        "GROUP BY BillingCountry ORDER BY COUNT(Id) DESC LIMIT 20"
    )
    country_dist = [{"country": (r.get("BillingCountry") or "(blank)"),
                     "count": r.get("cnt") or r.get("expr0") or 0} for r in country_rows]
    for c in country_dist[:8]:
        print(f"   {c['country']:<35} {c['count']:,}")

    # ── Corporation field on Account ──────────────────────────────────────────
    corp_acct_dist = []
    if has_corp_acct:
        print("\n🏷️  Account Corporation__c distribution...")
        corp_rows = sf.soql_all(client,
            "SELECT Corporation__c, COUNT(Id) cnt FROM Account "
            "GROUP BY Corporation__c ORDER BY COUNT(Id) DESC LIMIT 30"
        )
        corp_acct_dist = [{"corporation": (r.get("Corporation__c") or "(blank)"),
                           "count": r.get("cnt") or r.get("expr0") or 0} for r in corp_rows]
        for c in corp_acct_dist[:10]:
            print(f"   {c['corporation']:<35} {c['count']:,}")
    else:
        print("\n   ⚠️  Corporation__c not on Account")

    # ── Contact language distribution ─────────────────────────────────────────
    lang_dist = []
    if has_lang_cont:
        print("\n🌐 Contact Z_CRM_Language__c distribution...")
        lang_rows = sf.soql_all(client,
            "SELECT Z_CRM_Language__c, COUNT(Id) cnt FROM Contact "
            "GROUP BY Z_CRM_Language__c ORDER BY COUNT(Id) DESC LIMIT 20"
        )
        lang_dist = [{"language": (r.get("Z_CRM_Language__c") or "(blank)"),
                      "count": r.get("cnt") or r.get("expr0") or 0} for r in lang_rows]
        for l in lang_dist[:8]:
            print(f"   {l['language']:<35} {l['count']:,}")
    else:
        print("\n   ⚠️  Z_CRM_Language__c not on Contact")

    # ── Contacts with no opt-in for any brand ─────────────────────────────────
    optin_on_contact = [f for f in sf.OPTIN_FIELDS if f in contact_fields]
    no_optin_contacts = -1
    if optin_on_contact:
        null_cond = " AND ".join(f"{f} = false OR {f} = null" for f in optin_on_contact)
        no_optin_contacts = sf.soql_count(client,
            f"SELECT COUNT() FROM Contact WHERE ({null_cond})"
        )
        print(f"\n📭 Contacts with no brand opt-in: {no_optin_contacts:,}")

    output = {
        "total_accounts":          total_accts,
        "accounts_no_contacts":    no_contacts,
        "industry_distribution":   industry_dist,
        "country_distribution":    country_dist,
        "corporation_distribution": corp_acct_dist,
        "language_distribution":   lang_dist,
        "contacts_no_optin":       no_optin_contacts,
        "field_presence": {
            "Corporation__c_on_Account": has_corp_acct,
            "Corporation__c_on_Contact": has_corp_cont,
            "Z_CRM_Language__c_on_Contact": has_lang_cont,
        },
    }

    utils.save_json(output, OUTPUT_JSON)
    _export_csv(output)
    print(f"\n✅ Account hierarchy scrape complete.")


def _export_csv(output):
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)

        w.writerow(["=== ACCOUNT SUMMARY ==="])
        w.writerow(["Total accounts",          output["total_accounts"]])
        w.writerow(["Accounts without contacts", output["accounts_no_contacts"]])
        w.writerow(["Contacts with no opt-in",   output["contacts_no_optin"]])

        for section, key, col in [
            ("INDUSTRY", "industry_distribution", "industry"),
            ("BILLING COUNTRY", "country_distribution", "country"),
            ("CORPORATION", "corporation_distribution", "corporation"),
            ("CONTACT LANGUAGE", "language_distribution", "language"),
        ]:
            data = output.get(key, [])
            if data:
                w.writerow([])
                w.writerow([f"=== {section} ==="])
                w.writerow([col.title(), "Count"])
                for item in data:
                    w.writerow([item.get(col,""), item.get("count",0)])

    print(f"✅ Exported {OUTPUT_CSV}")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
