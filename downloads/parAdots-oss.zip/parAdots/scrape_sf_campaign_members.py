"""
SF Scraper 1 — Campaign Member Attribution
===========================================
Queries CampaignMember to show how many Leads/Contacts were touched
by each campaign and what the outcome was (Responded, Sent, etc.).

Closes the gap: "only 30% of key assets linked to a campaign" — this
tells you whether the campaigns that ARE linked are generating outcomes.

Output:
  sf_campaign_members.json
  sf_campaign_members.csv

Called from run_sf.py / run_all.py:
  from scrape_sf_campaign_members import run
  run(page=page)
"""
from __future__ import annotations
import csv, json, sys
from playwright.sync_api import sync_playwright
import salesforce_api as sf
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""


def run(page=None, client: sf.SalesforceClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("sf_campaign_members.json")
    OUTPUT_CSV  = utils.output_path("sf_campaign_members.csv")

    print("\n🚀 SF Scraper 1 — Campaign Member Attribution")
    print("=" * 50)

    if client is None:
        if page is None:
            print("❌ Need page or client"); sys.exit(1)
        client = sf.client_from_page(page)

    # ── Campaign summary (members + responses) ────────────────────────────────
    print("📋 Querying campaign member counts by campaign + status...")
    q = """
        SELECT CampaignId, Campaign.Name, Campaign.Type, Campaign.Status,
               LeadOrContactId, Status,
               COUNT(Id) cnt
        FROM   CampaignMember
        GROUP  BY CampaignId, Campaign.Name, Campaign.Type,
                  Campaign.Status, LeadOrContactId, Status
    """
    # GROUP BY with aggregate — SF returns rows not records, use soql_all
    # Note: LeadOrContactId is not groupable — use separate Lead/Contact count queries
    q_by_status = """
        SELECT CampaignId, Campaign.Name, Campaign.Type,
               Campaign.StartDate, Campaign.EndDate,
               Status, COUNT(Id) cnt
        FROM   CampaignMember
        GROUP  BY CampaignId, Campaign.Name, Campaign.Type,
                  Campaign.StartDate, Campaign.EndDate, Status
        ORDER  BY Campaign.Name
    """
    rows = sf.soql_all(client, q_by_status)
    print(f"   ✅ {len(rows)} campaign × status combinations")

    # ── Campaign-level roll-up ────────────────────────────────────────────────
    campaigns: dict[str, dict] = {}
    for r in rows:
        cid  = r.get("CampaignId", "")
        camp  = r.get("Campaign") or {}
        name  = r.get("Name")      or camp.get("Name")      or cid
        ctype = r.get("Type")      or camp.get("Type", "")
        start = r.get("StartDate") or camp.get("StartDate", "")
        end   = r.get("EndDate")   or camp.get("EndDate", "")
        status = r.get("Status", "")
        cnt    = r.get("cnt", 0) or r.get("expr0", 0)

        if cid not in campaigns:
            campaigns[cid] = {
                "id": cid, "name": name, "type": ctype,
                "start_date": start, "end_date": end,
                "total_members": 0, "responded": 0,
                "status_breakdown": {},
            }
        campaigns[cid]["total_members"] += cnt
        campaigns[cid]["status_breakdown"][status] = \
            campaigns[cid]["status_breakdown"].get(status, 0) + cnt
        if status and status.lower() in ("responded", "responded - converted"):
            campaigns[cid]["responded"] += cnt

    results = sorted(campaigns.values(), key=lambda x: -x["total_members"])

    # ── Opportunity attribution per campaign ──────────────────────────────────
    print("💰 Querying opportunity revenue by campaign...")
    q_opps = """
        SELECT CampaignId, Campaign.Name,
               COUNT(Id) opp_count,
               SUM(Amount) total_amount
        FROM   Opportunity
        WHERE  CampaignId != null
          AND  IsWon = false
        GROUP  BY CampaignId, Campaign.Name
    """
    opp_rows = sf.soql_all(client, q_opps)
    opp_map = {}
    for r in opp_rows:
        cid = r.get("CampaignId", "")
        opp_map[cid] = {
            "open_opps":    r.get("opp_count") or r.get("expr0", 0),
            "pipeline_amt": r.get("total_amount") or r.get("expr1", 0),
        }

    q_won = """
        SELECT CampaignId, COUNT(Id) won_count, SUM(Amount) won_amount
        FROM   Opportunity
        WHERE  CampaignId != null AND IsWon = true
        GROUP  BY CampaignId
    """
    won_rows = sf.soql_all(client, q_won)
    for r in won_rows:
        cid = r.get("CampaignId", "")
        if cid in opp_map:
            opp_map[cid]["won_opps"]   = r.get("won_count") or r.get("expr0", 0)
            opp_map[cid]["won_amount"] = r.get("won_amount") or r.get("expr1", 0)
        else:
            opp_map[cid] = {
                "open_opps": 0, "pipeline_amt": 0,
                "won_opps":  r.get("won_count") or r.get("expr0", 0),
                "won_amount": r.get("won_amount") or r.get("expr1", 0),
            }

    # Merge opp data into campaign results
    for c in results:
        opp = opp_map.get(c["id"], {})
        c["open_opps"]    = opp.get("open_opps", 0)
        c["pipeline_amt"] = opp.get("pipeline_amt", 0)
        c["won_opps"]     = opp.get("won_opps", 0)
        c["won_amount"]   = opp.get("won_amount", 0)

    # Summary
    total_members  = sum(c["total_members"] for c in results)
    total_responded = sum(c["responded"] for c in results)
    total_won_amt  = sum(c.get("won_amount") or 0 for c in results)
    print(f"\n📊 Summary:")
    print(f"   Campaigns with members : {len(results)}")
    print(f"   Total member records   : {total_members:,}")
    print(f"   Total responded        : {total_responded:,}")
    print(f"   Total won revenue      : {total_won_amt:,.0f}")

    utils.save_json(results, OUTPUT_JSON)
    _export_csv(results)
    print(f"\n✅ Campaign member attribution complete.")


def _export_csv(results):
    headers = ["#", "Campaign Name", "ID", "Type",
               "Total Members", "Responded", "Open Opps",
               "Pipeline Amount", "Won Opps", "Won Amount",
               "Start Date", "End Date"]
    rows = [
        [i+1, r["name"], r["id"], r.get("type",""),
         r["total_members"], r["responded"],
         r.get("open_opps",0), r.get("pipeline_amt",0) or "",
         r.get("won_opps",0), r.get("won_amount",0) or "",
         r.get("start_date",""), r.get("end_date","")]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
