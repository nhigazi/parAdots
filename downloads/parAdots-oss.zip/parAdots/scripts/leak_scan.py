#!/usr/bin/env python3
"""Fail if any real client name, email, org URL or Salesforce ID slips into the tree.
Usage:  python3 scripts/leak_scan.py [root]
Add the real names you must never ship to CLIENT_TOKENS before publishing."""
import os, re, sys
ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLIENT_TOKENS = []  # e.g. ["acme-real-name", "realbrand"]
OK_EMAIL = re.compile(r"@([a-z0-9-]+\.)*(example\.(com|org)|company\.com|domain\.com|your-org)$", re.I)
FAKE_SF  = re.compile(r"//(your-org|org|myorg|demo|orgtest|example|test|x)\.", re.I)
patterns = {
    "client token": re.compile("|".join(re.escape(t) for t in CLIENT_TOKENS), re.I) if CLIENT_TOKENS else None,
    "email":        re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    "real SF URL":  re.compile(r"https?://[A-Za-z0-9-]+\.(my\.salesforce|lightning\.force)\.com", re.I),
    "nonzero BU id": re.compile(r"\b0Uv(?!000000000000)[A-Za-z0-9]{12,15}\b"),
}
TEXT = {".py",".js",".json",".md",".txt",".html",".css",".env",".template",".yml",".yaml",".sh",".ps1",".csv"}
hits=[]
for dp,_,fs in os.walk(ROOT):
    if os.sep+".git" in dp or os.sep+"branding" in dp: continue
    for f in fs:
        if os.path.splitext(f)[1].lower() not in TEXT: continue
        p=os.path.join(dp,f); rel=os.path.relpath(p,ROOT)
        try: lines=open(p,encoding="utf-8",errors="replace").read().splitlines()
        except Exception: continue
        for i,line in enumerate(lines,1):
            for label,rx in patterns.items():
                if not rx: continue
                for m in rx.finditer(line):
                    g=m.group(0)
                    if label=="email" and OK_EMAIL.search(g): continue
                    if label=="real SF URL" and FAKE_SF.search(g): continue
                    hits.append(f"{rel}:{i}: [{label}] {g}")
if hits:
    print("LEAK SCAN FAILED — %d finding(s):"%len(hits)); print("\n".join(hits)); sys.exit(1)
print("Leak scan clean."); sys.exit(0)
