# Changelog

## Unreleased
- Viewer UI fully in English.
- Multi-org Pardot/Salesforce scraping, enrichment, analysis, draw.io export and local dashboard.
- Bundled synthetic `demo` org for out-of-the-box exploration.
- First public open-source release of parAdots.
