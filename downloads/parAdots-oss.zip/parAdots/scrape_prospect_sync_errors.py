"""
Pardot Scraper — Prospect Sync Errors (Step 1 of 2)
====================================================
Scrapes the Pardot connector *prospect* sync-error queue — the list a
consultant sees when browsing:

    Connectors → Salesforce → Sync Errors
    <PARDOT_HOME>/prospectSyncError/prospects

Each row is a prospect whose write-back to Salesforce was rejected by a CRM
validation rule / trigger / duplicate rule. We capture the whole row so the
error can be triaged and (in Step 2, resolve_prospect_sync_errors.py) traced
to the exact offending value on the prospect record.

Strategy: CSV Export vs. DOM Pagination
----------------------------------------
Primary path (Stage 1): Native CSV export from the queue. Provides Error/Error On
plus 32 additional fields (Email, Country, State, CRM IDs, etc.), enabling
Stage 2 to read prospect values directly without visiting detail pages.

Fallback path: DOM pagination via the HTML table (robust when export is
unavailable, e.g. some orgs).

Language-robustness
-------------------
Column *headers* are English even on non-English tenants, but the error
*messages* are in the tenant's Salesforce language (confirmed German on
globex). We therefore parse the table structurally (by header position with
a positional fallback) and never match on error-message wording here — that
is left to the classifier in Step 2, which handles localisation explicitly.

Output (output/{org}/):
  pardot_prospect_sync_errors.json
  pardot_prospect_sync_errors.csv

Called from run_all.py:
  from scrape_prospect_sync_errors import run
  run(page)
"""
from __future__ import annotations

import csv
import os
import re
import sys

import utils

SYNC_ERROR_PATH = "/prospectSyncError/prospects"
PROSPECT_PATH   = "/prospect/read/id/{id}"

MAX_PAGES = 200  # safety cap; queue can be large

# Canonical output columns from DOM path (order matters for the CSV / viewer table)
COLUMNS = [
    "Prospect ID", "Name", "Company", "Score", "Grade",
    "Error On", "Error", "Updated", "Prospect URL",
]

# Additional export columns from CSV export (not in DOM scrape path)
EXPORT_COLUMNS_EXTRA = [
    "Email", "Country", "State", "City", "Zip", "Phone", "Salutation",
    "Assigned User", "CRM Contact FID", "CRM Lead FID",
    "Created Date", "First Assigned", "Last Activity At", "Campaign",
    "Do Not Email",
]

# Full column set including export extras; used when export succeeds
COLUMNS_FULL = COLUMNS + EXPORT_COLUMNS_EXTRA

RAW_EXPORT_NAME = "pardot_prospect_sync_errors_export_raw.csv"

# Header text → canonical column. Matched case-insensitively / by prefix so
# minor UI wording changes ("Error on", "Updated at") still map.
_HEADER_ALIASES = {
    "name":     "Name",
    "company":  "Company",
    "score":    "Score",
    "grade":    "Grade",
    "error on": "Error On",
    "error":    "Error",
    "updated":  "Updated",
}

# JS that reads the sync-error table out of the DOM in one round-trip.
# Returns {headers:[...], rows:[{cells:[...], prospectId, prospectHref}]}.
_EXTRACT_JS = r"""
() => {
  const idFromHref = (href) => {
    if (!href) return null;
    const m = href.match(/\/prospect(?:Detail)?\/(?:read\/)?id\/(\d+)/i)
           || href.match(/\/prospect[^0-9]*(\d{4,})/i);
    return m ? m[1] : null;
  };

  // Pick the table that looks like the sync-error grid: the one whose header
  // row mentions "error". Fall back to the largest table on the page.
  const tables = Array.from(document.querySelectorAll('table'));
  let target = null, best = -1;
  for (const t of tables) {
    const headTxt = (t.querySelector('tr')?.innerText || '').toLowerCase();
    const rowCount = t.querySelectorAll('tr').length;
    if (headTxt.includes('error') && rowCount > best) { target = t; best = rowCount; }
  }
  if (!target) {
    for (const t of tables) {
      const rc = t.querySelectorAll('tr').length;
      if (rc > best) { target = t; best = rc; }
    }
  }
  if (!target) return { headers: [], rows: [] };

  const allRows = Array.from(target.querySelectorAll('tr'));
  // Header = first row that contains <th>, else first row.
  let headerRow = allRows.find(r => r.querySelector('th')) || allRows[0];
  const headers = Array.from(headerRow.querySelectorAll('th,td'))
                       .map(c => (c.innerText || '').trim());

  const bodyRows = allRows.filter(r => r !== headerRow && r.querySelector('td'));
  const rows = bodyRows.map(r => {
    // Collapse newlines / repeated whitespace so cells are single-line & clean.
    const cells = Array.from(r.querySelectorAll('td'))
                       .map(c => (c.innerText || '').trim().replace(/\s+/g, ' '));
    let prospectId = null, prospectHref = null;
    for (const a of r.querySelectorAll('a[href]')) {
      const id = idFromHref(a.getAttribute('href'));
      if (id) { prospectId = id; prospectHref = a.getAttribute('href'); break; }
    }
    return { cells, prospectId, prospectHref };
  });
  return { headers, rows };
}
"""


def _map_headers(headers: list[str]) -> dict[int, str]:
    """Return {cell_index: canonical_column} from the scraped header row."""
    mapping: dict[int, str] = {}
    for idx, raw in enumerate(headers):
        h = (raw or "").strip().lower()
        if not h:
            continue
        # exact/alias
        if h in _HEADER_ALIASES:
            mapping[idx] = _HEADER_ALIASES[h]
            continue
        # prefix match ("error on" before "error"; check longer keys first)
        for alias in sorted(_HEADER_ALIASES, key=len, reverse=True):
            if h.startswith(alias):
                mapping[idx] = _HEADER_ALIASES[alias]
                break
    return mapping


# Positional fallback used when header text can't be mapped (e.g. an icon-only
# first column). Mirrors the observed column order of the sync-error grid.
_POSITIONAL = ["Name", "Company", "Score", "Grade", "Error On", "Error", "Updated"]


def _row_to_record(cells: list[str], header_map: dict[int, str],
                   prospect_id: str | None) -> dict:
    rec = {c: "" for c in COLUMNS_FULL}  # Include export extras even when DOM source
    if header_map:
        for idx, col in header_map.items():
            if idx < len(cells):
                rec[col] = cells[idx]
    else:
        # No usable headers — fall back to fixed order, skipping a leading
        # checkbox/star column if the row has one extra cell.
        offset = 1 if len(cells) == len(_POSITIONAL) + 2 else 0
        for i, col in enumerate(_POSITIONAL):
            j = i + offset
            if j < len(cells):
                rec[col] = cells[j]
    if prospect_id:
        rec["Prospect ID"] = prospect_id
        rec["Prospect URL"] = utils.pardot_url(PROSPECT_PATH.format(id=prospect_id))
    return rec


def _norm_dt(dt_str: str) -> str:
    """Normalize date/time to ISO format YYYY-MM-DD HH:MM:SS.
    Handles both ISO (2026-08-10 23:07:30) and German (10.08.2026 23:07) formats."""
    if not dt_str or not dt_str.strip():
        return ""
    s = dt_str.strip()
    # Already ISO format: pass through
    if re.match(r"^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}", s):
        return s
    # German format: 10.08.2026 23:07 → 2026-08-10 23:07:00
    m = re.match(r"(\d{2})\.(\d{2})\.(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?", s)
    if m:
        day, month, year, hour, minute, second = m.groups()
        sec = second or "00"
        return f"{year}-{month}-{day} {hour}:{minute}:{sec}"
    # If format is unrecognized, pass through as-is
    return s


def _unescape_csv_injection(value: str) -> str:
    """Remove leading backslash used to escape CSV-injection characters (+, =, -, @)."""
    if value and value[0] in "\\":
        return value[1:]
    return value


def _force_all_filters(page) -> int | None:
    """
    Ensure filters are set to capture the full queue: 'All Prospects' view
    and 'All Time' date range. Returns the expected row count from the
    grid header after filters are applied.

    Waits for ajax responses to complete so subsequent export captures the
    correct data.
    """
    try:
        selects = page.query_selector_all("select")

        # Set the View select to "All Prospects"
        if len(selects) >= 1:
            view_select = selects[0]
            try:
                # Use expect_response to wait for the filter change to take effect
                with page.expect_response(
                    lambda r: "prospectSyncError/prospects/ajax" in r.url, timeout=15000
                ):
                    view_select.select_option(label="All Prospects")
            except Exception:
                pass  # select might not have the option; continue

        # Set the Date Range select (second select) to "All Time"
        if len(selects) >= 3:
            date_select = selects[2]
            try:
                with page.expect_response(
                    lambda r: "prospectSyncError/prospects/ajax" in r.url, timeout=15000
                ):
                    date_select.select_option(label="All Time")
            except Exception:
                pass  # select might not have the option; continue

        # Let any pending updates settle
        page.wait_for_timeout(1000)

        # Extract expected count from the grid header
        try:
            body_text = page.inner_text("body")
            # Grid might show "Showing 1-50 of 642" or similar
            m = re.search(r"of\s+([\d,]+)", body_text, re.I)
            if m:
                num_str = m.group(1).replace(",", "")
                return int(num_str)
        except Exception:
            pass

        return None
    except Exception as e:
        print(f"   ⚠️  Filter setup failed: {e}")
        return None


def _export_via_csv(page) -> tuple[str, int] | None:
    """
    Trigger CSV export via Tools → CSV Export → Express Export and save the file.

    Returns: (path_to_raw_csv, expected_row_count) or None if export unavailable.
    The path points to the raw CSV with all 41 export columns; the caller
    is responsible for mapping to COLUMNS_FULL and deleting the raw file.
    """
    try:
        # Wait for page to fully load
        page.wait_for_load_state("networkidle")

        # Click Tools dropdown — try multiple selectors
        tools_selectors = [
            "text=Tools",
            "button:has-text('Tools')",
            "[aria-label*='Tools']",
            "button:near(text=CSV Export)",
        ]
        tools_clicked = False
        for sel in tools_selectors:
            try:
                page.click(sel, timeout=5000)
                tools_clicked = True
                break
            except Exception:
                continue

        if not tools_clicked:
            print(f"   ⚠️  Could not find Tools button; export unavailable")
            return None

        page.wait_for_timeout(800)

        # Click CSV Export — try multiple selectors
        csv_selectors = [
            "text=CSV Export",
            "button:has-text('CSV Export')",
            "[role='menuitem']:has-text('CSV Export')",
        ]
        csv_clicked = False
        for sel in csv_selectors:
            try:
                page.click(sel, timeout=5000)
                csv_clicked = True
                break
            except Exception:
                continue

        if not csv_clicked:
            print(f"   ⚠️  Could not find CSV Export option; export unavailable")
            # Debug: show what's on the page
            try:
                visible_text = page.inner_text("body")[:500]
                print(f"      Page text: {visible_text}...")
            except Exception:
                pass
            return None

        # Wait for export dialog — try multiple selectors
        dialog_selectors = [
            "[role='dialog']",
            ".modal",
            "[class*='dialog']",
            "[class*='modal']",
            "div[style*='display: block']",
        ]
        dialog_found = False
        for sel in dialog_selectors:
            try:
                page.wait_for_selector(sel, timeout=5000)
                dialog_found = True
                break
            except Exception:
                continue

        if not dialog_found:
            print(f"   ⚠️  Export dialog not found; export unavailable")
            return None

        page.wait_for_timeout(1000)  # Let dialog fully render

        # Extract expected count from "Export N Prospects"
        expected = None
        body_text = page.inner_text("body")
        m = re.search(r"Export\s+([\d.,]+)\s+Prospects", body_text, re.I)
        if m:
            # Remove thousands separators (. in some locales, , in others)
            num_str = m.group(1).replace(".", "").replace(",", "")
            try:
                expected = int(num_str)
            except ValueError:
                pass

        # Select Express Export (should be default, but try to be explicit)
        try:
            # Try different radio button selectors
            radio_selectors = [
                "input[type=radio][value*='express' i]",
                "input[type=radio]:near(text=Express Export)",
                "input[value*=express]",
            ]
            for sel in radio_selectors:
                try:
                    page.check(sel, timeout=5000)
                    break
                except Exception:
                    continue
        except Exception:
            pass  # Radio button might already be selected

        # Wait a moment for UI to settle
        page.wait_for_timeout(500)

        # Trigger download
        with page.expect_download(timeout=180_000) as dl:
            page.click("button:has-text('Export'), text=Export", timeout=10000)

        # Save to our output directory
        path = utils.output_path(RAW_EXPORT_NAME)
        dl.value.save_as(path)

        # Return path and expected count (expected might be None if we couldn't extract it)
        return (path, expected) if expected else None
    except Exception as e:
        print(f"   ⚠️  CSV export failed: {e}")
        return None


def _records_from_export(path: str) -> list[dict]:
    """
    Parse the raw CSV export file. Returns a list of dicts with keys normalized
    to canonical column names (e.g., "Prospect Id" → "Prospect ID").

    Handles:
    - CSV injection escaping (leading backslash on +, =, -, @)
    - Date normalization to ISO format
    - Cleaning prospect names (removing number prefixes from Salutation field)
    - Column name normalization to match COLUMNS_FULL
    """
    # Map from export column names to canonical names
    _EXPORT_COL_MAP = {
        "Prospect Id": "Prospect ID",
        "Updated Date": "Updated",
        "User": "Assigned User",
        # Others are already canonical or will be preserved as-is
    }

    records = []
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if not row or not any(row.values()):
                    # Skip completely empty rows
                    continue

                # Unescape CSV injection escaping on all values
                for key in row:
                    row[key] = _unescape_csv_injection(row[key] or "")

                # Normalize dates to ISO format
                for date_key in ("Error On", "Updated Date", "Created Date", "First Assigned", "Last Activity At"):
                    if date_key in row:
                        row[date_key] = _norm_dt(row[date_key])

                # Reconstruct Name from First Name + Last Name (cleaner than DOM version)
                if "First Name" in row and "Last Name" in row:
                    first = (row.get("First Name") or "").strip()
                    last = (row.get("Last Name") or "").strip()
                    row["Name"] = f"{first} {last}".strip()

                # Normalize column names
                normalized = {}
                for col, value in row.items():
                    canonical_col = _EXPORT_COL_MAP.get(col, col)
                    normalized[canonical_col] = value

                records.append(normalized)
    except Exception as e:
        print(f"   ⚠️  Failed to parse CSV export: {e}")
        return []

    return records


def _next_button(ctx):
    """ctx is a Playwright Page or Frame (both expose query_selector)."""
    for sel in ("a:has-text('Next')", "a[rel='next']", "[aria-label='Next']",
                "[aria-label='Next page']", "a:has-text('›')", "a:has-text('»')",
                ".next a", "li.next a"):
        try:
            btn = ctx.query_selector(sel)
            if btn and btn.is_visible():
                # Skip disabled pagination controls.
                cls = (btn.get_attribute("class") or "").lower()
                if "disabled" in cls:
                    continue
                return btn
        except Exception:
            continue
    return None


def _build_lightning_url(path: str) -> str | None:
    """
    Construct the Lightning 'Account Engagement' wrapper URL that embeds a
    classic Pardot page in an iframe, e.g.
      https://your-org.lightning.force.com/lightning/page/pardot
          ?pardot__path=%2FprospectSyncError%2Fprospects
    Derived from SF_LOGIN_URL's My Domain host.
    """
    from urllib.parse import quote
    login = os.getenv("SF_LOGIN_URL", "")
    host = ""
    if "my.salesforce.com" in login:
        host = login.split("//", 1)[-1].split(".my.salesforce.com")[0]
    elif ".lightning.force.com" in login:
        host = login.split("//", 1)[-1].split(".lightning.force.com")[0]
    if not host:
        return None
    # Observed wrapper route on this org: /lightning/page/pardot/account
    return (f"https://{host}.lightning.force.com/lightning/page/pardot/account"
            f"?pardot__path={quote(path, safe='')}")


def _has_table(ctx) -> bool:
    try:
        return bool(ctx.evaluate(
            "() => Array.from(document.querySelectorAll('table'))"
            ".some(t => (t.innerText||'').toLowerCase().includes('error'))"))
    except Exception:
        return False


def _find_extraction_ctx(page):
    """
    Return the Page or Frame that actually holds the sync-error table.
    Handles both the classic pi.pardot.com page (top frame) and the Lightning
    wrapper (table inside a pardot iframe).
    """
    if _has_table(page):
        return page
    # Search frames: prefer ones whose URL points at the sync-error path/pardot.
    frames = sorted(
        page.frames,
        key=lambda f: 0 if ("prospectSyncError" in (f.url or "") or "pardot" in (f.url or "")) else 1,
    )
    for fr in frames:
        if fr == page.main_frame:
            continue
        if _has_table(fr):
            return fr
    return None


def _scrape_all_pages(page) -> list[dict]:
    records: list[dict] = []
    seen: set[str] = set()          # dedupe by prospect id
    seen_pages: set[str] = set()    # dedupe by row signature (no id case)

    for page_num in range(1, MAX_PAGES + 1):
        ctx = _find_extraction_ctx(page)
        if ctx is None:
            if page_num == 1:
                print("   ⚠️  No sync-error table found (top frame or iframes)")
            break
        try:
            data = ctx.evaluate(_EXTRACT_JS)
        except Exception as e:
            print(f"   ⚠️  Extract failed on page {page_num}: {e}")
            break

        header_map = _map_headers(data.get("headers", []))
        rows = data.get("rows", [])
        added = 0
        for row in rows:
            rec = _row_to_record(row.get("cells", []), header_map, row.get("prospectId"))
            pid = rec.get("Prospect ID") or ""
            # Skip spacer / empty rows (no id, no name, no error text).
            if not pid and not rec["Name"].strip() and not rec["Error"].strip():
                continue
            sig = pid or "|".join([rec["Name"], rec["Company"], rec["Error On"], rec["Error"][:60]])
            if pid and pid in seen:
                continue
            if not pid and sig in seen_pages:
                continue
            if pid:
                seen.add(pid)
            else:
                seen_pages.add(sig)
            records.append(rec)
            added += 1

        print(f"   Page {page_num}: {len(rows)} rows, {added} new (total {len(records)})")

        btn = _next_button(ctx)
        if not btn or added == 0:
            break
        try:
            # The grid paginates via a Prototype.js Ajax.Updater (no real page
            # nav), so "networkidle" is not a reliable completion signal, and
            # even waiting for the ajax response can race the DOM patch (the
            # response can resolve before/without the fragment actually being
            # swapped in). The pager's own "page" input is the ground truth —
            # wait for it to actually advance before re-extracting.
            with page.expect_response(
                lambda r: "prospectSyncError/prospects/ajax" in r.url, timeout=15000
            ):
                btn.click()
            try:
                ctx.wait_for_function(
                    "(n) => document.getElementById('page') "
                    "&& document.getElementById('page').value === String(n)",
                    arg=page_num + 1,
                    timeout=10000,
                )
            except Exception:
                page.wait_for_timeout(1000)  # no #page input found — best-effort wait
        except Exception:
            break

    return records


def run(page=None) -> None:
    print("\n🚀 Pardot Scraper — Prospect Sync Errors (Step 1)")
    print("=" * 50)
    if page is None:
        print("❌ Need a Playwright page")
        sys.exit(1)

    out_json = utils.output_path("pardot_prospect_sync_errors.json")
    out_csv  = utils.output_path("pardot_prospect_sync_errors.csv")

    records = []
    source = None

    def _attempt_export(url: str, url_label: str) -> tuple[list[dict], str | None]:
        """Attempt CSV export on the given URL. Returns (records, source_indicator)."""
        print(f"   Navigating to {url_label}")
        utils.navigate(page, url, timeout=30000)
        page.wait_for_timeout(2500)

        # Force filters to ensure full queue is captured
        _force_all_filters(page)

        # Attempt CSV export (primary path)
        print("   Attempting CSV export…")
        result = _export_via_csv(page)
        if result:
            path, expected = result
            print(f"   Export downloaded; parsing {expected} expected rows…")
            recs = _records_from_export(path)

            # Guard: verify completeness
            if expected is not None and len(recs) != expected:
                raise RuntimeError(
                    f"Sync-Error-Export unvollständig: {len(recs)} Zeilen, "
                    f"erwartet {expected} (Filter/Export-Pfad prüfen)")

            print(f"   ✓ Parsed {len(recs)} rows from export")

            # Ensure all required COLUMNS_FULL are present in each record
            for rec in recs:
                # Add missing columns with empty strings
                for col in COLUMNS_FULL:
                    if col not in rec:
                        rec[col] = ""
                # Ensure Prospect URL is set
                if rec.get("Prospect ID"):
                    rec["Prospect URL"] = utils.pardot_url(PROSPECT_PATH.format(id=rec["Prospect ID"]))
                rec["_source"] = "export"

            # Clean up raw export file (contains PII not in COLUMNS_FULL)
            try:
                os.remove(path)
            except Exception:
                pass

            return recs, "export"
        else:
            print("   Export unavailable; falling back to DOM scraping…")
            return None, None

    # Attempt 1: classic pi.pardot.com (works when the session has classic access).
    result = _attempt_export(utils.pardot_url(SYNC_ERROR_PATH), utils.pardot_url(SYNC_ERROR_PATH))
    if result[0] is not None:
        records, source = result
    else:
        # Attempt 2: Lightning 'Account Engagement' wrapper
        lightning = _build_lightning_url(SYNC_ERROR_PATH)
        if lightning:
            print(f"   Retrying with Lightning wrapper:\n     {lightning}")
            result = _attempt_export(lightning, "Lightning wrapper")
            if result[0] is not None:
                records, source = result
            else:
                print("   ⚠️  Export failed on Lightning wrapper; using DOM scrape fallback")
        else:
            print("   ⚠️  Could not derive Lightning wrapper URL from SF_LOGIN_URL")

    # If export path fully failed, fall back to DOM scraping on current page
    if not records:
        print("   Using DOM pagination fallback…")
        records_dom = _scrape_all_pages(page)
        records = records_dom
        source = "dom"
        for rec in records:
            rec["_source"] = "dom"

    print(f"\n   Total sync-error prospects: {len(records)}")

    utils.save_json(records, out_json)
    # Output with COLUMNS_FULL, filling in missing columns with empty strings
    # (DOM fallback may have empty export-extra columns)
    rows = [[rec.get(c, "") for c in COLUMNS_FULL] for rec in records]
    utils.save_csv(rows, COLUMNS_FULL, out_csv)
    print(f"   Saved to pardot_prospect_sync_errors.json/csv (source: {source or 'unknown'})")
    print("\n✅ Prospect sync-error scrape complete.")
    print("   Next: python3 resolve_prospect_sync_errors.py   (Step 2 — root-cause values)")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--org", metavar="NAME", help="Org config to use (e.g. 'globex' or 'soylent').")
    args = parser.parse_args()

    utils.load_org_config(args.org)
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()


if __name__ == "__main__":
    main()
