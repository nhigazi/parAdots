"""
SF Scraper 5 — Pardot Sync Error Log
======================================
Reads Pardot connector sync events / errors from Salesforce objects.

Tries multiple object names in order (they differ by org setup):
  1. B2BMA_ConnectorEvent__c    — Account Engagement connector events
  2. Pardot4__Prospect__c       — Pardot-managed prospect object (sync log fields)
  3. Account_Engagement_Errors  — custom error log object

Also queries standard SF objects for signals of sync failure:
  • Leads where LastModifiedById is the Pardot integration user
    but the Pardot-side fields are blank (indicates failed write-back)
  • Contacts with CRM sync fields set but opt-in = null

Output:
  sf_sync_errors.json
  sf_sync_errors.csv

Called from run_sf.py / run_all.py:
  from scrape_sf_sync_errors import run
  run(page=page)
"""
from __future__ import annotations
import csv, json, sys
from datetime import datetime, timezone, timedelta
import salesforce_api as sf
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""

# Connector event object candidates — first one that exists wins
CONNECTOR_EVENT_CANDIDATES = [
    "B2BMA_ConnectorEvent__c",
    "pardot4__B2BMA_ConnectorEvent__c",
]

# How far back to look for sync errors
LOOKBACK_DAYS = 90


def _try_connector_events(client: sf.SalesforceClient) -> tuple[str | None, list[dict]]:
    """Return (object_name, records) for the first connector event object that exists."""
    for obj in CONNECTOR_EVENT_CANDIDATES:
        if sf.object_exists(client, obj):
            print(f"   Found connector event object: {obj}")
            cutoff = (datetime.now(timezone.utc) - timedelta(days=LOOKBACK_DAYS)).strftime("%Y-%m-%dT%H:%M:%SZ")

            # Describe to find available fields
            fnames = sf.field_names(client, obj)
            select_fields = [f for f in [
                "Id", "Name", "CreatedDate",
                "B2BMA_Event_Type__c", "B2BMA_Status__c",
                "B2BMA_Error_Message__c", "B2BMA_Record_Id__c",
                "B2BMA_Object_Type__c",
            ] if f in fnames]

            if not select_fields:
                select_fields = ["Id", "Name", "CreatedDate"]

            q = (f"SELECT {', '.join(select_fields)} FROM {obj} "
                 f"WHERE CreatedDate >= {cutoff} "
                 f"ORDER BY CreatedDate DESC LIMIT 1000")
            records = sf.soql_all(client, q)
            return obj, records

    return None, []


def _check_pardot_integration_user(client: sf.SalesforceClient) -> dict:
    """Find the Pardot integration user and check for leads modified by it."""
    result: dict = {"integration_user_id": None, "leads_last_modified_by_pardot": -1}
    try:
        users = sf.soql_all(client,
            "SELECT Id, Name, Username FROM User "
            "WHERE (Username LIKE '%pardot%' OR Username LIKE '%b2bma%' OR Name LIKE '%Pardot%') "
            "AND IsActive = true LIMIT 5"
        )
        if users:
            uid = users[0]["Id"]
            result["integration_user_id"] = uid
            result["integration_user_name"] = users[0].get("Name","")
            cutoff = (datetime.now(timezone.utc) - timedelta(days=LOOKBACK_DAYS)).strftime("%Y-%m-%dT%H:%M:%SZ")
            result["leads_last_modified_by_pardot"] = sf.soql_count(
                client,
                f"SELECT COUNT() FROM Lead WHERE LastModifiedById = '{uid}' AND LastModifiedDate >= {cutoff}"
            )
    except Exception as e:
        print(f"   ⚠️  Could not query integration user: {e}")
    return result


def _check_leads_missing_optin_after_sync(client: sf.SalesforceClient) -> int:
    """Leads synced from Pardot (have IsConverted=false, Email present) but missing all opt-in fields."""
    optin_fields = sf.OPTIN_FIELDS
    present = [f for f in optin_fields if f in sf.field_names(client, "Lead")]
    if not present:
        return -1
    null_conditions = " AND ".join(f"{f} = null" for f in present)
    q = (f"SELECT COUNT() FROM Lead "
         f"WHERE IsConverted = false AND Email != null "
         f"AND ({null_conditions})")
    return sf.soql_count(client, q)


def run(page=None, client: sf.SalesforceClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("sf_sync_errors.json")
    OUTPUT_CSV  = utils.output_path("sf_sync_errors.csv")

    print("\n🚀 SF Scraper 5 — Pardot Sync Error Log")
    print("=" * 50)

    if client is None:
        if page is None:
            print("❌ Need page or client"); sys.exit(1)
        client = sf.client_from_page(page)

    print(f"   Lookback window: {LOOKBACK_DAYS} days\n")

    # ── Connector event log ───────────────────────────────────────────────────
    print("🔌 Checking connector event log...")
    obj_name, events = _try_connector_events(client)

    if not events and obj_name:
        print(f"   ✅ Object exists but no events in last {LOOKBACK_DAYS} days")
    elif not obj_name:
        print(f"   ⚠️  No connector event object found — org may use a different schema")

    # Classify events by type/status
    error_events   = [e for e in events if "error" in str(e.get("B2BMA_Status__c","")).lower()
                                        or "fail"  in str(e.get("B2BMA_Status__c","")).lower()]
    success_events = [e for e in events if "success" in str(e.get("B2BMA_Status__c","")).lower()]
    print(f"   Total events : {len(events)}")
    print(f"   Errors       : {len(error_events)}")
    print(f"   Successes    : {len(success_events)}")

    # ── Integration user activity ─────────────────────────────────────────────
    print("\n👤 Checking Pardot integration user...")
    integration = _check_pardot_integration_user(client)
    if integration.get("integration_user_id"):
        print(f"   Integration user: {integration.get('integration_user_name','')} ({integration['integration_user_id']})")
        print(f"   Leads modified in last {LOOKBACK_DAYS}d: {integration['leads_last_modified_by_pardot']:,}")
    else:
        print("   ⚠️  No Pardot integration user found")

    # ── Leads missing opt-in fields after sync ────────────────────────────────
    print("\n🔍 Checking Leads missing opt-in fields...")
    missing_optin = _check_leads_missing_optin_after_sync(client)
    if missing_optin >= 0:
        print(f"   Leads with email but all opt-in fields null: {missing_optin:,}")
    else:
        print("   ⚠️  Opt-in fields not found on Lead — check OPTIN_FIELDS in .env")

    output = {
        "connector_event_object":    obj_name,
        "lookback_days":             LOOKBACK_DAYS,
        "total_events":              len(events),
        "error_events":              len(error_events),
        "success_events":            len(success_events),
        "error_event_details":       error_events[:100],   # cap at 100 for JSON size
        "integration_user":          integration,
        "leads_missing_optin_fields": missing_optin,
    }

    utils.save_json(output, OUTPUT_JSON)
    _export_csv(output, error_events)
    print(f"\n✅ Sync error log scrape complete.")


def _export_csv(output, error_events):
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(["=== SYNC ERROR SUMMARY ==="])
        w.writerow(["Metric", "Value"])
        w.writerow(["Connector event object",    output["connector_event_object"] or "Not found"])
        w.writerow(["Lookback days",             output["lookback_days"]])
        w.writerow(["Total events",              output["total_events"]])
        w.writerow(["Error events",              output["error_events"]])
        w.writerow(["Success events",            output["success_events"]])
        w.writerow(["Leads missing opt-in",      output["leads_missing_optin_fields"]])
        integ = output.get("integration_user", {})
        w.writerow(["Integration user",          integ.get("integration_user_name","N/A")])
        w.writerow(["Leads modified by Pardot",  integ.get("leads_last_modified_by_pardot","N/A")])

        if error_events:
            w.writerow([])
            w.writerow(["=== ERROR EVENT DETAILS (up to 100) ==="])
            all_keys = list(dict.fromkeys(k for e in error_events for k in e.keys()))
            w.writerow(all_keys)
            for e in error_events[:100]:
                w.writerow([e.get(k,"") for k in all_keys])

    print(f"✅ Exported {OUTPUT_CSV}")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
