"""
Pardot Sent Emails Scraper — v5 API  (replaces scrape_sent_emails.py)
======================================================================
Pulls all sent list-emails from /api/v5/objects/list-emails in a single
paged pass and enriches each record with resolved names for campaign,
folder, tracker domain, and recipient lists.

No per-email detail reads.  No stats endpoint calls.

Captures per sent email:
  - id, name, subject
  - Sender name / email / reply-to  (from senderOptions if returned)
  - sentAt timestamp (ISO 8601)
  - Recipient list names  (resolved from recipientListIds)
  - Suppression list names
  - Campaign name, folder name, tracker domain
  - isArchived flag
  - createdAt / updatedAt

Also runs the same cadence analysis as the browser-based scraper:
  - Groups sends by recipient list and brand to reveal frequency patterns

Output:
  pardot_sent_emails.json      — per-send records
  pardot_sent_emails.csv       — flat table for Excel
  pardot_email_cadence.json    — cadence analysis by list and brand
  pardot_email_cadence.md      — human-readable cadence report

Usage (standalone):
  python3 fetch_sent_emails_api.py

Called from run_all.py:
  from fetch_sent_emails_api import run
  run(page=page)     # logged-in Playwright Page
  run(client=client) # pre-built PardotClient
"""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from datetime import datetime, timedelta

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON  = ""   # set at run() time via utils.output_path()
OUTPUT_CSV   = ""
CADENCE_JSON = "pardot_email_cadence.json"
CADENCE_MD   = "pardot_email_cadence.md"

MONTHS_BACK = 12

LIST_FIELDS = [
    "id", "name", "subject",
    "type",
    "isSent", "sentAt",
    "campaignId", "folderId", "trackerDomainId",
    "createdAt", "updatedAt",
]

CAMPAIGN_FIELDS = ["id", "name"]
FOLDER_FIELDS   = ["id", "name"]
TRACKER_FIELDS  = ["id", "domain"]


# ── Helpers ───────────────────────────────────────────────────────────────────

def _str(v) -> str:
    return "" if v is None else str(v)


# ── Record shaping ────────────────────────────────────────────────────────────

def shape_record(
    le: dict,
    campaign_map: dict,
    folder_map: dict,
    tracker_map: dict,
) -> dict:
    return {
        "id":             str(le.get("id", "")),
        "name":           le.get("name", "") or "",
        "subject":        le.get("subject", "") or "",
        "type":           le.get("type", "") or "",
        "is_sent":        bool(le.get("isSent")),
        "sent_at":        le.get("sentAt", "") or "",
        "campaign":       (campaign_map.get(le.get("campaignId")) or {}).get("name", ""),
        "folder":         (folder_map.get(le.get("folderId")) or {}).get("name", ""),
        "tracker_domain": (tracker_map.get(le.get("trackerDomainId")) or {}).get("domain", ""),
        "created_at":     le.get("createdAt", "") or "",
        "updated_at":     le.get("updatedAt", "") or "",
    }


# ── CSV export ────────────────────────────────────────────────────────────────

CSV_HEADERS = [
    "#", "Name", "ID", "Subject", "Type",
    "Sent At",
    "Campaign", "Folder", "Tracker Domain",
    "Created At", "Updated At",
]


def export_csv(results: list[dict]) -> None:
    rows = [
        [
            i + 1,
            r["name"], r["id"], r["subject"], r["type"],
            r["sent_at"],
            r["campaign"], r["folder"], r["tracker_domain"],
            r["created_at"], r["updated_at"],
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(CSV_HEADERS)
        for row in rows:
            w.writerow(row)
    print(f"   ✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Cadence analysis ──────────────────────────────────────────────────────────

BRAND_KEYWORDS = {
    "ACM":    ["acm", "acme", "acmunity", "k1"],
    "GLB":    ["glb", "globex"],
    "INI":    ["ini", "initech"],
    "Global": [],
}

EMAIL_TYPE_KEYWORDS = {
    "Newsletter":    ["newsletter", "nl "],
    "Consent":       ["consent", "optin", "opt-in", "doi", "bestätigung", "confirmation"],
    "Event":         ["ish", "messe", "event", "gewinnspiel", "launch", "bau "],
    "Presse":        ["presse", "press"],
    "Transactional": ["welcome", "willkommen", "dankesmail", "thank", "danke"],
    "Internal":      ["intern", "mitarbeiter", "test", "steffi", "tatiana", "rebecca", "monika"],
}


def _classify_email(name: str) -> tuple[str, str]:
    name_lower = name.lower()
    brand = "Unknown"
    for b, keywords in BRAND_KEYWORDS.items():
        if b == "Global":
            continue
        if any(kw in name_lower for kw in keywords):
            brand = b
            break
    etype = "Other"
    for t, keywords in EMAIL_TYPE_KEYWORDS.items():
        if any(kw in name_lower for kw in keywords):
            etype = t
            break
    return brand, etype


def _parse_iso(date_str: str) -> datetime | None:
    """Parse ISO 8601 timestamps returned by the v5 API."""
    if not date_str:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(date_str[:26].rstrip("Z"), fmt.rstrip("%z"))
            return dt.replace(tzinfo=None)  # naive for comparison
        except ValueError:
            continue
    return None


def analyze_cadence(emails: list[dict]) -> dict:
    cutoff = datetime.now() - timedelta(days=MONTHS_BACK * 30)

    by_list  = defaultdict(list)
    by_brand = defaultdict(list)
    by_type  = defaultdict(list)
    by_month = defaultdict(int)

    for email in emails:
        brand, etype = _classify_email(email.get("name", ""))
        email["brand"]      = brand
        email["email_type"] = etype

        list_name = email.get("campaign") or "Unknown Campaign"
        by_list[list_name].append(email)
        by_brand[brand].append(email)
        by_type[etype].append(email)

        dt = _parse_iso(email.get("sent_at", ""))
        if dt and dt >= cutoff:
            by_month[dt.strftime("%Y-%m")] += 1

    list_cadence = []
    for list_name, sends in sorted(by_list.items(), key=lambda x: -len(x[1])):
        dates = [_parse_iso(e.get("sent_at", "")) for e in sends]
        dates = sorted([d for d in dates if d], reverse=True)

        if len(dates) >= 2:
            gaps = [(dates[i] - dates[i + 1]).days for i in range(len(dates) - 1)]
            avg_gap = sum(gaps) / len(gaps)
            if avg_gap <= 10:
                frequency = "Weekly or more"
            elif avg_gap <= 20:
                frequency = "Bi-weekly (~every 2 weeks)"
            elif avg_gap <= 40:
                frequency = "Monthly"
            elif avg_gap <= 100:
                frequency = "Quarterly"
            else:
                frequency = "Ad-hoc / one-off"
        elif len(dates) == 1:
            frequency = "Single send (one-off)"
        else:
            frequency = "Unknown"

        most_recent = dates[0].strftime("%Y-%m-%d") if dates else "unknown"
        list_cadence.append({
            "list":        list_name,
            "total_sends": len(sends),
            "frequency":   frequency,
            "most_recent": most_recent,
            "email_names": list(dict.fromkeys(e["name"] for e in sends))[:5],
        })

    brand_summary = {
        brand: {
            "total_sends": len(sends),
            "types": dict(
                sorted(
                    {t: sum(1 for e in sends if e.get("email_type") == t)
                     for t in set(e.get("email_type", "Other") for e in sends)}.items(),
                    key=lambda x: -x[1],
                )
            ),
        }
        for brand, sends in by_brand.items()
    }

    return {
        "generated_at":   datetime.now().isoformat(),
        "period_months":  MONTHS_BACK,
        "total_sends":    len(emails),
        "by_list":        list_cadence,
        "by_brand":       brand_summary,
        "by_type":        {t: len(s) for t, s in sorted(by_type.items(), key=lambda x: -len(x[1]))},
        "sends_by_month": dict(sorted(by_month.items())),
    }


def build_cadence_md(cadence: dict) -> str:
    lines = [
        "# Pardot Email Cadence Report",
        f"**Period:** Last {cadence['period_months']} months  |  "
        f"**Total sends:** {cadence['total_sends']}  |  "
        f"**Generated:** {cadence['generated_at'][:10]}",
        "",
        "## Sends by Email Type",
        "",
        "| Type | Sends |",
        "|---|---|",
    ]
    for etype, count in cadence["by_type"].items():
        lines.append(f"| {etype} | {count} |")

    lines += ["", "## Sends by Brand", ""]
    for brand, data in sorted(cadence["by_brand"].items(), key=lambda x: -x[1]["total_sends"]):
        types_str = ", ".join(f"{t}: {c}" for t, c in data["types"].items())
        lines.append(f"**{brand}** — {data['total_sends']} send(s)  |  {types_str}")

    lines += [
        "",
        "## Send Frequency by Recipient List",
        "",
        "| Campaign | Total Sends | Frequency | Most Recent | Sample Email Names |",
        "|---|---|---|---|---|",
    ]
    for entry in cadence["by_list"]:
        names_preview = "; ".join(entry["email_names"][:2])
        lines.append(
            f"| {entry['list']} | {entry['total_sends']} | "
            f"{entry['frequency']} | {entry['most_recent']} | {names_preview} |"
        )

    if cadence["sends_by_month"]:
        lines += ["", "## Monthly Send Volume", ""]
        for month, count in sorted(cadence["sends_by_month"].items()):
            bar = "█" * min(count, 40)
            lines.append(f"  {month}  {bar}  {count}")

    lines += [
        "",
        "---",
        "",
        "## Use Case Implications",
        "",
        "| Frequency Pattern | Implied Use Case |",
        "|---|---|",
        "| Weekly or more | Active newsletter or drip sequence |",
        "| Bi-weekly | Regular newsletter cadence |",
        "| Monthly | Monthly newsletter or digest |",
        "| Quarterly | Seasonal campaign |",
        "| Ad-hoc / single send | Event-driven, trade show, or product launch |",
    ]
    return "\n".join(lines)


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    """
    Entry point for both standalone use and run_all.py integration.

    Pass either:
      page   – a logged-in Playwright Page (token extracted automatically)
      client – an already-built PardotClient (skips browser entirely)
    """
    print("\n🚀 Pardot Sent Emails Scraper (v5 API)")
    print("=" * 45)

    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_sent_emails.json")
    OUTPUT_CSV  = utils.output_path("pardot_sent_emails.csv")

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    # Pre-load lookup maps — one call each, resolved client-side
    print("📋 Pre-loading campaigns...")
    campaign_map = pardot_api.lookup_map(client, "objects/campaigns", fields=CAMPAIGN_FIELDS)
    print(f"   ✅ {len(campaign_map)} campaign(s)")

    print("📁 Pre-loading folders...")
    folder_map = pardot_api.lookup_map(client, "objects/folders", fields=FOLDER_FIELDS)
    print(f"   ✅ {len(folder_map)} folder(s)")

    print("🌐 Pre-loading tracker domains...")
    tracker_map = pardot_api.lookup_map(client, "objects/tracker-domains", fields=TRACKER_FIELDS)
    print(f"   ✅ {len(tracker_map)} tracker domain(s)")

    # Single pass: fetch all list-emails, filter client-side
    # (the v5 list-emails endpoint does not support sentAtAfter/sentAtBefore query params)
    cutoff = datetime.now() - timedelta(days=MONTHS_BACK * 30)
    print(f"\n📨 Fetching all list-emails (will filter to last {MONTHS_BACK} months client-side)...")
    raw = list(pardot_api.paged_get(client, "objects/list-emails", fields=LIST_FIELDS))
    print(f"   ✅ {len(raw)} list-email record(s) returned")

    # Keep only sent emails within the cutoff window
    sent = []
    for le in raw:
        if not le.get("isSent"):
            continue
        dt = _parse_iso(le.get("sentAt", ""))
        if dt is None or dt >= cutoff:
            sent.append(le)

    unsent   = sum(1 for le in raw if not le.get("isSent"))
    too_old  = len(raw) - unsent - len(sent)
    print(f"   ℹ️  {len(sent)} sent within last {MONTHS_BACK} months"
          f"  (dropped {unsent} unsent, {too_old} older than cutoff)")

    if not sent:
        print("⚠️  No sent list-emails found — check credentials, business unit ID, and date range.")
        with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
            json.dump([], f)
        export_csv([])
        return

    # Shape records
    results = [shape_record(le, campaign_map, folder_map, tracker_map) for le in sent]

    # Write JSON + CSV
    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"   ✅ Saved {OUTPUT_JSON} ({len(results)} record(s))")
    export_csv(results)

    # Cadence analysis
    print("\n📊 Running email cadence analysis...")
    cadence = analyze_cadence(results)

    with open(CADENCE_JSON, "w", encoding="utf-8") as f:
        json.dump(cadence, f, indent=2, ensure_ascii=False)
    print(f"   ✅ Saved {CADENCE_JSON}")

    md = build_cadence_md(cadence)
    with open(CADENCE_MD, "w", encoding="utf-8") as f:
        f.write(md)
    print(f"   ✅ Saved {CADENCE_MD}")

    # Summary
    print(f"\n── Email Cadence Summary ─────────────────────────")
    print(f"   Total sends captured: {cadence['total_sends']}")
    for etype, count in list(cadence["by_type"].items())[:6]:
        print(f"   {etype:<20} {count} send(s)")
    print(f"\n   Top campaigns by send volume:")
    for entry in cadence["by_list"][:6]:
        print(f"   • {entry['list'][:45]:<45}  {entry['total_sends']}× — {entry['frequency']}")

    print(f"\n✅ Sent emails scrape complete — {len(results)} record(s) captured.")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()
    print("\n🚀 Pardot Sent Emails Scraper (v5 API)")
    print("=" * 45)

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
