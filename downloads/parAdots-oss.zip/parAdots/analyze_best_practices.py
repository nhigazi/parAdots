"""
Pardot Best Practice Gap Analyzer
====================================
Reads all pardot_*.json exports and the cross-reference map, then runs
a set of best-practice checks against the Account Engagement instance.

Output:
  pardot_gap_analysis.md    — human-readable Markdown report
  pardot_gap_analysis.json  — structured gaps for MCP consumption

Usage:
  python3 analyze_best_practices.py                 # uses .active-org
  python3 set_org.py --org <org> && python3 analyze_best_practices.py

No browser / login required.
Run analyze_cross_references.py first for richer orphan data (empty
campaigns, broken dynamic-content field references, and no-campaign
assets are pulled from pardot_cross_references.json into the
"orphaned_assets" check — without it that check just says "unknown").

Every check and the "Detected Use Cases & Patterns" section is generated
purely from the active org's own scraped data — nothing here assumes a
particular customer's brand names, locales, or field vocabulary, so the
same report is meaningful for any org in configs/.

Configurable thresholds (override per org in configs/<org>.env — an org
with a smaller newsletter program shouldn't be held to a bigger org's bar):
  GAP_MIN_SCORING_ACTIVITIES     default 5    (see MIN_SCORING_ACTIVITIES)
  GAP_ES_COVERAGE_MIN_PCT        default 50   (see ES_COVERAGE_MIN_PCT)
  GAP_CAMPAIGN_COVERAGE_MIN_PCT  default 70   (see CAMPAIGN_COVERAGE_MIN_PCT)
  GAP_ORPHAN_LISTS_MAX           default 5    (see ORPHAN_LISTS_MAX)
  GAP_PAUSED_AUTOMATIONS_MAX     default 10   (see PAUSED_AUTOMATIONS_MAX)

Example configs/globex.env line to lower the ES coverage bar to 30%:
  GAP_ES_COVERAGE_MIN_PCT=30
"""

import json
import os
import sys
from datetime import datetime

import utils

BASE_DIR = os.path.dirname(__file__)   # overridden in main() to utils.OUTPUT_DIR

# ── Configurable thresholds ───────────────────────────────────────────────────
# Defaults below; override per-org by setting these in configs/<org>.env
# (e.g. GAP_ES_COVERAGE_MIN_PCT=40). _load_thresholds() re-reads them from the
# environment after utils.load_org_config() has applied the org-specific .env,
# so a fast-growing or differently-structured org isn't held to one org's bar.
MIN_SCORING_ACTIVITIES    = 5    # below this many scored activity types → critical gap
ES_COVERAGE_MIN_PCT       = 50   # % of newsletter lists needing an ES nurture program
CAMPAIGN_COVERAGE_MIN_PCT = 70   # % of forms/programs needing a Connected Campaign
ORPHAN_LISTS_MAX          = 5    # orphan lists above this → flagged
PAUSED_AUTOMATIONS_MAX    = 10   # paused automations above this → flagged


def _load_thresholds():
    global MIN_SCORING_ACTIVITIES, ES_COVERAGE_MIN_PCT, CAMPAIGN_COVERAGE_MIN_PCT
    global ORPHAN_LISTS_MAX, PAUSED_AUTOMATIONS_MAX
    MIN_SCORING_ACTIVITIES    = int(os.getenv("GAP_MIN_SCORING_ACTIVITIES", MIN_SCORING_ACTIVITIES))
    ES_COVERAGE_MIN_PCT       = float(os.getenv("GAP_ES_COVERAGE_MIN_PCT", ES_COVERAGE_MIN_PCT))
    CAMPAIGN_COVERAGE_MIN_PCT = float(os.getenv("GAP_CAMPAIGN_COVERAGE_MIN_PCT", CAMPAIGN_COVERAGE_MIN_PCT))
    ORPHAN_LISTS_MAX          = int(os.getenv("GAP_ORPHAN_LISTS_MAX", ORPHAN_LISTS_MAX))
    PAUSED_AUTOMATIONS_MAX    = int(os.getenv("GAP_PAUSED_AUTOMATIONS_MAX", PAUSED_AUTOMATIONS_MAX))


def _load(filename):
    path = os.path.join(BASE_DIR, filename)
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ── Data loading ──────────────────────────────────────────────────────────────

def load_all():
    return {
        "lists":         _load("pardot_dynamic_lists.json") or [],
        "automations":   _load("pardot_automation_rules.json") or [],
        "forms":         _load("pardot_forms.json") or [],
        "formhandlers":  _load("pardot_formhandlers.json") or [],
        "programs":      _load("pardot_engagement_studio.json") or [],
        "dyn_content":   _load("pardot_dynamic_content.json") or [],
        "fields":        _load("pardot_fields.json") or [],
        "scoring":       _load("pardot_scoring_rules.json"),
        "emails":        _load("pardot_email_templates.json") or [],
        "landing_pages": _load("pardot_landing_pages.json") or [],
        "page_actions":  _load("pardot_page_actions.json") or [],
        "campaigns":     _load("pardot_campaigns.json") or [],
        "cross_refs":    _load("pardot_cross_references.json"),
        "preference_center": _load("pardot_preference_center.json") or [],
    }


# ── Individual gap checks ─────────────────────────────────────────────────────

def check_formal_scoring_model(d):
    scoring = d["scoring"]
    if not scoring:
        return {
            "id": "has_formal_scoring_model",
            "severity": "critical",
            "title": "No Lead Scoring Model Scraped",
            "status": "unknown",
            "detail": (
                "pardot_scoring_rules.json does not exist yet. "
                "Run scrape_scoring_rules.py (part of run_all.py) to capture scoring data. "
                "A formal scoring model with 5+ distinct activity types is required to enable "
                "MQL thresholds and structured sales hand-off."
            ),
            "recommendation": (
                "1. Run run_all.py to capture scoring rules.\n"
                "2. Define a scoring model with at minimum: email open (+1), "
                "link click (+5), form submit (+50), page visit (+2), file download (+10).\n"
                "3. Set an MQL threshold (e.g. score ≥ 100) and create a Salesforce assignment rule."
            ),
        }
    rules = scoring.get("scoring_rules", [])
    scored_activities = [r for r in rules if r.get("score") and r["score"] != ""]
    if len(scored_activities) < MIN_SCORING_ACTIVITIES:
        return {
            "id": "has_formal_scoring_model",
            "severity": "critical",
            "title": f"Scoring Model Has Fewer Than {MIN_SCORING_ACTIVITIES} Activity Types",
            "status": "partial",
            "detail": (
                f"Only {len(scored_activities)} distinct scoring activities detected "
                f"(threshold: {MIN_SCORING_ACTIVITIES}). "
                "A robust scoring model requires at least: email engagement, form submission, "
                "page visits, file downloads, and social clicks."
            ),
            "recommendation": (
                f"Expand the scoring model to cover at least {MIN_SCORING_ACTIVITIES} activity types. "
                "Define explicit MQL and recycling thresholds. "
                "Consider using Scoring Categories to separate behavioral from demographic scores."
            ),
        }
    return {
        "id": "has_formal_scoring_model",
        "severity": "ok",
        "title": "Formal Scoring Model Exists",
        "status": "pass",
        "detail": f"{len(scored_activities)} scoring activities found.",
        "recommendation": "",
    }


def check_grading(d):
    fields_data = d["fields"]
    if isinstance(fields_data, list):
        all_fields = []
        for obj in fields_data:
            all_fields.extend(obj.get("fields", []))
    else:
        all_fields = fields_data.get("fields", []) if fields_data else []

    grading_keywords = ("grade", "grading", "profile score", "profil")
    has_grading = any(
        any(kw in str(f.get("name", "")).lower() for kw in grading_keywords)
        for f in all_fields
    )
    if not has_grading:
        return {
            "id": "has_grading",
            "severity": "high",
            "title": "Profile Grading (Demographic Scoring) Not Detected",
            "status": "fail",
            "detail": (
                "No grading fields or scoring categories related to profile/demographic fit "
                "were found. Grading measures how well a prospect matches your ideal customer profile "
                "(industry, company size, segment/persona). Combined with behavioral scoring, "
                "it enables a precise MQL qualification matrix."
            ),
            "recommendation": (
                "Configure Pardot Grading with criteria for: ICP fit (A=high fit, B=medium fit, "
                "C=low fit), Company Size, Industry, and Country/Language. "
                "Map A-grade prospects to immediate sales follow-up."
            ),
        }
    return {
        "id": "has_grading",
        "severity": "ok",
        "title": "Profile Grading Detected",
        "status": "pass",
        "detail": "Grading-related fields found in the field configuration.",
        "recommendation": "",
    }


def check_preference_center(d):
    """
    Pardot has a dedicated "Email Preference Pages" object (Account Engagement
    Email → Preferences Page in the UI) — a real, first-class asset with its
    own scraper (scrape_preference_center.py → pardot_preference_center.json).
    Previously this check never loaded that file at all and only guessed from
    form/form-handler *names* containing "preference" — which produced a false
    "not detected" for orgs that have real preference pages configured under
    a name that doesn't happen to contain that keyword (confirmed against a
    live Umbrella screenshot showing 5 configured Email Preference Pages while
    this check reported none).
    """
    pref_centers = d.get("preference_center") or []
    # A record only counts as "real" if the scraper actually extracted
    # something usable — the page-scrape fallback can emit a placeholder
    # {"id": "unknown", "name": "Preference Center (details not extractable)",
    #  "source": "page_partial"} when it found *a* page but couldn't parse it.
    real_pref_centers = [
        p for p in pref_centers
        if p.get("source") in ("api", "page") and (p.get("name") or p.get("list_count"))
    ]

    if real_pref_centers:
        total_lists = sum(p.get("list_count", 0) for p in real_pref_centers)
        names = ", ".join(p.get("name", "") for p in real_pref_centers[:5])
        return {
            "id": "has_preference_center",
            "severity": "ok",
            "title": f"{len(real_pref_centers)} Email Preference Page(s) Configured",
            "status": "pass",
            "detail": f"{names}. Covering {total_lists} list(s) in total across all pages.",
            "recommendation": "",
        }

    if pref_centers and not real_pref_centers:
        # The scraper ran and found *something* on the preference-center page,
        # but couldn't parse individual pages out of it (source=page_partial).
        # Don't confidently say "not configured" — say the scrape is inconclusive.
        return {
            "id": "has_preference_center",
            "severity": "medium",
            "title": "Email Preference Page Data Inconclusive — Re-scrape Needed",
            "status": "unknown",
            "detail": (
                "scrape_preference_center.py ran but could not extract individual "
                "preference pages from the page scrape (only a generic placeholder was "
                "captured). This does NOT mean no preference center exists — verify "
                "manually under Account Engagement Email → Preferences Page, then "
                "re-run scrape_preference_center.py (ideally once its extraction logic "
                "has been pointed at the correct admin list URL)."
            ),
            "recommendation": (
                "Manually check Account Engagement Email → Preferences Page in the "
                "Pardot UI. If pages exist there, re-run scrape_preference_center.py; "
                "if the scraper still can't extract them, its URL/table-parsing needs "
                "fixing (see DEVLOG)."
            ),
        }

    # No pardot_preference_center.json at all — fall back to the old
    # name-based heuristic on forms/form handlers as a weak secondary signal,
    # but say explicitly that the authoritative scraper hasn't run.
    forms = d["forms"]
    fh = d["formhandlers"]
    pref_keywords = ("preference", "präferenz", "newsletter-einstellungen", "opt-down", "topic")
    all_names = [f.get("name", "").lower() for f in forms + fh]
    has_pref = any(any(kw in name for kw in pref_keywords) for name in all_names)
    all_actions = " ".join(str(f.get("completion_actions", "")) for f in forms + fh).lower()

    if not has_pref and "preference" not in all_actions:
        return {
            "id": "has_preference_center",
            "severity": "high",
            "title": "No Email Preference Center Detected (scraper not yet run)",
            "status": "unknown",
            "detail": (
                "pardot_preference_center.json does not exist — scrape_preference_center.py "
                "has not been run for this org, so this result is based only on a weak "
                "name-based guess over forms/form handlers, which found nothing. Run "
                "scrape_preference_center.py for a reliable answer before trusting this gap."
            ),
            "recommendation": (
                "Run scrape_preference_center.py (or python3 run_all.py). If it confirms no "
                "preference center exists, build a Pardot-hosted preference center page "
                "allowing prospects to:\n"
                "  1. Choose which brand/business-unit newsletters to receive\n"
                "  2. Choose topics (by industry vertical, content type, region, etc.)\n"
                "  3. Adjust communication frequency\n"
                "Link this page in every email footer alongside the unsubscribe link."
            ),
        }
    return {
        "id": "has_preference_center",
        "severity": "medium",
        "title": "Preference-Related Form/Handler Found (unverified)",
        "status": "partial",
        "detail": (
            "A form or form handler with a preference-related name was found, but "
            "pardot_preference_center.json doesn't exist — run scrape_preference_center.py "
            "to confirm this is a real, configured Email Preference Page."
        ),
        "recommendation": "Run scrape_preference_center.py to verify.",
    }


def check_progressive_profiling(d):
    forms = d["forms"]
    prog_profile_keywords = ("progressive", "progressiv", "progressive profiling")
    demo_keywords = ("beispiel", "demo", "test", "training", "sample")

    production_pp = []
    demo_pp = []
    for f in forms:
        name_lower = f.get("name", "").lower()
        if any(kw in name_lower for kw in prog_profile_keywords):
            if any(kw in name_lower for kw in demo_keywords):
                demo_pp.append(f.get("name"))
            else:
                production_pp.append(f.get("name"))

    if production_pp:
        return {
            "id": "uses_progressive_profiling",
            "severity": "ok",
            "title": "Progressive Profiling in Production",
            "status": "pass",
            "detail": f"Found in: {', '.join(production_pp)}",
            "recommendation": "",
        }
    if demo_pp:
        return {
            "id": "uses_progressive_profiling",
            "severity": "medium",
            "title": "Progressive Profiling Demo Form Exists — Not in Production",
            "status": "partial",
            "detail": (
                f"A demo form exists ({', '.join(demo_pp)}) but no production forms "
                "use progressive profiling. All production DOI and consent forms use static field sets."
            ),
            "recommendation": (
                "Apply progressive profiling to the DOI consent forms and any gated content forms. "
                "On first visit: capture Email + First Name + Country/Language. "
                "On return: reveal segment/persona, product interest, Company. "
                "This enriches CRM data without reducing conversion rates."
            ),
        }
    return {
        "id": "uses_progressive_profiling",
        "severity": "medium",
        "title": "Progressive Profiling Not Used",
        "status": "fail",
        "detail": "No forms (demo or production) use progressive profiling.",
        "recommendation": (
            "Implement progressive profiling on all gated content forms. "
            "Priority fields to collect progressively: segment/persona, product interest, "
            "company size, and phone number."
        ),
    }


def check_ab_testing(d):
    emails = d["emails"]
    lp = d["landing_pages"]
    ab_keywords = ("a/b", "ab test", "variant", "version a", "version b")
    has_ab = any(
        any(kw in e.get("name", "").lower() for kw in ab_keywords)
        for e in emails + lp
    )
    if not has_ab:
        return {
            "id": "has_ab_email_tests",
            "severity": "medium",
            "title": "No A/B Email or Landing Page Tests Detected",
            "status": "fail",
            "detail": (
                "No email templates or landing pages with A/B test naming conventions were found. "
                "Regular A/B testing of subject lines is a table-stakes best practice that "
                "typically yields 5–15% open rate improvements."
            ),
            "recommendation": (
                "Enable A/B testing on all newsletter sends. Start with subject line tests "
                "(test question vs. statement, German vs. English keywords). "
                "Use Pardot's built-in A/B send feature on scheduled email sends."
            ),
        }
    return {
        "id": "has_ab_email_tests",
        "severity": "ok",
        "title": "A/B Testing Detected",
        "status": "pass",
        "detail": "A/B test variants found in email or landing page names.",
        "recommendation": "",
    }


def check_landing_pages(d):
    lp = d["landing_pages"]
    if not lp:
        return {
            "id": "has_native_landing_pages",
            "severity": "high",
            "title": "No Native Pardot Landing Pages Detected",
            "status": "fail" if _load("pardot_landing_pages.json") is not None else "unknown",
            "detail": (
                "No Pardot-hosted landing pages were found. All forms appear to be embedded on "
                "external websites without Pardot landing page wrappers. Native landing pages "
                "provide: built-in conversion tracking, redirect management, A/B testing, "
                "and campaign attribution."
            ),
            "recommendation": (
                "Create native Pardot landing pages for:\n"
                "  1. Each DOI consent registration (per brand/locale combination)\n"
                "  2. Trade show / event registration pages\n"
                "  3. Gated content downloads (brochures, whitepapers)\n"
                "Connect each landing page to its form and to a Connected Campaign."
            ),
        }
    return {
        "id": "has_native_landing_pages",
        "severity": "ok",
        "title": f"{len(lp)} Native Landing Pages Found",
        "status": "pass",
        "detail": f"{len(lp)} landing pages scraped.",
        "recommendation": "",
    }


def check_page_actions(d):
    pa = d["page_actions"]
    if not pa:
        return {
            "id": "has_page_actions",
            "severity": "medium",
            "title": "No Website Page Actions / Tracking Detected",
            "status": "fail" if _load("pardot_page_actions.json") is not None else "unknown",
            "detail": (
                "No Pardot page actions were found. Without page actions, website visits "
                "are not triggering scoring or segmentation. Behavioral web intent signals "
                "are the most predictive lead qualification data."
            ),
            "recommendation": (
                "Configure Pardot Tracking Code on all brand websites. "
                "Create page actions for high-intent pages:\n"
                "  • Product/service detail pages → +5 score\n"
                "  • Pricing / dealer-finder pages → +15 score + notify sales\n"
                "  • Downloads (PDF brochures) → +10 score\n"
                "  • Career / About pages → -5 score (low intent signal)"
            ),
        }
    return {
        "id": "has_page_actions",
        "severity": "ok",
        "title": f"{len(pa)} Page Actions Configured",
        "status": "pass",
        "detail": f"{len(pa)} page action(s) found.",
        "recommendation": "",
    }


def check_engagement_studio_coverage(d):
    lists = d["lists"]
    programs = d["programs"]

    newsletter_lists = [l for l in lists if "newsletter" in l.get("name", "").lower()]
    program_entry_lists = set()
    for p in programs:
        for lname in p.get("entry_lists", []):
            program_entry_lists.add(lname.lower())

    covered = [l for l in newsletter_lists if l.get("name", "").lower() in program_entry_lists]
    coverage_pct = (len(covered) / len(newsletter_lists) * 100) if newsletter_lists else 0

    if coverage_pct < ES_COVERAGE_MIN_PCT:
        return {
            "id": "engagement_studio_coverage",
            "severity": "high",
            "title": f"Only {coverage_pct:.0f}% of Newsletter Lists Have a Nurture Program (threshold: {ES_COVERAGE_MIN_PCT:.0f}%)",
            "status": "partial",
            "detail": (
                f"{len(newsletter_lists)} newsletter lists found; only {len(covered)} are linked "
                "to an Engagement Studio entry list. New subscribers receive no automated welcome "
                "journey — a significant missed opportunity for first-impression engagement."
            ),
            "recommendation": (
                "Create a welcome nurture series for each brand × locale newsletter:\n"
                "  Day 0: Welcome email + brand overview\n"
                "  Day 7: Product highlight / hero use case\n"
                "  Day 14: Customer success story or whitepaper\n"
                "  Day 30: Soft CTA (contact sales / find dealer)\n"
                "Each program should use brand-specific localized email templates."
            ),
        }
    return {
        "id": "engagement_studio_coverage",
        "severity": "ok",
        "title": f"Engagement Studio Covers {coverage_pct:.0f}% of Newsletter Lists",
        "status": "pass",
        "detail": f"{len(covered)} of {len(newsletter_lists)} newsletter lists have entry programs.",
        "recommendation": "",
    }


def check_suppression_completeness(d):
    lists = d["lists"]
    newsletter_list_names = [l.get("name", "") for l in lists if "newsletter" in l.get("name", "").lower()]
    suppression_list_names = [l.get("name", "").lower() for l in lists if "suppression" in l.get("name", "").lower() or "unterdrück" in l.get("name", "").lower()]

    missing_suppression = []
    for nl_name in newsletter_list_names:
        brand_hint = nl_name.split(" ")[1] if len(nl_name.split(" ")) > 1 else ""
        if not any(brand_hint.lower() in sl for sl in suppression_list_names):
            missing_suppression.append(nl_name)

    if missing_suppression:
        return {
            "id": "suppression_completeness",
            "severity": "medium",
            "title": f"{len(missing_suppression)} Newsletter List(s) May Lack a Paired Suppression List",
            "status": "partial",
            "detail": (
                f"Possible gaps: {', '.join(missing_suppression[:5])}. "
                "Every newsletter send should suppress: hard bounces, global opt-outs, "
                "competitors, and brand-specific opt-out lists to protect sender reputation."
            ),
            "recommendation": (
                "Verify each newsletter list has corresponding suppression lists in the send flow:\n"
                "  • NL Audit Global Opt-Out OR Hardbounce (global)\n"
                "  • SUPPRESSION LIST - Competitors - {Brand}\n"
                "  • MITARBEITER lists (employees)\n"
                "Add suppressions as exclusion lists in each Engagement Studio program."
            ),
        }
    return {
        "id": "suppression_completeness",
        "severity": "ok",
        "title": "Suppression Lists Appear Complete",
        "status": "pass",
        "detail": "All newsletter brands appear to have matching suppression lists.",
        "recommendation": "",
    }


def check_consent_expiry(d):
    automations = d["automations"]
    fields_data = d["fields"]
    if isinstance(fields_data, list):
        all_fields = []
        for obj in fields_data:
            all_fields.extend(obj.get("fields", []))
    else:
        all_fields = fields_data.get("fields", []) if fields_data else []

    timestamp_fields = [
        f for f in all_fields
        if "timestamp" in f.get("name", "").lower() or "datum" in f.get("name", "").lower()
    ]
    expiry_rules = [
        a for a in automations
        if any(kw in str(a.get("sections", {})).lower()
               for kw in ("timestamp", "days", "tage", "expir", "ablauf", "older than"))
    ]
    if not expiry_rules:
        return {
            "id": "consent_expiry_handling",
            "severity": "critical",
            "title": "No Consent Expiry Automation Detected (GDPR Risk)",
            "status": "fail",
            "detail": (
                f"{len(timestamp_fields)} consent/timestamp field(s) exist "
                f"({', '.join(f.get('name','') for f in timestamp_fields[:5])}) "
                "but no automation rules were found that check consent age or trigger re-consent "
                "workflows. Under GDPR, marketing consent should be re-verified if inactive "
                "for 2 years (recommended industry practice). Stale consents represent legal risk."
            ) if timestamp_fields else (
                "No automation rules were found that check consent age or trigger re-consent "
                "workflows, and no consent/timestamp fields were detected either. Under GDPR, "
                "marketing consent should be re-verified if inactive for 2 years "
                "(recommended industry practice). Stale consents represent legal risk."
            ),
            "recommendation": (
                "Create automation rules for each brand/business unit that:\n"
                "  1. Identify prospects where the consent timestamp is older than 700 days\n"
                "     AND last email engagement > 365 days ago\n"
                "  2. Send a re-consent email asking whether they still want to receive communications\n"
                "  3. If no click within 30 days: set opt-in = false, opt-out = true\n"
                "  4. Log to a CRM Campaign such as 'Consent Renewal - {Brand} - {Year}'"
            ),
        }
    return {
        "id": "consent_expiry_handling",
        "severity": "ok",
        "title": "Consent Expiry / Renewal Automation Detected",
        "status": "pass",
        "detail": f"{len(expiry_rules)} rule(s) reference timestamp-based conditions.",
        "recommendation": "",
    }


def check_lifecycle_stages(d):
    fields_data = d["fields"]
    if isinstance(fields_data, list):
        all_fields = []
        for obj in fields_data:
            all_fields.extend(obj.get("fields", []))
    else:
        all_fields = fields_data.get("fields", []) if fields_data else []

    lifecycle_keywords = ("lifecycle", "lebenszyklus", "stage", "status", "mql", "sql", "opportunity stage")
    has_lifecycle = any(
        any(kw in f.get("name", "").lower() for kw in lifecycle_keywords)
        for f in all_fields
    )
    if not has_lifecycle:
        return {
            "id": "lifecycle_stage_tracking",
            "severity": "medium",
            "title": "No Prospect Lifecycle Stage Tracking Detected",
            "status": "fail",
            "detail": (
                "No lifecycle stage field was found. Without explicit stage tracking "
                "(Visitor → Subscriber → MQL → SQL → Opportunity → Customer), "
                "it is impossible to build funnel reports or measure marketing-to-sales conversion. "
                "The CRM has Lead/Contact status but Pardot-side lifecycle tracking is missing."
            ),
            "recommendation": (
                "Add a custom 'Pardot Lifecycle Stage' field with values:\n"
                "  Subscriber → MQL → Accepted by Sales → SQL → Opportunity → Won → Lost\n"
                "Automate stage transitions using Automation Rules:\n"
                "  Score ≥ 100 AND ICP grade = A → MQL\n"
                "  CRM Opportunity Stage = 'Qualification' → SQL\n"
                "Build a Pardot Lifecycle Report connected to Connected Campaigns."
            ),
        }
    return {
        "id": "lifecycle_stage_tracking",
        "severity": "ok",
        "title": "Lifecycle Stage Field Detected",
        "status": "pass",
        "detail": "Lifecycle-related field found.",
        "recommendation": "",
    }


def check_community_nurture(d):
    lists = d["lists"]
    programs = d["programs"]
    community_lists = [l for l in lists if "community" in l.get("name", "").lower()]
    if not community_lists:
        return {
            "id": "community_nurture",
            "severity": "low",
            "title": "No Community Lists Found",
            "status": "ok",
            "detail": "",
            "recommendation": "",
        }
    program_entry_lists = set()
    for p in programs:
        for lname in p.get("entry_lists", []):
            program_entry_lists.add(lname.lower())

    has_nurture = any(l.get("name", "").lower() in program_entry_lists for l in community_lists)
    list_names = ", ".join(l["name"] for l in community_lists)
    if not has_nurture:
        return {
            "id": "community_nurture",
            "severity": "medium",
            "title": f"Community List(s) Have No Dedicated Nurture Program ({list_names})",
            "status": "fail",
            "detail": (
                f"List(s) found: {list_names}. "
                "Community members are typically a high-value segment "
                "but receive no dedicated engagement journey in Engagement Studio."
            ),
            "recommendation": (
                "Create a dedicated community Engagement Studio program:\n"
                "  Month 1: Welcome + community benefits overview\n"
                "  Month 2: Exclusive product preview / early access offer\n"
                "  Ongoing: Quarterly community news digest\n"
                "  Trigger: Score above threshold OR purchase signal → sales notification"
            ),
        }
    return {
        "id": "community_nurture",
        "severity": "ok",
        "title": f"Community List(s) Have a Nurture Program ({list_names})",
        "status": "pass",
        "detail": "Community list is linked to an Engagement Studio entry list.",
        "recommendation": "",
    }


def check_connected_campaigns(d):
    campaigns = d["campaigns"]
    forms = d["forms"]
    programs = d["programs"]

    forms_with_campaign = [f for f in forms if f.get("campaign") and str(f.get("campaign")).strip() not in ("", "none", "null")]
    programs_with_campaign = [p for p in programs if p.get("campaign") and str(p.get("campaign")).strip() not in ("", "none", "null")]

    total_assets = len(forms) + len(programs)
    assets_with_campaign = len(forms_with_campaign) + len(programs_with_campaign)
    if total_assets == 0:
        coverage = 0
    else:
        coverage = assets_with_campaign / total_assets * 100

    if coverage < CAMPAIGN_COVERAGE_MIN_PCT:
        return {
            "id": "connected_campaigns_coverage",
            "severity": "low",
            "title": f"Only {coverage:.0f}% of Key Assets Linked to a Campaign (threshold: {CAMPAIGN_COVERAGE_MIN_PCT:.0f}%)",
            "status": "partial",
            "detail": (
                f"{assets_with_campaign} of {total_assets} forms/programs have a campaign association. "
                "Without Connected Campaigns, ROI attribution per campaign is incomplete. "
                "Pardot cannot report 'which campaign sourced this opportunity?'"
            ),
            "recommendation": (
                "Assign every form, landing page, and Engagement Studio program to a "
                "Connected Campaign. Use a consistent naming convention: "
                "'[Year] [Brand] [Type] [Region]' e.g. '2026 Newsletter DACH'."
            ),
        }
    return {
        "id": "connected_campaigns_coverage",
        "severity": "ok",
        "title": f"Campaign Attribution Coverage: {coverage:.0f}%",
        "status": "pass",
        "detail": f"{assets_with_campaign} of {total_assets} key assets have campaign associations.",
        "recommendation": "",
    }


# ── Orphan summary from cross-refs ────────────────────────────────────────────

def check_orphaned_assets(d):
    xref = d["cross_refs"]
    if not xref:
        return {
            "id": "orphaned_assets",
            "severity": "low",
            "title": "Cross-Reference Data Not Available",
            "status": "unknown",
            "detail": "Run analyze_cross_references.py first.",
            "recommendation": "",
        }
    orphans = xref.get("orphans", {})
    orphan_lists  = orphans.get("lists_not_referenced_anywhere", [])
    paused_autos  = orphans.get("paused_automations", [])
    empty_campaigns = orphans.get("campaigns_with_no_linked_assets", [])
    broken_dyncontent = orphans.get("dynamic_content_with_broken_field_reference", [])
    no_campaign_assets = (
        len(orphans.get("forms_without_campaign", []))
        + len(orphans.get("formhandlers_without_campaign", []))
        + len(orphans.get("sent_emails_without_campaign", []))
    )

    issues = (
        len(orphan_lists) > ORPHAN_LISTS_MAX
        or len(paused_autos) > PAUSED_AUTOMATIONS_MAX
        or len(empty_campaigns) > 0
        or len(broken_dyncontent) > 0
    )

    if issues:
        detail_parts = [
            f"Orphan lists (not referenced by any automation, form, or program): "
            f"{', '.join(i['name'] for i in orphan_lists[:5])}{'...' if len(orphan_lists) > 5 else ''}.",
            f"Paused automations (may be obsolete): "
            f"{', '.join(i['name'] for i in paused_autos[:5])}{'...' if len(paused_autos) > 5 else ''}.",
        ]
        if empty_campaigns:
            detail_parts.append(
                f"Campaigns with zero linked assets (likely dead): "
                f"{', '.join(i['name'] for i in empty_campaigns[:5])}{'...' if len(empty_campaigns) > 5 else ''}."
            )
        if broken_dyncontent:
            detail_parts.append(
                f"Dynamic content blocks whose `based_on` field no longer exists (personalization "
                f"silently broken — every recipient sees the default content): "
                f"{', '.join(i['name'] for i in broken_dyncontent[:5])}{'...' if len(broken_dyncontent) > 5 else ''}."
            )
        if no_campaign_assets:
            detail_parts.append(
                f"{no_campaign_assets} form(s)/form handler(s)/sent email(s) have no campaign "
                "attribution at all, so they cannot appear in any campaign ROI report."
            )
        return {
            "id": "orphaned_assets",
            "severity": "low" if not broken_dyncontent else "medium",
            "title": f"{len(orphan_lists)} Orphan Lists, {len(paused_autos)} Paused Automations, "
                     f"{len(empty_campaigns)} Empty Campaigns, {len(broken_dyncontent)} Broken Dynamic Content "
                     f"(list/automation thresholds: {ORPHAN_LISTS_MAX} / {PAUSED_AUTOMATIONS_MAX})",
            "status": "warning",
            "detail": " ".join(detail_parts),
            "recommendation": (
                "Review orphan lists for deletion or archiving — they consume quota and add confusion. "
                "Review paused automations: document why each is paused, then either reactivate "
                f"or delete (aim for < {PAUSED_AUTOMATIONS_MAX} paused rules at any time). "
                "Delete or repurpose campaigns with zero linked assets. "
                "Fix or remove dynamic content blocks with a broken field reference — they are "
                "currently showing the same default content to every recipient. "
                "Assign a Connected Campaign to every form, form handler, and list email."
            ),
        }
    return {
        "id": "orphaned_assets",
        "severity": "ok",
        "title": "Asset Hygiene Is Good",
        "status": "pass",
        "detail": (
            f"{len(orphan_lists)} orphan lists, {len(paused_autos)} paused automations, "
            f"{len(empty_campaigns)} empty campaigns, {len(broken_dyncontent)} broken dynamic content references."
        ),
        "recommendation": "",
    }


# ── Run all checks ────────────────────────────────────────────────────────────

CHECKS = [
    check_formal_scoring_model,
    check_consent_expiry,
    check_grading,
    check_preference_center,
    check_engagement_studio_coverage,
    check_landing_pages,
    check_ab_testing,
    check_progressive_profiling,
    check_lifecycle_stages,
    check_page_actions,
    check_suppression_completeness,
    check_community_nurture,
    check_connected_campaigns,
    check_orphaned_assets,
]

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "ok": 4}


def run_all_checks(d):
    results = [check(d) for check in CHECKS]
    return sorted(results, key=lambda r: SEVERITY_ORDER.get(r["severity"], 99))


# ── Markdown report builder ───────────────────────────────────────────────────

SEVERITY_EMOJI = {
    "critical": "🔴",
    "high":     "🟠",
    "medium":   "🟡",
    "low":      "🔵",
    "ok":       "✅",
}

STATUS_LABEL = {
    "pass":    "✅ Pass",
    "fail":    "❌ Fail",
    "partial": "⚠️  Partial",
    "unknown": "❓ Unknown",
    "warning": "⚠️  Warning",
    "ok":      "✅ Pass",
}


def build_use_case_summary(d):
    """
    Fully data-driven inventory & pattern summary for the active org.

    No org-, brand-, product-, or language-specific vocabulary is hardcoded here —
    every claim is derived from the actual scraped data for utils.ACTIVE_ORG, and a
    section is only emitted if matching data was actually found. This avoids the
    previous failure mode where a single customer's brand names (and assumed
    locale/persona structure) were printed verbatim into every other org's report.
    """
    lists = d["lists"]
    automations = d["automations"]
    programs = d["programs"]
    forms = d["forms"]
    fh = d["formhandlers"]
    dyn = d["dyn_content"]

    def _sample(items, n=5, key="name"):
        names_ = [i.get(key, "") for i in items[:n]]
        more = f" (+{len(items) - n} more)" if len(items) > n else ""
        return (", ".join(n_ for n_ in names_ if n_) + more) if names_ else "none"

    consent_lists     = [l for l in lists if any(kw in l.get("name", "").lower() for kw in ("check", "consent", "optin", "opt-in", "doi", "waiting"))]
    newsletter_lists  = [l for l in lists if "newsletter" in l.get("name", "").lower()]
    suppression_lists = [l for l in lists if any(kw in l.get("name", "").lower() for kw in ("suppression", "unterdrück"))]
    employee_lists    = [l for l in lists if any(kw in l.get("name", "").lower() for kw in ("mitarbeiter", "employee", "internal"))]
    community_lists   = [l for l in lists if "community" in l.get("name", "").lower()]

    consent_autos = [a for a in automations if "consent" in a.get("name", "").lower()]
    spam_autos    = [a for a in automations if "spam" in a.get("name", "").lower()]
    sync_autos    = [a for a in automations if any(kw in a.get("name", "").lower() for kw in ("sync", "crm"))]

    doi_forms   = [f for f in forms if any(kw in f.get("name", "").lower() for kw in ("doi", "optin", "opt-in"))]
    event_forms = [f for f in forms if any(kw in f.get("name", "").lower() for kw in ("event", "messe", "fair", "webinar", "tradeshow"))]

    lines = [
        "## Detected Use Cases & Patterns",
        "",
        f"_Org: **{utils.ACTIVE_ORG}** — every figure below is derived from this instance's "
        f"own scraped data; no other customer's brand names, locales, or segmentation are assumed._",
        "",
    ]

    if consent_lists or consent_autos or doi_forms:
        lines += [
            "### Consent / Double Opt-In Management",
            f"**{len(consent_lists)} consent-related list(s)**, **{len(consent_autos)} consent "
            f"automation rule(s)**, **{len(doi_forms)} opt-in form(s)** detected.",
            f"Examples: {_sample(consent_lists)}",
            "",
        ]
    if newsletter_lists:
        lines += [
            "### Newsletter Segmentation",
            f"**{len(newsletter_lists)} newsletter list(s)** found: {_sample(newsletter_lists)}.",
            "",
        ]
    if suppression_lists or spam_autos:
        lines += [
            "### Suppression & Spam Protection",
            f"**{len(suppression_lists)} suppression list(s)**: {_sample(suppression_lists)}. "
            f"**{len(spam_autos)} spam-detection automation(s)** found.",
            "",
        ]
    if event_forms:
        lines += [
            "### Event / Trade-Show Forms",
            f"**{len(event_forms)} event-related form(s)**: {_sample(event_forms)}.",
            "",
        ]
    if community_lists:
        lines += [
            "### Community Lists",
            f"**{len(community_lists)} community list(s)**: {_sample(community_lists)}.",
            "",
        ]
    if sync_autos:
        lines += [
            "### CRM Sync Automation",
            f"**{len(sync_autos)} automation rule(s)** reference sync/CRM keywords: {_sample(sync_autos)}.",
            "",
        ]
    if employee_lists:
        lines += [
            "### Internal / Employee Exclusion",
            f"**{len(employee_lists)} employee/internal list(s)**: {_sample(employee_lists)}.",
            "",
        ]
    if programs:
        lines += [
            "### Engagement Studio",
            f"**{len(programs)} Engagement Studio program(s)** configured.",
            "",
        ]

    lines += [
        f"**Asset Inventory:** {len(lists)} dynamic lists · {len(automations)} automation rules · "
        f"{len(forms)} forms · {len(fh)} form handlers · {len(programs)} Engagement Studio programs · "
        f"{len(dyn)} dynamic content blocks",
    ]
    return "\n".join(lines)


def build_markdown_report(d, checks):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    xref = d["cross_refs"]
    summary = xref.get("summary", {}) if xref else {}

    critical = [c for c in checks if c["severity"] == "critical"]
    high     = [c for c in checks if c["severity"] == "high"]
    medium   = [c for c in checks if c["severity"] == "medium"]
    low      = [c for c in checks if c["severity"] == "low"]
    ok       = [c for c in checks if c["severity"] == "ok"]

    lines = [
        f"# Pardot Best Practice Gap Analysis",
        f"**Generated:** {now}  |  **Org:** {utils.ACTIVE_ORG}",
        "",
        "---",
        "",
        build_use_case_summary(d),
        "",
        "---",
        "",
        "## Best Practice Gap Analysis",
        "",
        f"| Severity | Check | Status |",
        f"|---|---|---|",
    ]
    for c in checks:
        emoji = SEVERITY_EMOJI.get(c["severity"], "")
        status = STATUS_LABEL.get(c["status"], c["status"])
        lines.append(f"| {emoji} {c['severity'].upper()} | {c['title']} | {status} |")

    lines += ["", "---", ""]

    for severity_label, group in [
        ("Critical (Compliance Risk)", critical),
        ("High (Revenue Impact)", high),
        ("Medium (Efficiency & Data Quality)", medium),
        ("Low (Nice to Have)", low),
    ]:
        if not group:
            continue
        lines.append(f"## {severity_label}")
        lines.append("")
        for c in group:
            emoji = SEVERITY_EMOJI.get(c["severity"], "")
            lines.append(f"### {emoji} {c['title']}")
            lines.append("")
            if c.get("detail"):
                lines.append(f"**Issue:** {c['detail']}")
                lines.append("")
            if c.get("recommendation"):
                lines.append(f"**Recommendation:**")
                lines.append("")
                for rec_line in c["recommendation"].splitlines():
                    lines.append(rec_line)
                lines.append("")
            lines.append("---")
            lines.append("")

    if ok:
        lines.append("## Passing Checks")
        lines.append("")
        for c in ok:
            lines.append(f"- ✅ **{c['title']}** — {c.get('detail', '')}")
        lines.append("")

    return "\n".join(lines)


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    global BASE_DIR
    if not utils.OUTPUT_DIR:
        utils.load_org_config()
    BASE_DIR = utils.OUTPUT_DIR
    _load_thresholds()

    print("\n🔍 Pardot Best Practice Gap Analyzer")
    print("=" * 45)
    print("Reads existing JSON exports — no browser required.\n")

    d = load_all()
    checks = run_all_checks(d)

    critical_count = sum(1 for c in checks if c["severity"] == "critical" and c["status"] != "pass")
    high_count     = sum(1 for c in checks if c["severity"] == "high" and c["status"] != "pass")
    medium_count   = sum(1 for c in checks if c["severity"] == "medium" and c["status"] != "pass")

    print(f"   Ran {len(checks)} checks: "
          f"{critical_count} critical · {high_count} high · {medium_count} medium gaps\n")

    # Save JSON
    output_json = {
        "generated_at": datetime.now().isoformat(),
        "org": utils.ACTIVE_ORG,
        "summary": {
            "critical_gaps": critical_count,
            "high_gaps": high_count,
            "medium_gaps": medium_count,
        },
        "checks": checks,
    }
    with open(utils.output_path("pardot_gap_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(output_json, f, indent=2, ensure_ascii=False)
    print("   ✅ JSON saved to pardot_gap_analysis.json")

    # Save Markdown
    md = build_markdown_report(d, checks)
    with open(utils.output_path("pardot_gap_analysis.md"), "w", encoding="utf-8") as f:
        f.write(md)
    print("   ✅ Markdown saved to pardot_gap_analysis.md")

    print(f"\n── Priority Gaps ────────────────────────────────")
    for c in checks:
        if c["severity"] in ("critical", "high") and c["status"] not in ("pass", "ok"):
            emoji = SEVERITY_EMOJI.get(c["severity"], "")
            print(f"   {emoji} [{c['severity'].upper()}] {c['title']}")

    print(f"\n✅ Gap analysis complete.")


if __name__ == "__main__":
    main()
