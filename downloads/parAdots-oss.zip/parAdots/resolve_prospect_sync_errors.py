"""
Pardot Prospect Sync Errors — Root-Cause Resolver (Step 2 of 2)
===============================================================
Takes the raw sync-error queue captured by scrape_prospect_sync_errors.py and,
for every row, works out *what to actually fix*:

  1. Classify the CRM error message (localisation-aware: DE + EN).
  2. Decide where the offending value lives — on the Pardot prospect (a value
     being pushed) or in Salesforce (record state / owner).
  3. When it lives on the prospect, read the prospect via the Pardot v5 API and
     pin the exact field + value that violates the rule:
        • picklist / field-integrity → the prospect value NOT in the SF field's
          valid picklist (verified against a live SObject describe)
        • value-too-long            → the prospect value longer than the SF
          field length
     When it lives in Salesforce (inactive owner / reactivation of an inactive
     record) → resolve the inactive user's name; no prospect field to change.

Design note — why "find the value that fails the rule"
------------------------------------------------------
There is no reliable generic map from a Salesforce field *label* (as it appears
in a localised error string) to a Pardot prospect field API name. Instead of
guessing the mapping, we use the SObject describe the error itself points at
(its picklist values / length) and search the prospect for the value that
breaks *that* constraint. This is language-independent and self-verifying.

The classifier (classify_error / extract_trailing_field / find_offending_value)
is pure and import-safe so it can be unit-tested without a browser or org.

Auth: SF describe via salesforce_api (CLI token or Pardot session); prospect
reads via pardot_api (Pardot v5, token lifted from the browser session).

Output (output/{org}/):
  pardot_prospect_sync_errors.csv    (rewritten with resolution columns added)
  pardot_prospect_sync_errors_resolved.json

Called from run_all.py / run_sf.py:
  from resolve_prospect_sync_errors import run
  run(page=page, client=sf_client)
"""
from __future__ import annotations

import os
import re
import sys

import utils

# ── Error classes ───────────────────────────────────────────────────────────
CLS_INACTIVE_OWNER   = "INACTIVE_OWNER"
CLS_LIFECYCLE        = "LIFECYCLE_INACTIVE"      # reactivate / mark-active validation
CLS_FIELD_INTEGRITY  = "FIELD_INTEGRITY"         # picklist / bad value
CLS_FIELD_TOO_LONG   = "FIELD_TOO_LONG"
CLS_REQUIRED_MISSING = "REQUIRED_MISSING"
CLS_DUPLICATE        = "DUPLICATE"
CLS_INVALID_ID       = "INVALID_ID"              # bad CRM Contact/Lead id (e.g. CampaignMember)
CLS_INVALID_EMAIL    = "INVALID_EMAIL"           # invalid email (prospect or synced from CRM)
CLS_CUSTOM_VALIDATION = "CUSTOM_VALIDATION"      # generic custom validation rule
CLS_OTHER            = "OTHER"

# Where the fix has to happen.
FIX_PROSPECT = "Pardot prospect field"
FIX_CRM      = "Salesforce (CRM record / owner)"
FIX_DEDUPE   = "Salesforce dedupe / prospect email"
FIX_UNKNOWN  = "Review manually"

# Localisation keyword sets (lower-cased substring match). DE + EN.
_KW = {
    "inactive_owner":  ("inactive owner", "inactive user", "inaktiver benutzer",
                        "inaktiven benutzer", "inaktiver eigentümer"),
    "lifecycle":       ("inaktiv", "reaktiv", "reactivate", "inactive record",
                        "als aktiv markiert", "mark active", "marked as active"),
    "field_integrity": ("field integrity exception",),
    "too_long":        ("too long", "zu lang", "data value too large",
                        "value too large", "string_too_long"),
    "required":        ("required field", "erforderlich", "pflichtfeld",
                        "required_field_missing", "missing a required"),
    "duplicate":       ("duplicate", "duplikat", "duplicate_value",
                        "duplicate value found"),
    "invalid_id":      ("invalid id", "unzulässiger typ des id", "unzulaessiger typ des id",
                        "id-werts", "id value of incorrect type", "malformed id",
                        "ungültige id"),
    "invalid_picklist": ("invalid picklist value", "restricted picklist",
                        "bad value for restricted picklist",
                        "fehlerhafter wert für eingeschränkt",
                        "eingeschränktes auswahllistenfeld"),
    "invalid_email":   ("invalid email", "ungültige e-mail", "ungueltige e-mail",
                        "invalid email address", "ungültige e-mail-adresse"),
    "synced_from_sf":  ("synced from salesforce", "being synced from salesforce",
                        "from salesforce"),
    "custom_val":      ("custom validation exception", "field_custom_validation",
                        "fieldcustomvalidation"),
}

_EMAIL_RE = re.compile(r"[\w.+\-]+@[\w\-]+\.[\w.\-]+", re.UNICODE)


def extract_email(msg: str) -> str:
    m = _EMAIL_RE.search(msg or "")
    return m.group(0) if m else ""

# SF field-label hint → candidate Pardot prospect standard field names.
# Used only to *prefer* a candidate when several prospect values break a rule;
# the picklist/length check is what actually confirms the offender.
_LABEL_HINTS = (
    (("bundesland", "bundesstaat", "state", "province", "postanschrift"), ["state"]),
    (("land", "country", "staat"),                                        ["country"]),
    (("ort", "city", "stadt"),                                            ["city"]),
    (("plz", "zip", "postal", "postleitzahl"),                            ["zip"]),
    (("straße", "strasse", "street", "address", "adresse"),               ["address1", "address2"]),
    (("firma", "company", "unternehmen", "account"),                      ["company"]),
    (("telefon", "phone", "fon"),                                         ["phone", "fax"]),
    (("titel", "title", "position"),                                      ["jobTitle"]),
)

# Conservative set of *known-valid* Pardot v5 prospect fields to request.
# Requesting an unknown field name makes v5 400 the whole read, so we stick to
# documented standard fields; these cover the address/identity constraints that
# CRM validation rules almost always fire on.
PROSPECT_FIELDS = [
    "id", "salesforceId", "firstName", "lastName", "email", "company", "jobTitle",
    "department", "country", "city", "state", "zip", "territory",
    "phone", "fax", "salutation", "website", "source", "industry",
]

# Mapping from CSV export/canonical column names to PROSPECT_FIELDS keys
_EXPORT_FIELD_MAPPING = {
    "Email": "email",
    "Country": "country",
    "State": "state",
    "City": "city",
    "Zip": "zip",
    "Phone": "phone",
    "Salutation": "salutation",
    "First Name": "firstName",
    "Last Name": "lastName",
    "Company": "company",
    "Job Title": "jobTitle",
    "Department": "department",
    "Territory": "territory",
    "Fax": "fax",
    "Website": "website",
    "Source": "source",
    "Industry": "industry",
}


def _prospect_from_record(rec: dict) -> dict:
    """
    Extract prospect field values directly from the CSV export record.
    Returns a dict keyed like PROSPECT_FIELDS with values available from the export.
    Used as the first step in FIX_PROSPECT resolution, before hitting the API or
    UI scrape.

    Records should already have normalized column names from scrape_prospect_sync_errors.
    """
    prospect = {}

    # Map standard fields from export columns
    for export_col, field_key in _EXPORT_FIELD_MAPPING.items():
        if export_col in rec and rec[export_col]:
            prospect[field_key] = rec[export_col]

    # CRM ID: prefer CRM Contact FID, fall back to CRM Lead FID
    if rec.get("CRM Contact FID"):
        prospect["salesforceId"] = rec["CRM Contact FID"]
    elif rec.get("CRM Lead FID") and rec["CRM Lead FID"] != "[[crm_deleted]]":
        prospect["salesforceId"] = rec["CRM Lead FID"]

    # Prospect ID from the record
    if rec.get("Prospect ID"):
        prospect["id"] = rec["Prospect ID"]

    return prospect

# Salesforce Id 3-char key-prefix → object.
_USER_PREFIX = "005"
_ID_PREFIX_OBJ = {"00Q": "Lead", "003": "Contact"}

# Classic prospect read-page UI label → canonical PROSPECT_FIELDS key.
# Fallback source used when the Pardot v5 API read (pardot_api.get_one) fails
# (401 / token rejected by the org) — the browser is already authenticated
# for the classic UI, so we scrape the same field/value table it renders.
PROSPECT_PATH = "/prospect/read/id/{id}"
_UI_LABEL_TO_FIELD = {
    # English UI
    "country": "country", "state": "state", "city": "city",
    "zip/postal code": "zip", "street": "address1", "address two": "address2",
    "phone": "phone", "fax": "fax", "position": "jobTitle",
    "department": "department", "territory": "territory", "source": "source",
    "salutation": "salutation", "company": "company", "website": "website",
    "industry": "industry", "email": "email",
    "crm lead id": "salesforceId", "crm contact id": "salesforceId",
    # German UI (Soylent etc.)
    "land": "country", "bundesland": "state", "staat": "state",
    "bundesland/provinz": "state", "stadt": "city", "ort": "city",
    "plz": "zip", "postleitzahl": "zip", "plz/postleitzahl": "zip",
    "straße": "address1", "strasse": "address1", "adresse": "address1",
    "adresse 1": "address1", "adresse 2": "address2", "adresse zwei": "address2",
    "telefon": "phone", "abteilung": "department", "gebiet": "territory",
    "region": "territory", "quelle": "source", "anrede": "salutation",
    "unternehmen": "company", "firma": "company",
    "webseite": "website", "branche": "industry", "e-mail": "email",
    "crm-lead-id": "salesforceId", "crm-kontakt-id": "salesforceId",
    "crm lead-id": "salesforceId", "crm kontakt-id": "salesforceId",
}

# Fuzzy fallback for UI labels not in the exact map (substring, order matters —
# most specific first so 'bundesland' hits state before 'land' hits country).
_UI_LABEL_FUZZY = (
    ("bundesland", "state"), ("bundesstaat", "state"),
    ("postleitzahl", "zip"), ("plz", "zip"),
    ("country", "country"), ("land", "country"), ("staat", "country"),
    ("city", "city"), ("stadt", "city"), ("ort", "city"),
    ("street", "address1"), ("straße", "address1"), ("strasse", "address1"),
    ("telefon", "phone"), ("phone", "phone"),
    ("firma", "company"), ("unternehmen", "company"), ("company", "company"),
    ("branche", "industry"), ("industry", "industry"),
    ("lead id", "salesforceId"), ("contact id", "salesforceId"),
    ("lead-id", "salesforceId"), ("kontakt-id", "salesforceId"),
)

_PROSPECT_FIELD_TABLE_JS = r"""
() => {
  const out = {};
  document.querySelectorAll('tr').forEach(tr => {
    const k = tr.querySelector('td.key');
    const v = tr.querySelector('td.value');
    if (k && v) out[(k.innerText || '').trim().toLowerCase()] = (v.innerText || '').trim();
  });
  return out;
}
"""


def _scrape_prospect_fields_from_page(page, prospect_id: str) -> dict:
    """
    Fallback prospect-field read via the classic Pardot UI (already
    authenticated in this browser session) for when the v5 API token is
    rejected by the org. Returns a dict keyed like PROSPECT_FIELDS.
    """
    try:
        utils.navigate(page, utils.pardot_url(PROSPECT_PATH.format(id=prospect_id)), timeout=20000)
        page.wait_for_timeout(1500)
        raw = page.evaluate(_PROSPECT_FIELD_TABLE_JS)
    except Exception as e:
        # Surface the failure instead of silently returning nothing — a blank
        # values row is indistinguishable from "prospect has no value" otherwise.
        return {"_scrape_error": f"{type(e).__name__}: {e}"}
    out = {}
    unmapped = []
    for label, value in (raw or {}).items():
        key = _UI_LABEL_TO_FIELD.get(label)
        if not key:
            key = next((f for kw, f in _UI_LABEL_FUZZY if kw in label), None)
        if key and value:
            out.setdefault(key, value)   # exact-map hit wins over fuzzy
        elif value:
            unmapped.append(label)
    if not out and unmapped:
        # Self-diagnosis: surface what the page actually showed so a label-map
        # gap is visible in the output instead of silently producing blanks.
        out["_unmapped_labels"] = ", ".join(unmapped[:15])
    return out


# ── Pure classification / extraction (unit-testable) ─────────────────────────

def _has(msg_low: str, keys) -> bool:
    return any(k in msg_low for k in keys)


def extract_trailing_field(msg: str) -> str:
    """
    Salesforce field-integrity / validation messages usually end with the
    offending field label after the last ': ' — e.g.
      '... gültigen Bundesstaaten aus.: Bundesland (Postanschrift)'
    Return that trailing label, or '' if the tail looks like a sentence.
    """
    if ":" not in msg:
        return ""
    tail = msg.rsplit(":", 1)[1].strip()
    # A field label is short and not a full sentence.
    if tail and len(tail) <= 60 and tail.count(" ") <= 6 and not tail.endswith("."):
        return tail
    return ""


def extract_leading_field(msg: str) -> str:
    """
    Some messages name the field between the first two colons, e.g.
      'Invalid picklist value: Sprache: fehlerhafter Wert für …' → 'Sprache'
    Return that field label, or '' if it doesn't look like one.
    """
    parts = msg.split(":")
    if len(parts) >= 3:
        cand = parts[1].strip()
        if cand and len(cand) <= 60 and cand.count(" ") <= 6 and not cand.endswith("."):
            return cand
    return ""


def extract_sf_id(msg: str, prefix: str = "") -> str:
    """Extract the first 15/18-char Salesforce Id in the message (optionally
    filtered by key-prefix, e.g. '005' for User)."""
    for m in re.finditer(r"\b([a-zA-Z0-9]{15}|[a-zA-Z0-9]{18})\b", msg):
        sid = m.group(1)
        if not prefix or sid.startswith(prefix):
            # crude sanity: must contain a digit (SF ids do)
            if any(c.isdigit() for c in sid):
                return sid
    return ""


def classify_error(msg: str) -> dict:
    """
    Classify a CRM sync-error message. Pure: no I/O.
    Returns:
      { error_class, fix_location, field_label, sf_id, subtype }
    """
    m = (msg or "").strip()
    low = m.lower()
    out = {"error_class": CLS_OTHER, "fix_location": FIX_UNKNOWN,
           "field_label": "", "sf_id": "", "subtype": ""}

    if not m:
        return out

    # Order matters: most specific first.
    if _has(low, _KW["inactive_owner"]):
        out.update(error_class=CLS_INACTIVE_OWNER, fix_location=FIX_CRM,
                   sf_id=extract_sf_id(m, _USER_PREFIX), subtype="owner")
        return out

    if _has(low, _KW["invalid_id"]):
        # e.g. CampaignMember insert with an invalid/mistyped CRM Contact/Lead id:
        # the prospect isn't linked to a valid CRM record. Fix is CRM-side.
        out.update(error_class=CLS_INVALID_ID, fix_location=FIX_CRM,
                   field_label="CRM Contact/Lead Id", subtype="crm_id")
        return out

    if _has(low, _KW["invalid_email"]):
        # Bad email flowing from Salesforce → fix in CRM; otherwise the
        # prospect's own email is invalid.
        loc = FIX_CRM if _has(low, _KW["synced_from_sf"]) else FIX_PROSPECT
        out.update(error_class=CLS_INVALID_EMAIL, fix_location=loc,
                   field_label="email", subtype="email")
        return out

    if _has(low, _KW["too_long"]):
        out.update(error_class=CLS_FIELD_TOO_LONG, fix_location=FIX_PROSPECT,
                   field_label=extract_trailing_field(m))
        return out

    if _has(low, _KW["field_integrity"]):
        out.update(error_class=CLS_FIELD_INTEGRITY, fix_location=FIX_PROSPECT,
                   field_label=extract_trailing_field(m), subtype="picklist")
        return out

    if _has(low, _KW["invalid_picklist"]):
        # Restricted/invalid picklist value (e.g. 'Invalid picklist value:
        # Sprache: …'). Same remediation as a field-integrity picklist error, so
        # reuse that class to get value-pinning + Pardot/SF comparison.
        out.update(error_class=CLS_FIELD_INTEGRITY, fix_location=FIX_PROSPECT,
                   field_label=extract_leading_field(m) or extract_trailing_field(m),
                   subtype="restricted_picklist")
        return out

    if _has(low, _KW["required"]):
        out.update(error_class=CLS_REQUIRED_MISSING, fix_location=FIX_PROSPECT,
                   field_label=extract_trailing_field(m))
        return out

    if _has(low, _KW["duplicate"]):
        out.update(error_class=CLS_DUPLICATE, fix_location=FIX_DEDUPE)
        return out

    if _has(low, _KW["custom_val"]):
        # Lifecycle (inactive/reactivate) validation rules can't be fixed on a
        # prospect field — the CRM record state is the blocker.
        if _has(low, _KW["lifecycle"]):
            out.update(error_class=CLS_LIFECYCLE, fix_location=FIX_CRM,
                       subtype="reactivation")
        else:
            out.update(error_class=CLS_CUSTOM_VALIDATION, fix_location=FIX_PROSPECT,
                       field_label=extract_trailing_field(m))
        return out

    # Bare lifecycle wording without the "Custom Validation Exception" prefix.
    if _has(low, _KW["lifecycle"]):
        out.update(error_class=CLS_LIFECYCLE, fix_location=FIX_CRM,
                   subtype="reactivation")
        return out

    return out


def _candidate_fields(field_label: str) -> list[str]:
    """Prospect field names hinted by the SF label (best-effort ordering)."""
    low = (field_label or "").lower()
    hinted: list[str] = []
    for keys, fields in _LABEL_HINTS:
        if any(k in low for k in keys):
            hinted.extend(fields)
    return list(dict.fromkeys(hinted))


def find_offending_value(prospect: dict, sf_detail: dict | None,
                         cls: dict) -> dict:
    """
    Locate the exact prospect field/value that violates the rule.
    Pure: operates on already-fetched data.

    Returns { field, value, reason, confidence } (field='' if not found).
    """
    res = {"field": "", "value": "", "reason": "", "confidence": "low"}
    if not prospect:
        return res

    hinted = _candidate_fields(cls.get("field_label", ""))
    # Search order: hinted fields first, then every other string field.
    # Keys starting with '_' are diagnostics, not prospect fields.
    keys = hinted + [k for k in prospect.keys()
                     if k not in hinted and not k.startswith("_")]

    ec = cls.get("error_class")

    if ec in (CLS_FIELD_INTEGRITY, CLS_CUSTOM_VALIDATION) and sf_detail and sf_detail.get("picklist_values"):
        valid = {str(v).strip().lower() for v in sf_detail["picklist_values"]}
        violators = [k for k in keys
                     if prospect.get(k) not in (None, "")
                     and str(prospect[k]).strip().lower() not in valid]
        if violators:
            k = violators[0]  # keys is hint-ordered, so a hinted field wins
            # High confidence when the field is hinted by the SF label, or when
            # it's the only prospect value that breaks this picklist.
            conf = "high" if (k in hinted or len(violators) == 1) else "medium"
            res.update(field=k, value=str(prospect[k]),
                       reason=f"'{prospect[k]}' is not a valid picklist value for "
                              f"{sf_detail.get('label') or sf_detail.get('api_name')}",
                       confidence=conf)
        return res

    if ec == CLS_FIELD_TOO_LONG and sf_detail and sf_detail.get("length"):
        limit = int(sf_detail["length"])
        violators = [k for k in keys
                     if prospect.get(k) is not None and len(str(prospect[k])) > limit]
        if violators:
            k = violators[0]
            conf = "high" if (k in hinted or len(violators) == 1) else "medium"
            res.update(field=k, value=str(prospect[k]),
                       reason=f"length {len(str(prospect[k]))} exceeds field limit {limit}",
                       confidence=conf)
        return res

    # No SF detail (couldn't map the label): report the hinted field's value.
    for k in hinted:
        v = prospect.get(k)
        if v not in (None, ""):
            res.update(field=k, value=str(v),
                       reason="mapped from SF field label; picklist not verified",
                       confidence="medium")
            return res
    return res


# ── Salesforce describe → field index ────────────────────────────────────────

def _field_detail(fm: dict) -> dict:
    return {
        "api_name": fm.get("name", ""),
        "label":    fm.get("label", ""),
        "type":     fm.get("type", ""),
        "length":   fm.get("length"),
        "picklist_values": [v["value"] for v in fm.get("picklistValues", []) if v.get("active")],
    }


def _build_field_index(client, sobjects=("Lead", "Contact")) -> dict:
    """Return {label_or_name(lower): field_detail}. Lead wins on collision."""
    import salesforce_api as sf
    index: dict[str, dict] = {}
    for obj in sobjects:
        d = sf.describe(client, obj)
        if not d:
            continue
        for fm in d.get("fields", []):
            det = _field_detail(fm)
            for key in (det["label"], det["api_name"]):
                if key:
                    index.setdefault(key.strip().lower(), det)
    return index


def _lookup_field(index: dict, label: str) -> dict | None:
    if not label:
        return None
    low = label.strip().lower()
    if low in index:
        return index[low]
    # Try without a trailing parenthetical qualifier: "State (Mailing)" → "state"
    base = re.sub(r"\s*\(.*?\)\s*$", "", low).strip()
    return index.get(base)


# ── Pardot↔SF value + sync-behavior comparison (state / picklist errors) ──────

def _load_field_sync_map(org_output: str) -> dict:
    """
    Build {key_lower: {sync_behavior, sf_field, field_values}} from the Fields
    scrape (pardot_fields.json), keyed by Pardot api_name, display name, and the
    mapped SF field so any of them resolves the sync behavior.
    """
    import json
    path = os.path.join(org_output, "pardot_fields.json")
    out: dict = {}
    if not os.path.exists(path):
        return out
    try:
        data = json.load(open(path, encoding="utf-8"))
    except Exception:
        return out
    for grp in (data if isinstance(data, list) else []):
        for f in grp.get("fields", []):
            info = {"sync_behavior": f.get("sync_behavior", ""),
                    "sf_field": f.get("sf_field", ""),
                    "field_values": f.get("field_values", [])}
            for k in (f.get("api_name"), f.get("name"), f.get("sf_field")):
                if k:
                    out.setdefault(str(k).strip().lower(), info)
    return out


def _obj_from_id(sfid: str) -> str | None:
    return _ID_PREFIX_OBJ.get((sfid or "")[:3])


def _sf_field_meta_for_object(client, obj: str, label: str) -> dict | None:
    """Find the field on `obj` whose describe label matches `label` (with/without
    a trailing parenthetical)."""
    import salesforce_api as sf
    d = sf.describe(client, obj)
    if not d:
        return None
    low = label.strip().lower()
    base = re.sub(r"\s*\(.*?\)\s*$", "", low).strip()
    for fm in d.get("fields", []):
        l = (fm.get("label") or "").strip().lower()
        if l == low or l == base:
            return fm
    return None


def _sf_values_by_id(client, sfid: str, obj: str, field_apis: list[str]) -> dict:
    """Fetch several fields of one record in a single SOQL. Returns {api: value}."""
    import salesforce_api as sf
    fields = [f for f in field_apis if f]
    if not fields:
        return {}
    try:
        rows = sf.soql_all(client,
            f"SELECT {', '.join(dict.fromkeys(fields))} FROM {obj} WHERE Id = '{sfid}' LIMIT 1")
        return rows[0] if rows else {}
    except Exception:
        return {}


def _country_field_for_state(state_meta: dict, obj_field_names: set) -> str:
    """
    Resolve the mailing-country field paired with a state field.
    Prefers the dependent picklist's controllerName (describe), preferring the
    human-readable Country field over the ISO CountryCode. Falls back to a name
    transform (…State→…Country).
    """
    cands: list[str] = []
    ctrl = state_meta.get("controllerName") or ""
    if ctrl:
        if ctrl.endswith("Code"):
            cands.append(ctrl[:-4])   # MailingCountryCode → MailingCountry (display)
        cands.append(ctrl)
    nm = state_meta.get("name", "")
    if "State" in nm:
        cands.append(nm.replace("StateCode", "Country").replace("State", "Country"))
    for c in cands:
        if c in obj_field_names:
            return c
    return ""


def compare_sides(prospect: dict, cls: dict, sf_client, sync_map: dict) -> dict:
    """
    For a field/picklist error, gather the Pardot value, the Salesforce value,
    whether they differ, and the field's sync behavior. Best-effort; any missing
    piece is left blank with a note.
    """
    res = {"pardot_value": "", "sf_value": "", "differ": "",
           "pardot_country": "", "sf_country": "", "country_differ": "",
           "dependent": False, "sync_behavior": "", "sf_field_api": "", "note": ""}
    label = cls.get("field_label", "")

    hinted = _candidate_fields(label)
    pfield = hinted[0] if hinted else ""
    pval = prospect.get(pfield) if pfield else None
    res["pardot_value"] = "" if pval is None else str(pval)
    # Country is the controlling field of the State dependent picklist — always
    # capture the Pardot side so a country mismatch can be spotted.
    res["pardot_country"] = str(prospect.get("country") or "")

    # Sync behavior: try the Pardot field name, then the SF label.
    for key in (pfield, label):
        info = sync_map.get(str(key).strip().lower()) if key else None
        if info and info.get("sync_behavior"):
            res["sync_behavior"] = info["sync_behavior"]
            break

    sfid = prospect.get("salesforceId") or ""
    if not sfid:
        res["note"] = "no CRM id on prospect"
        return res
    if sf_client is None:
        res["note"] = "no SF client for CRM read"
        return res
    obj = _obj_from_id(sfid)
    if not obj:
        res["note"] = f"unrecognised CRM id prefix {sfid[:3]}"
        return res
    fmeta = _sf_field_meta_for_object(sf_client, obj, label)
    if not fmeta:
        res["note"] = f"field '{label}' not found on {obj}"
        return res
    res["sf_field_api"] = fmeta.get("name", "")
    res["dependent"]    = bool(fmeta.get("dependentPicklist"))

    import salesforce_api as sf
    names = sf.field_names(sf_client, obj)
    country_field = _country_field_for_state(fmeta, names)

    vals = _sf_values_by_id(sf_client, sfid, obj,
                            [res["sf_field_api"], country_field])
    sval = vals.get(res["sf_field_api"])
    res["sf_value"] = "" if sval is None else str(sval)
    if country_field:
        cval = vals.get(country_field)
        res["sf_country"] = "" if cval is None else str(cval)

    if res["pardot_value"] or res["sf_value"]:
        res["differ"] = ("Yes" if res["pardot_value"].strip().lower()
                         != res["sf_value"].strip().lower() else "No")
    if res["pardot_country"] or res["sf_country"]:
        res["country_differ"] = ("Yes" if res["pardot_country"].strip().lower()
                                 != res["sf_country"].strip().lower() else "No")
    return res


# ── Runner ───────────────────────────────────────────────────────────────────

RESOLUTION_COLUMNS = [
    "Error Class", "Fix Location", "SF Field",
    "Offending Field", "Offending Value",
    "Pardot Value", "SF Value", "Values Differ",
    "Pardot Country", "SF Country",
    "Sync Behavior", "Valid / Limit", "Confidence", "Resolution Note",
]


def _valid_or_limit(sf_detail: dict | None, cls: dict) -> str:
    if not sf_detail:
        return ""
    if cls.get("error_class") == CLS_FIELD_TOO_LONG:
        return f"max {sf_detail.get('length')}"
    pv = sf_detail.get("picklist_values") or []
    if pv:
        shown = ", ".join(pv[:12])
        return shown + (f" … (+{len(pv) - 12})" if len(pv) > 12 else "")
    return ""


def run(page=None, client=None) -> None:
    print("\n🚀 Prospect Sync Errors — Root-Cause Resolver (Step 2)")
    print("=" * 50)

    in_json      = utils.output_path("pardot_prospect_sync_errors.json")
    out_csv_res  = utils.output_path("pardot_prospect_sync_errors_resolved.csv")
    out_json     = utils.output_path("pardot_prospect_sync_errors_resolved.json")

    if not os.path.exists(in_json):
        print(f"❌ {in_json} not found — run scrape_prospect_sync_errors.py first.")
        return

    import json
    with open(in_json, encoding="utf-8") as f:
        records = json.load(f)
    print(f"   Loaded {len(records)} sync-error rows")

    # SF describe index (picklist values + lengths). Optional but needed for
    # high-confidence resolution.
    field_index: dict = {}
    import salesforce_api as sf
    if client is None:
        try:
            client = sf.client_from_cli()
        except Exception as e:
            print(f"   ℹ️  SF CLI auth unavailable ({e}); trying browser session")
    if client is None and page is not None:
        try:
            client = sf.client_from_page(page)
        except Exception as e:
            print(f"   ⚠️  No Salesforce client ({e}); picklist verification disabled")
    if client is not None:
        try:
            print("   Building Lead/Contact field index (describe)…")
            field_index = _build_field_index(client)
            print(f"   Indexed {len(field_index)} field labels/names")
        except Exception as e:
            print(f"   ⚠️  describe failed ({e}); picklist verification disabled")

    # Pardot v5 client for prospect reads.
    pardot_client = None
    if page is not None:
        try:
            import pardot_api
            pardot_client = pardot_api.client_from_page(page)
        except SystemExit:
            print("   ⚠️  Pardot API token unavailable; prospect values will not be read")
        except Exception as e:
            print(f"   ⚠️  Pardot client init failed ({e}); prospect values not read")

    # Field sync-behavior map from the Fields scrape (pardot_fields.json).
    sync_map = _load_field_sync_map(utils.OUTPUT_DIR)
    if sync_map:
        print(f"   Loaded sync behavior for {len(sync_map)} field key(s)")
    else:
        print("   ℹ️  pardot_fields.json not found — Sync Behavior column will be blank "
              "(run the Fields scraper to populate it)")

    # Cache inactive-user name lookups.
    _user_cache: dict[str, str] = {}

    def _user_name(uid: str) -> str:
        if not uid or client is None:
            return ""
        if uid in _user_cache:
            return _user_cache[uid]
        try:
            rows = sf.soql_all(client,
                f"SELECT Name, IsActive FROM User WHERE Id = '{uid}' LIMIT 1")
            name = rows[0]["Name"] if rows else ""
        except Exception:
            name = ""
        _user_cache[uid] = name
        return name

    resolved = []
    for i, rec in enumerate(records, 1):
        msg = rec.get("Error", "")
        pid = rec.get("Prospect ID", "")
        cls = classify_error(msg)
        sf_detail = _lookup_field(field_index, cls["field_label"])

        r = {
            "Error Class":     cls["error_class"],
            "Fix Location":    cls["fix_location"],
            "SF Field":        (sf_detail or {}).get("label") or cls["field_label"],
            "Offending Field": "",
            "Offending Value": "",
            "Pardot Value":    "",
            "SF Value":        "",
            "Values Differ":   "",
            "Pardot Country":  "",
            "SF Country":      "",
            "Sync Behavior":   "",
            "Valid / Limit":   _valid_or_limit(sf_detail, cls),
            "Confidence":      "low",
            "Resolution Note": "",
        }

        if cls["error_class"] == CLS_INACTIVE_OWNER:
            uid = cls["sf_id"]
            nm  = _user_name(uid)
            r["Offending Value"] = f"{uid} {('('+nm+')') if nm else ''}".strip()
            r["Confidence"] = "high" if uid else "medium"
            r["Resolution Note"] = ("Reassign the lead/contact owner to an active "
                                    "user, or reactivate the user in Salesforce.")

        elif cls["error_class"] == CLS_LIFECYCLE:
            r["Offending Value"] = "CRM record is inactive"
            r["Confidence"] = "high"
            r["Resolution Note"] = ("A CRM validation rule blocks (re)activating an "
                                    "inactive record via sync. Fix in Salesforce, not Pardot.")

        elif cls["error_class"] == CLS_INVALID_ID:
            r["Offending Field"] = "CRM Contact/Lead Id"
            r["Offending Value"] = extract_email(msg) or "unlinked prospect"
            r["Confidence"] = "medium"
            # Check if the CRM Lead/Contact FID is marked as deleted
            if rec.get("CRM Lead FID") == "[[crm_deleted]]":
                r["Resolution Note"] = ("Prospect verweist auf einen in Salesforce gelöschten Lead/Contact — "
                                        "neuen CRM-Datensatz zuordnen oder Prospect archivieren.")
            else:
                r["Resolution Note"] = ("Prospect is not linked to a valid Salesforce "
                                        "Contact/Lead, so CampaignMember sync fails — fix "
                                        "the CRM record linkage / prospect's CRM id.")

        elif cls["error_class"] == CLS_INVALID_EMAIL:
            email = extract_email(msg)
            r["Offending Field"] = "email"
            r["Offending Value"] = email
            r["Confidence"] = "high" if email else "medium"
            if cls["fix_location"] == FIX_CRM:
                r["Resolution Note"] = ("Invalid email is being synced FROM Salesforce — "
                                        "correct the Lead/Contact email in the CRM.")
            else:
                r["Resolution Note"] = "Prospect email is invalid — correct it in Pardot."

        elif cls["error_class"] == CLS_DUPLICATE:
            r["Offending Field"] = "email"
            r["Offending Value"] = rec.get("Name", "") and ""  # value unknown from list
            r["Offending Value"] = ""
            r["Confidence"] = "medium"
            r["Resolution Note"] = ("Duplicate Lead/Contact in Salesforce for this "
                                    "prospect's email — deduplicate the CRM records.")

        elif cls["fix_location"] == FIX_PROSPECT and (pardot_client or page) and pid:
            # Step 1: Try to extract prospect values from the CSV export record
            prospect = _prospect_from_record(rec)

            # Step 2: If export lacks a hinted field, try the Pardot v5 API
            _hinted = _candidate_fields(cls["field_label"])
            export_incomplete = bool(_hinted) and not any(
                prospect.get(h) not in (None, "") for h in _hinted)
            if export_incomplete and pardot_client:
                try:
                    import pardot_api
                    api_prospect = pardot_api.get_one(pardot_client, "objects/prospects",
                                                      pid, fields=PROSPECT_FIELDS)
                    if api_prospect:
                        # API values fill in what the export didn't have
                        for k, v in api_prospect.items():
                            if prospect.get(k) in (None, ""):
                                prospect[k] = v
                except Exception as e:
                    # API read failure is not fatal — we already have export values
                    pass

            # Step 3: Last resort — scrape the classic prospect page if needed
            _still_incomplete = bool(_hinted) and not any(
                prospect.get(h) not in (None, "") for h in _hinted)
            if _still_incomplete and page is not None:
                scraped = _scrape_prospect_fields_from_page(page, pid)
                diag = ""
                if scraped and "_scrape_error" in scraped:
                    diag = f"UI scrape failed: {scraped.pop('_scrape_error')}"
                elif scraped and "_unmapped_labels" in scraped:
                    diag = (f"UI scrape found only unmapped labels: "
                            f"{scraped.pop('_unmapped_labels')}")
                if scraped and not prospect:
                    prospect = scraped
                elif scraped and prospect:
                    for k, v in scraped.items():   # fill gaps; API values win
                        if prospect.get(k) in (None, ""):
                            prospect[k] = v
                if diag:
                    # Keep an earlier API-failure note; both are diagnostic.
                    r["Resolution Note"] = ((r["Resolution Note"] + " | ")
                                            if r["Resolution Note"] else "") + diag
                elif prospect:
                    r["Resolution Note"] = ""  # clear a stale API-failure note
            if not prospect and not r["Resolution Note"]:
                r["Resolution Note"] = "prospect read empty (API and UI scrape)"
            found = find_offending_value(prospect or {}, sf_detail, cls)
            r["Offending Field"] = found["field"]
            r["Offending Value"] = found["value"]
            r["Confidence"]      = found["confidence"]
            if found["reason"]:
                r["Resolution Note"] = found["reason"]
            elif not r["Resolution Note"]:
                r["Resolution Note"] = ("Couldn't pin the value automatically — check "
                                        f"the prospect's '{cls['field_label']}' field.")

            # For picklist/field-integrity errors (e.g. Bundesland/State):
            # compare the Pardot value against the live Salesforce value and
            # surface the field's sync behavior.
            if cls["error_class"] in (CLS_FIELD_INTEGRITY, CLS_CUSTOM_VALIDATION):
                cmp = compare_sides(prospect or {}, cls, client, sync_map)
                r["Pardot Value"]   = cmp["pardot_value"] or r["Offending Value"]
                r["SF Value"]       = cmp["sf_value"]
                r["Values Differ"]  = cmp["differ"]
                r["Pardot Country"] = cmp["pardot_country"]
                r["SF Country"]     = cmp["sf_country"]
                r["Sync Behavior"]  = cmp["sync_behavior"]
                # State is a dependent picklist controlled by Country: a country
                # mismatch is the most likely root cause of the state error.
                if cmp["dependent"] and cmp["country_differ"] == "Yes":
                    r["Resolution Note"] = (
                        f"Country mismatch controls the State picklist — "
                        f"Pardot country='{cmp['pardot_country']}' vs Salesforce "
                        f"country='{cmp['sf_country']}'. Fix the country first. "
                        + (r["Resolution Note"] or ""))
                elif cmp["differ"] == "Yes":
                    r["Resolution Note"] = (
                        f"Pardot='{cmp['pardot_value']}' vs Salesforce='{cmp['sf_value']}' "
                        f"differ; sync behavior: {cmp['sync_behavior'] or 'unknown'}. "
                        + (r["Resolution Note"] or ""))
                elif cmp["note"]:
                    r["Resolution Note"] = (r["Resolution Note"] or "") + f" [{cmp['note']}]"
        else:
            r["Resolution Note"] = "Review manually — unrecognised error pattern."

        merged = {**rec, **r}
        resolved.append(merged)

        if i <= 8 or i % 50 == 0:
            print(f"   [{i}/{len(records)}] {cls['error_class']:<18} "
                  f"{(r['Offending Field'] or r['Fix Location'])}: {r['Offending Value'][:40]}")

    # Write outputs: leave the Step 1 raw CSV untouched, write the resolution
    # columns to a separate _resolved.csv/.json pair instead.
    from scrape_prospect_sync_errors import COLUMNS_FULL as BASE_COLUMNS
    all_cols = BASE_COLUMNS + RESOLUTION_COLUMNS
    rows = [[m.get(c, "") for c in all_cols] for m in resolved]
    utils.save_csv(rows, all_cols, out_csv_res)
    utils.save_json(resolved, out_json)

    # Summary
    from collections import Counter
    counts = Counter(m["Error Class"] for m in resolved)
    print("\n   Breakdown by error class:")
    for k, v in counts.most_common():
        print(f"     {k:<20} {v}")

    # Unresolved / needs-attention report — answers "what haven't we resolved?"
    other = [m for m in resolved if m["Error Class"] == CLS_OTHER]
    unpinned = [m for m in resolved
                if m["Fix Location"] == FIX_PROSPECT and not m.get("Offending Value")]
    if other:
        print(f"\n   ⚠️  Unclassified (OTHER): {len(other)} — distinct patterns:")
        for msg, n in Counter((m.get("Error", "") or "(empty)")[:80]
                              for m in other).most_common(10):
            print(f"        {n:>4}×  {msg!r}")
    else:
        print("\n   ✅ No unclassified (OTHER) errors.")
    if unpinned:
        print(f"   ⚠️  Field errors with no pinned value: {len(unpinned)} "
              "(prospect read/scrape did not yield the field value)")
    print("\n✅ Root-cause resolution complete.")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--org", metavar="NAME", help="Org config to use (e.g. 'globex' or 'soylent').")
    args = parser.parse_args()

    utils.load_org_config(args.org)
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()


if __name__ == "__main__":
    main()
