"""
List-Emails Field Diagnostic — v5 API  (round 2)
==================================================
Round 1 confirmed the root cause of scrape_list_emails.py returning 0 records:
14 of its 15 extra field names don't exist on the v5 `objects/list-emails`
object at all (HTTP 400 "unknown field", one bad field kills the whole
request; pardot_api.paged_get() swallows the 400 silently and returns an
empty list, which run_all.py then logs as a false success).

Cross-checked against the official Salesforce v5 docs
(https://developer.salesforce.com/docs/marketing/pardot/guide/list-email-v5.html):
  - There is NO send-category field (List/Automated/Generator/Plugin/Hidden/
    A-B-Test — the split shown in the classic UI dropdown) on this object at
    all. `type` is content format only (html / text / htmlAndText).
  - There is NO `status` field — only booleans `isSent`, `isPaused`,
    `isDeleted`. `scheduledTime` is write-only, can't be read back.
  - Recipient lists come back as a nested `recipientLists` array (not a flat
    `listId`/`listName`); `recipientListIds` is write-only.
  - Sender/reply-to come back as nested `senderOptions[]` / `replyToOptions[]`
    arrays (not flat `senderAddress`/`senderName`/`replyToAddress`).
  - Stats (queued/sent/delivered/opens/clicks/bounces/unsubscribes) are NOT
    on this object — they require a separate call per record:
    `GET /api/v5/objects/list-emails/<id>/stats`.
  - `fetch_sent_emails_api.py` ("Sent Emails") and `scrape_list_emails.py`
    ("List Emails") query the SAME object (`objects/list-emails`) — there is
    no separate "per-recipient send" object at this endpoint. The true
    per-recipient object is `objects/emails` (unrelated, not yet scraped).

This round verifies the exact field names planned for the rewritten
scrape_list_emails.py (nested objects + booleans) and probes the `/stats`
sub-resource shape, before committing to the rewrite.

Usage:
  python3 diagnose_list_emails_fields.py                # uses .active-org
  python3 diagnose_list_emails_fields.py --org globex
  python3 diagnose_list_emails_fields.py --org acme

Output (under output/<org>/diagnostics/):
  list_emails_raw_sample.json     — sample records with the new field set
  list_emails_field_test_v2.json  — pass/fail per candidate field
  list_emails_stats_sample.json   — raw response from the /stats sub-resource
                                     for one real sent list email

Called from run_all.py: not wired in — deliberately standalone, run manually
alongside a full session login.
"""

from __future__ import annotations

import argparse
import json
import os

from playwright.sync_api import sync_playwright

import pardot_api
import utils

SAMPLE_SIZE = 5

# Field set already confirmed working (round 1).
KNOWN_GOOD_FIELDS = [
    "id", "name", "subject", "type", "isSent", "sentAt",
    "campaignId", "folderId", "trackerDomainId", "createdAt", "updatedAt",
]

# New candidate fields for the scrape_list_emails.py rewrite — per official
# docs these should exist, but v5 field-name validation has already proven
# stricter/quirkier than the docs' own comments suggest, so verify live.
CANDIDATE_FIELDS = [
    "isPaused", "isDeleted", "clientType",
    "createdById", "updatedById",
    "recipientLists", "suppressionLists",
    "senderOptions", "replyToOptions",
    "campaign", "folder", "createdBy", "updatedBy",
]


# ── Raw HTTP helper (bypasses paged_get's silent error swallowing) ───────────

def _raw_get(client: pardot_api.PardotClient, fields=None, limit: int = SAMPLE_SIZE):
    """Direct GET against objects/list-emails. Returns (status_code, body)."""
    url = f"{pardot_api.PARDOT_API_BASE}/objects/list-emails"
    params = {"limit": limit}
    if fields:
        params["fields"] = ",".join(fields)
    resp = client.session.get(url, headers=client.headers(), params=params, timeout=30)
    try:
        return resp.status_code, resp.json()
    except Exception:
        return resp.status_code, resp.text


# ── Diagnostic steps ──────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    if client is None:
        client = pardot_api.client_from_page(page)

    diag_dir = utils.output_path("diagnostics", "_")  # ensures dir exists
    diag_dir = os.path.dirname(diag_dir)

    print("\n🔬 List-Emails Field Diagnostic (v5 API) — round 2")
    print("=" * 50)

    # ① Bisect each new candidate field individually against the known-good base
    print(f"\n① Bisecting {len(CANDIDATE_FIELDS)} candidate field(s) one at a time...")
    results = {}
    for f in CANDIDATE_FIELDS:
        status, body = _raw_get(client, fields=KNOWN_GOOD_FIELDS + [f], limit=1)
        ok = status == 200
        results[f] = {"status": status, "ok": ok, "body_preview": "" if ok else str(body)[:200]}
        print(f"   {'✅' if ok else '❌'} {f:<20} status={status}" + ("" if ok else f"  {str(body)[:150]}"))

    test_path = os.path.join(diag_dir, "list_emails_field_test_v2.json")
    with open(test_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    good = [f for f, r in results.items() if r["ok"]]
    bad  = [f for f, r in results.items() if not r["ok"]]
    validated_fields = KNOWN_GOOD_FIELDS + good

    # ② Pull a real sample using only the validated field set
    print(f"\n② Sample with validated field set ({len(validated_fields)} fields)...")
    status, body = _raw_get(client, fields=validated_fields, limit=SAMPLE_SIZE)
    print(f"   status: {status}")
    sample_values = []
    if status == 200:
        sample_values = body.get("values", [])
        sample_path = os.path.join(diag_dir, "list_emails_raw_sample.json")
        with open(sample_path, "w", encoding="utf-8") as f:
            json.dump(sample_values, f, indent=2, ensure_ascii=False)
        print(f"   ✅ saved {len(sample_values)} record(s) → {sample_path}")
        if sample_values:
            print(f"   nested shape check:")
            for k in ("recipientLists", "senderOptions", "replyToOptions", "campaign", "folder"):
                if k in validated_fields:
                    example = next((v.get(k) for v in sample_values if v.get(k)), "— empty on all sampled records —")
                    print(f"     {k}: {json.dumps(example, ensure_ascii=False)[:200]}")
    else:
        print(f"   ❌ body: {str(body)[:400]}")

    # ③ Probe the /stats sub-resource for one real sent list email
    print("\n③ Stats sub-resource probe...")
    sent_id = next((v.get("id") for v in sample_values if v.get("isSent")), None)
    if not sent_id and sample_values:
        sent_id = sample_values[0].get("id")
    if sent_id:
        url = f"{pardot_api.PARDOT_API_BASE}/objects/list-emails/{sent_id}/stats"
        resp = client.session.get(url, headers=client.headers(), timeout=30)
        print(f"   GET .../list-emails/{sent_id}/stats → status {resp.status_code}")
        stats_path = os.path.join(diag_dir, "list_emails_stats_sample.json")
        try:
            stats_body = resp.json()
            with open(stats_path, "w", encoding="utf-8") as f:
                json.dump(stats_body, f, indent=2, ensure_ascii=False)
            print(f"   ✅ saved → {stats_path}")
            if resp.status_code == 200:
                print(f"   fields returned: {', '.join(sorted(stats_body.keys()))}")
        except Exception:
            print(f"   ❌ body: {resp.text[:300]}")
    else:
        print("   ⚠️  No record ID available from step ② sample — skipped.")

    # ── Summary ────────────────────────────────────────────────────────────
    print("\n── Summary ──────────────────────────────────────")
    print(f"   ✅ Validated field set for scrape_list_emails.py rewrite:")
    print(f"      {validated_fields}")
    if bad:
        print(f"   ❌ Still invalid (leave out): {', '.join(bad)}")
    print(f"\n   Inspect {diag_dir}/ for full samples before the rewrite.")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Diagnose the objects/list-emails v5 endpoint (field discovery + 400 bisection)."
    )
    parser.add_argument("--org", metavar="NAME", help="Org config to use (e.g. 'globex' or 'acme').")
    args = parser.parse_args()

    utils.load_org_config(args.org)
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
