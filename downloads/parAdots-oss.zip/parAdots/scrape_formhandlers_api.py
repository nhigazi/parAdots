"""
Pardot Form Handler Scraper — v5 API + browser hybrid
======================================================
API:     objects/form-handlers, objects/form-handler-fields,
         objects/campaigns, objects/folders, objects/tracker-domains
Browser: one read-page visit per handler (no screenshots) for:
           - completion_actions
           - prospect_count

Output:
  pardot_formhandlers.json
  pardot_formhandlers.csv

Usage:
  python3 scrape_formhandlers_api.py
"""

from __future__ import annotations

import csv
import json
import os
import re
import sys

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time via utils.output_path()
OUTPUT_CSV  = ""


# Set True after the UI-language guard passes on the first handler visited in
# a run — see _extract_browser_data() / utils.assert_english_ui.
_LANGUAGE_VERIFIED = False

HANDLER_FIELDS = [
    "id", "name",
    "campaignId", "folderId",
    "successLocation", "errorLocation",
    "trackerDomainId",
    "isDataForwarded", "isAlwaysEmail", "isCookieless",
    "salesforceId",
    "createdAt", "updatedAt",
]

# prospectApiFieldName removed — not a valid v5 field (causes 400).
# prospectApiFieldId returns the raw API name; display label is resolved
# from pardot_fields.json via load_prospect_field_names().
HANDLER_FIELD_FIELDS = [
    "id", "formHandlerId", "name", "dataFormat",
    "isMaintainInitialValue", "isRequired", "errorMessage",
    "prospectApiFieldId",
]

TRACKER_LOOKUP_FIELDS  = ("id", "domain")
CAMPAIGN_LOOKUP_FIELDS = ("id", "name")
FOLDER_LOOKUP_FIELDS   = ("id", "name")


def load_prospect_field_names() -> dict[str, str]:
    """
    Build api_name → display_name from pardot_fields.json (Prospect section).
    Falls back to {} so field mappings degrade gracefully without the file.
    Stores both original-case and lower-case keys for flexible lookup.
    """
    path = utils.output_path("pardot_fields.json")
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

    lookup: dict[str, str] = {}
    for obj in data:
        if obj.get("object") != "Prospect":
            continue
        for field in obj.get("fields", []):
            api_name = (field.get("api_name") or "").strip()
            name     = (field.get("name") or "").strip()
            if api_name and name:
                lookup[api_name]       = name
                lookup[api_name.lower()] = name
    return lookup


def build_handler_fields_index(client: pardot_api.PardotClient) -> dict[str, list[dict]]:
    """One paged sweep over form-handler-fields, grouped by handler ID."""
    index: dict[str, list[dict]] = {}
    for mapping in pardot_api.paged_get(
        client, "objects/form-handler-fields", fields=HANDLER_FIELD_FIELDS,
    ):
        handler_id = str(mapping.get("formHandlerId") or "")
        if not handler_id:
            continue
        index.setdefault(handler_id, []).append(mapping)
    for mappings in index.values():
        mappings.sort(key=lambda m: m.get("name") or "")
    return index


def format_mappings(mappings: list[dict], field_names: dict[str, str]) -> list[str]:
    """
    'External Field → Prospect Display Name (required)'
    Resolves prospectApiFieldId → label via field_names lookup.
    """
    out = []
    for m in mappings:
        external    = (m.get("name") or "").strip()
        prospect_id = (m.get("prospectApiFieldId") or "").strip()
        prospect_lbl = (
            field_names.get(prospect_id)
            or field_names.get(prospect_id.lower())
            or prospect_id
        )
        required = " (required)" if m.get("isRequired") else ""
        if external:
            target = prospect_lbl or "(unmapped)"
            out.append(f"{external} → {target}{required}")
    return out


def shape_handler(
    handler: dict,
    trackers: dict,
    campaigns: dict,
    folders: dict,
    handler_fields_index: dict[str, list[dict]],
    field_names: dict[str, str],
) -> dict:
    hid = str(handler.get("id"))
    return {
        "id":                hid,
        "name":              handler.get("name", ""),
        "campaign":          (campaigns.get(handler.get("campaignId")) or {}).get("name", ""),
        "folder":            (folders.get(handler.get("folderId")) or {}).get("name", ""),
        "success_location":  handler.get("successLocation", "") or "",
        "error_location":    handler.get("errorLocation", "") or "",
        "tracker_domain":    (trackers.get(handler.get("trackerDomainId")) or {}).get("domain", ""),
        "is_data_forwarded": bool(handler.get("isDataForwarded")),
        "is_always_email":   bool(handler.get("isAlwaysEmail")),
        "is_cookieless":     bool(handler.get("isCookieless")),
        "salesforce_id":     handler.get("salesforceId", "") or "",
        "created_at":        handler.get("createdAt", "") or "",
        "updated_at":        handler.get("updatedAt", "") or "",
        # Filled by browser pass below
        "completion_actions": [],
        "prospect_count":     None,
        "usage":              [],
        "field_mappings":    format_mappings(handler_fields_index.get(hid, []), field_names),
    }


def _extract_browser_data(page, handler_id: str) -> tuple[list[str], int | None, list[dict]]:
    """
    Visit /formHandler/read/id/{id}, extract completion_actions, prospect_count,
    and usage (which Engagement Studio programs / automation rules reference
    this handler — see utils.extract_usage_inline). No screenshots — innerText
    extraction only.
    Returns (completion_actions, prospect_count_or_None, usage).

    NOTE: does NOT use truncate_at_prospects — the nav bar contains a
    "Prospects" link that would cut the text before the content section.
    Instead, headings are located directly in the non-empty line list.
    """
    url = f"{utils.PARDOT_HOME}/formHandler/read/id/{handler_id}"
    try:
        page.goto(url, wait_until="networkidle", timeout=15000)
    except Exception:
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=12000)
        except Exception as e:
            print(f"   ⚠️  Could not load handler {handler_id}: {e}")
            return [], None, []

    page.wait_for_timeout(1000)

    try:
        body_text = page.evaluate("() => document.body.innerText") or ""
    except Exception:
        return [], None, []

    # Filter to non-empty lines for reliable heading detection
    lines = [l.strip() for l in body_text.splitlines() if l.strip()]

    # UI language guard — check ONCE per run, on the first handler visited.
    # Let it propagate uncaught; callers must not swallow it as a per-item
    # scrape failure. See utils.assert_english_ui.
    global _LANGUAGE_VERIFIED
    if not _LANGUAGE_VERIFIED:
        utils.assert_english_ui(lines, f"Pardot formHandler detail page (id {handler_id})")
        _LANGUAGE_VERIFIED = True

    # Prospect count: pagination footer renders as "Showing" … "of N".
    # Confirmed (2026-07-02, globex dynamic-list bug): this formHandler read
    # page is served through the Salesforce Lightning "Account Engagement"
    # wrapper, not classic pi.pardot.com chrome, so it follows the org user's
    # Salesforce language (German for globex: "Vervollständigungsaktionen"
    # instead of "Completion Actions" — see screenshot). "of N" almost
    # certainly localises to "von N". Not independently verified live for
    # this exact footer string — if prospect_count is still empty after this
    # fix for a German-locale org, inspect the actual page text and add the
    # real string here rather than assuming.
    # Last ~20 lines contain: per-page options (5/10/15/25/50) then "of N"/"von N"
    prospect_count: int | None = None
    for line in reversed(lines[-20:]):
        m = re.match(r'^(?:of|von)\s+([\d,.]+)$', line, re.IGNORECASE)
        if m:
            prospect_count = int(m.group(1).replace(",", "").replace(".", ""))
            break

    # Completion actions: between "Completion Actions" and "Form Field Mappings"
    # (English) / German equivalents. "Vervollständigungsaktionen" is CONFIRMED
    # via screenshot (globex formHandler read page, 2026-07-02). The German
    # heading for "Form Field Mappings" was NOT visible in that screenshot
    # (page wasn't scrolled that far) — "formularfeldzuordnungen" is a literal
    # guess, not verified live. If completion_actions still comes out empty
    # or truncated for a German-locale org, check the real heading text.
    ACTIONS_HEADINGS = ("completion actions", "vervollständigungsaktionen")
    FIELDS_HEADINGS  = ("form field mappings", "formularfeldzuordnungen")

    actions_idx = fields_idx = None
    for i, line in enumerate(lines):
        ll = line.lower()
        if actions_idx is None and ll in ACTIONS_HEADINGS:
            actions_idx = i
        elif actions_idx is not None and fields_idx is None and ll in FIELDS_HEADINGS:
            fields_idx = i
            break

    # Usage: no tab, no fixed selector — see utils.extract_usage_inline. Safe
    # to call regardless of where actions_idx/fields_idx landed above; it
    # does its own DOM query and doesn't depend on the innerText already
    # captured, nor does it switch tabs (unlike extract_usage_tab), so
    # ordering relative to the innerText read above doesn't matter here.
    usage = utils.extract_usage_inline(page)

    if actions_idx is None:
        return [], prospect_count, usage

    end_idx = fields_idx if fields_idx is not None else len(lines)
    noise   = {"there are no actions"}
    # Action lines have format "Action Type\tdetail" — normalise to "Action Type: detail"
    completion_actions = [
        line.replace("\t", ": ")
        for line in lines[actions_idx + 1 : end_idx]
        if line and line.lower() not in noise
    ]
    return completion_actions, prospect_count, usage


def export_csv(results: list[dict]) -> None:
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow([
            "#", "Name", "ID",
            "Campaign", "Folder",
            "Success Location", "Error Location",
            "Tracker Domain",
            "Is Data Forwarded", "Is Always Email", "Is Cookieless",
            "Completion Actions", "Prospect Count",
            "Field Mappings",
            "Usage Count", "Usage",
            "Salesforce ID", "Created At", "Updated At",
        ])
        for i, r in enumerate(results, 1):
            usage = r.get("usage") or []
            w.writerow([
                i,
                r["name"], r["id"],
                r.get("campaign", ""),
                r.get("folder", ""),
                r.get("success_location", ""),
                r.get("error_location", ""),
                r.get("tracker_domain", ""),
                r.get("is_data_forwarded", ""),
                r.get("is_always_email", ""),
                r.get("is_cookieless", ""),
                "\n".join(r.get("completion_actions", [])),
                "" if r.get("prospect_count") is None else r["prospect_count"],
                "\n".join(r.get("field_mappings", [])),
                len(usage),
                "; ".join(f"{u.get('type','')}: {u.get('name','')}" for u in usage),
                r.get("salesforce_id", ""),
                r.get("created_at", ""),
                r.get("updated_at", ""),
            ])
    print(f"✅ Exported {OUTPUT_CSV} ({len(results)} rows)")


def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_formhandlers.json")
    OUTPUT_CSV  = utils.output_path("pardot_formhandlers.csv")
    print("\n🚀 Pardot Form Handler Scraper (v5 API + browser hybrid)")
    print("=" * 55)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    field_names = load_prospect_field_names()
    print(f"📖 Loaded {len(field_names) // 2} prospect field name(s) for mapping resolution")

    print("📚 Pre-loading reference data...")
    trackers  = pardot_api.lookup_map(client, "objects/tracker-domains", TRACKER_LOOKUP_FIELDS)
    campaigns = pardot_api.lookup_map(client, "objects/campaigns",       CAMPAIGN_LOOKUP_FIELDS)
    folders   = pardot_api.lookup_map(client, "objects/folders",         FOLDER_LOOKUP_FIELDS)
    print(f"   ✅ {len(trackers)} tracker(s) / {len(campaigns)} campaign(s) / {len(folders)} folder(s)")

    print("📚 Indexing form-handler field mappings...")
    handler_fields_index = build_handler_fields_index(client)
    total_mappings = sum(len(v) for v in handler_fields_index.values())
    print(f"   ✅ {total_mappings} mapping row(s) across {len(handler_fields_index)} handler(s)")

    print("📋 Fetching form handlers...")
    results: list[dict] = []
    for handler in pardot_api.paged_get(client, "objects/form-handlers", fields=HANDLER_FIELDS):
        results.append(shape_handler(handler, trackers, campaigns, folders, handler_fields_index, field_names))
    print(f"   ✅ {len(results)} form handler(s)\n")

    if page is not None:
        print(f"🌐 Browser pass — completion actions + prospect counts + usage ({len(results)} handler(s))...")
        for r in results:
            try:
                actions, count, usage = _extract_browser_data(page, r["id"])
            except utils.UnexpectedUILanguageError as e:
                print(str(e))
                sys.exit(1)
            r["completion_actions"] = actions
            r["prospect_count"]     = count
            r["usage"]              = usage
            label      = f"{count} prospects" if count is not None else "count unavailable"
            action_str = f"{len(actions)} action(s)" if actions else "no actions"
            usage_str  = f"{len(usage)} usage(s)" if usage else "unused"
            print(f"   ✅ {r['name']} — {action_str}, {label}, {usage_str}")
        print()
    else:
        print("⚠️  No browser page — completion_actions, prospect_count, and usage left empty.\n")

    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"✅ Saved {OUTPUT_JSON} ({len(results)} form handlers)")
    export_csv(results)


def main() -> None:
    utils.load_org_config()
    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
