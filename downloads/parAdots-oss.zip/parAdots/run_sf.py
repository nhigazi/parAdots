"""
Run All Salesforce Analysis Scrapers — Single Login Session
============================================================
Runs all 9 SF-side scrapers sequentially against one SalesforceClient.

Auth modes (--auth):
  auto   (default) — use the SF CLI token if an authenticated org is found,
                     otherwise fall back to a Pardot Playwright login.
  cli              — SF CLI token only (sf org display); no browser opens.
                     This is the preferred path: it decouples SF analysis
                     from the Pardot login and is MFA-safe.
  pardot           — legacy Pardot browser session (Playwright) only.

Scrapers run in this order:
  1.  Campaign Member Attribution    (scrape_sf_campaign_members.py)
  2.  Opt-In Field Sync Audit        (scrape_sf_optin_sync_audit.py)
  3.  Lead Quality / Resolution      (scrape_sf_lead_quality.py)
  4.  Opportunity Attribution        (scrape_sf_opportunity_attribution.py)
  5.  Pardot Sync Error Log          (scrape_sf_sync_errors.py)
  6.  Custom Field Mapping           (scrape_sf_field_mapping.py)
  7.  Account / Corp Hierarchy       (scrape_sf_account_hierarchy.py)
  8.  Task / Activity Follow-Up      (scrape_sf_task_activity.py)
  9.  Report & Dashboard Inventory   (scrape_sf_reports_inventory.py)

Usage:
  python3 run_sf.py                       # auto auth, .active-org
  python3 run_sf.py --org globex         # one-off org override
  python3 run_sf.py --auth cli            # CLI token, no browser
  python3 run_sf.py --auth cli --alias globex   # explicit SF CLI alias
"""

import argparse
import os
import sys

import utils
import salesforce_api as sf


def _scrapers():
    from scrape_sf_campaign_members       import run as run_campaigns
    from scrape_sf_optin_sync_audit       import run as run_optin
    from scrape_sf_lead_quality           import run as run_leads
    from scrape_sf_opportunity_attribution import run as run_opps
    from scrape_sf_sync_errors            import run as run_sync_errors
    from scrape_sf_field_mapping          import run as run_fields
    from scrape_sf_account_hierarchy      import run as run_accounts
    from scrape_sf_task_activity          import run as run_tasks
    from scrape_sf_reports_inventory      import run as run_reports
    return [
        ("Campaign Member Attribution",  run_campaigns),
        ("Opt-In Field Sync Audit",      run_optin),
        ("Lead Quality / Resolution",    run_leads),
        ("Opportunity Attribution",      run_opps),
        ("Pardot Sync Error Log",        run_sync_errors),
        ("Custom Field Mapping",         run_fields),
        ("Account / Corp Hierarchy",     run_accounts),
        ("Task / Activity Follow-Up",    run_tasks),
        ("Report & Dashboard Inventory", run_reports),
    ]


def _run_all(client: sf.SalesforceClient) -> None:
    for name, run_fn in _scrapers():
        print(f"\n{'─' * 50}")
        print(f"▶  Starting: {name}")
        print(f"{'─' * 50}")
        try:
            run_fn(client=client)
            print(f"✅  Finished: {name}")
        except Exception as e:
            print(f"❌  {name} failed: {e}")
            import traceback
            traceback.print_exc()
            print("   Continuing with next scraper...")


def _client_via_cli(alias):
    """Try SF CLI auth; return a client or None (with a printed reason)."""
    if not sf.cli_available():
        print("   ℹ️  SF CLI not installed — cannot use CLI auth")
        return None
    try:
        client = sf.client_from_cli(alias)
        print(f"   ✅ Connected via SF CLI to {client.instance_url}\n")
        return client
    except Exception as e:
        print(f"   ⚠️  {e}")
        return None


def _client_via_pardot():
    """Legacy path: Playwright login, then extract the Pardot session token.

    Returns (client, cleanup_callable).
    """
    from playwright.sync_api import sync_playwright
    pw      = sync_playwright().start()
    context = utils.launch_context(pw, slow_mo=50)
    page    = context.new_page()
    page.set_viewport_size({"width": 1400, "height": 900})
    utils.login(page)
    print("\n🔑 Extracting Salesforce token (Pardot session)...")
    client = sf.client_from_page(page)
    print(f"   ✅ Connected to {client.instance_url}\n")

    def _cleanup():
        try:
            context.close()
        finally:
            pw.stop()

    return client, _cleanup


def main():
    parser = argparse.ArgumentParser(description="Run all Salesforce analysis scrapers.")
    parser.add_argument("--org", metavar="NAME",
        help="Org config to use (e.g. 'globex'). Overrides .active-org for this run.")
    parser.add_argument("--auth", choices=["auto", "cli", "pardot"], default="auto",
        help="Auth source: auto (CLI then Pardot), cli (SF CLI only), pardot (browser only).")
    parser.add_argument("--alias", metavar="SF_ALIAS",
        help="Explicit SF CLI org alias/username for --auth cli/auto.")
    args = parser.parse_args()

    org = utils.load_org_config(args.org)
    print(f"📁 Out : {utils.OUTPUT_DIR}")
    print(f"🔐 Auth: {args.auth}")
    utils.validate_credentials()

    print("\n🚀 Salesforce Analysis Suite — Single Login Run")
    print("=" * 50)

    cleanup = None
    client  = None

    if args.auth in ("auto", "cli"):
        client = _client_via_cli(args.alias)
        if client is None and args.auth == "cli":
            print("\n❌ CLI auth required (--auth cli) but unavailable. Aborting.")
            print("   Authenticate once with: sf org login web --instance-url <url> --alias <name>")
            sys.exit(1)

    if client is None:  # pardot mode, or auto-fallback
        if args.auth == "auto":
            print("   ↪︎ Falling back to Pardot browser login...")
        client, cleanup = _client_via_pardot()

    try:
        _run_all(client)
    finally:
        if cleanup:
            cleanup()

    print("\n" + "=" * 50)
    print("✅ All Salesforce scrapers completed.")
    print(f"\n   Output directory: {utils.OUTPUT_DIR}")
    print("   Files produced:")
    for fname in sorted(os.listdir(utils.OUTPUT_DIR)):
        if fname.startswith("sf_"):
            size = os.path.getsize(os.path.join(utils.OUTPUT_DIR, fname))
            print(f"     {fname:<50} {size:,} bytes")


if __name__ == "__main__":
    main()
