# Quick start — auditing your own org

The package ships with a synthetic `demo` org so the dashboard works out of the box.

## 1. Create an org config
```bash
cp .env.template configs/myorg.env
```
Edit it: `SF_LOGIN_URL`, `SF_USERNAME`, `PARDOT_BUSINESS_UNIT_ID`, `CHROME_PROFILE`
(the Chrome profile holding your logged-in Salesforce session), optional `SF_CLI_ALIAS`.
`configs/*.env` is git-ignored and never leaves your machine.

## 2. Select the org
```bash
python3 set_org.py myorg        # set default (.active-org)
python3 set_org.py --list
```

## 3. Authenticate (browser-session mode)
Log in to Salesforce once in the configured Chrome profile — scrapers attach to that session,
no Connected App needed. Salesforce scrapers can also use the CLI:
```bash
sf org login web --instance-url <SF_LOGIN_URL> --alias myorg
python3 run_sf.py --auth cli --alias myorg
```

## 4. Run the audit
```bash
python3 run_all.py --org myorg      # all scrapers, then analysis/export
```
Output lands in `output/myorg/`.

## 5. Explore
```bash
python3 viewer.py                   # http://localhost:8765 — pick your org
```
Or just double-click **`parAdots.command`** (macOS) / **`parAdots.bat`** (Windows) — same thing.
