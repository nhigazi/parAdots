"""
SF Scraper 6 — Custom Field Mapping Validation
================================================
Uses the SF Describe API to verify that every Pardot-relevant custom field
exists on both Lead and Contact with the correct type and (for picklists)
the expected set of values.

Fields validated (all discovered from the org — nothing hard-coded per org):
  • Opt-in consent fields     (discovered by pattern)
  • Consent timestamp fields  (discovered by pattern)
  • Consent source fields     (discovered by pattern)
  • Pardot managed fields     (pi__* — standard on every connected org)
  • Extra per-org fields      (optional, via PARDOT_SYNC_FIELDS in configs/{org}.env)

A mismatch between Lead and Contact field definitions (e.g. picklist values
present on Lead but absent on Contact) silently corrupts CRM sync writes.

Output:
  sf_field_mapping.json
  sf_field_mapping.csv

Called from run_sf.py / run_all.py:
  from scrape_sf_field_mapping import run
  run(page=page)
"""
from __future__ import annotations
import csv, json, sys, os
import salesforce_api as sf
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""

# No org-specific field names are hard-coded here. The Pardot managed-package
# (pi__*) fields are standard on every connected org and are discovered from
# describe (see _discover_pi_fields). Org-specific custom fields are pinned
# per-org via the PARDOT_SYNC_FIELDS env var in configs/{org}.env.

def _discover_pi_fields(client: sf.SalesforceClient,
                        sobjects: tuple[str, ...] = ("Lead", "Contact")) -> list[str]:
    """Return sorted pi__* managed-package field names present on the given objects."""
    found: set[str] = set()
    for obj in sobjects:
        d = sf.describe(client, obj) or {}
        for f in d.get("fields", []):
            n = f.get("name", "")
            if n.startswith("pi__"):
                found.add(n)
    return sorted(found)

def _get_fields_to_check(client: sf.SalesforceClient | None = None) -> list[str]:
    extra = os.getenv("PARDOT_SYNC_FIELDS","")
    extra_list = [f.strip() for f in extra.split(",") if f.strip()]

    # Resolve opt-in / timestamp fields against the org (describe discovery),
    # falling back to brand-derived defaults only when no client is available.
    # Avoids seeding the check with the raw Optin_Double_* defaults, which show
    # up as false "missing" issues when the org uses crm_-prefixed names.
    _, optin_fields, ts_fields = sf.resolve_consent_fields(client)
    base = optin_fields + ts_fields + extra_list

    # Describe-driven, org-agnostic: brand "source" consent fields + the Pardot
    # managed-package (pi__*) fields that exist on every connected org.
    if client is not None:
        try:
            disc = sf.discover_consent_fields(client)
            base += disc.get("source_fields", [])
        except Exception as e:
            print(f"   ⚠️  Consent-field discovery skipped ({e})")
        try:
            base += _discover_pi_fields(client)
        except Exception as e:
            print(f"   ⚠️  pi__ field discovery skipped ({e})")

    return list(dict.fromkeys(base))


def _field_detail(field_meta: dict) -> dict:
    """Extract the properties we care about from an SObject field describe."""
    picklist_vals = [v["value"] for v in field_meta.get("picklistValues",[]) if v.get("active")]
    return {
        "api_name":       field_meta.get("name",""),
        "label":          field_meta.get("label",""),
        "type":           field_meta.get("type",""),
        "length":         field_meta.get("length"),
        "is_custom":      field_meta.get("custom", False),
        "picklist_values": picklist_vals,
        "updateable":     field_meta.get("updateable", False),
        "nillable":       field_meta.get("nillable", True),
    }


def _describe_fields(client: sf.SalesforceClient, sobject: str) -> dict[str, dict]:
    """Return {api_name: field_detail} for an SObject."""
    d = sf.describe(client, sobject)
    if not d:
        return {}
    return {f["name"]: _field_detail(f) for f in d.get("fields",[])}


def run(page=None, client: sf.SalesforceClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("sf_field_mapping.json")
    OUTPUT_CSV  = utils.output_path("sf_field_mapping.csv")

    print("\n🚀 SF Scraper 6 — Custom Field Mapping Validation")
    print("=" * 50)

    if client is None:
        if page is None:
            print("❌ Need page or client"); sys.exit(1)
        client = sf.client_from_page(page)

    fields_to_check = _get_fields_to_check(client)
    print(f"   Fields to validate: {len(fields_to_check)}")
    print(f"   Objects: Lead, Contact\n")

    print("📋 Describing Lead fields...")
    lead_all    = _describe_fields(client, "Lead")
    print("📋 Describing Contact fields...")
    contact_all = _describe_fields(client, "Contact")

    results = []
    issues  = []

    for fname in fields_to_check:
        lead_f    = lead_all.get(fname)
        contact_f = contact_all.get(fname)

        lead_exists    = lead_f is not None
        contact_exists = contact_f is not None
        type_match     = (lead_f["type"] == contact_f["type"]) if (lead_f and contact_f) else None

        # Picklist value drift
        picklist_drift: list[str] = []
        if lead_f and contact_f and lead_f["type"] == "picklist":
            lead_vals = set(lead_f["picklist_values"])
            cont_vals = set(contact_f["picklist_values"])
            only_lead = lead_vals - cont_vals
            only_cont = cont_vals - lead_vals
            picklist_drift = [f"+Lead:{v}" for v in sorted(only_lead)] + \
                             [f"+Contact:{v}" for v in sorted(only_cont)]

        status = "✅ OK"
        if not lead_exists:
            status = "❌ Missing on Lead"
            issues.append({"field": fname, "issue": "Missing on Lead"})
        elif not contact_exists:
            status = "⚠️  Missing on Contact"
            issues.append({"field": fname, "issue": "Missing on Contact"})
        elif type_match is False:
            status = f"⚠️  Type mismatch: Lead={lead_f['type']} Contact={contact_f['type']}"
            issues.append({"field": fname, "issue": status})
        elif picklist_drift:
            status = f"⚠️  Picklist drift ({len(picklist_drift)} values differ)"
            issues.append({"field": fname, "issue": f"Picklist drift: {'; '.join(picklist_drift[:5])}"})

        icon = "✅" if status.startswith("✅") else ("❌" if status.startswith("❌") else "⚠️ ")
        print(f"   {icon} {fname:<45} {status}")

        results.append({
            "field":            fname,
            "lead_exists":      lead_exists,
            "contact_exists":   contact_exists,
            "lead_type":        lead_f["type"]    if lead_f    else None,
            "contact_type":     contact_f["type"] if contact_f else None,
            "type_match":       type_match,
            "picklist_drift":   picklist_drift,
            "lead_updateable":  lead_f["updateable"]    if lead_f    else None,
            "contact_updateable": contact_f["updateable"] if contact_f else None,
            "status":           status,
        })

    print(f"\n📊 Validation summary:")
    print(f"   Fields checked : {len(results)}")
    print(f"   Issues found   : {len(issues)}")
    for issue in issues:
        print(f"   ⚠️  {issue['field']}: {issue['issue']}")

    output = {
        "fields_checked": len(results),
        "issues_count":   len(issues),
        "results":        results,
        "issues":         issues,
    }

    utils.save_json(output, OUTPUT_JSON)
    _export_csv(results)
    print(f"\n✅ Field mapping validation complete.")


def _export_csv(results):
    headers = ["Field", "Lead Exists", "Contact Exists",
               "Lead Type", "Contact Type", "Type Match",
               "Picklist Drift", "Status"]
    rows = [
        [r["field"],
         "Yes" if r["lead_exists"] else "No",
         "Yes" if r["contact_exists"] else "No",
         r.get("lead_type",""), r.get("contact_type",""),
         "Yes" if r["type_match"] else ("N/A" if r["type_match"] is None else "No"),
         "; ".join(r.get("picklist_drift",[])[:10]),
         r["status"]]
        for r in results
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
