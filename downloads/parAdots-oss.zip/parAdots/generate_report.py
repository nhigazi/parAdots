"""
Pardot Audit Report Generator
================================
Reads all pardot_*.json exports and generates a self-contained HTML report:
  - Instance overview (asset counts, last scraped)
  - Detected use-case cards — only shown for patterns actually found in this
    org's data; nothing here is a fixed list, so orgs with fewer/different
    patterns get a shorter, still-accurate card set instead of a fabricated one
  - Best practice gap analysis table (color-coded by severity)
  - Asset inventory tables (lists, automations, programs, forms)
  - Cross-reference orphan section

Output:
  pardot_audit_report.html  — open directly in any browser (no server needed)

Usage:
  python3 generate_report.py                       # uses .active-org
  python3 set_org.py --org <org> && python3 generate_report.py

Run analyze_cross_references.py and analyze_best_practices.py first —
this script only renders their JSON output, it does not compute anything.

No browser / login required.
"""

import json
import os
import sys
from datetime import datetime

import utils

BASE_DIR = os.path.dirname(__file__)   # overridden in main() to utils.OUTPUT_DIR


def _load(filename):
    path = os.path.join(BASE_DIR, filename)
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


# ── Severity colour map ───────────────────────────────────────────────────────

SEV_COLOUR = {
    "critical": "#dc2626",
    "high":     "#ea580c",
    "medium":   "#ca8a04",
    "low":      "#2563eb",
    "ok":       "#16a34a",
}

STATUS_BADGE = {
    "pass":    ('<span style="background:#dcfce7;color:#166534;padding:2px 8px;border-radius:12px;font-size:12px">✅ Pass</span>'),
    "ok":      ('<span style="background:#dcfce7;color:#166534;padding:2px 8px;border-radius:12px;font-size:12px">✅ Pass</span>'),
    "fail":    ('<span style="background:#fee2e2;color:#991b1b;padding:2px 8px;border-radius:12px;font-size:12px">❌ Fail</span>'),
    "partial": ('<span style="background:#fef9c3;color:#854d0e;padding:2px 8px;border-radius:12px;font-size:12px">⚠️ Partial</span>'),
    "warning": ('<span style="background:#fef9c3;color:#854d0e;padding:2px 8px;border-radius:12px;font-size:12px">⚠️ Warning</span>'),
    "unknown": ('<span style="background:#f3f4f6;color:#6b7280;padding:2px 8px;border-radius:12px;font-size:12px">❓ Unknown</span>'),
}


# ── Section builders ──────────────────────────────────────────────────────────

def build_overview_cards(data):
    counts = [
        ("Dynamic Lists",       len(data["lists"]),       "#6366f1"),
        ("Automation Rules",    len(data["automations"]), "#f59e0b"),
        ("Forms",               len(data["forms"]),       "#10b981"),
        ("Form Handlers",       len(data["fh"]),          "#3b82f6"),
        ("Engagement Programs", len(data["programs"]),    "#8b5cf6"),
        ("Dynamic Content",     len(data["dyn"]),         "#ec4899"),
        ("Email Templates",     len(data["emails"]),      "#0ea5e9"),
        ("Landing Pages",       len(data["lps"]),         "#14b8a6"),
        ("Page Actions",        len(data["page_actions"]), "#f97316"),
        ("Campaigns",           len(data["campaigns"]),   "#84cc16"),
    ]
    cards = []
    for label, count, colour in counts:
        cards.append(f"""
        <div style="background:{colour}18;border:1px solid {colour}40;border-radius:10px;padding:16px 20px;text-align:center;min-width:120px">
          <div style="font-size:32px;font-weight:700;color:{colour}">{count}</div>
          <div style="font-size:13px;color:#374151;margin-top:4px">{label}</div>
        </div>""")
    return "".join(cards)


def build_use_case_section(data):
    """
    Fully data-driven — mirrors the fix applied to
    analyze_best_practices.py::build_use_case_summary(). The previous version
    hardcoded Acme/Globex brand names ("ACM, GLB, GLB-CH, INI"), German
    persona vocabulary ("Architekt", "Handwerk", "WoWi"), and literal employee
    domains (@acme.de, @globex.ch) into every org's HTML report regardless
    of which org it was actually generated for. A card is only shown if
    matching data was found for *this* org, and all descriptive text is built
    from real names/counts rather than another customer's configuration.
    """
    lists = data["lists"]
    autos = data["automations"]
    forms = data["forms"]
    programs = data["programs"]

    def _names(items, kw_field="name", n=3):
        shown = [str(i.get(kw_field, "")) for i in items[:n] if i.get(kw_field)]
        more = f" (+{len(items) - n} more)" if len(items) > n else ""
        return ", ".join(shown) + more

    consent_lists = [l for l in lists if any(kw in l.get("name", "").lower() for kw in ("check", "consent", "optin", "opt-in", "doi", "waiting"))]
    newsletter_lists = [l for l in lists if "newsletter" in l.get("name", "").lower()]
    suppression_lists = [l for l in lists if any(kw in l.get("name", "").lower() for kw in ("suppression", "unterdrück"))]
    employee_lists = [l for l in lists if any(kw in l.get("name", "").lower() for kw in ("mitarbeiter", "employee", "internal"))]
    community_lists = [l for l in lists if "community" in l.get("name", "").lower()]
    doi_forms = [f for f in forms if any(kw in f.get("name", "").lower() for kw in ("doi", "optin", "opt-in"))]
    event_forms = [f for f in forms if any(kw in f.get("name", "").lower() for kw in ("event", "messe", "fair", "webinar", "tradeshow"))]
    consent_autos = [a for a in autos if "consent" in a.get("name", "").lower()]
    spam_autos = [a for a in autos if "spam" in a.get("name", "").lower()]
    sync_autos = [a for a in autos if any(kw in a.get("name", "").lower() for kw in ("sync", "crm"))]

    use_cases = []
    if consent_lists or consent_autos or doi_forms:
        use_cases.append(("🔒", "Consent / Double Opt-In Management",
            f"{len(consent_lists)} consent list(s) · {len(consent_autos)} consent automation(s) · "
            f"{len(doi_forms)} opt-in form(s). Examples: {_names(consent_lists)}",
            "#dc2626"))
    if newsletter_lists:
        use_cases.append(("📧", "Newsletter Segmentation",
            f"{len(newsletter_lists)} newsletter list(s): {_names(newsletter_lists)}",
            "#2563eb"))
    if suppression_lists or spam_autos:
        use_cases.append(("🚫", "Suppression & Spam Protection",
            f"{len(suppression_lists)} suppression list(s) · {len(spam_autos)} spam detection rule(s)",
            "#dc2626"))
    if event_forms:
        use_cases.append(("🎪", "Event / Trade-Show Forms",
            f"{len(event_forms)} event-related form(s): {_names(event_forms)}",
            "#0891b2"))
    if community_lists:
        use_cases.append(("👥", "Community Lists",
            f"{len(community_lists)} community list(s): {_names(community_lists)}",
            "#7c3aed"))
    if programs:
        use_cases.append(("🔄", "Engagement Studio",
            f"{len(programs)} program(s) configured",
            "#d97706"))
    if sync_autos:
        use_cases.append(("🔗", "CRM Sync Automation",
            f"{len(sync_autos)} automation(s) reference sync/CRM keywords: {_names(sync_autos)}",
            "#0284c7"))
    if employee_lists:
        use_cases.append(("👤", "Internal / Employee Exclusion",
            f"{len(employee_lists)} employee/internal list(s): {_names(employee_lists)}",
            "#64748b"))

    if not use_cases:
        return "<p style='color:#6b7280'>No recognizable use-case patterns detected in this org's scraped data.</p>"

    cards = []
    for icon, title, desc, colour in use_cases:
        cards.append(f"""
        <div style="border:1px solid #e5e7eb;border-left:4px solid {colour};border-radius:8px;padding:14px 16px;margin-bottom:10px">
          <div style="font-weight:600;color:#111827;margin-bottom:4px">{icon} {_esc(title)}</div>
          <div style="color:#6b7280;font-size:13px">{_esc(desc)}</div>
        </div>""")
    return "".join(cards)


def build_gap_table(checks):
    if not checks:
        return "<p style='color:#6b7280'>No gap analysis data available. Run analyze_best_practices.py.</p>"

    rows = []
    for c in checks:
        colour = SEV_COLOUR.get(c["severity"], "#6b7280")
        sev_badge = f'<span style="background:{colour}18;color:{colour};padding:2px 8px;border-radius:12px;font-size:12px;font-weight:600">{c["severity"].upper()}</span>'
        status_html = STATUS_BADGE.get(c["status"], c["status"])
        title = _esc(c["title"])
        detail = _esc(c.get("detail", "")[:200])
        rec = _esc(c.get("recommendation", "").split("\n")[0][:180]) if c.get("recommendation") else ""

        rows.append(f"""
        <tr>
          <td style="padding:10px 12px;vertical-align:top">{sev_badge}</td>
          <td style="padding:10px 12px;vertical-align:top;font-weight:500">{title}</td>
          <td style="padding:10px 12px;vertical-align:top">{status_html}</td>
          <td style="padding:10px 12px;vertical-align:top;color:#6b7280;font-size:12px">{detail}</td>
          <td style="padding:10px 12px;vertical-align:top;color:#1d4ed8;font-size:12px">{rec}</td>
        </tr>""")

    return f"""
    <table style="width:100%;border-collapse:collapse;font-size:13px">
      <thead>
        <tr style="background:#f9fafb;border-bottom:2px solid #e5e7eb">
          <th style="padding:10px 12px;text-align:left;color:#374151">Severity</th>
          <th style="padding:10px 12px;text-align:left;color:#374151">Check</th>
          <th style="padding:10px 12px;text-align:left;color:#374151">Status</th>
          <th style="padding:10px 12px;text-align:left;color:#374151">Issue</th>
          <th style="padding:10px 12px;text-align:left;color:#374151">Recommendation</th>
        </tr>
      </thead>
      <tbody>{"".join(rows)}</tbody>
    </table>"""


def build_asset_table(items, columns):
    """Generic asset inventory table."""
    if not items:
        return "<p style='color:#6b7280;font-style:italic'>No data available.</p>"

    headers = "".join(f'<th style="padding:8px 12px;text-align:left;color:#374151;white-space:nowrap">{_esc(c)}</th>' for c in columns)
    rows = []
    for i, item in enumerate(items[:200]):  # cap at 200 rows
        bg = "#f9fafb" if i % 2 == 0 else "#ffffff"
        cells = "".join(
            f'<td style="padding:7px 12px;color:#374151;font-size:12px;max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{_esc(str(item.get(c.lower().replace(" ", "_"), item.get(c, "")))[:100])}</td>'
            for c in columns
        )
        rows.append(f'<tr style="background:{bg};border-bottom:1px solid #f3f4f6">{cells}</tr>')

    return f"""
    <div style="overflow-x:auto">
    <table style="width:100%;border-collapse:collapse;font-size:13px">
      <thead><tr style="background:#f3f4f6;border-bottom:2px solid #e5e7eb">{headers}</tr></thead>
      <tbody>{"".join(rows)}</tbody>
    </table>
    </div>"""


def build_cadence_section(cadence):
    if not cadence:
        return "<p style='color:#6b7280;font-style:italic'>No cadence data yet. Run scrape_sent_emails.py.</p>"

    by_type = cadence.get("by_type", {})
    by_list = cadence.get("by_list", [])
    by_brand = cadence.get("by_brand", {})
    by_month = cadence.get("sends_by_month", {})
    total = cadence.get("total_sends", 0)

    # Type pills
    type_pills = "".join(
        f'<span style="background:#f3f4f6;border:1px solid #e5e7eb;border-radius:20px;'
        f'padding:4px 12px;font-size:13px;margin:3px">'
        f'<strong>{_esc(t)}</strong> {c}</span>'
        for t, c in by_type.items()
    )

    # Monthly sparkline (text bar chart)
    max_count = max(by_month.values()) if by_month else 1
    sparkline_rows = "".join(
        f'<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">'
        f'<span style="font-size:11px;color:#6b7280;width:60px;flex-shrink:0">{month}</span>'
        f'<div style="height:16px;width:{int(count/max_count*200)}px;background:#6366f1;border-radius:3px;min-width:4px"></div>'
        f'<span style="font-size:11px;color:#374151">{count}</span></div>'
        for month, count in sorted(by_month.items())
    )

    # List cadence table (top 15)
    FREQ_COLOUR = {
        "Weekly or more":         "#dc2626",
        "Bi-weekly (~every 2 weeks)": "#ea580c",
        "Monthly":                "#16a34a",
        "Quarterly":              "#2563eb",
        "Ad-hoc / one-off":       "#6b7280",
        "Single send (one-off)":  "#9ca3af",
        "Unknown":                "#d1d5db",
    }
    list_rows = "".join(
        f'<tr style="background:{"#f9fafb" if i%2==0 else "#fff"};border-bottom:1px solid #f3f4f6">'
        f'<td style="padding:8px 12px;font-size:12px;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{_esc(e["list"])}</td>'
        f'<td style="padding:8px 12px;font-size:12px;text-align:center">{e["total_sends"]}</td>'
        f'<td style="padding:8px 12px;font-size:12px">'
        f'<span style="color:{FREQ_COLOUR.get(e["frequency"],"#374151")};font-weight:500">{_esc(e["frequency"])}</span></td>'
        f'<td style="padding:8px 12px;font-size:12px;color:#6b7280">{e["most_recent"]}</td>'
        f'<td style="padding:8px 12px;font-size:11px;color:#9ca3af;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{_esc("; ".join(e["email_names"][:2]))}</td>'
        f'</tr>'
        for i, e in enumerate(by_list[:20])
    )

    return f"""
    <div style="margin-bottom:16px">
      <p style="color:#374151;font-size:13px;margin-bottom:10px">
        <strong>{total}</strong> sends captured (last {cadence.get("period_months",12)} months)
      </p>
      <div style="margin-bottom:12px">{type_pills}</div>
    </div>

    <div style="display:flex;gap:24px;flex-wrap:wrap;margin-bottom:20px">
      {''.join(
        f'<div style="background:#f9fafb;border-radius:8px;padding:12px 16px;min-width:120px">'
        f'<div style="font-size:24px;font-weight:700;color:#6366f1">{d["total_sends"]}</div>'
        f'<div style="font-size:12px;color:#6b7280">{brand}</div></div>'
        for brand, d in sorted(by_brand.items(), key=lambda x: -x[1]["total_sends"])
      )}
    </div>

    <div style="display:flex;gap:24px;flex-wrap:wrap">
      <div style="flex:1;min-width:300px">
        <h3 style="margin-bottom:10px">Send Volume by Month</h3>
        {sparkline_rows if sparkline_rows else '<p style="color:#9ca3af;font-size:13px">No date data available</p>'}
      </div>
    </div>

    <h3 style="margin:20px 0 10px">Send Frequency by Recipient List</h3>
    <div style="overflow-x:auto">
    <table style="width:100%;border-collapse:collapse;font-size:13px">
      <thead><tr style="background:#f3f4f6;border-bottom:2px solid #e5e7eb">
        <th style="padding:8px 12px;text-align:left">Recipient List</th>
        <th style="padding:8px 12px;text-align:center">Sends</th>
        <th style="padding:8px 12px;text-align:left">Frequency</th>
        <th style="padding:8px 12px;text-align:left">Last Send</th>
        <th style="padding:8px 12px;text-align:left">Sample Emails</th>
      </tr></thead>
      <tbody>{list_rows}</tbody>
    </table>
    </div>"""


def build_orphan_section(xref):
    if not xref:
        return "<p style='color:#6b7280'>Run analyze_cross_references.py first.</p>"

    o = xref.get("orphans", {})
    parts = []

    orphan_lists = o.get("lists_not_referenced_anywhere", [])
    if orphan_lists:
        items_html = "".join(f'<li style="color:#374151;font-size:13px">{_esc(i["name"])} <span style="color:#9ca3af">(id: {i["id"]})</span></li>' for i in orphan_lists)
        parts.append(f'<h4 style="color:#dc2626;margin:12px 0 6px">🗑 {len(orphan_lists)} Orphan List(s)</h4><ul style="margin:0 0 12px;padding-left:20px">{items_html}</ul>')

    paused = o.get("paused_automations", [])
    if paused:
        items_html = "".join(f'<li style="color:#374151;font-size:13px">{_esc(i["name"])}</li>' for i in paused[:20])
        parts.append(f'<h4 style="color:#ea580c;margin:12px 0 6px">⏸ {len(paused)} Paused Automation(s)</h4><ul style="margin:0 0 12px;padding-left:20px">{items_html}</ul>')

    no_actions = o.get("forms_without_completion_actions", [])
    if no_actions:
        items_html = "".join(f'<li style="color:#374151;font-size:13px">{_esc(i["name"])}</li>' for i in no_actions)
        parts.append(f'<h4 style="color:#ca8a04;margin:12px 0 6px">⚠️ {len(no_actions)} Form(s) With No Completion Actions</h4><ul style="margin:0 0 12px;padding-left:20px">{items_html}</ul>')

    return "".join(parts) if parts else "<p style='color:#16a34a'>✅ No significant orphans detected.</p>"


# ── Full HTML assembly ────────────────────────────────────────────────────────

def generate_html(data):
    gap_data = data.get("gap_analysis") or {}
    checks = gap_data.get("checks", [])
    xref = data.get("cross_refs")
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    summary = gap_data.get("summary", {})

    critical_count = summary.get("critical_gaps", "?")
    high_count     = summary.get("high_gaps", "?")
    medium_count   = summary.get("medium_gaps", "?")

    def section(title, content, id_=""):
        return f"""
    <section id="{id_}" style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:24px;margin-bottom:24px">
      <h2 style="font-size:18px;font-weight:700;color:#111827;margin:0 0 16px;padding-bottom:12px;border-bottom:1px solid #f3f4f6">{title}</h2>
      {content}
    </section>"""

    # Navigation tabs
    nav = """
    <nav style="display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap">
      <a href="#overview"    style="padding:7px 16px;border-radius:8px;background:#6366f1;color:#fff;text-decoration:none;font-size:14px;font-weight:500">Overview</a>
      <a href="#use-cases"   style="padding:7px 16px;border-radius:8px;background:#f3f4f6;color:#374151;text-decoration:none;font-size:14px;font-weight:500">Use Cases</a>
      <a href="#gaps"        style="padding:7px 16px;border-radius:8px;background:#f3f4f6;color:#374151;text-decoration:none;font-size:14px;font-weight:500">Gap Analysis</a>
      <a href="#lists"       style="padding:7px 16px;border-radius:8px;background:#f3f4f6;color:#374151;text-decoration:none;font-size:14px;font-weight:500">Lists</a>
      <a href="#automations" style="padding:7px 16px;border-radius:8px;background:#f3f4f6;color:#374151;text-decoration:none;font-size:14px;font-weight:500">Automations</a>
      <a href="#programs"    style="padding:7px 16px;border-radius:8px;background:#f3f4f6;color:#374151;text-decoration:none;font-size:14px;font-weight:500">Programs</a>
      <a href="#cadence"     style="padding:7px 16px;border-radius:8px;background:#f3f4f6;color:#374151;text-decoration:none;font-size:14px;font-weight:500">Email Cadence</a>
      <a href="#orphans"     style="padding:7px 16px;border-radius:8px;background:#f3f4f6;color:#374151;text-decoration:none;font-size:14px;font-weight:500">Orphans</a>
    </nav>"""

    # Summary KPI bar
    kpi_bar = f"""
    <div style="display:flex;gap:16px;margin-bottom:24px;flex-wrap:wrap">
      <div style="background:#fee2e2;border-radius:10px;padding:12px 20px;text-align:center">
        <div style="font-size:28px;font-weight:700;color:#dc2626">{critical_count}</div>
        <div style="font-size:12px;color:#991b1b">Critical Gaps</div>
      </div>
      <div style="background:#ffedd5;border-radius:10px;padding:12px 20px;text-align:center">
        <div style="font-size:28px;font-weight:700;color:#ea580c">{high_count}</div>
        <div style="font-size:12px;color:#9a3412">High Gaps</div>
      </div>
      <div style="background:#fef9c3;border-radius:10px;padding:12px 20px;text-align:center">
        <div style="font-size:28px;font-weight:700;color:#ca8a04">{medium_count}</div>
        <div style="font-size:12px;color:#854d0e">Medium Gaps</div>
      </div>
    </div>"""

    # Asset count grid
    overview_content = kpi_bar + f"""
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      {build_overview_cards(data)}
    </div>"""

    # Build list table with key columns
    list_items = [{"name": l.get("name",""), "id": l.get("id",""), "rules": str(len(l.get("rules",[]))) + " rule(s)"} for l in data["lists"]]
    auto_items = [{"name": a.get("name",""), "id": a.get("id",""), "status": str(a.get("status",""))} for a in data["automations"]]
    prog_items = [{
        "name": p.get("name",""),
        "id": p.get("id",""),
        "status": p.get("status",""),
        "entry_lists": ", ".join(p.get("entry_lists",[]))[:80],
    } for p in data["programs"]]

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pardot Audit Report — {now}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f1f5f9; color: #111827; }}
  h1 {{ font-size: 24px; font-weight: 800; }}
  h3 {{ font-size: 15px; font-weight: 600; color: #374151; margin-bottom: 8px; }}
</style>
</head>
<body>
<div style="max-width:1280px;margin:0 auto;padding:24px">

  <header style="margin-bottom:24px">
    <h1 style="color:#111827">📊 Pardot Audit Report</h1>
    <p style="color:#6b7280;margin-top:4px;font-size:14px">
      Org: <strong>{_esc(utils.ACTIVE_ORG)}</strong>
      &nbsp;|&nbsp; Generated: {now}
    </p>
  </header>

  {nav}

  {section("Instance Overview", overview_content, "overview")}
  {section("Detected Use Cases & Patterns", build_use_case_section(data), "use-cases")}
  {section("Best Practice Gap Analysis", build_gap_table(checks), "gaps")}
  {section(f"Dynamic Lists ({len(data['lists'])})", build_asset_table(list_items, ["Name", "ID", "Rules"]), "lists")}
  {section(f"Automation Rules ({len(data['automations'])})", build_asset_table(auto_items, ["Name", "ID", "Status"]), "automations")}
  {section(f"Engagement Studio Programs ({len(data['programs'])})", build_asset_table(prog_items, ["Name", "ID", "Status", "Entry_Lists"]), "programs")}
  {section("Email Send Cadence", build_cadence_section(data.get("cadence")), "cadence")}
  {section("Orphaned & Inactive Assets", build_orphan_section(xref), "orphans")}

  <footer style="text-align:center;color:#9ca3af;font-size:12px;padding:24px 0">
    Generated by Pardot List Analyzer · {now}
  </footer>
</div>
</body>
</html>"""
    return html


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    global BASE_DIR
    if not utils.OUTPUT_DIR:
        utils.load_org_config()
    BASE_DIR = utils.OUTPUT_DIR

    print("\n📊 Generating Pardot Audit Report...")

    data = {
        "lists":       _load("pardot_dynamic_lists.json") or [],
        "automations": _load("pardot_automation_rules.json") or [],
        "forms":       _load("pardot_forms.json") or [],
        "fh":          _load("pardot_formhandlers.json") or [],
        "programs":    _load("pardot_engagement_studio.json") or [],
        "dyn":         _load("pardot_dynamic_content.json") or [],
        "emails":      _load("pardot_email_templates.json") or [],
        "lps":         _load("pardot_landing_pages.json") or [],
        "page_actions":_load("pardot_page_actions.json") or [],
        "campaigns":   _load("pardot_campaigns.json") or [],
        "gap_analysis":_load("pardot_gap_analysis.json"),
        "cross_refs":  _load("pardot_cross_references.json"),
        "cadence":     _load("pardot_email_cadence.json"),
    }

    html = generate_html(data)
    output = utils.output_path("pardot_audit_report.html")
    with open(output, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"   ✅ Report saved to pardot_audit_report.html")
    print(f"   Open it in a browser: open pardot_audit_report.html")
    print(f"\n✅ Report generation complete.")


if __name__ == "__main__":
    main()
