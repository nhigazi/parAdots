# Contributing

- **Never commit real org data or credentials.** Only the synthetic `demo` org and
  `configs/demo.env` belong in the repo. Run `python3 scripts/leak_scan.py` before pushing.
- **Tests:** `node --test tests/*.test.js`; keep `python3 -m py_compile` clean.
- **New scrapers** follow the existing `scrape_*.py` pattern (see `utils.py`).
- **No client names, real domains, emails or org IDs** in code, comments, tests or fixtures —
  use fictional brands (Acme, Globex, …) and `example.com`.
