"""
Pardot List Membership Count Scraper — v5 API
===============================================
Enriches every list (static + dynamic) with live member counts from
/api/v5/objects/list-memberships.

The existing scrape_dynamic_lists.py and static list scrapers capture list
definitions and rules but not how many prospects currently belong to each
list. This scraper closes that gap.

Why member counts matter:
  • Health check: a consent list with 0 opted-in members is a silent failure
  • Brand/locale coverage: shows which ACM/GLB/INI locale combinations have
    active subscribers vs. orphan lists
  • Capacity planning: flags very large lists that exceed send limits
  • Segmentation sanity: dynamic rule lists with unexpectedly low counts often
    indicate broken filter logic

Approach:
  1. Read all list IDs from the already-scraped pardot_dynamic_lists.json and
     pardot_static_lists.json (falls back to API fetch if files absent).
  2. For each list, query /api/v5/objects/list-memberships?listId={id}&
     optedOut=false to count active (non-opted-out) members.
     A second pass with optedOut=true gives opted-out count.
  3. Write enriched output with: list id, name, type, active_count,
     optedout_count, total_count, last_scraped_at.

Note on performance: the v5 list-memberships endpoint supports filtering by
listId but does not return a totalElements count directly (it pages through
records). To avoid fetching every prospect row, this scraper uses a
lightweight HEAD/count approach: request page size 1 and read the
nextPageToken absence + values length as a lower bound, OR iterates pages
counting records. For lists with > 1000 members, page-counting is done with
the maximum page size (200) to minimise requests.

Output:
  pardot_list_memberships.json
  pardot_list_memberships.csv

Usage (standalone):
  python3 scrape_list_memberships.py

Called from run_all.py:
  from scrape_list_memberships import run
  run(page=page)
"""

from __future__ import annotations

import csv
import json
import os
import sys
from datetime import datetime, timezone

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time
OUTPUT_CSV  = ""

LIST_FIELDS = ["id", "name", "isCrm", "isDynamic", "folderId", "createdAt", "updatedAt"]
MEMBERSHIP_FIELDS = ["id", "listId", "optedOut"]

# Max page size for counting passes — minimises HTTP round trips
COUNT_PAGE_SIZE = 200


# ── List source ───────────────────────────────────────────────────────────────

def _load_existing_lists() -> list[dict]:
    """
    Try to load list definitions from already-scraped JSON files.
    Falls back to an empty list (caller will fetch from API).
    """
    lists: list[dict] = []
    seen: set = set()

    for filename in ("pardot_dynamic_lists.json", "pardot_static_lists.json"):
        path = utils.output_path(filename)
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            for item in data:
                lid = str(item.get("id", ""))
                if lid and lid not in seen:
                    seen.add(lid)
                    lists.append({
                        "id":        lid,
                        "name":      item.get("name", ""),
                        "is_dynamic": item.get("isDynamic") or item.get("is_dynamic", False),
                    })
        except Exception as e:
            print(f"   ⚠️  Could not read {filename}: {e}")

    return lists


def _fetch_lists_from_api(client: pardot_api.PardotClient) -> list[dict]:
    print("   ↪︎ Fetching lists from API (no local JSON found)...")
    raw = list(pardot_api.paged_get(client, "objects/lists", fields=LIST_FIELDS))
    return [
        {
            "id":         str(r.get("id", "")),
            "name":       r.get("name", ""),
            "is_dynamic": bool(r.get("isDynamic")),
        }
        for r in raw
    ]


# ── Count helpers ─────────────────────────────────────────────────────────────

def _count_memberships(
    client: pardot_api.PardotClient,
    list_id: str,
    opted_out: bool,
) -> int:
    """
    Count memberships for a given list filtered by optedOut status.
    Fetch all memberships for this list, then filter in Python.
    """
    try:
        # API doesn't support filtering by listId or optedOut directly;
        # fetch all memberships and filter in Python.
        records = list(pardot_api.paged_get(
            client,
            endpoint="objects/list-memberships",
            fields=["id", "optedOut"],
            extra_params={"listId": list_id},
            page_size=COUNT_PAGE_SIZE,
        ))
        # Filter by optedOut status
        return sum(1 for r in records if bool(r.get("optedOut", False)) == opted_out)
    except Exception:
        # Some lists (CRM-synced system lists) block membership reads
        return 0


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_list_memberships.json")
    OUTPUT_CSV  = utils.output_path("pardot_list_memberships.csv")

    print("\n🚀 Pardot List Membership Count Scraper (v5 API)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    # Load list definitions
    lists = _load_existing_lists()
    if lists:
        print(f"📋 Loaded {len(lists)} list(s) from local JSON files")
    else:
        lists = _fetch_lists_from_api(client)
        print(f"   ✅ {len(lists)} list(s) fetched from API")

    if not lists:
        print("⚠️  No lists found — nothing to count.")
        utils.save_json([], OUTPUT_JSON)
        _export_csv([])
        return

    scraped_at = datetime.now(timezone.utc).isoformat()
    print(f"\n🔢 Counting memberships for {len(lists)} list(s)...")
    print("   (two passes per list: active + opted-out)\n")

    results = []
    for i, lst in enumerate(lists, 1):
        lid  = lst["id"]
        name = lst["name"] or f"list_{lid}"
        print(f"   [{i}/{len(lists)}] {name} (id: {lid})")

        active_count  = _count_memberships(client, lid, opted_out=False)
        optout_count  = _count_memberships(client, lid, opted_out=True)
        total_count   = active_count + optout_count

        print(f"              active={active_count}  opted-out={optout_count}  total={total_count}")

        results.append({
            "id":            lid,
            "name":          name,
            "is_dynamic":    lst.get("is_dynamic", False),
            "active_count":  active_count,
            "optedout_count": optout_count,
            "total_count":   total_count,
            "scraped_at":    scraped_at,
        })

    # Summary
    total_active = sum(r["active_count"] for r in results)
    total_optout = sum(r["optedout_count"] for r in results)
    empty_lists  = [r for r in results if r["total_count"] == 0]
    print(f"\n📊 Membership summary:")
    print(f"   Lists scraped  : {len(results)}")
    print(f"   Total active   : {total_active:,}")
    print(f"   Total opted-out: {total_optout:,}")
    print(f"   Empty lists    : {len(empty_lists)}")
    if empty_lists:
        for r in empty_lists[:5]:
            print(f"      • {r['name']}")
        if len(empty_lists) > 5:
            print(f"      … and {len(empty_lists) - 5} more")

    utils.save_json(results, OUTPUT_JSON)
    _export_csv(results)
    print(f"\n✅ List membership scrape complete — {len(results)} lists counted.")


def _export_csv(results: list[dict]) -> None:
    headers = [
        "#", "Name", "ID", "Type",
        "Active Members", "Opted-Out", "Total",
        "Scraped At",
    ]
    rows = [
        [
            i + 1,
            r["name"], r["id"],
            "Dynamic" if r.get("is_dynamic") else "Static",
            r["active_count"], r["optedout_count"], r["total_count"],
            r["scraped_at"],
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
