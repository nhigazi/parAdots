"""
Pardot Lead Scoring Rules & Profile Scraper
=============================================
Scrapes three related qualification assets from Account Engagement:

  1. Scoring Rules  — behavioral score adjustments per activity type
     List:   <PARDOT_HOME>/scoringRules

  2. Scoring Categories — groupings of scoring rules (if configured)
     List:   <PARDOT_HOME>/scoringCategory
     Detail: <PARDOT_HOME>/scoringCategory/read/id/{id}

  3. Profiles (Grading) — demographic fit criteria driving A/B/C/D grades
     List:   <PARDOT_HOME>/profile
     Detail: <PARDOT_HOME>/profile/read/id/{id}

Output:
  pardot_scoring_rules.json
  pardot_scoring_rules.csv
  pardot_profiles.json
  pardot_profiles.csv

Usage (standalone):
  python3 scrape_scoring_rules.py

Called from run_all.py with a shared browser page.
"""

import re
import time
from playwright.sync_api import sync_playwright

import utils

OUTPUT_JSON  = ""   # set at run() time via utils.output_path()
OUTPUT_CSV   = ""
SCREENSHOTS  = ""

# Confirmed scoring rules page
SCORING_RULES_PATH = "/scoringRules"

# Fallbacks tried if the primary returns a blank / not-found page
SCORING_RULES_FALLBACKS = [
    "/scoring",
    "/admin/scoring",
]

# Confirmed category URLs
CATEGORY_LIST_PATH   = "/scoringCategory"
CATEGORY_DETAIL_PATH = "/scoringCategory/read/id/{id}"

# Confirmed profile (grading) URLs
PROFILES_JSON       = "pardot_profiles.json"
PROFILES_CSV        = "pardot_profiles.csv"
PROFILE_LIST_PATH    = "/profile"
PROFILE_DETAIL_PATH  = "/profile/read/id/{id}"


# ── Scrape the default scoring page ──────────────────────────────────────────

def _scrape_scoring_page(page, url):
    utils.navigate(page, url)
    utils.scroll_to_bottom(page, steps=3)
    utils.screenshot(page, f"{SCREENSHOTS}/scoring_main.png")
    # filter_prospects=False: the sidebar nav contains "Prospects" which would
    # truncate the page text before any scoring content is reached.
    return utils.get_page_text(page, filter_prospects=False)


def _parse_scoring_text(text):
    """
    Parse the raw Pardot scoring page text into structured scoring rules.
    Returns a list of dicts: {activity, score, category, notes}

    Pardot renders the scoring table as block elements, so innerText gives
    the activity and its score on SEPARATE consecutive lines:

        Custom Redirect Click
        3 points
        Email Open
        0 points
        Form Error
        -5 points

    Single-line formats (e.g. "Email Open  +1") are also handled as fallback.
    """
    rules = []
    lines = [l.strip() for l in text.splitlines() if l.strip()]

    # Matches a standalone score line: "3 points", "-5 points", "+50 points", "0 points"
    score_line_re  = re.compile(r'^([\+\-]?\d+)\s+points?\s*$', re.IGNORECASE)
    # Fallback: activity and score on the same line "Email Open  +1" or "Form Submit  50 points"
    inline_score_re = re.compile(r'^(.+?)\s+([\+\-]?\d+)\s+points?\s*$', re.IGNORECASE)
    inline_bare_re  = re.compile(r'^(.+?)\s+([\+\-]\d+)\s*$')

    # Known Pardot scoring activity names — used to identify activity lines
    # and skip navigation/header noise.
    KNOWN_ACTIVITIES = {
        "custom redirect click", "email click", "email open", "file access",
        "form error", "form handler error", "form handler submission",
        "form submission", "landing page error", "landing page success",
        "olark chat", "opportunity created", "opportunity lost", "opportunity won",
        "page view", "site search query", "social message link click",
        "third party click", "tracker link click", "visitor session",
        "webinar attended", "webinar invited", "webinar registered",
    }

    current_category = "Scoring Rules"
    i = 0
    while i < len(lines):
        line = lines[i]
        ll   = line.lower()

        # Section header: "Scoring Rules" or "Scoring Categories"
        if ll in ("scoring rules", "scoring categories"):
            current_category = line
            i += 1
            continue

        # Two-line format: activity on this line, "N points" on the next
        if ll in KNOWN_ACTIVITIES and i + 1 < len(lines):
            next_line = lines[i + 1]
            m = score_line_re.match(next_line)
            if m:
                rules.append({
                    "activity": line,
                    "score":    m.group(1),
                    "category": current_category,
                    "notes":    "",
                })
                i += 2
                continue

        # Single-line formats (fallback)
        m = inline_score_re.match(line) or inline_bare_re.match(line)
        if m and len(m.group(1)) > 3:
            rules.append({
                "activity": m.group(1).strip(),
                "score":    m.group(2).strip(),
                "category": current_category,
                "notes":    "",
            })
            i += 1
            continue

        i += 1

    # If structured parsing found nothing, store the raw text for manual review
    if not rules:
        rules.append({
            "activity": "Raw page text (needs manual review)",
            "score":    "",
            "category": "Unparsed",
            "notes":    "\n".join(lines[:100]),
        })

    return rules


# ── Scrape scoring categories ─────────────────────────────────────────────────

def _scrape_categories(page):
    utils.navigate(page, utils.pardot_url(CATEGORY_LIST_PATH))
    utils.scroll_to_bottom(page, steps=3)
    utils.screenshot(page, f"{SCREENSHOTS}/scoring_categories.png")

    # Discover individual category IDs from the list page
    cat_items = utils.collect_ids_from_page(page, r'/scoringCategory/read/id/(\d+)')

    categories = []
    if cat_items:
        for item in cat_items[:50]:
            cat_url = utils.pardot_url(CATEGORY_DETAIL_PATH.format(id=item["id"]))
            utils.navigate(page, cat_url)
            text = utils.get_page_text(page)
            lines = [l.strip() for l in text.splitlines() if l.strip()]
            categories.append({
                "id":   item["id"],
                "name": item.get("name", ""),
                "raw_text_snippet": "\n".join(lines[:20]),
            })
        return categories

    # Fallback: parse category names from list page text
    text = utils.get_page_text(page)
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    seen = set()
    for line in lines:
        if 3 < len(line) < 60 and line not in seen and not re.match(r'^[\d\+\-\s]+$', line):
            seen.add(line)
            categories.append({"id": "", "name": line, "raw_text_snippet": ""})
    return categories[:50]


# ── Scrape profiles (grading) ────────────────────────────────────────────────

def _discover_profiles(page):
    utils.navigate(page, utils.pardot_url(PROFILE_LIST_PATH))
    utils.scroll_to_bottom(page, steps=3)
    utils.screenshot(page, f"{SCREENSHOTS}/profiles_list.png")
    return utils.collect_ids_from_page(page, r'/profile/read/id/(\d+)')


def _scrape_profile(page, profile_id, profile_name):
    url = utils.pardot_url(PROFILE_DETAIL_PATH.format(id=profile_id))
    utils.navigate(page, url)
    utils.screenshot(page, f"{SCREENSHOTS}/profile_{profile_id}.png")

    text = utils.get_page_text(page)
    if "page not found" in text.lower():
        return None

    lines = [l.strip() for l in text.splitlines() if l.strip()]

    def extract_field(keywords):
        for i, line in enumerate(lines):
            if any(kw.lower() in line.lower() for kw in keywords):
                if ":" in line:
                    val = line.split(":", 1)[1].strip()
                    if val:
                        return val[:300]
                if i + 1 < len(lines):
                    return lines[i + 1][:300]
        return ""

    description = extract_field(["description", "beschreibung"])
    criteria    = extract_field(["criteria", "criterion", "kriterien"])
    grade       = extract_field(["grade", "bewertung", "rating"])

    return {
        "id":          profile_id,
        "name":        profile_name,
        "description": description,
        "grade":       grade,
        "criteria":    criteria,
        "raw_text_snippet": "\n".join(lines[:30]),
    }


# ── Run ───────────────────────────────────────────────────────────────────────

def run(page):
    """Scrape scoring rules — no browser lifecycle management."""
    global OUTPUT_JSON, OUTPUT_CSV, SCREENSHOTS
    OUTPUT_JSON = utils.output_path("pardot_scoring_rules.json")
    OUTPUT_CSV  = utils.output_path("pardot_scoring_rules.csv")
    SCREENSHOTS = utils.output_path("screenshots", "scoring")
    utils.reset_screenshots(SCREENSHOTS)
    print("\n📊 Scraping lead scoring rules...")

    scoring_text = ""
    for url in [utils.pardot_url(p) for p in [SCORING_RULES_PATH] + SCORING_RULES_FALLBACKS]:
        print(f"   Trying {url}...")
        utils.navigate(page, url)
        current_url = page.url.lower()
        if "scoring" in current_url or "admin" in current_url:
            utils.scroll_to_bottom(page, steps=3)
            scoring_text = utils.get_page_text(page, filter_prospects=False)
            utils.screenshot(page, f"{SCREENSHOTS}/scoring_main.png")
            break
        text = utils.get_page_text(page, filter_prospects=False)
        if text and len(text) > 200:
            scoring_text = text
            utils.screenshot(page, f"{SCREENSHOTS}/scoring_main.png")
            break

    if not scoring_text:
        print("⚠️  Could not load scoring page — capturing current state")
        scoring_text = utils.get_page_text(page)
        utils.screenshot(page, f"{SCREENSHOTS}/scoring_fallback.png")

    rules = _parse_scoring_text(scoring_text)
    print(f"   Found {len(rules)} scoring rule(s)")

    # Attempt to scrape scoring categories
    print("   Checking scoring categories...")
    try:
        categories = _scrape_categories(page)
        print(f"   Found {len(categories)} potential category name(s)")
    except Exception as e:
        print(f"   ⚠️  Categories page unavailable: {e}")
        categories = []

    result = {
        "scoring_rules": rules,
        "scoring_categories": categories,
        "raw_page_available": bool(scoring_text),
        "notes": (
            "Scoring rules scraped from Pardot admin scoring page. "
            "If 'Unparsed' entries appear, check screenshots/scoring/ for the raw page. "
            "A formal scoring model with 5+ distinct activity types is a best-practice requirement."
        ),
    }

    utils.save_json(result, OUTPUT_JSON)

    csv_rows = [
        [i + 1, r["category"], r["activity"], r["score"], r["notes"]]
        for i, r in enumerate(rules)
    ]
    utils.save_csv(
        csv_rows,
        ["#", "Category", "Activity", "Score", "Notes"],
        OUTPUT_CSV,
    )

    if categories:
        names = [c["name"] if isinstance(c, dict) else c for c in categories[:10]]
        print(f"   Scoring categories: {', '.join(names)}")

    # Scrape profiles (grading)
    print("\n🎯 Scraping profiles (grading)...")
    profiles = []
    try:
        profile_items = _discover_profiles(page)
        print(f"   Found {len(profile_items)} profile(s)")
        for i, item in enumerate(profile_items, 1):
            print(f"   [{i}/{len(profile_items)}] {item.get('name', item['id'])}")
            data = _scrape_profile(page, item["id"], item.get("name", ""))
            if data:
                profiles.append(data)
            time.sleep(0.5)
    except Exception as e:
        print(f"   ⚠️  Profiles page unavailable: {e}")

    utils.save_json(profiles, PROFILES_JSON)
    profile_rows = [
        [i + 1, p["id"], p["name"], p["grade"], p["description"], p["criteria"]]
        for i, p in enumerate(profiles)
    ]
    utils.save_csv(
        profile_rows,
        ["#", "ID", "Profile Name", "Grade", "Description", "Criteria"],
        PROFILES_CSV,
    )
    print(f"   Profiles saved: {len(profiles)}")
    print(f"\n✅ Scoring rules & profiles scrape complete.")


# ── Standalone entry point ────────────────────────────────────────────────────

def main():
    utils.load_org_config()
    utils.validate_credentials()
    print("\n🚀 Pardot Lead Scoring Rules Scraper")
    print("=" * 45)

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
