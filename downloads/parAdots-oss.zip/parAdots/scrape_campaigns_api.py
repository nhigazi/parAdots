"""
Pardot Campaign Scraper — v5 API  (replaces scrape_campaigns.py)
================================================================
Pulls Pardot Connected Campaigns from /api/v5/objects/campaigns and
enriches each record with:

  • Salesforce Campaign metadata (type, status, dates, ROI stats,
    description, owner, parent campaign) via SOQL — with full pagination.
  • Linked Pardot assets (forms, form handlers, landing pages, list
    emails) fetched in a single bulk pass per asset type, then grouped
    client-side — no per-campaign HTTP calls.
  • Folder name resolved from /api/v5/objects/folders.

Output:
  pardot_campaigns.json
  pardot_campaigns.csv

Usage (standalone):
  python3 scrape_campaigns_api.py

Called from run_all.py:
  from scrape_campaigns_api import run
  run(page=page)          # page is a logged-in Playwright Page
  # or
  run(client=client)      # if you already have a PardotClient
"""

from __future__ import annotations

import csv
import json
import os
import sys
from collections import defaultdict
from typing import Iterable

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time via utils.output_path()
OUTPUT_CSV  = ""

# ── Field lists ───────────────────────────────────────────────────────────────

CAMPAIGN_FIELDS = [
    "id", "name", "cost", "salesforceId",
    "folderId", "createdAt", "updatedAt",
]

FOLDER_FIELDS = ["id", "name"]

# Each tuple: (v5 endpoint, comma-separated fields, display label)
ASSET_TYPES: list[tuple[str, str, str]] = [
    ("objects/forms",          "id,name,campaignId", "Form"),
    ("objects/form-handlers",  "id,name,campaignId", "Form Handler"),
    ("objects/landing-pages",  "id,name,campaignId", "Landing Page"),
    ("objects/list-emails",    "id,name,campaignId", "List Email"),
]

# Salesforce Campaign SELECT — relationship fields (Owner.Name, Parent.Name)
# come back as nested objects in the REST response.
SF_SELECT = (
    "Id, Name, Type, Status, StartDate, EndDate, "
    "BudgetedCost, ActualCost, IsActive, Description, "
    "NumberOfLeads, NumberOfConvertedLeads, NumberOfContacts, "
    "NumberOfOpportunities, NumberOfWonOpportunities, "
    "AmountAllOpportunities, AmountWonOpportunities, "
    "Owner.Name, ParentId, Parent.Name"
)

SF_QUERY_BATCH = 200   # safe IN-clause cap; SOQL allows more but 200 avoids URL limits


# ── Helpers ───────────────────────────────────────────────────────────────────

def _chunked(iterable: Iterable, size: int):
    bucket: list = []
    for item in iterable:
        bucket.append(item)
        if len(bucket) >= size:
            yield bucket
            bucket = []
    if bucket:
        yield bucket


# ── Step 1 + 2: Salesforce SOQL with pagination and extended fields ───────────

def fetch_sf_campaigns(
    client: pardot_api.PardotClient,
    sf_ids: list[str],
) -> dict[str, dict]:
    """
    Batch-query Salesforce for enriched Campaign records.

    Handles SOQL pagination via nextRecordsUrl (Salesforce returns this
    instead of nextPageToken when result sets exceed 2 000 rows).

    The Pardot access token is valid for the Salesforce REST API because
    they share the same Connected App OAuth scope.
    """
    if not sf_ids:
        return {}

    base    = pardot_api.SF_LOGIN_URL
    out: dict[str, dict] = {}
    session = client.session
    auth_headers = {
        "Authorization": f"Bearer {client.access_token}",
        "Content-Type":  "application/json",
    }

    for batch in _chunked(sf_ids, SF_QUERY_BATCH):
        in_clause = ",".join(f"'{i}'" for i in batch)
        soql = f"SELECT {SF_SELECT} FROM Campaign WHERE Id IN ({in_clause})"

        next_url: str | None = f"{base}/services/data/v60.0/query"
        params: dict | None  = {"q": soql}

        # Follow nextRecordsUrl until Salesforce signals done:true
        while next_url:
            if params:
                resp = session.get(
                    next_url, headers=auth_headers,
                    params=params, timeout=pardot_api.DEFAULT_TIMEOUT,
                )
                params = None  # subsequent pages: nextRecordsUrl carries the query
            else:
                resp = session.get(
                    next_url, headers=auth_headers,
                    timeout=pardot_api.DEFAULT_TIMEOUT,
                )

            if resp.status_code != 200:
                print(f"⚠️  SF SOQL failed ({resp.status_code}): {resp.text[:200]}")
                break

            body = resp.json()
            for record in body.get("records", []):
                out[record["Id"]] = record

            nr = body.get("nextRecordsUrl")
            next_url = f"{base}{nr}" if nr else None

    return out


# ── Step 3: Bulk-fetch linked assets ─────────────────────────────────────────

def fetch_linked_assets(
    client: pardot_api.PardotClient,
) -> dict[str, dict[str, list[str]]]:
    """
    Fetch ALL forms / form-handlers / landing-pages / list-emails in four
    single-pass requests, then group by campaignId and asset type client-side.

    This avoids N × 4 HTTP calls (one per campaign × asset type) which
    would be slow for large instances.

    Returns:
        {
          str(campaignId): {
            "Form":         ["Name A", ...],
            "Form Handler": ["Name B", ...],
            "Landing Page": [...],
            "List Email":   [...],
          }
        }
    Every campaign entry always contains all four type keys (empty list when
    there are no assets of that type), making count derivation unconditional.
    """
    # Seed every label so callers always get all four keys, even with zero assets.
    labels = [label for _, _, label in ASSET_TYPES]
    asset_map: dict[str, dict[str, list[str]]] = defaultdict(
        lambda: {lbl: [] for lbl in labels}
    )

    for endpoint, fields_csv, label in ASSET_TYPES:
        fields = fields_csv.split(",")
        count  = 0
        for item in pardot_api.paged_get(client, endpoint, fields=fields):
            cid  = item.get("campaignId")
            name = (item.get("name") or "").strip()
            if cid and name:
                asset_map[str(cid)][label].append(name)
                count += 1
        print(f"   ✅ {label}s: {count} asset(s) mapped to campaigns")

    return dict(asset_map)


# ── Step 4 + 5: Shape record with all enriched fields ────────────────────────

def _str(v) -> str:
    return "" if v is None else str(v)


def shape_campaign(
    camp: dict,
    sf_map: dict[str, dict],
    asset_map: dict[str, dict[str, list[str]]],
    folder_map: dict,
) -> dict:
    sf_id   = camp.get("salesforceId") or ""
    sf      = sf_map.get(sf_id, {}) if sf_id else {}
    camp_id = str(camp.get("id", ""))

    # Cost: prefer Pardot value, fall back to SF BudgetedCost then ActualCost
    cost = camp.get("cost")
    if cost is None and sf:
        cost = sf.get("BudgetedCost") or sf.get("ActualCost")

    # Folder name from pre-loaded map
    folder_id   = camp.get("folderId")
    folder_rec  = folder_map.get(folder_id) or {}
    folder_name = folder_rec.get("name", "")

    # Relationship fields come back as nested dicts from Salesforce REST
    owner_name  = ((sf.get("Owner")  or {}).get("Name")  or "")
    parent_name = ((sf.get("Parent") or {}).get("Name")  or "")

    # Asset counts — by_type always has all four keys (seeded in fetch_linked_assets)
    by_type: dict[str, list[str]] = asset_map.get(camp_id, {})
    assets_total   = sum(len(v) for v in by_type.values())
    # Flat list preserves the "[Type] Name" format for the linked_assets field
    linked_flat    = [
        f"[{lbl}] {name}"
        for lbl, names in by_type.items()
        for name in names
    ]
    by_type_counts = {lbl: len(names) for lbl, names in by_type.items()}

    return {
        "id":                    camp_id,
        "name":                  camp.get("name", ""),
        "type":                  sf.get("Type", "")   or "",
        "status":                sf.get("Status", "") or "",
        "is_active":             _str(sf.get("IsActive")),
        "start_date":            sf.get("StartDate", "")  or "",
        "end_date":              sf.get("EndDate", "")    or "",
        "cost":                  "" if cost in (None, "") else _str(cost),
        "description":           sf.get("Description", "") or "",
        "owner":                 owner_name,
        "parent_campaign":       parent_name,
        "sf_campaign":           sf_id,
        "folder_name":           folder_name,
        "num_leads":             _str(sf.get("NumberOfLeads")),
        "num_converted_leads":   _str(sf.get("NumberOfConvertedLeads")),
        "num_contacts":          _str(sf.get("NumberOfContacts")),
        "num_opportunities":     _str(sf.get("NumberOfOpportunities")),
        "num_won_opportunities": _str(sf.get("NumberOfWonOpportunities")),
        "amount_all_opps":       _str(sf.get("AmountAllOpportunities")),
        "amount_won_opps":       _str(sf.get("AmountWonOpportunities")),
        "linked_assets_total":   assets_total,
        "linked_assets_by_type": by_type_counts,
        "linked_assets":         linked_flat,
        "created_at":            camp.get("createdAt", "") or "",
        "updated_at":            camp.get("updatedAt", "") or "",
    }


def export_csv(results: list[dict]) -> None:
    # Asset type labels must match the keys produced by fetch_linked_assets()
    asset_labels = [label for _, _, label in ASSET_TYPES]

    headers = [
        "#", "Name", "ID", "Type", "Status", "Is Active",
        "Start Date", "End Date", "Cost", "Description",
        "Owner", "Parent Campaign", "SF Campaign", "Folder",
        "Leads", "Converted Leads", "Contacts",
        "Opportunities", "Won Opportunities",
        "Amount All Opps", "Amount Won Opps",
        "Assets Total",
        *[f"# {lbl}s" for lbl in asset_labels],
        "Linked Assets", "Created At", "Updated At",
    ]
    rows = [
        [
            i + 1,
            r["name"], r["id"], r["type"], r["status"], r["is_active"],
            r["start_date"], r["end_date"], r["cost"], r["description"],
            r["owner"], r["parent_campaign"], r["sf_campaign"], r["folder_name"],
            r["num_leads"], r["num_converted_leads"], r["num_contacts"],
            r["num_opportunities"], r["num_won_opportunities"],
            r["amount_all_opps"], r["amount_won_opps"],
            r["linked_assets_total"],
            *[r["linked_assets_by_type"].get(lbl, 0) for lbl in asset_labels],
            "; ".join(r["linked_assets"]),
            r["created_at"], r["updated_at"],
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    """
    Entry point for both standalone use and run_all.py integration.

    Pass either:
      page   – a logged-in Playwright Page (token extracted automatically)
      client – an already-built PardotClient (skips browser entirely)
    """
    print("\n🚀 Pardot Campaign Scraper (v5 API)")
    print("=" * 45)

    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_campaigns.json")
    OUTPUT_CSV  = utils.output_path("pardot_campaigns.csv")

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    # 1. Pardot campaigns
    print("📋 Fetching campaigns from Pardot v5 API...")
    campaigns = list(pardot_api.paged_get(
        client, "objects/campaigns", fields=CAMPAIGN_FIELDS,
    ))
    print(f"   ✅ {len(campaigns)} campaign(s)")

    # 2. Folder names (pre-load once)
    print("📁 Loading folder names...")
    folder_map = pardot_api.lookup_map(client, "objects/folders", fields=FOLDER_FIELDS)
    print(f"   ✅ {len(folder_map)} folder(s)")

    # 3. Linked assets (bulk, one pass per asset type)
    print("🔗 Fetching linked assets...")
    asset_map = fetch_linked_assets(client)

    # 4. Salesforce Campaign metadata (with SOQL pagination)
    sf_ids = [c["salesforceId"] for c in campaigns if c.get("salesforceId")]
    print(f"☁️  Resolving Salesforce metadata for {len(sf_ids)} connected campaign(s)...")
    sf_map = fetch_sf_campaigns(client, sf_ids)
    print(f"   ✅ {len(sf_map)} SF Campaign record(s) returned")

    # 5. Shape and export
    results = [shape_campaign(c, sf_map, asset_map, folder_map) for c in campaigns]

    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"✅ Saved {OUTPUT_JSON} ({len(results)} campaigns)")
    export_csv(results)


def main() -> None:
    utils.load_org_config()
    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
