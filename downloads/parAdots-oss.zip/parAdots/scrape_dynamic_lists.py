"""
Pardot Dynamic List Rule Scraper
=================================
Since Pardot API v5 does NOT expose filter rules for dynamic lists,
this script uses two approaches combined:

  Part A – Pardot API v5:  Fetch all dynamic list IDs and names
  Part B – Playwright:     Log into Pardot UI and scrape filter rules
                           from each list's edit page

Output: JSON file with each list's name + human-readable rules

Usage:
  1. Copy .env.template to .env and fill in credentials
  2. pip3 install -r requirements.txt
  3. python3 scrape_dynamic_lists.py
"""

import json
import os
import sys
import time

import requests
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright

import pardot_api
import utils

load_dotenv()

# ── Config ────────────────────────────────────────────────────────────────────

SF_LOGIN_URL          = os.getenv("SF_LOGIN_URL", "https://login.salesforce.com/")
SF_USERNAME           = os.getenv("SF_USERNAME", "")
PARDOT_BU_ID          = os.getenv("PARDOT_BUSINESS_UNIT_ID", "")
DYNAMIC_OUTPUT_JSON   = ""   # set at run() time via utils.output_path()
DYNAMIC_OUTPUT_CSV    = ""
STATIC_OUTPUT_JSON    = ""
STATIC_OUTPUT_CSV     = ""
ALL_OUTPUT_CSV        = ""
OUTPUT_FILE           = DYNAMIC_OUTPUT_JSON  # kept for backward compat with run_all.py
SCREENSHOTS_DIR       = ""

# Set True after the UI-language guard passes on the first list visited in a
# run — see scrape_list_rules() / utils.assert_english_ui.
_LANGUAGE_VERIFIED    = False

CSV_HEADERS     = ["#", "List Name", "List ID", "Prospect Count", "Match Type", "Rules (Plain Text)", "Usage Count", "Usage"]
CSV_ALL_HEADERS = ["#", "Type", "List Name", "List ID", "Prospect Count", "Match Type", "Rules (Plain Text)", "Usage Count", "Usage"]

_STATIC_MARKER = "Static list — no filter rules"


def _is_static(lst):
    # Trust the discovery-time classification (Pardot's own `isDynamic` flag
    # / the UI "Dynamic" column) when we have it — it's locale-independent.
    # BUG (found 2026-07-02, globex): this used to be re-derived purely from
    # whether scrape_list_rules() found the English "Dynamic List Rules"
    # heading on the detail page. On non-English tenants (globex is German:
    # "Regeln für dynamische Listen") that heading never matches, so EVERY
    # list — including ones correctly identified as dynamic at discovery —
    # fell through to the static fallback text and got silently reclassified
    # as static. Confirmed via screenshot: a list with "Dynamische Liste: Ja"
    # in the Pardot UI was written out as Static because its rule-heading
    # text extraction failed on the German label.
    if "is_dynamic" in lst:
        return not lst["is_dynamic"]
    rules = lst.get("rules") or []
    if rules and isinstance(rules, list) and "raw_page_text" in rules[0]:
        return rules[0]["raw_page_text"].strip() == _STATIC_MARKER
    return _STATIC_MARKER in lst.get("explanation", "")


def _rules_text(lst):
    rules = lst.get("rules") or []
    if rules and isinstance(rules, list) and "raw_page_text" in rules[0]:
        return rules[0]["raw_page_text"]
    return lst.get("explanation", "")


def _usage_text(lst):
    """'Type: Name' per usage row, joined for the CSV column. Only populated
    for dynamic lists (see scrape_list_rules) — static lists here are the
    lighter, legacy duplicate of scrape_static_lists.py's fuller output,
    which is this project's authoritative source for static-list usage."""
    usage = lst.get("usage") or []
    return "; ".join(f"{u.get('type', '')}: {u.get('name', '')}" for u in usage)


def _write_one(items, json_path, csv_path):
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2, ensure_ascii=False)
    print(f"   ✅ JSON saved to {json_path}  ({len(items)} list(s))")
    rows = [
        [i, lst.get("name", ""), lst.get("id", ""), lst.get("prospect_count", ""), "", _rules_text(lst),
         len(lst.get("usage") or []), _usage_text(lst)]
        for i, lst in enumerate(items, 1)
    ]
    utils.save_csv(rows, CSV_HEADERS, csv_path)


def _check_duplicates(combined):
    """
    Check pardot_all_lists for duplicate IDs or duplicate names.
    Prints a summary and returns True if the list is clean, False if issues found.
    """
    from collections import Counter
    id_counts   = Counter(lst.get("id",   "") for lst in combined)
    name_counts = Counter(lst.get("name", "").strip().lower() for lst in combined)

    dup_ids   = {id_:   n for id_,   n in id_counts.items()   if n > 1 and id_}
    dup_names = {name: n for name, n in name_counts.items() if n > 1 and name}

    print("\n── Duplicate check (" + ALL_OUTPUT_CSV + ") ────────────────────────")
    clean = True

    if dup_ids:
        clean = False
        print(f"   ❌ Duplicate List IDs ({len(dup_ids)}):")
        for id_, n in sorted(dup_ids.items()):
            names = [lst["name"] for lst in combined if lst.get("id") == id_]
            print(f"      ID {id_} appears {n}×  → {names}")
    else:
        print("   ✅ No duplicate IDs")

    if dup_names:
        clean = False
        print(f"   ❌ Duplicate List Names ({len(dup_names)}):")
        for name, n in sorted(dup_names.items()):
            ids = [lst["id"] for lst in combined if lst.get("name", "").strip().lower() == name]
            print(f"      '{name}' appears {n}×  → IDs {ids}")
    else:
        print("   ✅ No duplicate names")

    if clean:
        print(f"   ✅ All {len(combined)} entries are unique — scraping result is correct")
    else:
        print("   ⚠️  Duplicates found — review the discovery views for overlap")
    return clean


def _write_outputs(results):
    """Split results into static / dynamic, write all three CSV/JSON files, check duplicates."""
    dynamic = [lst for lst in results if not _is_static(lst)]
    static  = [lst for lst in results if     _is_static(lst)]
    _write_one(dynamic, DYNAMIC_OUTPUT_JSON, DYNAMIC_OUTPUT_CSV)
    # NOTE: static lists are now owned exclusively by scrape_static_lists.py,
    # which writes the canonical pardot_static_lists.{json,csv}. This scraper no
    # longer writes that file — it only ever saw the dynamic view here, so its
    # "static" split was always empty and clobbered the real data with 0 rows.
    # `static` is still computed below only to build the combined all-lists view.

    # Combined segmentation list — dynamic first (sorted by name), then static
    combined = (
        sorted(dynamic, key=lambda x: x.get("name", "").lower()) +
        sorted(static,  key=lambda x: x.get("name", "").lower())
    )
    rows = [
        [i,
         "Dynamic" if not _is_static(lst) else "Static",
         lst.get("name", ""), lst.get("id", ""),
         lst.get("prospect_count", ""), "",
         _rules_text(lst),
         len(lst.get("usage") or []), _usage_text(lst)]
        for i, lst in enumerate(combined, 1)
    ]
    utils.save_csv(rows, CSV_ALL_HEADERS, ALL_OUTPUT_CSV)

    _check_duplicates(combined)

# ── Validate config ────────────────────────────────────────────────────────────

def validate_config():
    missing = []
    for name, val in [
        ("SF_USERNAME", SF_USERNAME),
        ("PARDOT_BUSINESS_UNIT_ID", PARDOT_BU_ID),
    ]:
        if not val or "your-" in val or val.startswith("your_"):
            missing.append(name)
    if missing:
        print(f"❌ Missing or placeholder values in .env: {', '.join(missing)}")
        print("   Copy .env.template to .env and fill in your credentials.")
        sys.exit(1)

# ── Part A: Get access token via JWT bearer flow ───────────────────────────────
# Requires SF_CLIENT_ID + SF_PRIVATE_KEY_FILE (or SF_PRIVATE_KEY) in .env.
# Falls back to browser-only mode if credentials are absent.

def get_access_token():
    return utils.get_sf_access_token()

# ── Part A: Fetch dynamic list metadata from Pardot API v5 ────────────────────

def fetch_dynamic_lists_api(access_token):
    print("📋 Fetching dynamic list index from Pardot API v5...")
    lists = []
    next_page_token = None
    base_url = f"{pardot_api.PARDOT_API_BASE}/objects/lists"

    headers = {
        "Authorization":              f"Bearer {access_token}",
        "Pardot-Business-Unit-Id":    PARDOT_BU_ID,
        "Content-Type":               "application/json",
    }

    while True:
        params = {"fields": "id,name,isDynamic,description", "pageSize": 200}
        if next_page_token:
            params["nextPageToken"] = next_page_token

        resp = requests.get(base_url, headers=headers, params=params)
        if resp.status_code != 200:
            print(f"❌ API error ({resp.status_code}): {resp.text[:300]}")
            return []

        data = resp.json()
        for item in data.get("values", []):
            if item.get("isDynamic"):
                lists.append({
                    "id":          item["id"],
                    "name":        item.get("name", f"List {item['id']}"),
                    "description": item.get("description", ""),
                    "rules":       [],
                })

        next_page_token = data.get("nextPageToken")
        if not next_page_token:
            break

    print(f"   ✅ Found {len(lists)} dynamic list(s) via API")
    return lists

# ── Part B: Log into Pardot via Salesforce SSO ────────────────────────────────

def login_to_pardot(page):
    utils.login(page)


def _click_salesforce_login_if_prompted(page):
    """Click 'Log in with Salesforce' if Pardot shows its login chooser page."""
    for selector in [
        "a:has-text('Log in with Salesforce')",
        "button:has-text('Log in with Salesforce')",
        "a:has-text('Login with Salesforce')",
        "button:has-text('Login with Salesforce')",
        "[data-id='sfdc'] a",
        "a[href*='salesforce'][href*='login']",
    ]:
        try:
            el = page.query_selector(selector)
            if el and el.is_visible():
                print("   🔗 Pardot login prompt detected — clicking 'Log in with Salesforce'...")
                before_url = page.url
                el.click()
                try:
                    page.wait_for_function(
                        f"() => window.location.href !== {repr(before_url)}",
                        timeout=15000,
                    )
                except Exception:
                    pass
                page.wait_for_timeout(3000)
                return
        except Exception:
            continue

# ── Part B: Scrape filter rules from a single list's edit page ─────────────────

def scrape_list_rules(page, list_id, list_name):
    """Navigate to the list read page, click the Details tab, extract rules."""

    url = f"{utils.PARDOT_HOME}/list/read/id/{list_id}"
    try:
        page.goto(url, wait_until="networkidle", timeout=15000)
    except Exception:
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=15000)
        except Exception:
            pass
    try:
        page.wait_for_selector("a[href='#details'], .list-detail, #content", timeout=8000)
    except Exception:
        pass

    # Click the Details tab (href="#details" — confirmed from page inspection)
    try:
        page.click("a[href='#details']")
        try:
            page.wait_for_selector("#details, .dynamic-list-rules", timeout=5000)
        except Exception:
            page.wait_for_timeout(800)
    except Exception:
        pass

    # Take multiple screenshots while scrolling to capture all rules.
    # Pardot Lightning uses a scrollable container, not window — find it
    # by checking common selectors, fall back to window scroll.
    # Two separate JS strings avoid the single-arg limitation of page.evaluate.
    _find_container = """
        (function() {
            var sel = ['.oneContent', '.appBodyContent', '.slds-template__container', 'main'];
            return sel.map(function(s){ return document.querySelector(s); })
                      .find(function(e){ return e && e.scrollHeight > e.clientHeight + 10; }) || null;
        })()
    """
    _get_state_js = """() => {
        var sel = ['.oneContent', '.appBodyContent', '.slds-template__container', 'main'];
        var el = sel.map(s => document.querySelector(s)).find(e => e && e.scrollHeight > e.clientHeight + 10);
        if (el) return { top: el.scrollTop, height: el.scrollHeight, client: el.clientHeight };
        return { top: window.scrollY, height: document.body.scrollHeight, client: window.innerHeight };
    }"""
    _reset_js = """() => {
        var sel = ['.oneContent', '.appBodyContent', '.slds-template__container', 'main'];
        var el = sel.map(s => document.querySelector(s)).find(e => e && e.scrollHeight > e.clientHeight + 10);
        if (el) { el.scrollTop = 0; } else { window.scrollTo(0, 0); }
    }"""

    viewport_h = page.viewport_size["height"] if page.viewport_size else 900
    scroll_step = int(viewport_h * 0.85)  # 15% overlap between shots
    MAX_SHOTS = 3  # safety cap

    page.evaluate(_reset_js)
    page.wait_for_timeout(300)

    shot_index = 1
    while shot_index <= MAX_SHOTS:
        page.screenshot(path=f"{SCREENSHOTS_DIR}/list_{list_id}_{shot_index}.png")
        state = page.evaluate(_get_state_js)
        if state["top"] + state["client"] >= state["height"]:
            break
        # Scroll down by one step inside the right container
        scroll_down_js = f"""() => {{
            var sel = ['.oneContent', '.appBodyContent', '.slds-template__container', 'main'];
            var el = sel.map(s => document.querySelector(s)).find(e => e && e.scrollHeight > e.clientHeight + 10);
            if (el) {{ el.scrollTop += {scroll_step}; }} else {{ window.scrollBy(0, {scroll_step}); }}
        }}"""
        page.evaluate(scroll_down_js)
        page.wait_for_timeout(400)
        shot_index += 1

    # Reset scroll for text extraction
    page.evaluate(_reset_js)

    # UI language guard — check ONCE per run, on the first list visited, and
    # let a failure propagate all the way up (NOT caught by the try/except
    # below, and callers must not swallow it as a per-item scrape failure).
    # See utils.assert_english_ui for why: matching hardcoded English text
    # against a non-English UI silently produces empty/misclassified data
    # instead of an error.
    global _LANGUAGE_VERIFIED
    if not _LANGUAGE_VERIFIED:
        precheck_text = page.evaluate("""() => document.body.innerText""") or ""
        precheck_lines = [l.strip() for l in precheck_text.splitlines() if l.strip()]
        utils.assert_english_ui(precheck_lines, f"Pardot list detail page (id {list_id})")
        _LANGUAGE_VERIFIED = True

    rules = []
    prospect_count = ""
    try:
        full_text = page.evaluate("""() => document.body.innerText""")
        # Do NOT call truncate_at_prospects here — it would cut at the
        # "Prospects" tab label before the rules section is reached.
        lines = [l.strip() for l in full_text.splitlines() if l.strip()]

        # Extract Total Prospects from the stat card at the top of the page.
        # The card renders as two consecutive lines: the number then the label.
        # Tenant UI language varies (confirmed: German "Potenzielle Kunden
        # insgesamt" on globex) — match known label variants, not just English.
        _TOTAL_PROSPECTS_LABELS = (
            "total prospects",
            "potenzielle kunden insgesamt",
        )
        for i, line in enumerate(lines):
            if line.lower() in _TOTAL_PROSPECTS_LABELS and i > 0:
                raw = lines[i - 1].replace(".", "").replace(",", "").strip()
                if raw.isdigit():
                    prospect_count = raw
                break

        # The rules section heading — English and German (confirmed: globex
        # renders "Regeln für dynamische Listen"). Add more locales here as
        # they turn up rather than assuming English-only.
        rule_section_headers = [
            "dynamic list rules",
            "regeln für dynamische listen",
            "regeln für dynamische liste",
        ]

        rule_start = None
        for i, line in enumerate(lines):
            if any(h in line.lower() for h in rule_section_headers):
                rule_start = i + 1  # start AFTER the heading line
                break

        if rule_start is not None:
            # Collect all lines after the rules heading.
            # Stop at the next major section (tab labels are before the
            # heading so they won't trigger these stops).
            stop_after_rules = [
                "subscribers",
                "list emails",
                "usage",
                "listen-e-mails",
                "nutzung",
            ]
            trimmed = []
            for line in lines[rule_start:]:
                if any(kw in line.lower() for kw in stop_after_rules):
                    break
                trimmed.append(line)
            rules = [{"raw_page_text": "\n".join(trimmed)}]
        else:
            # Fallback: "Dynamic List Rules" heading not found — return raw text
            # from after the tab bar to avoid dumping navigation noise.
            rules = [{"raw_page_text": "Static list — no filter rules"}]

    except Exception:
        pass

    # Usage tab — read AFTER the rules extraction above, not before: clicking
    # a[href='#usage'] switches the active tab panel, which would hide the
    # #details panel's content (rules) from document.body.innerText if read
    # afterward. a[href='#usage'] is a URL fragment, not display text, so
    # this click itself works regardless of tenant UI language (unlike the
    # rules-heading matching above, which needs the bilingual keyword list).
    usage = utils.extract_usage_tab(page)

    return rules, prospect_count, usage


# ── Part B: Browser-only fallback list discovery ───────────────────────────────

# JS that reads name, ID and Dynamic column value from the current list page.
# Locates the "Dynamic" column by header text so it works regardless of column order.
_DISCOVER_JS = """() => {
    const headerRow = document.querySelector('table thead tr') ||
                      document.querySelector('table tr');
    const headers = headerRow
        ? Array.from(headerRow.querySelectorAll('th, td'))
              .map(h => h.innerText.trim().toLowerCase())
        : [];
    const dynCol = headers.findIndex(h => h === 'dynamic' || h.includes('dynamic'));

    return Array.from(document.querySelectorAll('table tbody tr, table tr')).flatMap(row => {
        const link = row.querySelector(
            'a[href*="/list/read/id/"], a[href*="/list/edit/id/"]'
        );
        if (!link) return [];
        const href = link.getAttribute('href') || '';
        const m = href.match(/\\/list\\/(?:read|edit)\\/id\\/(\\d+)/);
        if (!m) return [];
        const cells = Array.from(row.querySelectorAll('td'));
        const dynVal = dynCol >= 0 && cells[dynCol]
            ? cells[dynCol].innerText.trim().toLowerCase() : '';
        const name = link.innerText.trim() || ('List ' + m[1]);
        if (!name || name.startsWith('\\n')) return [];
        return [{ id: m[1], name, isDynamic: dynVal === 'yes' }];
    });
}"""

_NEXT_SELECTORS = [
    "a:has-text('Next')",
    "a:has-text('›')",
    "a:has-text('»')",
    "[aria-label='Next page']",
    "[aria-label='Next']",
    ".next a",
    "a[rel='next']",
]


def _collect_all_pages(page, label, dynamic_lists, static_lists, seen_ids,
                       force_dynamic=False, dynamic_only=False):
    """
    Walk every pagination page starting from the current page state,
    collecting lists into dynamic_lists / static_lists.

    force_dynamic=True: treat every row as dynamic regardless of column value
        (used for views where every entry is dynamic by definition).
    dynamic_only=True: skip rows where Dynamic=No entirely — do not add them
        to static_lists either (used for the Archived Lists view, where archived
        static lists should not appear in the active static output).
    """
    page_num = 0
    while True:
        page_num += 1
        try:
            items = page.evaluate(_DISCOVER_JS)
        except Exception:
            items = []

        added = 0
        for item in items:
            if item["id"] not in seen_ids:
                is_dyn = force_dynamic or item["isDynamic"]
                if dynamic_only and not is_dyn:
                    continue  # skip archived static lists
                seen_ids.add(item["id"])
                entry = {"id": item["id"], "name": item["name"],
                         "description": "", "rules": []}
                if is_dyn:
                    dynamic_lists.append(entry)
                else:
                    static_lists.append(entry)
                added += 1

        total_so_far = len(dynamic_lists) + len(static_lists)
        print(f"   📄 {label} page {page_num}: {added} new list(s) "
              f"(running total {total_so_far}: "
              f"{len(dynamic_lists)} dynamic, {len(static_lists)} static)")

        next_btn = None
        for sel in _NEXT_SELECTORS:
            try:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    next_btn = btn
                    break
            except Exception:
                continue

        if not next_btn or added == 0:
            break
        try:
            next_btn.click()
            try:
                page.wait_for_load_state("networkidle", timeout=8000)
            except Exception:
                page.wait_for_timeout(1000)
        except Exception:
            break


def discover_lists_via_internal_api(page):
    """
    Primary, instance-independent discovery.

    Calls the Pardot v5 lists API *from within the authenticated browser
    session* and reads the ``isDynamic`` flag directly. This avoids the
    fragile UI heuristic in ``discover_lists_via_browser`` which depends on a
    "Dynamic" column that the modern Lightning Lists table does NOT render
    (every row then defaults to static → 0 dynamic lists).

    Returns (dynamic_lists, static_lists) on success, or (None, None) if the
    in-page API could not be used — in which case the caller falls back to UI
    scraping (no regression vs. previous behaviour).
    """
    print("🔌 Discovering lists via in-page Pardot API v5 (isDynamic)...")

    # The relative /api path resolves against the current page origin, so we
    # must be on the org's Pardot host. After SSO the page may sit on a Salesforce
    # Lightning origin — navigate first if needed.
    try:
        if not utils.is_pardot_url(page.url):
            page.goto(utils.PARDOT_HOME + "/list",
                      wait_until="domcontentloaded", timeout=20000)
    except Exception:
        pass

    fetch_js = """async (buId) => {
        const out = [];
        let token = null;
        for (let i = 0; i < 50; i++) {
            let url = '/api/v5/objects/lists'
                + '?fields=id,name,isDynamic,description&pageSize=200';
            if (token) url += '&nextPageToken=' + encodeURIComponent(token);
            const headers = {'Content-Type': 'application/json'};
            if (buId) headers['Pardot-Business-Unit-Id'] = buId;
            let r;
            try { r = await fetch(url, {headers}); }
            catch (e) { return {error: String(e)}; }
            if (!r.ok) return {error: 'HTTP ' + r.status};
            const data = await r.json();
            (data.values || []).forEach(v => out.push(v));
            token = data.nextPageToken;
            if (!token) break;
        }
        return {values: out};
    }"""

    try:
        resp = page.evaluate(fetch_js, PARDOT_BU_ID or None)
    except Exception as e:
        print(f"   ⚠️  in-page API call raised: {e} — falling back to UI scraping")
        return None, None

    if not resp or resp.get("error"):
        err = (resp or {}).get("error", "no response")
        print(f"   ⚠️  in-page API not usable ({err}) — falling back to UI scraping")
        return None, None

    values = resp.get("values") or []
    if not values:
        print("   ⚠️  in-page API returned 0 lists — falling back to UI scraping")
        return None, None

    dynamic_lists, static_lists = [], []
    for item in values:
        entry = {
            "id":          str(item["id"]),
            "name":        item.get("name", f"List {item['id']}"),
            "description": item.get("description", ""),
            "rules":       [],
        }
        if item.get("isDynamic"):
            dynamic_lists.append(entry)
        else:
            static_lists.append(entry)

    # Sanity check: a tenant with dozens/hundreds of lists and ZERO dynamic
    # ones is implausible — it means the `isDynamic` field came back falsy
    # for every row (missing/renamed field, permission gap, API quirk for
    # this tenant, etc.), not that the org genuinely has no dynamic lists.
    # Silently trusting that would mislabel every dynamic list as static
    # (this happened for real — see DEVLOG). Treat it as unreliable and
    # force the browser-based fallback, which reads the actual "Dynamic"
    # column/views in the UI instead of this flag.
    if values and not dynamic_lists:
        print(f"   ⚠️  API returned {len(values)} list(s) but 0 marked dynamic — "
              f"isDynamic flag looks unreliable for this tenant, falling back to UI scraping")
        return None, None

    print(f"   ✅ API: {len(values)} list(s) — "
          f"{len(dynamic_lists)} dynamic, {len(static_lists)} static")
    return dynamic_lists, static_lists


def discover_lists_via_browser(page):
    """
    Navigate to the Pardot lists page and collect all lists.

    Reads the Dynamic column from the "All Current Lists" view, then also
    reads the "Inactive Dynamic Lists" view (a separate filter option in the
    Pardot list page dropdown) to pick up dynamic lists that have been
    deactivated — those are absent from the default view but still relevant.

    Returns (dynamic_lists, static_lists).
    """
    print("🌐 Discovering lists via browser (no API credentials)...")
    dynamic_lists = []
    static_lists  = []
    seen_ids      = set()

    candidate_urls = [
        utils.PARDOT_HOME + "/list",
        utils.PARDOT_HOME + "/prospect-list",
        utils.PARDOT_HOME + "/lists",
    ]

    for list_url in candidate_urls:
        print(f"   Trying {list_url}...")
        try:
            page.goto(list_url, wait_until="domcontentloaded", timeout=20000)
        except Exception:
            continue
        try:
            page.wait_for_load_state("networkidle", timeout=10000)
        except Exception:
            pass
        try:
            page.wait_for_selector("table, select", timeout=8000)
        except Exception:
            pass
        page.screenshot(path=f"{SCREENSHOTS_DIR}/list_discovery.png")

        # Find the SPECIFIC <select> that controls the "Anzeigen"/"Show" view
        # filter — scoped per-element, not aggregated across every <select>
        # on the page. BUG (found 2026-07-02, globex): the old code read
        # `document.querySelectorAll('select option')` across ALL selects on
        # the page combined, then called `page.select_option("select", value)`
        # which always targets the FIRST <select> in the DOM. On a Salesforce
        # Lightning page (globex's Lists page now lives under Marketing >
        # Segmentierung, not classic pi.pardot.com chrome) there can easily be
        # other <select> elements earlier in the DOM (language pickers, page
        # size, etc.). If the matched option's value belongs to a DIFFERENT
        # select than the first one, `select_option` raises, is swallowed by
        # the bare `except`, and the page silently stays on whatever view was
        # already loaded — confirmed via screenshot: the page was stuck on
        # the browser's session-persisted "Inaktive dynamische Listen" view,
        # and that view's ~17 entries got scraped and mislabelled as the
        # "All Current Lists" pass (see also the classification fix in
        # `_is_static`).
        #
        # Fix: identify the correct <select> by its own option contents
        # (must offer at least 2 of the 3 known views), operate on that
        # exact element handle, and verify the switch actually happened by
        # re-reading the selected value afterwards instead of trusting that
        # `select_option()` not raising means it worked.
        _VIEW_KEYWORDS = {
            "dynamic":  ("dynamic", "dynamisch"),
            "all":      ("all", "alle"),
            "inactive": ("inactive", "inaktiv"),
            "archived": ("archived", "archiv"),
        }

        def _find_view_select():
            try:
                selects = page.query_selector_all("select")
            except Exception:
                return None, []
            best, best_opts, best_score = None, [], 0
            for sel in selects:
                try:
                    opts = sel.eval_on_selector_all(
                        "option",
                        "els => els.map(o => ({value:o.value, text:o.innerText.trim()}))",
                    )
                except Exception:
                    continue
                score = sum(
                    1 for kws in _VIEW_KEYWORDS.values()
                    if any(any(k in (o["text"] or "").lower() for k in kws) for o in opts)
                )
                if score > best_score:
                    best, best_opts, best_score = sel, opts, score
            if best_score < 2:
                return None, []  # doesn't look like the view-filter select
            return best, best_opts

        view_select, opts = _find_view_select()
        if view_select is None:
            print("   ⚠️  Could not identify the view-filter <select> — "
                  "scraping whatever view is currently loaded (may be incomplete "
                  "if the browser persisted a filtered view from a previous session)")

        def _current_selected_text():
            try:
                return (view_select.eval_on_selector(
                    "option:checked", "o => o.innerText.trim()"
                ) or "").lower()
            except Exception:
                return ""

        def _switch_view(view_key):
            """Select the view matching any keyword for view_key. Returns label or None.
            Verifies the switch by re-reading the selected option afterwards —
            a non-raising select_option() call is NOT sufficient proof it worked."""
            if view_select is None:
                return None
            keywords = _VIEW_KEYWORDS[view_key]
            match = next(
                (o for o in opts
                 if any(k in o["value"].lower() or k in o["text"].lower() for k in keywords)),
                None,
            )
            if not match:
                return None
            try:
                refreshed = utils.select_view_and_wait(page, view_select, match["value"])
            except Exception as e:
                print(f"   ⚠️  select_option('{match['text']}') raised: {e}")
                return None
            if not refreshed:
                print(f"   ⚠️  Switched to '{match['text']}' but the table never re-rendered — "
                      f"not trusting this pass")
                return None
            selected_now = _current_selected_text()
            if not any(k in selected_now for k in keywords):
                print(f"   ⚠️  Switched to '{match['text']}' but page shows "
                      f"'{selected_now}' after switching — not trusting this pass")
                return None
            return match["text"]

        # ── Pass 1: "Dynamic Lists" ──────────────────────────────────────────
        # Efficiently fetch only active dynamic lists by name.
        label = _switch_view("dynamic")
        if label:
            _collect_all_pages(page, label, dynamic_lists, static_lists,
                               seen_ids, force_dynamic=True)
        else:
            print("   ⚠️  'Dynamic Lists' view not found — falling back to 'All Current Lists'")
            # Fallback: "All" view if "Dynamic" doesn't exist
            label = _switch_view("all")
            if not label:
                print("   ⚠️  Could not verify switch to 'All Current Lists' — "
                      "results from this pass may reflect a stale filtered view, "
                      "not the full list. Re-run with a headed browser to inspect.")
                label = "All Current Lists (UNVERIFIED)"
            _collect_all_pages(page, label, dynamic_lists, static_lists, seen_ids)

        if not dynamic_lists and not static_lists:
            continue  # try next candidate URL

        # ── Pass 2: "Inactive Dynamic Lists" ──────────────────────────────────
        # Lists deactivated by a user; absent from active dynamic lists but still
        # have rules. Every entry in this view is dynamic by definition.
        label = _switch_view("inactive")
        if label:
            _collect_all_pages(page, label, dynamic_lists, static_lists,
                               seen_ids, force_dynamic=True)
        else:
            print("   ⚠️  'Inactive Dynamic Lists' view not found — skipping")

        # ── Pass 3: "Archived Lists" ───────────────────────────────────────────
        # Archived lists don't appear in active/inactive views. The view contains
        # both static and dynamic archived entries — only the dynamic ones are
        # relevant; archived static lists must not pollute the static output.
        label = _switch_view("archived")
        if label:
            _collect_all_pages(page, label, dynamic_lists, static_lists,
                               seen_ids, dynamic_only=True)
        else:
            print("   ⚠️  'Archived Lists' view not found — skipping")

        break  # found lists — don't try other URLs

    # Last resort: Pardot internal API (no Dynamic column available in the UI)
    if not dynamic_lists and not static_lists:
        print("   Trying Pardot internal list endpoint...")
        try:
            resp = page.evaluate("""async () => {
                const r = await fetch(
                    '/api/v5/objects/lists?fields=id,name,isDynamic&pageSize=200',
                    { headers: {'Content-Type': 'application/json'} }
                );
                return r.ok ? await r.json() : null;
            }""")
            if resp and resp.get("values"):
                for item in resp["values"]:
                    entry = {
                        "id":          str(item["id"]),
                        "name":        item.get("name", f"List {item['id']}"),
                        "description": item.get("description", ""),
                        "rules":       [],
                    }
                    if item.get("isDynamic"):
                        dynamic_lists.append(entry)
                    else:
                        static_lists.append(entry)
        except Exception:
            pass

    total = len(dynamic_lists) + len(static_lists)
    print(f"   {'✅' if total else '⚠️ '} Found {total} list(s): "
          f"{len(dynamic_lists)} dynamic, {len(static_lists)} static")
    if not total:
        print(f"   Debug screenshots saved to {SCREENSHOTS_DIR}/")
    return dynamic_lists, static_lists

# ── Plain-text explanation builder ────────────────────────────────────────────

def explain_rules(rules):
    if not rules:
        return "No rules found — check screenshots folder for the page capture."

    if "raw_page_text" in rules[0]:
        return (
            "📋 Rules (extracted from page):\n\n"
            + rules[0]["raw_page_text"]
            + "\n\n💡 Paste this into Copilot Chat: "
            + "'Explain these Pardot dynamic list rules in simple terms a marketer can understand'"
        )

    connector = rules[0].get("connector", "AND")
    parts = []
    for i, r in enumerate(rules):
        prefix = f" {connector} " if i > 0 else ""
        parts.append(f'{prefix}[{r.get("field","?")}] {r.get("operator","?")} "{r.get("value","?")}"')

    return "Prospects included when: " + "".join(parts)

# ── Run (browser-agnostic entry point) ───────────────────────────────────────

def _detail_says_static(rules):
    """Ground truth static/dynamic straight from the detail page: a list is
    static iff scrape_list_rules() found no rules section (it then records
    _STATIC_MARKER) or returned nothing; a list with a real rules section is
    dynamic. This is the authoritative classifier — see run(). It relies on the
    bilingual rules-heading keywords in scrape_list_rules(); add locales there
    if a tenant's UI language isn't matched."""
    if not rules:
        return True
    if isinstance(rules, list) and isinstance(rules[0], dict) and "raw_page_text" in rules[0]:
        return rules[0]["raw_page_text"].strip() == _STATIC_MARKER
    return False


def fetch_all_lists_index(access_token):
    """Fetch the FULL list index (id, name, description) via Pardot v5, plus the
    isDynamic flag captured as a LOW-TRUST hint only. Classification happens from
    each list's detail page (run()), because isDynamic is unreliable on some
    tenants (Acme returns isDynamic=true for static lists — DEVLOG 2026-09-17).
    Returns (candidates, api_flags); api_flags maps str(id) -> bool|None."""
    print("📋 Fetching full list index from Pardot API v5...")
    candidates, api_flags = [], {}
    next_page_token = None
    base_url = f"{pardot_api.PARDOT_API_BASE}/objects/lists"
    headers = {
        "Authorization":           f"Bearer {access_token}",
        "Pardot-Business-Unit-Id": PARDOT_BU_ID,
        "Content-Type":            "application/json",
    }
    while True:
        params = {"fields": "id,name,isDynamic,description", "pageSize": 200}
        if next_page_token:
            params["nextPageToken"] = next_page_token
        resp = requests.get(base_url, headers=headers, params=params)
        if resp.status_code != 200:
            print(f"❌ API error ({resp.status_code}): {resp.text[:300]}")
            return [], {}
        data = resp.json()
        for item in data.get("values", []):
            _id = str(item["id"])
            candidates.append({"id": _id, "name": item.get("name", f"List {_id}"),
                               "description": item.get("description", ""), "rules": []})
            api_flags[_id] = item.get("isDynamic")
        next_page_token = data.get("nextPageToken")
        if not next_page_token:
            break
    print(f"   ✅ Indexed {len(candidates)} list(s) via API")
    return candidates, api_flags


def _discover_all_candidates(page, access_token):
    """Return (candidates, api_flags) covering ALL lists. Prefers the v5 API
    index; falls back to the in-page API / UI discovery. api_flags carries the
    (unreliable) isDynamic hint for the locale-miss safety net only."""
    if access_token:
        cands, flags = fetch_all_lists_index(access_token)
        if cands:
            return cands, flags
    dyn, sta = discover_lists_via_internal_api(page)
    if dyn is None:
        dyn, sta = discover_lists_via_browser(page)
    dyn = dyn or []
    sta = sta or []
    cands, flags = [], {}
    for lst in dyn:
        _id = str(lst["id"])
        cands.append({"id": _id, "name": lst.get("name", f"List {_id}"),
                      "description": lst.get("description", ""), "rules": []})
        flags[_id] = True
    for lst in sta:
        _id = str(lst["id"])
        cands.append({"id": _id, "name": lst.get("name", f"List {_id}"),
                      "description": lst.get("description", ""), "rules": []})
        flags[_id] = False
    return cands, flags


def run(page, access_token=None):
    """Discover, scrape, and export — no browser lifecycle management.

    Outputs are always written via the finally block, even on partial runs
    or empty discovery, so that screenshot effort is never lost.
    """
    global DYNAMIC_OUTPUT_JSON, DYNAMIC_OUTPUT_CSV, STATIC_OUTPUT_JSON, \
           STATIC_OUTPUT_CSV, ALL_OUTPUT_CSV, OUTPUT_FILE, SCREENSHOTS_DIR
    DYNAMIC_OUTPUT_JSON = utils.output_path("pardot_dynamic_lists.json")
    DYNAMIC_OUTPUT_CSV  = utils.output_path("pardot_dynamic_lists.csv")
    STATIC_OUTPUT_JSON  = utils.output_path("pardot_static_lists.json")
    STATIC_OUTPUT_CSV   = utils.output_path("pardot_static_lists.csv")
    ALL_OUTPUT_CSV      = utils.output_path("pardot_all_lists.csv")
    OUTPUT_FILE         = DYNAMIC_OUTPUT_JSON
    SCREENSHOTS_DIR     = utils.output_path("screenshots", "dynamic_lists")
    utils.reset_screenshots(SCREENSHOTS_DIR)
    results = []
    try:
        candidates, api_flags = _discover_all_candidates(page, access_token)
        if not candidates:
            print("❌ No lists found. Check your credentials and Pardot access.")
            return

        # ── Classify by the DETAIL PAGE, not the v5 isDynamic flag ──────────
        # A list is dynamic iff its detail page shows a rules section; otherwise
        # scrape_list_rules() records _STATIC_MARKER. The v5 isDynamic flag is
        # unreliable on some tenants (Acme returns true for static lists —
        # DEVLOG 2026-09-17), so it is only a locale-miss safety net below,
        # never the primary signal.
        print(f"\n🔍 Classifying {len(candidates)} list(s) by detail-page rules...")
        for i, lst in enumerate(candidates, 1):
            print(f"   [{i}/{len(candidates)}] {lst['name']} (id: {lst['id']})")
            try:
                rules, prospect_count, usage = scrape_list_rules(page, lst["id"], lst["name"])
            except utils.UnexpectedUILanguageError as e:
                print(str(e))
                sys.exit(1)
            except Exception as e:
                rules, prospect_count, usage = [], "", []
                print(f"     ⚠️  scrape failed: {e}")
            is_static = _detail_says_static(rules)
            lst["rules"]          = rules if not is_static else [{"raw_page_text": _STATIC_MARKER}]
            lst["prospect_count"] = prospect_count
            lst["usage"]          = usage
            lst["is_dynamic"]     = not is_static
            lst["explanation"]    = (f"📋 Rules (extracted from page):\n\n{_STATIC_MARKER}"
                                     if is_static else explain_rules(rules))
            results.append(lst)
            time.sleep(0.5)

        dyn_count = sum(1 for lst in results if lst.get("is_dynamic"))

        # ── Locale-miss safety net ──────────────────────────────────────────
        # If EVERY list came back static, the rules-heading keywords probably
        # don't match this tenant's UI language (mirror of the 2026-07-02
        # globex bug). Rather than silently emit 0 dynamic lists, fall back to
        # the v5 isDynamic hint where we have it.
        if results and dyn_count == 0 and any(v is not None for v in api_flags.values()):
            print("   ⚠️  Detail-page classification found 0 dynamic lists — the rules "
                  "heading likely doesn't match this tenant's UI language. Falling back "
                  "to the v5 isDynamic flag (add the heading keyword to scrape_list_rules "
                  "to fix this properly).")
            for lst in results:
                flag = api_flags.get(str(lst["id"]))
                if flag is not None:
                    lst["is_dynamic"] = bool(flag)
            dyn_count = sum(1 for lst in results if lst.get("is_dynamic"))

        # Cross-check: log where the v5 flag disagrees with the detail page.
        disagree = [lst for lst in results
                    if api_flags.get(str(lst["id"])) is not None
                    and bool(api_flags[str(lst["id"])]) != bool(lst.get("is_dynamic"))]
        if disagree:
            print(f"   ℹ️  {len(disagree)} list(s) where v5 isDynamic disagrees with the "
                  f"detail page (trusting the detail page):")
            for lst in disagree[:20]:
                print(f"        - {lst['name']} (id {lst['id']}): "
                      f"isDynamic={api_flags.get(str(lst['id']))} → "
                      f"{'dynamic' if lst['is_dynamic'] else 'static'}")

        print(f"\n✅ Done! {dyn_count} dynamic / {len(results) - dyn_count} static "
              f"(of {len(results)}) — dynamic written to {DYNAMIC_OUTPUT_JSON} / {DYNAMIC_OUTPUT_CSV}")
        print(f"         static lists are scraped separately by scrape_static_lists.py "
              f"→ pardot_static_lists.{{json,csv}}")
    finally:
        _write_outputs(results)

# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    utils.load_org_config()
    validate_config()

    print("\n🚀 Pardot Dynamic List Rule Scraper")
    print("=" * 45)

    access_token, _ = get_access_token()

    with sync_playwright() as pw:
        context = utils.launch_context(pw)
        page    = context.new_page()
        page.set_viewport_size({"width": 1600, "height": 900})
        try:
            login_to_pardot(page)
            run(page, access_token)
        finally:
            context.close()

if __name__ == "__main__":
    main()
