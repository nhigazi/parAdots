"""
Org Selection Test Suite
=========================
load_org_config() must pick the org the user asked for:

- --org NAME / --org=NAME on sys.argv is honoured by every standalone scraper
  (previously ignored → silently fell back to .active-org)
- an explicit org_name argument still wins over sys.argv
- salesforce_api, imported before load_org_config(), follows the org switch
"""

import os
import sys
from pathlib import Path

import pytest

import salesforce_api
import utils

BASE = Path(__file__).parent
ORG = "_orgtest"
_VARS = ("SF_LOGIN_URL", "SF_USERNAME", "PARDOT_HOME", "PARDOT_API_BASE",
         "PARDOT_BUSINESS_UNIT_ID", "CONSENT_BRANDS")


@pytest.fixture
def test_org(monkeypatch):
    cfg = BASE / "configs" / f"{ORG}.env"
    cfg.write_text("SF_LOGIN_URL=https://orgtest.my.salesforce.com/\n"
                   "SF_USERNAME=someone@orgtest\nCONSENT_BRANDS=ABC\n")
    saved_argv = sys.argv[:]
    for var in _VARS:
        monkeypatch.delenv(var, raising=False)
    try:
        yield ORG
    finally:
        sys.argv = saved_argv
        cfg.unlink()
        out = BASE / "output" / ORG
        if out.exists() and not any(out.iterdir()):
            out.rmdir()
        for var in _VARS:
            os.environ.pop(var, None)
        salesforce_api.refresh_config()


def test_org_flag_on_argv_is_used(test_org):
    sys.argv = ["scrape_x.py", "--org", test_org]
    assert utils.load_org_config() == test_org


def test_org_flag_equals_form(test_org):
    sys.argv = ["scrape_x.py", f"--org={test_org}", "--update"]
    assert utils.load_org_config() == test_org


def test_explicit_argument_beats_argv(test_org):
    sys.argv = ["scrape_x.py", "--org", "does-not-exist"]
    assert utils.load_org_config(test_org) == test_org


def test_salesforce_api_follows_org(test_org):
    sys.argv = ["scrape_x.py", "--org", test_org]
    utils.load_org_config()
    assert salesforce_api.SF_LOGIN_URL == "https://orgtest.my.salesforce.com"
    assert salesforce_api.SF_HOST == "orgtest.my.salesforce.com"
    assert salesforce_api.OPTIN_FIELDS == ["Optin_Double_ABC__c"]
