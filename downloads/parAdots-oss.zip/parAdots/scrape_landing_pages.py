"""
Pardot Landing Page Scraper
=============================
Scrapes native Pardot landing pages:
  - Name, campaign, folder, status (published/draft)
  - URL / tracker domain
  - Associated form
  - A/B variant flag

Output:
  pardot_landing_pages.json
  pardot_landing_pages.csv

Usage (standalone):
  python3 scrape_landing_pages.py
"""

import re
import time
from playwright.sync_api import sync_playwright

import utils

OUTPUT_JSON = ""   # set at run() time via utils.output_path()
OUTPUT_CSV  = ""
SCREENSHOTS = ""

LIST_PATH = "/landingPage"


def discover_landing_pages(page):
    print("\n🏠 Discovering landing pages...")
    seen = set()
    items = []

    utils.navigate(page, utils.pardot_url(LIST_PATH))
    utils.scroll_to_bottom(page, steps=5)
    utils.screenshot(page, f"{SCREENSHOTS}/lp_list.png")

    found = utils.collect_ids_from_page(page, r'/landingPage/read/id/(\d+)')
    for item in found:
        if item["id"] not in seen:
            seen.add(item["id"])
            items.append(item)

    # Paginate — Pardot shows 50 items per page
    extra, _ = utils.paginate_collect(page, r'/landingPage/read/id/(\d+)', seen)
    items.extend(extra)

    print(f"   ✅ Found {len(items)} landing page(s)")
    return items


def scrape_landing_page(page, lp_id, lp_name):
    url = f"{utils.PARDOT_HOME}/landingPage/read/id/{lp_id}"
    utils.navigate(page, url)
    utils.screenshot(page, f"{SCREENSHOTS}/lp_{lp_id}.png")

    text = utils.get_page_text(page)
    lines = [l.strip() for l in text.splitlines() if l.strip()]

    def extract_field(keywords):
        for i, line in enumerate(lines):
            if any(kw.lower() in line.lower() for kw in keywords):
                if ":" in line:
                    val = line.split(":", 1)[1].strip()
                    if val:
                        return val[:200]
                if i + 1 < len(lines):
                    return lines[i + 1][:200]
        return ""

    status    = extract_field(["status", "published", "draft"])
    campaign  = extract_field(["campaign", "kampagne"])
    folder    = extract_field(["folder", "ordner"])
    form_name = extract_field(["form", "formular"])
    lp_url    = extract_field(["url", "link", "address"])
    tracker   = extract_field(["tracker domain", "tracking domain"])

    ab_variant = any(kw in lp_name.lower() for kw in ("a/b", "variant", "version a", "version b"))

    return {
        "id":         lp_id,
        "name":       lp_name,
        "status":     status,
        "campaign":   campaign,
        "folder":     folder,
        "form":       form_name,
        "url":        lp_url,
        "tracker":    tracker,
        "ab_variant": ab_variant,
        "raw_text_snippet": "\n".join(lines[:30]),
    }


def run(page):
    global OUTPUT_JSON, OUTPUT_CSV, SCREENSHOTS
    OUTPUT_JSON = utils.output_path("pardot_landing_pages.json")
    OUTPUT_CSV  = utils.output_path("pardot_landing_pages.csv")
    SCREENSHOTS = utils.output_path("screenshots", "landing_pages")
    utils.reset_screenshots(SCREENSHOTS)
    items = discover_landing_pages(page)

    if not items:
        print("⚠️  No landing pages found — Pardot landing pages may not be in use (this is a gap).")
        utils.save_json([], OUTPUT_JSON)
        utils.save_csv([], ["#", "Name", "ID", "Status", "Campaign", "Folder",
                            "Form", "URL", "Tracker Domain", "A/B Variant"], OUTPUT_CSV)
        return

    print(f"\n🔍 Scraping {len(items)} landing page(s)...")
    results = []
    for i, item in enumerate(items, 1):
        print(f"   [{i}/{len(items)}] {item['name']} (id: {item['id']})")
        data = scrape_landing_page(page, item["id"], item["name"])
        results.append(data)
        time.sleep(0.8)

    utils.save_json(results, OUTPUT_JSON)

    rows = [
        [i + 1, r["name"], r["id"], r["status"], r["campaign"],
         r["folder"], r["form"], r["url"], r["tracker"], "Yes" if r["ab_variant"] else "No"]
        for i, r in enumerate(results)
    ]
    utils.save_csv(
        rows,
        ["#", "Name", "ID", "Status", "Campaign", "Folder",
         "Form", "URL", "Tracker Domain", "A/B Variant"],
        OUTPUT_CSV,
    )
    print(f"\n✅ Landing pages scrape complete — {len(results)} page(s).")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    print("\n🚀 Pardot Landing Page Scraper")
    print("=" * 45)

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
