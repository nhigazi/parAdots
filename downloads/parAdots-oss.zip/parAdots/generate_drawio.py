#!/usr/bin/env python3
"""
Engagement Studio → draw.io generator  (v3)
─────────────────────────────────────────────
Shapes
  ▲  Triangle START   – green,  entry + suppression lists
  ●  Ellipse  END     – red,    one per branch termination
  ◇  Diamond  DECISION– orange, YES (right) / NO (left)  with timeout
  □  Rounded  ACTION  – blue
  ⏱  Delay    TRIGGER – yellow  (designation TRIGGER, not in current data)

Layout
  · YES branches grow to the RIGHT, NO to the LEFT
  · Each DECISION's YES+NO subtree is wrapped in a collapsible swimlane
    container so the user can click [−] to fold the branches
  · Annotations ([F] / ✉ / ☰) are placed to the RIGHT of each shape,
    inside its container column, so they never overlap adjacent shapes
  · Two-pass: positions computed first, then XML generated with containers

Run:  python3 generate_drawio.py
Output: output/drawio/ES_<id>_<slug>.drawio   (one file per program)
"""

import json, html, os, re
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple

# ── Layout constants ───────────────────────────────────────────────────────────
COL_W    = 320    # horizontal space per leaf column
ROW_H    = 70     # gap between node BOTTOM and next node TOP
NW, NH   = 160, 50   # action node
DW, DH   = 180, 90   # decision diamond
EW, EH   = 120, 50   # end ellipse
TW, TH   = 130, 70   # start triangle
ANNO_GAP = 12         # gap from shape right edge to annotation
ANNO_W   = 190        # annotation width
CONT_PAD = 18         # padding inside collapsible container
CONT_HDR = 22         # container header strip height
MARGIN_X = 60         # left margin for the whole diagram

# ── draw.io cell styles ────────────────────────────────────────────────────────
S_START  = ("triangle;whiteSpace=wrap;html=1;direction=south;"
            "fillColor=#d5e8d4;strokeColor=#82b366;fontStyle=1;fontSize=10;")
S_END    = ("ellipse;whiteSpace=wrap;html=1;"
            "fillColor=#f8cecc;strokeColor=#b85450;fontStyle=1;fontSize=10;")
S_DEC    = ("rhombus;whiteSpace=wrap;html=1;"
            "fillColor=#ffe6cc;strokeColor=#d79b00;fontStyle=1;fontSize=10;")
S_ACT    = ("rounded=1;whiteSpace=wrap;html=1;"
            "fillColor=#dae8fc;strokeColor=#6c8ebf;fontSize=10;")
S_TRIG   = ("shape=mxgraph.flowchart.delay;whiteSpace=wrap;html=1;"
            "fillColor=#fff2cc;strokeColor=#d6b656;fontSize=10;")
S_ANNO   = ("text;html=1;align=left;verticalAlign=top;"
            "resizable=0;points=[];strokeColor=none;fillColor=none;"
            "fontSize=9;fontColor=#555555;")
S_EDGE   = "edgeStyle=orthogonalEdgeStyle;html=1;fontSize=9;exitX=0.5;exitY=1;exitDx=0;exitDy=0;"
S_YES    = ("edgeStyle=orthogonalEdgeStyle;html=1;fontSize=9;"
            "strokeColor=#82b366;fontColor=#82b366;fontStyle=1;")
S_NO     = ("edgeStyle=orthogonalEdgeStyle;html=1;fontSize=9;"
            "strokeColor=#b85450;fontColor=#b85450;fontStyle=1;")

def S_CONT(hdr_clr, txt_clr):
    return (f"swimlane;startSize={CONT_HDR};fillColor=none;"
            f"strokeColor={hdr_clr};dashed=0;fontSize=8;fontStyle=1;"
            f"fontColor={txt_clr};strokeWidth=1;"
            f"collapsible=1;foldable=1;")

# ── Helpers ────────────────────────────────────────────────────────────────────

def esc(t):
    return html.escape(str(t or ""), quote=True)

def slug(s):
    s = re.sub(r"[^\w\s-]", "", s).strip()
    return re.sub(r"\s+", "_", s)

def child_path(parent, direction):
    return direction if not parent else f"{parent} → {direction}"

def timeout_str(sec):
    if not sec:  return ""
    h = int(sec) // 3600
    if h >= 24:  return f"⏱ {h//24}d"
    return f"⏱ {h}h"

def shape_dims(des):
    if des == "DECISION": return DW, DH
    if des == "TRIGGER":  return NW + 20, NH + 10
    if des == "END":      return EW, EH
    return NW, NH

def shape_style(des):
    return {
        "DECISION": S_DEC,
        "TRIGGER":  S_TRIG,
        "END":      S_END,
    }.get(des, S_ACT)

def step_label(step):
    """Human-readable label for the shape body."""
    des  = step["designation"]
    wait = timeout_str(step.get("timeout", 0))
    rules = step.get("rules", [])

    if des == "DECISION":
        if rules:
            r = rules[0]
            name = (r.get("object_name") or "").strip()
            op   = r.get("operator", "")
            val  = r.get("value", "")
            base = name or step.get("label", "Rule")
            cond = f"{base} {op} {val}".strip() if op else base
            return (cond + ("\n" + wait if wait else "")).strip()
        return (step.get("label", "Decision") + ("\n" + wait if wait else "")).strip()

    if des == "END":
        return ("END" + ("\n" + wait if wait else "")).strip()

    if des == "TRIGGER":
        return (step.get("label", "Trigger") + ("\n" + wait if wait else "")).strip()

    return step.get("label", "Action")

def annotation_lines(step):
    """Lines for the floating label beside the shape."""
    lines = []
    for r in step.get("rules", []):
        n  = (r.get("object_name") or "").strip()
        op = r.get("operator", "")
        val = r.get("value", "")
        if n:
            lines.append(f"[F] {n}" + (f" {op} {val}" if op and val else ""))
    for a in step.get("actions", []):
        n  = (a.get("object_name") or "").strip()
        t  = a.get("object_type", "")
        pfx = {"email_template": "✉", "listx": "☰",
               "prospect_field_custom": "[F]",
               "dynamic_list": "☰", "crm_campaign_status": "📋"}.get(t, "•")
        if n:
            lines.append(f"{pfx} {n}")
    return lines


# ── Tree layout (pure math, no XML) ───────────────────────────────────────────

@dataclass
class PlacedNode:
    step:        dict
    branch_path: str
    abs_cx:      float   # absolute center x
    abs_y:       float   # absolute top y
    w:           float
    h:           float
    anno_lines:  List[str] = field(default_factory=list)

def get_steps_for_path(steps, path):
    return [s for s in steps if s["branch_path"] == path]

def leaf_count(steps, path, _all_paths):
    yp = child_path(path, "YES")
    np = child_path(path, "NO")
    hy = yp in _all_paths
    hn = np in _all_paths
    if not hy and not hn:
        return 1
    w = 0
    if hy: w += leaf_count(steps, yp, _all_paths)
    if hn: w += leaf_count(steps, np, _all_paths)
    return max(1, w)

def place_branch(steps, path, cx, y_start, _all_paths, placed, depth=0):
    """
    Recursively place all nodes for `path`.
    Returns y-coordinate immediately after the last placed item (including children).
    """
    path_steps = get_steps_for_path(steps, path)
    y = y_start

    for step in path_steps:
        des    = step["designation"]
        w, h   = shape_dims(des)
        alines = annotation_lines(step)

        placed.append(PlacedNode(
            step=step, branch_path=path,
            abs_cx=cx, abs_y=y, w=w, h=h,
            anno_lines=alines,
        ))

        y += h + ROW_H

        yp = child_path(path, "YES")
        np = child_path(path, "NO")
        hy = yp in _all_paths
        hn = np in _all_paths

        if des in ("DECISION", "TRIGGER") and (hy or hn):
            yw = leaf_count(steps, yp, _all_paths) if hy else 0
            nw = leaf_count(steps, np, _all_paths) if hn else 0

            if hy and hn:
                yes_cx = cx + nw * COL_W / 2
                no_cx  = cx - yw * COL_W / 2
            elif hy:
                yes_cx = cx;  no_cx = cx
            else:
                no_cx  = cx;  yes_cx = cx

            child_y = y

            ybottom = nbottom = child_y
            if hn:
                nbottom = place_branch(steps, np,  no_cx,  child_y, _all_paths, placed, depth+1)
            if hy:
                ybottom = place_branch(steps, yp, yes_cx, child_y, _all_paths, placed, depth+1)

            y = max(ybottom, nbottom) + ROW_H

    return y


# ── XML builder ────────────────────────────────────────────────────────────────

class Builder:
    def __init__(self):
        self._cells = []
        self._id    = 2
        self.node_cid    = {}  # step node_id → cell id
        self.branch_first = {} # branch_path → first cell id
        self.prev_in_branch = {} # branch_path → last cell id

    def _nid(self):
        i = self._id; self._id += 1; return str(i)

    def node(self, value, style, x, y, w, h, parent="1", tooltip=""):
        cid = self._nid()
        tt  = f' tooltip="{esc(tooltip)}"' if tooltip else ""
        self._cells.append(
            f'<mxCell id="{cid}" value="{esc(value)}" style="{style}"'
            f' vertex="1" parent="{parent}"{tt}>'
            f'<mxGeometry x="{round(x)}" y="{round(y)}" width="{round(w)}" height="{round(h)}"'
            f' as="geometry"/></mxCell>'
        )
        return cid

    def text(self, value, x, y, w=ANNO_W, h=None, parent="1"):
        if h is None:
            h = max(16, value.count("\n") * 16 + 16)
        cid = self._nid()
        self._cells.append(
            f'<mxCell id="{cid}" value="{esc(value)}" style="{S_ANNO}"'
            f' vertex="1" parent="{parent}">'
            f'<mxGeometry x="{round(x)}" y="{round(y)}" width="{round(w)}" height="{round(h)}"'
            f' as="geometry"/></mxCell>'
        )
        return cid

    def container(self, value, style, x, y, w, h, parent="1"):
        cid = self._nid()
        self._cells.append(
            f'<mxCell id="{cid}" value="{esc(value)}" style="{style}"'
            f' vertex="1" parent="{parent}">'
            f'<mxGeometry x="{round(x)}" y="{round(y)}" width="{round(w)}" height="{round(h)}"'
            f' as="geometry"/></mxCell>'
        )
        return cid

    def edge(self, src, tgt, label="", style=None, parent="1"):
        cid = self._nid()
        self._cells.append(
            f'<mxCell id="{cid}" value="{esc(label)}" style="{style or S_EDGE}"'
            f' edge="1" source="{src}" target="{tgt}" parent="{parent}">'
            f'<mxGeometry relative="1" as="geometry"/></mxCell>'
        )
        return cid

    def xml(self, diagram_name):
        inner = "\n        ".join(self._cells)
        return (
            '<mxfile>\n'
            f'  <diagram name="{esc(diagram_name)}">\n'
            '    <mxGraphModel dx="1800" dy="1000" grid="1" gridSize="10"'
            ' guides="1" tooltips="1" connect="1" arrows="1" fold="1"'
            ' page="1" pageScale="1" pageWidth="3307" pageHeight="2339"'
            ' math="0" shadow="0">\n'
            '      <root>\n'
            '        <mxCell id="0"/>\n'
            '        <mxCell id="1" parent="0"/>\n'
            f'        {inner}\n'
            '      </root>\n'
            '    </mxGraphModel>\n'
            '  </diagram>\n'
            '</mxfile>'
        )


# ── Container builder ──────────────────────────────────────────────────────────

def descendants_of(branch_path, all_placed):
    """Return all PlacedNodes in YES/NO sub-trees of a DECISION at branch_path."""
    yp = child_path(branch_path, "YES")
    np = child_path(branch_path, "NO")
    result = []
    for pn in all_placed:
        p = pn.branch_path
        if (p == yp or p.startswith(yp + " → ") or
                p == np or p.startswith(np + " → ")):
            result.append(pn)
    return result

def bbox_of(nodes):
    """Bounding box (x_min, y_min, x_max, y_max) including annotation width."""
    xs, ys = [], []
    for pn in nodes:
        x = pn.abs_cx - pn.w / 2
        xs.extend([x, x + pn.w + (ANNO_GAP + ANNO_W if pn.anno_lines else 0)])
        ys.extend([pn.abs_y, pn.abs_y + pn.h])
    if not xs:
        return 0, 0, 0, 0
    return min(xs), min(ys), max(xs), max(ys)


# ── Main program → drawio ──────────────────────────────────────────────────────

def program_to_drawio(prog):
    steps      = prog["steps"]
    _all_paths = {s["branch_path"] for s in steps}
    b          = Builder()

    # ── Compute layout ──────────────────────────────────────────────────────
    root_leaf_w = leaf_count(steps, "", _all_paths)
    cx_root     = MARGIN_X + root_leaf_w * COL_W / 2

    all_placed: List[PlacedNode] = []
    place_branch(steps, "", cx_root, TH + 60, _all_paths, all_placed)

    # ── Draw START triangle ─────────────────────────────────────────────────
    entry   = prog.get("entry_lists", "") or "(no entry list)"
    suppres = prog.get("suppression_lists", "") or ""
    status  = prog.get("status", "")
    lbl_start = f"START\n☰ {entry}"
    if suppres:
        lbl_start += f"\n⛔ {suppres}"
    start_cid = b.node(lbl_start, S_START,
                       cx_root - TW / 2, 20, TW, TH,
                       tooltip=f"Status: {status}")

    # ── Collect DECISION nodes that have YES/NO children ───────────────────
    branching_decisions = []
    for pn in all_placed:
        if pn.step["designation"] not in ("DECISION", "TRIGGER"):
            continue
        yp = child_path(pn.branch_path, "YES")
        np = child_path(pn.branch_path, "NO")
        if yp in _all_paths or np in _all_paths:
            branching_decisions.append((pn.branch_path, pn))

    # Deepest first so inner containers are created before outer
    branching_decisions.sort(key=lambda x: x[0].count(" → "), reverse=True)

    # Map: branch_path → (container_cid, cont_abs_x, cont_abs_y_content_top)
    branch_container: Dict[str, Tuple[str, float, float]] = {}

    for branch_path, pn_dec in branching_decisions:
        desc = descendants_of(branch_path, all_placed)
        if not desc:
            continue

        x0, y0, x1, y1 = bbox_of(desc)
        cx = x0 - CONT_PAD
        cy = y0 - CONT_PAD - CONT_HDR
        cw = (x1 - x0) + 2 * CONT_PAD
        ch = (y1 - y0) + 2 * CONT_PAD + CONT_HDR

        rules = pn_dec.step.get("rules", [])
        rule_name = ""
        if rules:
            rule_name = (rules[0].get("object_name") or "").strip()
        cont_label = f"▼ {rule_name or pn_dec.step.get('label','Decision')}"

        cont_cid = b.container(cont_label, S_CONT("#cccccc", "#666666"), cx, cy, cw, ch)

        # Map child branch paths → this container
        yp = child_path(branch_path, "YES")
        np = child_path(branch_path, "NO")
        content_top = cy + CONT_HDR
        branch_container[yp] = (cont_cid, cx, content_top)
        branch_container[np] = (cont_cid, cx, content_top)

    # ── Place each node, routing into its container if applicable ───────────
    def find_container(bp):
        if bp in branch_container:
            return branch_container[bp]
        parts = bp.split(" → ")
        for length in range(len(parts) - 1, 0, -1):
            prefix = " → ".join(parts[:length])
            if prefix in branch_container:
                return branch_container[prefix]
        return None, 0, 0

    first_in_branch: Dict[str, str] = {}
    prev_in_branch:  Dict[str, str] = {}
    node_to_cid:     Dict[int, str] = {}

    for pn in all_placed:
        bp  = pn.branch_path
        des = pn.step["designation"]
        cont_cid, ox, oy = find_container(bp)

        if cont_cid:
            px  = pn.abs_cx - pn.w / 2 - ox
            py  = pn.abs_y - oy
            par = cont_cid
        else:
            px, py, par = pn.abs_cx - pn.w / 2, pn.abs_y, "1"

        cid = b.node(step_label(pn.step), shape_style(des),
                     px, py, pn.w, pn.h, parent=par)
        node_to_cid[pn.step["node_id"]] = cid

        if bp not in first_in_branch:
            first_in_branch[bp] = cid

        # Sequential edge within the same branch
        if bp in prev_in_branch:
            b.edge(prev_in_branch[bp], cid, parent="1")
        prev_in_branch[bp] = cid

        # Annotation
        if pn.anno_lines:
            ann_text = "\n".join(pn.anno_lines)
            if cont_cid:
                ax = pn.abs_cx - pn.w / 2 + pn.w + ANNO_GAP - ox
                ay = pn.abs_y - oy
            else:
                ax = pn.abs_cx + pn.w / 2 + ANNO_GAP
                ay = pn.abs_y
            b.text(ann_text, ax, ay, parent=par)

    # ── Connect START → first root node ────────────────────────────────────
    if "" in first_in_branch:
        b.edge(start_cid, first_in_branch[""], parent="1")

    # ── YES / NO edges from each DECISION ──────────────────────────────────
    for branch_path, pn_dec in branching_decisions:
        dec_cid = node_to_cid.get(pn_dec.step["node_id"])
        if not dec_cid:
            continue
        yp = child_path(branch_path, "YES")
        np = child_path(branch_path, "NO")

        if yp in first_in_branch:
            b.edge(dec_cid, first_in_branch[yp], "YES", S_YES, parent="1")
        if np in first_in_branch:
            b.edge(dec_cid, first_in_branch[np], "NO",  S_NO,  parent="1")

    # ── Status badge ────────────────────────────────────────────────────────
    status_colors = {
        "Running": ("#d5e8d4", "#82b366"),
        "Paused":  ("#fff2cc", "#d6b656"),
        "Draft":   ("#f0f0f0", "#888888"),
        "Error":   ("#f8cecc", "#b85450"),
    }
    fc, sc = status_colors.get(status, ("#f0f0f0", "#888888"))
    b.node(f"● {status}",
           f"rounded=1;whiteSpace=wrap;html=1;fillColor={fc};strokeColor={sc};fontSize=9;",
           20, 20, 80, 24)

    return b.xml(prog["name"])


# ── Entry point ────────────────────────────────────────────────────────────────

def main():
    base  = os.path.dirname(os.path.abspath(__file__))
    src   = os.path.join(base, "output", "globex", "pardot_engagement_studio.json")
    outd  = os.path.join(base, "output", "drawio")
    os.makedirs(outd, exist_ok=True)

    with open(src, encoding="utf-8") as f:
        programs = json.load(f)

    for prog in programs:
        xml   = program_to_drawio(prog)
        fname = f"ES_{prog['id']}_{slug(prog['name'])}.drawio"
        path  = os.path.join(outd, fname)
        with open(path, "w", encoding="utf-8") as f:
            f.write(xml)
        n = len(prog["steps"])
        print(f"✓  {fname}  ({n} steps, status={prog.get('status','?')})")

    print(f"\n{len(programs)} diagrams written to {outd}")

if __name__ == "__main__":
    main()
