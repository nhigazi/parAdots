"""
SF Scraper 9 — Report & Dashboard Inventory
============================================
Inventories Salesforce Reports and Dashboards related to Pardot /
Account Engagement KPIs.

If there are zero campaign performance reports, that is a process gap
independent of tool configuration — marketing has no visibility into
what's working.

Captures:
  • All Reports with "pardot", "campaign", "account engagement", "lead score",
    "newsletter", "opt" in name or description
  • Dashboard components referencing those reports
  • Last run date per report (reveals stale / never-run reports)
  • Report type distribution (tabular, summary, matrix, joined)
  • Folders containing Pardot-related reports

Output:
  sf_reports_inventory.json
  sf_reports_inventory.csv

Called from run_sf.py / run_all.py:
  from scrape_sf_reports_inventory import run
  run(page=page)
"""
from __future__ import annotations
import csv, json, sys
import salesforce_api as sf
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""

# Keywords to filter reports by name — case-insensitive SOQL LIKE
REPORT_KEYWORDS = [
    "pardot", "account engagement", "campaign", "lead score",
    "newsletter", "optin", "opt-in", "consent", "mql",
    "engagement studio", "b2b", "globex", "acme", "initech",
]


def _build_name_filter() -> str:
    """Build a SOQL WHERE clause for report name keywords."""
    clauses = [f"Name LIKE '%{kw}%'" for kw in REPORT_KEYWORDS]
    return "(" + " OR ".join(clauses) + ")"


def run(page=None, client: sf.SalesforceClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("sf_reports_inventory.json")
    OUTPUT_CSV  = utils.output_path("sf_reports_inventory.csv")

    print("\n🚀 SF Scraper 9 — Report & Dashboard Inventory")
    print("=" * 50)

    if client is None:
        if page is None:
            print("❌ Need page or client"); sys.exit(1)
        client = sf.client_from_page(page)

    # ── Check available fields on Report object ───────────────────────────────
    report_fields_available = sf.field_names(client, "Report")
    has_last_run     = "LastRunDate" in report_fields_available
    has_description  = "Description" in report_fields_available
    has_format       = "Format" in report_fields_available

    select_fields = ["Id", "Name", "DeveloperName", "FolderName", "OwnerId",
                     "CreatedDate", "LastModifiedDate"]
    if has_last_run:
        select_fields.append("LastRunDate")
    if has_description:
        select_fields.append("Description")
    if has_format:
        select_fields.append("Format")

    # ── Total report count ────────────────────────────────────────────────────
    total_reports = sf.soql_count(client, "SELECT COUNT() FROM Report")
    print(f"   Total reports in org: {total_reports:,}")

    # ── Pardot-related reports ────────────────────────────────────────────────
    print(f"\n📊 Filtering reports by {len(REPORT_KEYWORDS)} Pardot-related keywords...")
    name_filter = _build_name_filter()
    q = f"SELECT {', '.join(select_fields)} FROM Report WHERE {name_filter} ORDER BY Name"
    reports = sf.soql_all(client, q)
    print(f"   ✅ {len(reports)} matching report(s) found")

    results = []
    never_run = []
    stale     = []

    from datetime import datetime, timezone, timedelta
    cutoff_stale = (datetime.now(timezone.utc) - timedelta(days=180)).isoformat()

    for r in reports:
        last_run = r.get("LastRunDate","")
        name     = r.get("Name","")
        is_never_run = has_last_run and not last_run
        is_stale     = has_last_run and last_run and last_run < cutoff_stale

        if is_never_run:
            never_run.append(name)
        if is_stale:
            stale.append(name)

        results.append({
            "id":            r.get("Id",""),
            "name":          name,
            "developer_name": r.get("DeveloperName",""),
            "folder":        r.get("FolderName",""),
            "format":        r.get("Format","") if has_format else "",
            "last_run":      last_run,
            "never_run":     is_never_run,
            "stale":         is_stale,
            "created_at":    r.get("CreatedDate",""),
            "updated_at":    r.get("LastModifiedDate",""),
            "description":   (r.get("Description","") or "")[:200],
        })

    # ── Folder distribution ───────────────────────────────────────────────────
    folder_counts: dict[str, int] = {}
    for r in results:
        f = r["folder"] or "(no folder)"
        folder_counts[f] = folder_counts.get(f, 0) + 1

    # ── Dashboard count ───────────────────────────────────────────────────────
    print("\n📋 Checking dashboards...")
    dash_fields = sf.field_names(client, "Dashboard")
    dash_select = ["Id", "Title", "FolderName"]
    if "LastViewedDate" in dash_fields:
        dash_select.append("LastViewedDate")

    dash_filter = _build_name_filter().replace("Name", "Title")
    q_dash = f"SELECT {', '.join(dash_select)} FROM Dashboard WHERE {dash_filter} ORDER BY Title"
    dashboards = sf.soql_all(client, q_dash)
    print(f"   ✅ {len(dashboards)} matching dashboard(s) found")

    print(f"\n📊 Report summary:")
    print(f"   Matching reports    : {len(results)}")
    print(f"   Never run           : {len(never_run)}")
    print(f"   Stale (>180 days)   : {len(stale)}")
    print(f"   Matching dashboards : {len(dashboards)}")
    if not results:
        print("   ⚠️  No Pardot-related reports found — reporting gap confirmed")

    output = {
        "total_reports_in_org":   total_reports,
        "matching_reports":       len(results),
        "never_run_reports":      len(never_run),
        "stale_reports":          len(stale),
        "matching_dashboards":    len(dashboards),
        "reports":                results,
        "dashboards":             [
            {"id": d.get("Id",""), "title": d.get("Title",""),
             "folder": d.get("FolderName",""), "last_viewed": d.get("LastViewedDate","")}
            for d in dashboards
        ],
        "folder_distribution":    [{"folder": k, "count": v}
                                   for k, v in sorted(folder_counts.items(), key=lambda x: -x[1])],
    }

    utils.save_json(output, OUTPUT_JSON)
    _export_csv(output)
    print(f"\n✅ Reports inventory complete.")


def _export_csv(output):
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)

        w.writerow(["=== SUMMARY ==="])
        w.writerow(["Total reports in org",     output["total_reports_in_org"]])
        w.writerow(["Pardot-related reports",   output["matching_reports"]])
        w.writerow(["Never run",                output["never_run_reports"]])
        w.writerow(["Stale (>180d)",            output["stale_reports"]])
        w.writerow(["Matching dashboards",      output["matching_dashboards"]])

        if output["reports"]:
            w.writerow([])
            w.writerow(["=== REPORT LIST ==="])
            w.writerow(["Name","Format","Folder","Last Run","Never Run","Stale","Description"])
            for r in output["reports"]:
                w.writerow([r["name"], r["format"], r["folder"], r["last_run"],
                            "Yes" if r["never_run"] else "No",
                            "Yes" if r["stale"] else "No",
                            r["description"]])

        if output["dashboards"]:
            w.writerow([])
            w.writerow(["=== DASHBOARDS ==="])
            w.writerow(["Title","Folder","Last Viewed"])
            for d in output["dashboards"]:
                w.writerow([d["title"], d["folder"], d["last_viewed"]])

    print(f"✅ Exported {OUTPUT_CSV}")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
