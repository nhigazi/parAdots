"""
parAdots: set_org.py — Switch the active org
=============================================
Writes the chosen org name to .active-org so that run_all.py and every
individual scraper use it automatically without needing a --org flag.

Usage:
  python3 set_org.py globex        # switch to globex
  python3 set_org.py --list         # show available orgs and current default
  python3 set_org.py                # same as --list

Org configs live in configs/<name>.env. Create a new one by copying
configs/globex.env and filling in the credentials for the new org.
"""

import os
import sys

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_CONFIGS_DIR = os.path.join(_BASE_DIR, "configs")
_ACTIVE_FILE = os.path.join(_BASE_DIR, ".active-org")


def _list_orgs() -> list[str]:
    if not os.path.isdir(_CONFIGS_DIR):
        return []
    return sorted(
        f[:-4] for f in os.listdir(_CONFIGS_DIR)
        if f.endswith(".env") and not f.startswith(".")
    )


def _current_org() -> str:
    if os.path.exists(_ACTIVE_FILE):
        val = open(_ACTIVE_FILE).read().strip()
        return val or "default (root .env)"
    return "default (root .env)"


def show_status():
    orgs = _list_orgs()
    current = _current_org()
    print(f"\n🌐 Active org : {current}")
    if orgs:
        print(f"📂 Available  : {', '.join(orgs)}")
        print(f"\n   Switch with: python3 set_org.py <org-name>")
    else:
        print("   No org configs found in configs/")
        print("   Create configs/<name>.env — see configs/globex.env as a template.")
    print()


def set_org(org_name: str):
    orgs = _list_orgs()
    if org_name not in orgs:
        print(f"❌  Unknown org: '{org_name}'")
        if orgs:
            print(f"    Available: {', '.join(orgs)}")
        else:
            print("    No configs found in configs/  — create configs/<name>.env first.")
        sys.exit(1)

    with open(_ACTIVE_FILE, "w") as f:
        f.write(org_name)

    print(f"✅  Active org set to: {org_name}")
    print(f"   Config: configs/{org_name}.env")
    print(f"   Output: output/{org_name}/")
    print(f"\n   Run scrapers: python3 run_all.py")
    print(f"   One-off override: python3 run_all.py --org <other-org>")


def main():
    args = sys.argv[1:]

    if not args or args[0] in ("--list", "-l", "--help", "-h"):
        show_status()
        return

    set_org(args[0])


if __name__ == "__main__":
    main()
