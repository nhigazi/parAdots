"""
Salesforce Object Storage Usage Audit
=====================================
Scrapes storage data directly from Setup > System Overview.
Shows all objects and their actual data storage (no estimation).

Usage:
  Standalone:   python3 scrape_sf_storage_usage.py [--org NAME]
  Via run_all:  run_all.py calls run(page)

Output:
  output/{org}/sf_storage_by_object.json
  output/{org}/sf_storage_by_object.csv
"""

import argparse
import csv
import json
import os
import re
import sys
from datetime import datetime
from playwright.sync_api import sync_playwright

import utils


def _resolve_base_url(page, base_url=None) -> str:
    """
    Determine the Salesforce instance origin to navigate Setup against.

    Prefer an explicitly passed base_url (e.g. client.instance_url). Otherwise
    derive it from the current page host — but reject pi.pardot.com, because in
    the full-suite run the page may still sit on Pardot after the Pardot block,
    which would send Setup navigation to a bogus host.
    """
    if base_url:
        return base_url.rstrip("/")
    host = ""
    if page is not None and "://" in (page.url or ""):
        host = page.url.split("://")[1].split("/")[0]
    if not host or "pardot" in host.lower():
        raise RuntimeError(
            "No Salesforce instance URL available — pass a client (client.instance_url) "
            "or ensure the page is on a Salesforce domain before calling."
        )
    return "https://" + host


# ── Storage scraping ──────────────────────────────────────────────────────────

def scrape_storage_table(page, base_url=None) -> list[dict]:
    """
    Navigate to Setup > Storage Usage and scrape the data storage table.
    Returns list of objects sorted by storage usage.
    """
    print("   🔍 Navigating to Setup > Storage Usage...")

    org_url = _resolve_base_url(page, base_url)
    page.goto(f"{org_url}/lightning/setup/CompanyResourceDisk/home", wait_until="domcontentloaded")

    # Wait for the Lightning storage table to render (selector-based, with a
    # bounded fallback) instead of a blind fixed sleep.
    print("   ⏳ Waiting for table to render...")
    try:
        page.wait_for_selector('table tbody tr, [role="row"]', timeout=30000)
    except Exception:
        page.wait_for_timeout(8000)

    results = []

    # Extract via JS. The SF storage table columns are
    #   Record Type | Record Count | Storage | Percent
    # so the storage value is NOT a fixed column index — pick the cell whose
    # text is a storage quantity (e.g. "123.4 MB") regardless of position.
    script = r"""
    () => {
        const re = /^[\d.,]+\s*(KB|MB|GB|TB|B)$/i;
        const data = [];
        const rows = document.querySelectorAll('table tbody tr, [role="row"]');

        for (const row of rows) {
            const cells = Array.from(row.querySelectorAll('td, [role="gridcell"]'));
            if (cells.length < 2) continue;

            const name = (cells[0].innerText || '').trim();
            if (!name) continue;
            const low = name.toLowerCase();
            if (low.includes('record type') || low === 'storage' ||
                low.includes('storage type')) {
                continue;  // header row
            }

            // Find the first cell after the name that is a storage quantity.
            let storage = '';
            for (let i = 1; i < cells.length; i++) {
                const t = (cells[i].innerText || '').trim();
                if (re.test(t)) { storage = t; break; }
            }
            if (storage) data.push({ name, storage });
        }

        return data;
    }
    """

    try:
        data = page.evaluate(script)
        print(f"   📊 Found {len(data)} storage entries via JavaScript\n")

        for item in data:
            if item["name"] and item["storage"]:
                storage_bytes = parse_storage_value(item["storage"])
                if storage_bytes > 0:
                    results.append({
                        "object": item["name"],
                        "storage_raw": item["storage"],
                        "storage_bytes": storage_bytes,
                        "storage_mb": round(storage_bytes / (1024 * 1024), 2),
                        "storage_gb": round(storage_bytes / (1024 * 1024 * 1024), 3),
                    })

    except Exception as e:
        print(f"   ⚠️  JavaScript extraction failed: {e}")
        print("   Trying fallback table parsing...\n")

    if not results:
        print("   ⚠️  Could not find storage table data")
        page.screenshot(path="/tmp/storage_page.png")
        print("   📸 Screenshot saved to /tmp/storage_page.png for debugging")
        return []

    # Sort by storage (descending)
    results.sort(key=lambda r: r["storage_bytes"], reverse=True)
    return results


def parse_storage_value(text: str) -> int:
    """Parse storage value like '123.45 MB' or '1.23 GB' into bytes."""
    text = text.strip().upper()

    # Match pattern like "123.45 MB" or "1.23 GB"
    match = re.search(r'([\d.]+)\s*(B|KB|MB|GB|TB)', text)
    if not match:
        return 0

    value = float(match.group(1))
    unit = match.group(2)

    units = {
        'B': 1,
        'KB': 1024,
        'MB': 1024 ** 2,
        'GB': 1024 ** 3,
        'TB': 1024 ** 4,
    }

    return int(value * units.get(unit, 1))


def run(page=None, client=None) -> None:
    """Entry point for run_all.py — scrape storage from Setup.

    Signature mirrors the other SF scrapers (page=None, client=None). Storage
    by object is only available in the Setup UI, so this scraper always needs a
    browser `page`; the `client` is used solely for its instance_url so Setup
    navigation targets the correct Salesforce origin.
    """
    print("\n🔍 Scraping Salesforce object storage from Setup...\n")

    if page is None:
        print("❌ Storage scraper needs a browser page (UI-only data).")
        return

    base_url = getattr(client, "instance_url", None) if client is not None else None

    try:
        results = scrape_storage_table(page, base_url)

        if not results:
            print("❌ No storage data collected")
            return

        # Summary
        total_storage_bytes = sum(r["storage_bytes"] for r in results)
        total_storage_gb = total_storage_bytes / (1024 * 1024 * 1024)
        total_storage_tb = total_storage_gb / 1024

        print(f"{'─' * 90}")
        print(f"📊 Total Storage: {total_storage_gb:,.2f} GB (~{total_storage_tb:.3f} TB)")
        print(f"   Across {len(results)} objects")
        print(f"{'─' * 90}\n")

        # Top 20 objects
        print("📈 Top 20 Objects by Storage Usage:")
        print(f"{'─' * 90}")
        print(f"{'#':>3} {'Object Name':40} {'Storage (MB)':>15} {'% of Total':>12}")
        print(f"{'─' * 90}")

        for idx, result in enumerate(results[:20], 1):
            pct = (result["storage_mb"] / (total_storage_gb * 1024)) * 100
            print(
                f"{idx:3d} {result['object']:40s} {result['storage_mb']:15.2f} {pct:11.1f}%"
            )

        print(f"{'─' * 90}")

        # Write JSON
        output_data = {
            "generated_at": datetime.now().isoformat(),
            "summary": {
                "total_storage_gb": round(total_storage_gb, 2),
                "total_storage_tb": round(total_storage_tb, 3),
                "objects_count": len(results),
            },
            "objects": results,
        }

        json_path = utils.output_path("sf_storage_by_object.json")
        with open(json_path, "w") as f:
            json.dump(output_data, f, indent=2)
        print(f"\n✅ JSON output: {json_path}")

        # Write CSV
        csv_path = utils.output_path("sf_storage_by_object.csv")
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "object",
                    "storage_raw",
                    "storage_mb",
                    "storage_gb",
                ],
            )
            writer.writeheader()
            for result in results:
                writer.writerow({
                    "object": result["object"],
                    "storage_raw": result["storage_raw"],
                    "storage_mb": result["storage_mb"],
                    "storage_gb": result["storage_gb"],
                })
        print(f"✅ CSV output:  {csv_path}\n")

    except Exception as e:
        print(f"❌ Error scraping storage: {e}")
        import traceback
        traceback.print_exc()


def main():
    """Standalone entry point — runs storage audit independently."""
    parser = argparse.ArgumentParser(
        description="Check Salesforce object storage usage"
    )
    parser.add_argument(
        "--org", metavar="NAME",
        help="Org config to use (e.g. 'globex'). Defaults to .active-org",
    )
    args = parser.parse_args()

    org = utils.load_org_config(args.org)
    print(f"🌐 Org: {org}")
    print(f"📁 Output: {utils.OUTPUT_DIR}\n")

    if not os.getenv("SF_USERNAME"):
        print("❌ SF_USERNAME not set in .env")
        return 1

    # Reuse the shared session-aware login (handles MFA / My-Domain redirects
    # and persists storage_state) instead of a brittle password-fill flow.
    with sync_playwright() as pw:
        ctx = utils.launch_context(pw)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page)
            return 0
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
            return 1
        finally:
            ctx.close()


if __name__ == "__main__":
    sys.exit(main())
