"""
SF Scraper 3 — Prospect-to-Lead/Contact Resolution (Lead Quality)
==================================================================
Analyses Lead and Contact data quality as it relates to Pardot:
  • Lead status distribution (New, Open, Working, Unqualified, Converted…)
  • Leads with no owner (queue-owned or null)
  • Leads with no email address (Pardot cannot sync without email)
  • Duplicate detection: Leads sharing an email with another Lead or Contact
  • Conversion rate: converted Leads vs total
  • Corporation / brand field coverage

This directly explains orphan lists and "42 dynamic lists not referenced" —
broken Lead data upstream causes Pardot segment logic to fail silently.

Output:
  sf_lead_quality.json
  sf_lead_quality.csv

Called from run_sf.py / run_all.py:
  from scrape_sf_lead_quality import run
  run(page=page)
"""
from __future__ import annotations
import csv, json, sys
import salesforce_api as sf
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""


def run(page=None, client: sf.SalesforceClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("sf_lead_quality.json")
    OUTPUT_CSV  = utils.output_path("sf_lead_quality.csv")

    print("\n🚀 SF Scraper 3 — Lead Quality / Prospect Resolution")
    print("=" * 50)

    if client is None:
        if page is None:
            print("❌ Need page or client"); sys.exit(1)
        client = sf.client_from_page(page)

    checks: dict = {}

    # ── Lead totals ───────────────────────────────────────────────────────────
    print("📋 Lead overview...")
    checks["lead_total"]     = sf.soql_count(client, "SELECT COUNT() FROM Lead")
    checks["lead_converted"] = sf.soql_count(client, "SELECT COUNT() FROM Lead WHERE IsConverted = true")
    checks["lead_no_email"]  = sf.soql_count(client, "SELECT COUNT() FROM Lead WHERE Email = null")
    checks["lead_no_owner"]  = sf.soql_count(client, "SELECT COUNT() FROM Lead WHERE OwnerId = null OR Owner.Type = 'Queue'")

    t = checks["lead_total"]
    print(f"   Total Leads        : {t:,}")
    print(f"   Converted          : {checks['lead_converted']:,}  ({_pct(checks['lead_converted'], t)}%)")
    print(f"   No email           : {checks['lead_no_email']:,}  ({_pct(checks['lead_no_email'], t)}%) ⚠️ Pardot can't sync")
    print(f"   No owner / Queue   : {checks['lead_no_owner']:,}  ({_pct(checks['lead_no_owner'], t)}%)")

    # ── Lead status breakdown ─────────────────────────────────────────────────
    print("\n📊 Lead status distribution...")
    status_rows = sf.soql_all(client,
        "SELECT Status, COUNT(Id) cnt FROM Lead GROUP BY Status ORDER BY COUNT(Id) DESC"
    )
    status_dist = [
        {"status": r.get("Status",""), "count": r.get("cnt") or r.get("expr0",0)}
        for r in status_rows
    ]
    checks["status_distribution"] = status_dist
    for s in status_dist[:10]:
        print(f"   {s['status']:<30} {s['count']:,}")

    # ── Corporation coverage (brand field) ────────────────────────────────────
    print("\n🏷️  Corporation field coverage on Lead...")
    corp_field_exists = "Corporation__c" in sf.field_names(client, "Lead")
    checks["corporation_field_on_lead"] = corp_field_exists
    if corp_field_exists:
        checks["lead_no_corporation"] = sf.soql_count(
            client, "SELECT COUNT() FROM Lead WHERE Corporation__c = null AND IsConverted = false"
        )
        corp_rows = sf.soql_all(client,
            "SELECT Corporation__c, COUNT(Id) cnt FROM Lead "
            "WHERE IsConverted = false GROUP BY Corporation__c ORDER BY COUNT(Id) DESC LIMIT 20"
        )
        checks["corporation_distribution"] = [
            {"corporation": (r.get("Corporation__c") or "(blank)"), "count": r.get("cnt") or r.get("expr0") or 0}
            for r in corp_rows
        ]
        print(f"   Missing Corporation: {checks['lead_no_corporation']:,}")
        for c in checks["corporation_distribution"][:8]:
            print(f"   {c['corporation']:<35} {c['count']:,}")
    else:
        print("   ⚠️  Corporation__c field not found on Lead")
        checks["corporation_distribution"] = []
        checks["lead_no_corporation"] = -1

    # ── Contact totals ────────────────────────────────────────────────────────
    print("\n👥 Contact overview...")
    checks["contact_total"]    = sf.soql_count(client, "SELECT COUNT() FROM Contact")
    checks["contact_no_email"] = sf.soql_count(client, "SELECT COUNT() FROM Contact WHERE Email = null")
    corp_on_contact = "Corporation__c" in sf.field_names(client, "Contact")
    checks["corporation_field_on_contact"] = corp_on_contact
    if corp_on_contact:
        checks["contact_no_corporation"] = sf.soql_count(
            client, "SELECT COUNT() FROM Contact WHERE Corporation__c = null"
        )
    print(f"   Total Contacts     : {checks['contact_total']:,}")
    print(f"   No email           : {checks['contact_no_email']:,}")

    # ── Duplicate email detection (Leads only — cross-object is expensive) ──
    print("\n🔍 Checking for duplicate Lead emails...")
    dup_q = """
        SELECT Email, COUNT(Id) cnt
        FROM   Lead
        WHERE  Email != null
          AND  IsConverted = false
        GROUP  BY Email
        HAVING COUNT(Id) > 1
        ORDER  BY COUNT(Id) DESC
        LIMIT  500
    """
    dup_rows = sf.soql_all(client, dup_q)
    checks["duplicate_email_groups"]  = len(dup_rows)
    checks["duplicate_email_records"] = sum(r.get("cnt") or r.get("expr0",0) for r in dup_rows)
    print(f"   Duplicate email groups : {checks['duplicate_email_groups']:,}")
    print(f"   Total duplicate records: {checks['duplicate_email_records']:,}")

    utils.save_json(checks, OUTPUT_JSON)
    _export_csv(checks)
    print(f"\n✅ Lead quality scrape complete.")


def _pct(part, total):
    return round(part / total * 100, 1) if total > 0 else 0.0


def _export_csv(checks):
    summary_rows = [
        ["Lead total",               checks.get("lead_total", "")],
        ["Lead converted",           checks.get("lead_converted", "")],
        ["Lead no email",            checks.get("lead_no_email", "")],
        ["Lead no owner/queue",      checks.get("lead_no_owner", "")],
        ["Lead missing Corporation", checks.get("lead_no_corporation", "N/A")],
        ["Lead duplicate groups",    checks.get("duplicate_email_groups", "")],
        ["Lead duplicate records",   checks.get("duplicate_email_records", "")],
        ["Contact total",            checks.get("contact_total", "")],
        ["Contact no email",         checks.get("contact_no_email", "")],
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(["Metric", "Value"])
        for row in summary_rows:
            w.writerow(row)
        w.writerow([])
        w.writerow(["Status", "Count"])
        for s in checks.get("status_distribution", []):
            w.writerow([s["status"], s["count"]])
        if checks.get("corporation_distribution"):
            w.writerow([])
            w.writerow(["Corporation", "Lead Count"])
            for c in checks["corporation_distribution"]:
                w.writerow([c["corporation"], c["count"]])
    print(f"✅ Exported {OUTPUT_CSV}")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
