@echo off
rem parAdots - one-click launcher (Windows)
rem Double-click to start the local audit dashboard.
rem The first start installs dependencies automatically (a few minutes);
rem every later start opens straight away.
setlocal
cd /d "%~dp0"

if not exist ".venv\" (
  echo First start - setting up parAdots. This can take a few minutes...
  powershell -ExecutionPolicy Bypass -NoProfile -File "setup.ps1"
  if errorlevel 1 (
    echo.
    echo Setup failed. Please make sure Python 3.10+ is installed, then try again.
    pause
    exit /b 1
  )
)

echo Starting parAdots - http://localhost:8765
echo (Keep this window open while you work; close it to stop the dashboard.)
".venv\Scripts\python.exe" viewer.py
pause
