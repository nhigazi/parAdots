#!/usr/bin/env bash
# parAdots setup — macOS / Linux
set -euo pipefail
cd "$(dirname "$0")"
echo "== parAdots setup =="
command -v python3 >/dev/null || { echo "ERROR: python3 not found"; exit 1; }
python3 - <<'PY'
import sys; assert sys.version_info>=(3,10), "Python 3.10+ required, found %s"%sys.version.split()[0]
PY
echo "-- virtualenv (.venv)"; python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip >/dev/null
echo "-- Python dependencies"; pip install -r requirements.txt
echo "-- Playwright Chromium"; python -m playwright install chromium || echo "   (skipped — run later)"
if command -v npm >/dev/null; then echo "-- Node dependencies"; npm install --no-audit --no-fund >/dev/null || echo "   (npm optional)"; else echo "-- npm not found (optional)"; fi
[ -f configs/demo.env ] || cp .env.template configs/demo.env
[ -f .active-org ] || echo demo > .active-org
echo ""; echo "== Done. Run: source .venv/bin/activate && python3 viewer.py  → http://localhost:8765 =="
