"""
Pardot Grading Profile Scraper — v5 API
=========================================
Pulls grading profiles and their criteria from:
  /api/v5/objects/profiles
  /api/v5/objects/profile-criteria

Grading profiles define how Pardot assigns letter grades (A–F) to prospects
based on demographic fit (job title, company size, industry, etc.). Only
relevant when profile grading is enabled (visible in account_settings).

Two-pass approach:
  Pass 1 — list all profiles (id, name, description, isDefault)
  Pass 2 — for each profile, fetch its criteria (field, match type, value, grade)

Output:
  pardot_profiles.json          — all profiles with embedded criteria
  pardot_profiles.csv           — one row per profile (summary)
  pardot_profile_criteria.csv   — one row per criterion (flat, joinable by profile_id)

Usage (standalone):
  python3 scrape_profiles.py

Called from run_all.py:
  from scrape_profiles import run
  run(page=page)
"""

from __future__ import annotations

import csv
import sys
from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON         = ""
OUTPUT_CSV_PROFILES = ""
OUTPUT_CSV_CRITERIA = ""

PROFILE_FIELDS = [
    "id", "name", "description", "isDefault",
    "createdAt", "updatedAt",
]

CRITERIA_FIELDS = [
    "id", "profileId", "fieldId", "fieldName", "value",
    "matchType", "grade", "priority",
]

# Flat label for match types
MATCH_LABEL = {
    "is":         "ist",
    "is_not":     "ist nicht",
    "contains":   "enthält",
    "starts_with": "beginnt mit",
    "ends_with":  "endet mit",
    "greater_than": "größer als",
    "less_than":  "kleiner als",
}


# ── Criteria ──────────────────────────────────────────────────────────────────

def _fetch_criteria_for_profile(
    client: pardot_api.PardotClient, profile_id: str | int
) -> list[dict]:
    """Fetch all criteria belonging to one profile."""
    try:
        raw = list(pardot_api.paged_get(
            client, "objects/profile-criteria",
            fields=CRITERIA_FIELDS,
            extra_params={"profileId": profile_id},
        ))
        return raw
    except Exception as e:
        print(f"     ⚠️  Could not fetch criteria for profile {profile_id}: {e}")
        return []


def shape_criterion(c: dict, profile_name: str) -> dict:
    match_raw = c.get("matchType", "") or ""
    match_label = MATCH_LABEL.get(match_raw, match_raw)
    field = c.get("fieldName") or c.get("fieldId") or ""
    value = c.get("value", "") or ""
    grade = c.get("grade", "") or ""
    human = f"Wenn {field} {match_label} '{value}' → Note {grade}"
    return {
        "id":           str(c.get("id", "")),
        "profile_id":   str(c.get("profileId", "")),
        "profile_name": profile_name,
        "field":        field,
        "match_type":   match_raw,
        "match_label":  match_label,
        "value":        value,
        "grade":        grade,
        "priority":     c.get("priority", ""),
        "human":        human,
    }


# ── Export ────────────────────────────────────────────────────────────────────

def export_profiles_csv(profiles: list[dict]) -> None:
    headers = [
        "#", "Name", "ID", "Default", "Description",
        "Criteria Count", "Grades Used", "Created At", "Updated At",
    ]
    rows = [
        [
            i + 1,
            p["name"],
            p["id"],
            "Yes" if p.get("is_default") else "No",
            p.get("description", ""),
            p["criteria_count"],
            ", ".join(sorted(set(c["grade"] for c in p["criteria"] if c["grade"]))),
            p.get("created_at", ""),
            p.get("updated_at", ""),
        ]
        for i, p in enumerate(profiles)
    ]
    with open(OUTPUT_CSV_PROFILES, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV_PROFILES} ({len(rows)} rows)")


def export_criteria_csv(criteria: list[dict]) -> None:
    headers = [
        "#", "Profile Name", "Profile ID", "Field",
        "Match Type", "Value", "Grade", "Priority", "Human Description",
    ]
    rows = [
        [
            i + 1,
            c["profile_name"],
            c["profile_id"],
            c["field"],
            c["match_type"],
            c["value"],
            c["grade"],
            c["priority"],
            c["human"],
        ]
        for i, c in enumerate(criteria)
    ]
    with open(OUTPUT_CSV_CRITERIA, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV_CRITERIA} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV_PROFILES, OUTPUT_CSV_CRITERIA
    OUTPUT_JSON         = utils.output_path("pardot_profiles.json")
    OUTPUT_CSV_PROFILES = utils.output_path("pardot_profiles.csv")
    OUTPUT_CSV_CRITERIA = utils.output_path("pardot_profile_criteria.csv")

    print("\n🎓 Pardot Grading Profile Scraper (v5 API)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    print("📋 Fetching profiles...")
    profiles_raw = list(pardot_api.paged_get(
        client, "objects/profiles", fields=PROFILE_FIELDS
    ))
    print(f"   ✅ {len(profiles_raw)} profile(s) found")

    if not profiles_raw:
        print("   ℹ️  No profiles found — profile grading may not be enabled in this org.")
        utils.save_json([], OUTPUT_JSON)
        export_profiles_csv([])
        export_criteria_csv([])
        return

    all_criteria: list[dict] = []
    profiles_out: list[dict] = []

    for i, p in enumerate(profiles_raw, 1):
        p_id   = p.get("id")
        p_name = p.get("name", f"Profile {p_id}")
        print(f"   [{i}/{len(profiles_raw)}] {p_name} (id: {p_id})")

        raw_criteria = _fetch_criteria_for_profile(client, p_id)
        shaped_criteria = [shape_criterion(c, p_name) for c in raw_criteria]
        all_criteria.extend(shaped_criteria)

        print(f"       → {len(shaped_criteria)} criteria")

        profiles_out.append({
            "id":            str(p_id),
            "name":          p_name,
            "description":   p.get("description", "") or "",
            "is_default":    bool(p.get("isDefault", False)),
            "created_at":    p.get("createdAt", "") or "",
            "updated_at":    p.get("updatedAt", "") or "",
            "criteria_count": len(shaped_criteria),
            "criteria":      shaped_criteria,
        })

    utils.save_json(profiles_out, OUTPUT_JSON)
    export_profiles_csv(profiles_out)
    export_criteria_csv(all_criteria)

    print(f"\n── Profile summary ─────────────────────────")
    for p in profiles_out:
        default_tag = " [DEFAULT]" if p["is_default"] else ""
        grades = sorted(set(c["grade"] for c in p["criteria"] if c["grade"]))
        print(f"   • {p['name']}{default_tag} — {p['criteria_count']} criteria, grades: {', '.join(grades) or '(none)'}")

    print(f"\n✅ Profile scrape complete — {len(profiles_out)} profile(s), {len(all_criteria)} total criteria.")


# ── Standalone ────────────────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
