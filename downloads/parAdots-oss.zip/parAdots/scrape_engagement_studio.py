"""
Pardot Engagement Studio Scraper
==================================
Uses the Pardot internal API (/workflowApiV2/workflows/{id}) to fetch
the complete step tree for each program — no canvas interaction needed.

Output:
  pardot_engagement_studio.json  — one object per program, with steps array
  pardot_engagement_studio.csv   — one row per step across all programs

Usage:
  python3 scrape_engagement_studio.py
"""

import csv, json, os, re, sys, time
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright

import utils

OUTPUT_JSON = ""   # set at run() time via utils.output_path()
OUTPUT_CSV  = ""
SCREENSHOTS = ""
LIST_PATH   = "/engagementStudio"

# ── Formatting helpers ────────────────────────────────────────────────────────

def label_from_name(name):
    """Convert dotted API name to human-readable label."""
    name = name or ""
    for prefix in ("Action.", "Any.Rule.", "Wait.", "Rule."):
        if name.startswith(prefix):
            name = name[len(prefix):]
            break
    return name.replace(".", " ")

def format_timeout(seconds):
    if not seconds:
        return ""
    seconds = int(seconds)
    if seconds >= 86400 and seconds % 86400 == 0:
        d = seconds // 86400
        return f"{d} day{'s' if d != 1 else ''}"
    if seconds >= 3600 and seconds % 3600 == 0:
        h = seconds // 3600
        return f"{h} hour{'s' if h != 1 else ''}"
    if seconds >= 60 and seconds % 60 == 0:
        m = seconds // 60
        return f"{m} minute{'s' if m != 1 else ''}"
    return f"{seconds}s"

def format_rules(rules):
    if not rules:
        return ""
    lines = []
    for r in rules:
        parts = [r.get("designation", "").replace("_", " ").title()]
        if r.get("operator"):
            parts.append(r["operator"])
        if r.get("value") not in (None, ""):
            parts.append(f"'{r['value']}'")
        if r.get("object_name"):
            parts.append(f"({r['object_name']})")
        lines.append(" ".join(p for p in parts if p))
    return "\n".join(lines)

def format_actions(actions):
    if not actions:
        return ""
    lines = []
    for a in actions:
        desig = a.get("designation", "").replace("_", " ").title()
        obj   = a.get("object_name") or ""
        val   = a.get("value") or ""
        if obj and val:
            lines.append(f"{desig}: {obj} = {val}")
        elif obj:
            lines.append(f"{desig}: {obj}")
        elif val:
            lines.append(f"{desig}: {val}")
        else:
            lines.append(desig)
    return "\n".join(lines)

def format_sources(sources):
    entry      = [s["name"] for s in sources if not s.get("suppressed")]
    suppressed = [s["name"] for s in sources if s.get("suppressed")]
    return "\n".join(entry), "\n".join(suppressed)

# ── Graph traversal ───────────────────────────────────────────────────────────

def traverse(nodes_by_id, start_id):
    """
    DFS traversal from start_id.
    Returns ordered list of step dicts.

    TRIGGER / RULE nodes with 2 destinations (verified against Pardot canvas
    for programs 945290 and 831682):
      sort_order=0 → NO  branch (condition not matched)
      sort_order=1 → YES branch (condition matched)
    """
    steps   = []
    visited = set()

    def dfs(node_id, branch_path):
        if node_id in visited:
            return
        visited.add(node_id)

        node  = nodes_by_id.get(node_id)
        if not node:
            return

        desig = node.get("designation", "")

        if desig != "START":
            steps.append({
                "step":        len(steps) + 1,
                "branch_path": branch_path,
                "node_id":     node_id,
                "designation": desig,
                "name":        node.get("name", ""),
                "label":       label_from_name(node.get("name", "")),
                "timeout":     node.get("timeout"),
                "match_type":  node.get("match_type") or "",
                "rules":       node.get("rules", []),
                "actions":     node.get("actions", []),
            })

        dsts = sorted(node.get("destination_nodes", []), key=lambda x: x["sort_order"])
        for i, dst in enumerate(dsts):
            if len(dsts) > 1:
                branch_label = "YES" if dst["sort_order"] == 1 else "NO"
                new_path = f"{branch_path} → {branch_label}" if branch_path else branch_label
            else:
                new_path = branch_path
            dfs(dst["node_id"], new_path)

    dfs(start_id, "")
    return steps

# ── Login ─────────────────────────────────────────────────────────────────────

def wait_for_login(page):
    print("=" * 60)
    print("⚠️  Make sure your Pardot UI language is set to English.")
    print("=" * 60)
    print()
    print("🌐 Opening browser — credentials will be filled automatically.")
    print("   Approve the MFA notification on your device when prompted.")
    print()

    page.goto(utils.SF_LOGIN_URL)
    page.wait_for_timeout(2000)
    try:
        page.fill("#username", utils.SF_USERNAME)
        page.fill("#password", utils.get_password())
        page.click("#Login")
    except Exception:
        pass

    print("   Waiting for MFA approval (approve on your device)...")
    SF_SESSION_SELECTORS = [
        ".slds-global-header", "#brandBand", "one-app-nav-bar",
        "a[title='App Launcher']", ".appLauncher", "one-app-launcher-header",
    ]
    MFA_KEYWORDS = ("login", "identity", "verification", "challenge", "mfa", "two-factor")
    for _ in range(15):
        page.wait_for_timeout(2000)
        url = page.url.lower()
        if utils.is_pardot_url(url) and "login" not in url:
            break
        if "salesforce.com" in url and not any(k in url for k in MFA_KEYWORDS):
            def sf_ui_present():
                for s in SF_SESSION_SELECTORS:
                    try:
                        if page.query_selector(s):
                            return True
                    except Exception:
                        pass
                return False
            if sf_ui_present():
                break
    else:
        print("⚠️  Timed out waiting for MFA — proceeding anyway.")

    print("   Navigating to Pardot...")
    try:
        page.goto(utils.PARDOT_HOME, wait_until="networkidle", timeout=30000)
    except Exception:
        try:
            page.goto(utils.PARDOT_HOME, wait_until="domcontentloaded", timeout=30000)
        except Exception:
            pass
    page.wait_for_timeout(2000)
    _click_salesforce_login_if_prompted(page)

    print("   Waiting for Pardot dashboard...")
    for _ in range(15):
        page.wait_for_timeout(2000)
        url = page.url.lower()
        if utils.is_pardot_url(url) and "login" not in url:
            if utils.pardot_dashboard_ready(page):
                break
    else:
        print("⚠️  Timed out waiting for dashboard — proceeding anyway.")

    print("✅ Dashboard detected — starting scraper.\n")


def _click_salesforce_login_if_prompted(page):
    for selector in [
        "a:has-text('Log in with Salesforce')",
        "button:has-text('Log in with Salesforce')",
        "a:has-text('Login with Salesforce')",
        "button:has-text('Login with Salesforce')",
        "[data-id='sfdc'] a",
        "a[href*='salesforce'][href*='login']",
    ]:
        try:
            el = page.query_selector(selector)
            if el and el.is_visible():
                print("   🔗 Pardot login prompt — clicking 'Log in with Salesforce'...")
                before_url = page.url
                el.click()
                try:
                    page.wait_for_function(
                        f"() => window.location.href !== {repr(before_url)}",
                        timeout=15000,
                    )
                except Exception:
                    pass
                page.wait_for_timeout(3000)
                return
        except Exception:
            continue

# ── Discover programs from list page ─────────────────────────────────────────

PROGRAM_LINK_RE = re.compile(r'/engagementStudio/studio#/(\d+)/')

def discover_programs(page):
    print("📋 Discovering Engagement Studio programs...")
    programs = []
    seen     = set()

    try:
        page.goto(utils.pardot_url(LIST_PATH), wait_until="networkidle", timeout=30000)
    except Exception:
        try:
            page.goto(utils.pardot_url(LIST_PATH), wait_until="domcontentloaded", timeout=30000)
        except Exception:
            pass

    # Wait for JS-rendered table
    page.wait_for_timeout(5000)

    # Scroll to load all rows
    for _ in range(4):
        try:
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(800)
        except Exception:
            break
    page.evaluate("window.scrollTo(0, 0)")

    page.screenshot(path=f"{SCREENSHOTS}/00_list.png", full_page=True)

    anchors = page.query_selector_all("a[href]")
    for a in anchors:
        href = a.get_attribute("href") or ""
        m = PROGRAM_LINK_RE.search(href)
        if m:
            prog_id = m.group(1)
            name    = a.inner_text().strip()
            if prog_id not in seen and name:
                seen.add(prog_id)
                programs.append({"id": prog_id, "name": name})

    # Fallback: scan page HTML
    if not programs:
        html = page.content()
        for m in PROGRAM_LINK_RE.finditer(html):
            prog_id = m.group(1)
            if prog_id not in seen:
                seen.add(prog_id)
                programs.append({"id": prog_id, "name": f"Program {prog_id}"})

    # Paginate — Pardot shows 50 items per page
    extra, _ = utils.paginate_collect(page, PROGRAM_LINK_RE.pattern, seen)
    programs.extend(extra)

    print(f"   ✅ Found {len(programs)} program(s)\n")
    return programs

# ── Fetch program data via API ────────────────────────────────────────────────

def fetch_program(page, program_id):
    """Fetch full workflow definition via the internal workflowApiV2."""
    url  = f"{utils.PARDOT_HOME}/workflowApiV2/workflows/{program_id}?is_salesforce=false"
    resp = page.context.request.get(url)
    if not resp.ok:
        print(f"   ⚠️  API error {resp.status} for program {program_id}")
        return None
    data      = resp.json()
    workflows = data.get("workflows", [])
    return workflows[0] if workflows else None

def fetch_status(page, program_id):
    """Fetch current run status from nurtureStatus endpoint."""
    url = f"{utils.PARDOT_HOME}/engagementStudio/nurtureStatus/id/{program_id}"
    try:
        resp = page.context.request.get(url)
        if resp.ok:
            return resp.json()
    except Exception:
        pass
    return {}

# ── Process one program ───────────────────────────────────────────────────────

def process_program(page, program_id, program_name):
    workflow = fetch_program(page, program_id)
    if not workflow:
        return None

    status_data  = fetch_status(page, program_id)
    nodes        = workflow.get("nodes", [])
    sources      = workflow.get("sources", [])
    start_id     = workflow.get("start_workflow_node_id")
    nodes_by_id  = {n["id"]: n for n in nodes}

    steps = traverse(nodes_by_id, start_id) if start_id else []

    entry_lists, suppression_lists = format_sources(sources)

    return {
        "id":                program_id,
        "name":              workflow.get("name", program_name),
        "type":              workflow.get("type", ""),
        "status":            status_data.get("status") or workflow.get("status", ""),
        "description":       workflow.get("description", "") or "",
        "archived":          workflow.get("archived", False),
        "last_updated":      status_data.get("lastUpdatedAt", ""),
        "entry_lists":       entry_lists,
        "suppression_lists": suppression_lists,
        "steps":             steps,
    }

# ── Export ────────────────────────────────────────────────────────────────────

def export_json(results):
    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"✅ Saved {OUTPUT_JSON} ({len(results)} programs)")

def export_csv(results):
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow([
            "#", "Program Name", "Program ID", "Status", "Last Updated",
            "Description", "Entry Lists", "Suppression Lists",
            "Step #", "Branch Path", "Type", "Label",
            "Wait Time", "Match Type", "Rules", "Actions",
        ])
        for prog in results:
            steps = prog.get("steps", [])
            if not steps:
                # Still write one row for programs with no steps
                w.writerow([
                    prog["id"], prog["name"], prog["id"], prog["status"],
                    prog["last_updated"], prog["description"],
                    prog["entry_lists"], prog["suppression_lists"],
                    "", "", "", "", "", "", "", "",
                ])
                continue

            for i, step in enumerate(steps):
                w.writerow([
                    prog["id"] if i == 0 else "",
                    prog["name"] if i == 0 else "",
                    prog["id"] if i == 0 else "",
                    prog["status"] if i == 0 else "",
                    prog["last_updated"] if i == 0 else "",
                    prog["description"] if i == 0 else "",
                    prog["entry_lists"] if i == 0 else "",
                    prog["suppression_lists"] if i == 0 else "",
                    step["step"],
                    step["branch_path"],
                    step["designation"],
                    step["label"],
                    format_timeout(step["timeout"]),
                    step["match_type"],
                    format_rules(step["rules"]),
                    format_actions(step["actions"]),
                ])

    print(f"✅ Saved {OUTPUT_CSV}")

# ── Run (browser-agnostic entry point) ───────────────────────────────────────

def run(page):
    """Discover, fetch, and export — no browser lifecycle management."""
    global OUTPUT_JSON, OUTPUT_CSV, SCREENSHOTS
    OUTPUT_JSON = utils.output_path("pardot_engagement_studio.json")
    OUTPUT_CSV  = utils.output_path("pardot_engagement_studio.csv")
    SCREENSHOTS = utils.output_path("screenshots", "engagement_studio")
    utils.reset_screenshots(SCREENSHOTS)
    programs = discover_programs(page)

    if not programs:
        print("❌ No Engagement Studio programs found.")
        return

    results = []
    print(f"🔍 Scraping {len(programs)} program(s)...\n")
    for prog in programs:
        print(f"   ▶  {prog['name']} (id: {prog['id']})")
        result = process_program(page, prog["id"], prog["name"])
        if result:
            step_count = len(result["steps"])
            print(f"      ✅ {step_count} step(s), status: {result['status']}")
            results.append(result)
        else:
            print(f"      ⚠️  Could not fetch program data")
        time.sleep(0.5)

    export_json(results)
    export_csv(results)

    print(f"\n── Summary ───────────────────────────────────────")
    for r in results:
        print(f"\n📋 {r['name']} (id: {r['id']}) — {r['status']}")
        if r["entry_lists"]:
            print(f"   Entry: {r['entry_lists'].replace(chr(10), ', ')}")
        for step in r["steps"]:
            indent = "      " if step["branch_path"] else "   "
            path   = f"[{step['branch_path']}] " if step["branch_path"] else ""
            wait   = f" (wait {format_timeout(step['timeout'])})" if step["timeout"] else ""
            print(f"{indent}{step['step']}. {path}{step['label']}{wait}")

    print(f"\n📸 Screenshots: {SCREENSHOTS}/")

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    utils.load_org_config()
    if not utils.SF_USERNAME:
        print("❌ Missing SF_USERNAME in .env")
        sys.exit(1)

    print("\n🚀 Pardot Engagement Studio Scraper")
    print("=" * 45)

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            wait_for_login(page)
            run(page)
        finally:
            context.close()

if __name__ == "__main__":
    main()
