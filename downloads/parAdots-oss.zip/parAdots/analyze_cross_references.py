"""
Pardot Cross-Reference Analyzer
=================================
Reads all pardot_*.json output files and builds a bidirectional dependency map:

  - Which automations reference each list? (dynamic AND static — both are
    merged into one lookup; static lists used to be invisible here entirely)
  - Which programs reference each list (entry / suppression)?
  - Which automations reference each form?
  - Which campaigns are linked to which forms/form handlers/sent emails —
    via the scraper's own `campaign` field on each asset, not text-guessing
  - Which dynamic content blocks are conditioned on a field that no longer
    exists (`based_on` validated against pardot_fields.json)
  - Orphan detection: lists, automations, forms, campaigns, and dynamic
    content not referenced by / linked to anything

Output:
  pardot_cross_references.json   — full dependency map
  pardot_cross_references.csv    — flat table for Excel

Usage:
  python3 analyze_cross_references.py               # uses .active-org
  python3 set_org.py --org <org> && python3 analyze_cross_references.py

Run this BEFORE analyze_best_practices.py so its "orphaned_assets" check
picks up the empty-campaign and broken-dynamic-content findings too.

No browser / login required — reads existing JSON exports only.

Known limitation: automation/program list & email references are still
extracted with regex against the scraper's raw page-text sections (there
are no structured IDs in that data), matched against Pardot's actual UI
wording ("Add prospect to list", "Remove prospect from list", "Prospect is
on list X", "Send prospect email" — verified against real scraped output,
not assumed). A list that is only ever used as a List Email recipient list
will still show up as an orphan: pardot_sent_emails.json does not capture
which list a send went to, so that link is invisible to this script until
the scraper is extended to capture it.
"""

import csv
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime

import utils

BASE_DIR = os.path.dirname(__file__)   # overridden in main() to utils.OUTPUT_DIR


def _load(filename):
    path = os.path.join(BASE_DIR, filename)
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _name(item):
    return item.get("name") or item.get("id", "unknown")


# ── Normalize list references ─────────────────────────────────────────────────

def _extract_list_refs_from_text(text):
    """
    Pull list names mentioned in a block of text.

    The original pattern set (`Add to list:`, `Remove from list:`, ...) was
    written against a generic/assumed Pardot vocabulary and silently matched
    almost nothing against this project's actual scraped automation-rule text,
    where Pardot's own UI uses different verbs (confirmed against real
    output/globex/pardot_automation_rules.json): "Add prospect to list",
    "Remove prospect from list" (tab-separated action lines), and
    "Prospect list" / "Prospect is on list X" for rule conditions. Both the
    original and the verified real-world patterns are kept since the scraper
    has been tweaked between projects and other orgs may still emit the
    original wording in some sections.
    """
    refs = []
    if not text:
        return refs
    patterns = [
        r"Add to list[:\s]+([^\n,]+)",
        r"Remove from list[:\s]+([^\n,]+)",
        r"List membership[:\s]+([^\n,]+)",
        r"Add prospect to list[:\t\s]+([^\n,]+)",
        r"Remove prospect from list[:\t\s]+([^\n,]+)",
        r"Prospect is on list\s+([^\n,]+?)(?=\s+Prospect|\s*$)",
        r"list \"([^\"]+)\"",
        r"list '([^']+)'",
    ]
    for p in patterns:
        for m in re.finditer(p, text, re.IGNORECASE):
            ref = m.group(1).strip().strip('"\'')
            if ref:
                refs.append(ref)
    return refs


def _extract_form_refs_from_text(text):
    """Pull form names mentioned in a block of text."""
    refs = []
    if not text:
        return refs
    patterns = [
        r"Form submission[:\s]+([^\n,]+)",
        r"Submits form[:\s]+([^\n,]+)",
        r"Prospect submitted form[:\t\s]+([^\n,]+)",
        r"form \"([^\"]+)\"",
    ]
    for p in patterns:
        for m in re.finditer(p, text, re.IGNORECASE):
            ref = m.group(1).strip().strip('"\'')
            if ref:
                refs.append(ref)
    return refs


def _extract_email_refs_from_text(text):
    """
    Pull email / template names mentioned in a block of text.

    Real automation-rule action text uses "Send prospect email\t<Template>",
    not the originally-assumed "Send email:" / "Autoresponder:" — see note on
    `_extract_list_refs_from_text` above. Both are matched.
    """
    refs = []
    if not text:
        return refs
    patterns = [
        r"Send email[:\s]+([^\n]+)",
        r"Send prospect email[:\t\s]+([^\n]+)",
        r"Autoresponder[:\s]+([^\n]+)",
        r"email \"([^\"]+)\"",
    ]
    for p in patterns:
        for m in re.finditer(p, text, re.IGNORECASE):
            ref = m.group(1).strip().strip('"\'')
            if ref and len(ref) < 120:
                refs.append(ref)
    return refs


# ── Build reference index ─────────────────────────────────────────────────────

def build_cross_references():
    print("📂 Loading scraped Pardot data...")

    dyn_lists    = _load("pardot_dynamic_lists.json") or []
    static_lists = _load("pardot_static_lists.json") or []
    automations  = _load("pardot_automation_rules.json") or []
    forms        = _load("pardot_forms.json") or []
    formhandlers = _load("pardot_formhandlers.json") or []
    programs     = _load("pardot_engagement_studio.json") or []
    dyn_content  = _load("pardot_dynamic_content.json") or []
    fields       = _load("pardot_fields.json") or []
    emails       = _load("pardot_email_templates.json") or []
    sent_emails  = _load("pardot_sent_emails.json") or []
    campaigns    = _load("pardot_campaigns.json") or []

    # "lists" used to mean dynamic lists only — static lists were invisible to
    # orphan/reference detection entirely. Tag each with its kind and merge so
    # both participate in the same reference map and orphan checks below.
    lists = (
        [{**l, "_kind": "dynamic"} for l in dyn_lists]
        + [{**l, "_kind": "static"} for l in static_lists]
    )

    print(f"   Lists: {len(lists)} ({len(dyn_lists)} dynamic, {len(static_lists)} static), "
          f"Automations: {len(automations)}, "
          f"Forms: {len(forms)}, FH: {len(formhandlers)}, "
          f"Programs: {len(programs)}, DynContent: {len(dyn_content)}, "
          f"Campaigns: {len(campaigns)}")

    # Build lookup: list name → list id
    list_by_name = {l.get("name", "").lower(): l.get("id", "") for l in lists}
    list_by_id   = {str(l.get("id", "")): l.get("name", "") for l in lists}
    form_by_name = {f.get("name", "").lower(): f.get("id", "") for f in forms}
    email_by_name = {e.get("name", "").lower(): e.get("id", "") for e in emails}

    all_field_names = set()
    for obj in fields:
        for f in obj.get("fields", []):
            n = f.get("name", "")
            if n:
                all_field_names.add(n.lower())

    # ref maps: key = list/form/email name, value = list of referencing assets
    list_refs    = defaultdict(list)   # list_name → [{type, id, name}]
    form_refs    = defaultdict(list)   # form_name → [{type, id, name}]
    email_refs   = defaultdict(list)   # email_name → [{type, id, name}]
    field_refs   = defaultdict(list)   # field_name → [{type, id, name}]

    # Track which assets DO reference something (for orphan detection)
    referenced_list_names  = set()
    referenced_form_names  = set()
    referenced_email_names = set()

    # ── Automations ───────────────────────────────────────────────────────────
    for auto in automations:
        auto_ref = {"type": "automation", "id": auto.get("id"), "name": auto.get("name")}
        secs = auto.get("sections", {})
        all_text = " ".join([
            secs.get("content", ""),
            secs.get("rules", ""),
            secs.get("actions", ""),
        ])
        for lname in _extract_list_refs_from_text(all_text):
            list_refs[lname].append(auto_ref)
            referenced_list_names.add(lname.lower())
        for fname in _extract_form_refs_from_text(all_text):
            form_refs[fname].append(auto_ref)
            referenced_form_names.add(fname.lower())
        for ename in _extract_email_refs_from_text(all_text):
            email_refs[ename].append(auto_ref)
            referenced_email_names.add(ename.lower())

    # ── Engagement Studio Programs ────────────────────────────────────────────
    for prog in programs:
        prog_ref = {"type": "program", "id": prog.get("id"), "name": prog.get("name")}
        for lname in prog.get("entry_lists", []):
            list_refs[lname].append({**prog_ref, "role": "entry_list"})
            referenced_list_names.add(lname.lower())
        for lname in prog.get("suppression_lists", []):
            list_refs[lname].append({**prog_ref, "role": "suppression_list"})
            referenced_list_names.add(lname.lower())
        # Also scan step actions
        for step in prog.get("steps", []):
            step_text = " ".join([
                str(step.get("actions", "")),
                str(step.get("rules", "")),
                str(step.get("label", "")),
            ])
            for lname in _extract_list_refs_from_text(step_text):
                list_refs[lname].append({**prog_ref, "role": "step_action"})
                referenced_list_names.add(lname.lower())
            for ename in _extract_email_refs_from_text(step_text):
                email_refs[ename].append({**prog_ref, "role": "step_action"})
                referenced_email_names.add(ename.lower())

    # ── Forms — completion actions reference lists and emails ─────────────────
    for form in forms:
        form_ref = {"type": "form", "id": form.get("id"), "name": form.get("name")}
        completion_text = str(form.get("completion_actions", ""))
        for lname in _extract_list_refs_from_text(completion_text):
            list_refs[lname].append(form_ref)
            referenced_list_names.add(lname.lower())
        for ename in _extract_email_refs_from_text(completion_text):
            email_refs[ename].append(form_ref)
            referenced_email_names.add(ename.lower())

    # ── Form Handlers ─────────────────────────────────────────────────────────
    for fh in formhandlers:
        fh_ref = {"type": "form_handler", "id": fh.get("id"), "name": fh.get("name")}
        fh_text = str(fh.get("completion_actions", "")) + " " + str(fh.get("field_mappings", ""))
        for lname in _extract_list_refs_from_text(fh_text):
            list_refs[lname].append(fh_ref)
            referenced_list_names.add(lname.lower())
        for ename in _extract_email_refs_from_text(fh_text):
            email_refs[ename].append(fh_ref)
            referenced_email_names.add(ename.lower())

    # ── Campaigns — structured (no regex): forms, form handlers, and sent ──────
    # emails all carry a direct `campaign` field from the scraper. Cross-checking
    # that field against Pardot's own campaign records (instead of guessing from
    # free text) tells us which assets have no campaign attribution at all, and
    # which campaigns in Pardot have zero linked assets (dead/unused campaigns).
    campaign_by_name = {c.get("name", "").lower(): c.get("id", "") for c in campaigns}
    campaign_refs = defaultdict(list)   # campaign_name → [{type, id, name}]

    def _link_campaign(asset, asset_type):
        camp_name = str(asset.get("campaign", "")).strip()
        if camp_name and camp_name.lower() not in ("none", "null", "n/a"):
            campaign_refs[camp_name].append(
                {"type": asset_type, "id": asset.get("id"), "name": asset.get("name")}
            )
        return camp_name

    forms_without_campaign = [
        {"id": f.get("id"), "name": f.get("name")}
        for f in forms if not _link_campaign(f, "form")
    ]
    formhandlers_without_campaign = [
        {"id": fh.get("id"), "name": fh.get("name")}
        for fh in formhandlers if not _link_campaign(fh, "form_handler")
    ]
    sent_emails_without_campaign = [
        {"id": e.get("id"), "name": e.get("name")}
        for e in sent_emails if not _link_campaign(e, "list_email")
    ]

    referenced_campaign_names = {n.lower() for n in campaign_refs}
    empty_campaigns = [
        {"id": c.get("id"), "name": c.get("name")}
        for c in campaigns
        if c.get("name", "").lower() not in referenced_campaign_names
        and int(str(c.get("linked_assets_total", 0)) or 0) == 0
    ]

    # ── Dynamic Content — validate `based_on` against actual field names ───────
    # Each dynamic content block is conditioned on a prospect field
    # ("Custom Field: Optin Double ACM PL"). If that field no longer exists in
    # the current field export, the personalization is silently broken
    # (Pardot falls back to default_content for everyone) — a real functional
    # gap the old text-only cross-reference couldn't see since it never read
    # pardot_dynamic_content.json or pardot_fields.json at all.
    dyn_content_broken_field_ref = []
    for dc in dyn_content:
        based_on = str(dc.get("based_on", ""))
        field_part = based_on.split(":", 1)[-1].strip().lower() if ":" in based_on else based_on.strip().lower()
        if field_part and all_field_names and field_part not in all_field_names:
            field_refs[field_part].append(
                {"type": "dynamic_content", "id": dc.get("id"), "name": dc.get("name"), "role": "broken_based_on"}
            )
            dyn_content_broken_field_ref.append(
                {"id": dc.get("id"), "name": dc.get("name"), "based_on": based_on}
            )

    # ── Orphan Detection ──────────────────────────────────────────────────────
    orphan_lists = [
        {"id": l.get("id"), "name": l.get("name"), "kind": l.get("_kind", "dynamic")}
        for l in lists
        if l.get("name", "").lower() not in referenced_list_names
    ]

    paused_automations = [
        {"id": a.get("id"), "name": a.get("name")}
        for a in automations
        if "paused" in str(a.get("status", "")).lower()
        or "paused" in str(a.get("sections", {}).get("content", "")).lower()
    ]

    forms_no_actions = [
        {"id": f.get("id"), "name": f.get("name")}
        for f in forms
        if not f.get("completion_actions") or str(f.get("completion_actions", "")).strip() in ("", "[]", "{}")
    ]

    orphan_emails = [
        {"id": e.get("id"), "name": e.get("name")}
        for e in emails
        if e.get("name", "").lower() not in referenced_email_names
    ]

    # ── Assemble output ───────────────────────────────────────────────────────
    cross_ref = {
        "generated_at": datetime.now().isoformat(),
        "summary": {
            "total_lists": len(lists),
            "total_dynamic_lists": len(dyn_lists),
            "total_static_lists": len(static_lists),
            "total_automations": len(automations),
            "total_forms": len(forms),
            "total_form_handlers": len(formhandlers),
            "total_programs": len(programs),
            "total_email_templates": len(emails),
            "total_sent_emails": len(sent_emails),
            "total_campaigns": len(campaigns),
            "total_dynamic_content": len(dyn_content),
            "orphan_lists_count": len(orphan_lists),
            "paused_automations_count": len(paused_automations),
            "forms_without_completion_actions": len(forms_no_actions),
            "forms_without_campaign_count": len(forms_without_campaign),
            "formhandlers_without_campaign_count": len(formhandlers_without_campaign),
            "sent_emails_without_campaign_count": len(sent_emails_without_campaign),
            "empty_campaigns_count": len(empty_campaigns),
            "dyn_content_broken_field_ref_count": len(dyn_content_broken_field_ref),
        },
        "list_references": {
            name: refs for name, refs in sorted(list_refs.items())
        },
        "form_references": {
            name: refs for name, refs in sorted(form_refs.items())
        },
        "email_references": {
            name: refs for name, refs in sorted(email_refs.items())
        },
        "campaign_references": {
            name: refs for name, refs in sorted(campaign_refs.items())
        },
        "field_references": {
            name: refs for name, refs in sorted(field_refs.items())
        },
        "orphans": {
            "lists_not_referenced_anywhere": orphan_lists,
            "paused_automations": paused_automations,
            "forms_without_completion_actions": forms_no_actions,
            "email_templates_not_referenced": orphan_emails,
            "forms_without_campaign": forms_without_campaign,
            "formhandlers_without_campaign": formhandlers_without_campaign,
            "sent_emails_without_campaign": sent_emails_without_campaign,
            "campaigns_with_no_linked_assets": empty_campaigns,
            "dynamic_content_with_broken_field_reference": dyn_content_broken_field_ref,
        },
    }

    return cross_ref


# ── Export CSV ────────────────────────────────────────────────────────────────

def export_csv(cross_ref):
    rows = []

    for list_name, refs in cross_ref["list_references"].items():
        for ref in refs:
            rows.append([
                "list", list_name, ref["type"], ref.get("id", ""),
                ref.get("name", ""), ref.get("role", "reference"),
            ])

    for form_name, refs in cross_ref["form_references"].items():
        for ref in refs:
            rows.append([
                "form", form_name, ref["type"], ref.get("id", ""),
                ref.get("name", ""), ref.get("role", "reference"),
            ])

    for email_name, refs in cross_ref["email_references"].items():
        for ref in refs:
            rows.append([
                "email_template", email_name, ref["type"], ref.get("id", ""),
                ref.get("name", ""), ref.get("role", "reference"),
            ])

    for campaign_name, refs in cross_ref["campaign_references"].items():
        for ref in refs:
            rows.append([
                "campaign", campaign_name, ref["type"], ref.get("id", ""),
                ref.get("name", ""), ref.get("role", "reference"),
            ])

    for field_name, refs in cross_ref["field_references"].items():
        for ref in refs:
            rows.append([
                "field", field_name, ref["type"], ref.get("id", ""),
                ref.get("name", ""), ref.get("role", "reference"),
            ])

    # Orphan rows
    for item in cross_ref["orphans"]["lists_not_referenced_anywhere"]:
        rows.append(["list", item["name"], "ORPHAN", item["id"], "", f"not referenced ({item.get('kind', 'dynamic')})"])

    for item in cross_ref["orphans"]["paused_automations"]:
        rows.append(["automation", item["name"], "PAUSED", item["id"], "", "paused"])

    for item in cross_ref["orphans"]["forms_without_completion_actions"]:
        rows.append(["form", item["name"], "NO_ACTIONS", item["id"], "", "no completion actions"])

    for item in cross_ref["orphans"]["forms_without_campaign"]:
        rows.append(["form", item["name"], "NO_CAMPAIGN", item["id"], "", "no campaign attribution"])

    for item in cross_ref["orphans"]["formhandlers_without_campaign"]:
        rows.append(["form_handler", item["name"], "NO_CAMPAIGN", item["id"], "", "no campaign attribution"])

    for item in cross_ref["orphans"]["sent_emails_without_campaign"]:
        rows.append(["list_email", item["name"], "NO_CAMPAIGN", item["id"], "", "no campaign attribution"])

    for item in cross_ref["orphans"]["campaigns_with_no_linked_assets"]:
        rows.append(["campaign", item["name"], "EMPTY", item["id"], "", "no linked assets"])

    for item in cross_ref["orphans"]["dynamic_content_with_broken_field_reference"]:
        rows.append(["dynamic_content", item["name"], "BROKEN_FIELD_REF", item["id"], item.get("based_on", ""), "based_on field not found"])

    with open(utils.output_path("pardot_cross_references.csv"), "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(["Asset Type", "Asset Name", "Referenced By Type",
                         "Referenced By ID", "Referenced By Name", "Role / Status"])
        writer.writerows(rows)
    print("   ✅ CSV  saved to pardot_cross_references.csv")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    global BASE_DIR
    if not utils.OUTPUT_DIR:
        utils.load_org_config()
    BASE_DIR = utils.OUTPUT_DIR

    print("\n🔗 Pardot Cross-Reference Analyzer")
    print("=" * 45)
    print("Reads existing JSON exports — no browser required.\n")

    cross_ref = build_cross_references()

    with open(utils.output_path("pardot_cross_references.json"), "w", encoding="utf-8") as f:
        json.dump(cross_ref, f, indent=2, ensure_ascii=False)
    print("   ✅ JSON saved to pardot_cross_references.json")

    export_csv(cross_ref)

    s = cross_ref["summary"]
    o = cross_ref["orphans"]
    print(f"\n── Summary ──────────────────────────────────────")
    print(f"   Lists:              {s['total_lists']}  ({s['total_dynamic_lists']} dynamic, "
          f"{s['total_static_lists']} static · {s['orphan_lists_count']} orphans)")
    print(f"   Automations:        {s['total_automations']}  ({s['paused_automations_count']} paused)")
    print(f"   Forms:              {s['total_forms']}  ({s['forms_without_completion_actions']} no actions, "
          f"{s['forms_without_campaign_count']} no campaign)")
    print(f"   Form Handlers:      {s['total_form_handlers']}  ({s['formhandlers_without_campaign_count']} no campaign)")
    print(f"   Programs:           {s['total_programs']}")
    print(f"   Email Templates:    {s['total_email_templates']}")
    print(f"   Sent Emails:        {s['total_sent_emails']}  ({s['sent_emails_without_campaign_count']} no campaign)")
    print(f"   Campaigns:          {s['total_campaigns']}  ({s['empty_campaigns_count']} with no linked assets)")
    print(f"   Dynamic Content:    {s['total_dynamic_content']}  ({s['dyn_content_broken_field_ref_count']} broken field reference)")
    print(f"\n⚠️  Orphan lists (not referenced by anything):")
    for item in o["lists_not_referenced_anywhere"][:10]:
        print(f"   • [{item.get('kind', 'dynamic')}] {item['name']} (id: {item['id']})")
    if len(o["lists_not_referenced_anywhere"]) > 10:
        print(f"   ... and {len(o['lists_not_referenced_anywhere']) - 10} more")
    if o["dynamic_content_with_broken_field_reference"]:
        print(f"\n⚠️  Dynamic content with a broken field reference:")
        for item in o["dynamic_content_with_broken_field_reference"][:10]:
            print(f"   • {item['name']} → based_on: {item['based_on']}")
    print(f"\n✅ Cross-reference analysis complete.")


if __name__ == "__main__":
    main()
