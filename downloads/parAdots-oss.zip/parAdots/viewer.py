#!/usr/bin/env python3
"""
Pardot Asset Viewer  —  local audit dashboard
Run:  python3 viewer.py
Opens: http://localhost:8765
"""

import http.server
import logging
import socketserver
import webbrowser
import threading
import subprocess
import json
import csv
import datetime
import shutil
import base64
import uuid
import tempfile
import urllib.request as _ureq
from pathlib import Path
from urllib.parse import urlparse, unquote

logger = logging.getLogger(__name__)

# Process analysis — import lazily to avoid startup cost
def _analyze_processes(org):
    import importlib.util, sys as _sys
    spec = importlib.util.spec_from_file_location('analyze_processes', BASE / 'analyze_processes.py')
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    processes = mod.analyze_org(org)
    status    = mod.load_status(org)
    return mod.merge_status(processes, status), mod

def _load_process_status(org) -> dict:
    path = BASE / 'output' / org / 'process_status.json'
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}

def _write_process_status(org, data: dict):
    path = BASE / 'output' / org / 'process_status.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')

def _board_state_path(org):
    return BASE / 'output' / org / 'board_state.json'

def _board_state_prev_path(org):
    return BASE / 'output' / org / 'board_state.prev.json'

def _load_board_state(org):
    path = _board_state_path(org)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, OSError):
        return {}

def _write_board_state(org, data):
    org_dir = BASE / 'output' / org
    org_dir.mkdir(parents=True, exist_ok=True)
    path = _board_state_path(org)
    prev_path = _board_state_prev_path(org)

    # Rotation: bestehenden Stand als Backup sichern, bevor überschrieben wird.
    # Best-effort — ein fehlgeschlagenes Backup darf den eigentlichen Save nicht blockieren.
    if path.exists():
        try:
            path.replace(prev_path)
        except OSError:
            pass

    # Atomarer Write: erst in tmp-Datei im selben Verzeichnis (gleiches Filesystem,
    # damit os.replace/Path.replace als POSIX-rename wirklich atomar ist), dann rename.
    fd, tmp_name = tempfile.mkstemp(dir=org_dir, suffix='.tmp')
    tmp_path = Path(tmp_name)
    try:
        with open(fd, 'w', encoding='utf-8') as f:
            f.write(json.dumps(data, ensure_ascii=False, indent=2))
        tmp_path.replace(path)
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise

def _save_process_status(org, proc_id, comp_key, user_status):
    """Persistiert einen User-Status für eine Prozess-Komponente."""
    data = _load_process_status(org)
    if proc_id not in data:
        data[proc_id] = {}
    if user_status is None:
        data[proc_id].pop(comp_key, None)
    else:
        data[proc_id][comp_key] = user_status
    _write_process_status(org, data)

def _verify_process(org, proc_id, verified_comp_keys: list, excluded_comp_keys: list):
    """Speichert verifizierten Prozessstand."""
    data = _load_process_status(org)
    if proc_id not in data:
        data[proc_id] = {}
    data[proc_id]['_verified']       = True
    data[proc_id]['_verified_at']    = datetime.datetime.now().isoformat()
    data[proc_id]['_verified_comps'] = verified_comp_keys
    data[proc_id]['_excluded_comps'] = excluded_comp_keys
    _write_process_status(org, data)

def _unverify_process(org, proc_id):
    data = _load_process_status(org)
    if proc_id in data:
        data[proc_id].pop('_verified',       None)
        data[proc_id].pop('_verified_at',    None)
        data[proc_id].pop('_verified_comps', None)
        data[proc_id].pop('_excluded_comps', None)
    _write_process_status(org, data)

def _load_org_assets(org: str) -> list:
    """Gibt eine vereinfachte Liste aller Pardot-Assets für den Asset-Picker zurück."""
    base = BASE / 'output' / org
    assets = []
    _type_map = [
        ('pardot_formhandlers.json',     'formhandler',     'prospect_count'),
        ('pardot_dynamic_lists.json',    'dynamic_list',    'prospect_count'),
        ('pardot_static_lists.json',     'static_list',     'prospect_count'),
        ('pardot_automation_rules.json', 'automation_rule', None),
        ('pardot_engagement_studio.json','es',              None),
        ('pardot_email_templates.json',  'email',           None),
        ('pardot_landing_pages.json',    'landing_page',    None),
    ]
    for fname, atype, pc_key in _type_map:
        fpath = base / fname
        if not fpath.exists():
            continue
        try:
            rows = json.loads(fpath.read_text(encoding='utf-8'))
        except Exception:
            continue
        for r in rows:
            a = {'type': atype, 'id': str(r.get('id', '')), 'name': str(r.get('name', ''))}
            if pc_key:
                pc = r.get(pc_key, 0)
                try:
                    a['prospect_count'] = int(pc)
                except (ValueError, TypeError):
                    a['prospect_count'] = 0
            assets.append(a)
    return assets

def _merge_added_comps(processes: list, org: str) -> list:
    """Fügt manuell vom User hinzugefügte Komponenten in jeden Prozess ein."""
    status = _load_process_status(org)
    for proc in processes:
        added = status.get(proc.get('id', ''), {}).get('_added_comps', [])
        if not added:
            continue
        existing_keys = {f"{c['type']}_{c['id']}" for c in proc.get('components', [])}
        for ac in added:
            k = f"{ac['type']}_{ac['id']}"
            if k not in existing_keys:
                proc['components'].append({
                    'type':          ac['type'],
                    'id':            str(ac['id']),
                    'name':          ac.get('name', ''),
                    'found_via':     'user_added',
                    'prospect_count': ac.get('prospect_count', 0),
                })
                existing_keys.add(k)
        proc['added_comps'] = added   # für Reset-Tracking im Frontend
    return processes


def _merge_user_processes(processes: list, org: str) -> list:
    """Fügt vom User manuell erstellte Prozesse (aus process_status.json) ein."""
    status = _load_process_status(org)
    user_procs = status.get('_user_processes', [])
    existing_ids = {p.get('id') for p in processes}
    for up in user_procs:
        if up.get('id') not in existing_ids:
            processes.append(up)
    return processes

BASE   = Path(__file__).parent
PORT   = 8765
ACTIVE = BASE / '.active-org'
CFGS   = BASE / 'configs'

SENSITIVE = {'SF_PASSWORD', 'SF_CLIENT_SECRET'}
MASK      = '••••••'

SECTIONS = [
    'automation_rules', 'engagement_studio', 'formhandlers', 'forms',
    'dynamic_lists', 'static_lists', 'fields', 'campaigns',
    'email_templates', 'sent_emails', 'list_emails', 'dynamic_content',
    'scoring_rules', 'custom_redirects', 'profiles',
    'landing_pages', 'page_actions', 'snippets', 'files',
    'preference_center', 'users', 'folders',
]


# ── scrape state ──────────────────────────────────────────────────────────────

_scrape_lock = threading.Lock()
_scrape = {
    'running':     False,
    'org':         None,
    'lines':       [],       # last 500 log lines
    'returncode':  None,     # None while running
    'started_at':  None,
    'finished_at': None,
}

def _venv_python():
    """Return the venv python if it exists, else fall back to python3."""
    venv = BASE / '.venv' / 'bin' / 'python3'
    return str(venv) if venv.exists() else 'python3'

def _run_scrape(org):
    """Background thread: run run_all.py and buffer stdout."""
    proc = subprocess.Popen(
        [_venv_python(), str(BASE / 'run_all.py'), '--org', org],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, cwd=str(BASE), bufsize=1
    )
    for raw_line in proc.stdout:
        line = raw_line.rstrip()
        with _scrape_lock:
            _scrape['lines'].append(line)
            if len(_scrape['lines']) > 500:
                _scrape['lines'] = _scrape['lines'][-500:]
    proc.wait()
    with _scrape_lock:
        _scrape['running']     = False
        _scrape['returncode']  = proc.returncode
        _scrape['finished_at'] = datetime.datetime.now().isoformat(timespec='seconds')

def start_scrape(org):
    with _scrape_lock:
        if _scrape['running']:
            return False, 'A scrape is already running.'
        _scrape.update({
            'running':     True,
            'org':         org,
            'lines':       [f'Starting full scrape for org: {org}'],
            'returncode':  None,
            'started_at':  datetime.datetime.now().isoformat(timespec='seconds'),
            'finished_at': None,
        })
    t = threading.Thread(target=_run_scrape, args=(org,), daemon=True)
    t.start()
    return True, 'started'

def scrape_status():
    with _scrape_lock:
        return dict(_scrape)   # shallow copy — safe for JSON


# ── per-job runner (cockpit) ──────────────────────────────────────────────────

# Registry of all runnable jobs: key → (label, script_file, extra_args)
JOBS = {
    # ── Full suite ──────────────────────────────────────────────────────────
    'run_all':          ('Run All (Pardot + SF)',    'run_all.py',                    []),
    'run_pardot_only':  ('Run Pardot Only',          'run_all.py',                    ['--no-sf']),
    # ── Pardot scrapers ────────────────────────────────────────────────────
    'dynamic_lists':    ('Dynamic Lists',            'scrape_dynamic_lists.py',       []),  # actually scraper.py for standalone? use scrape_dynamic_lists
    'static_lists':     ('Static Lists',              'scrape_static_lists.py',        []),  # single authoritative static-list scraper
    'automations':      ('Automation Rules',         'scrape_automations.py',         []),
    'automation_status':('Automation Status',        'fetch_automation_status.py',    []),
    'forms':            ('Forms',                    'scrape_forms.py',               []),
    'formhandlers':     ('Form Handlers',            'scrape_formhandlers_api.py',    []),
    'dynamic_content':  ('Dynamic Content',         'scrape_dynamic_content.py',     []),
    'engagement_studio':('Engagement Studio',        'scrape_engagement_studio.py',   []),
    'fields':           ('Field Settings',           'scrape_fields_api.py',          []),
    'email_templates':  ('Email Templates',          'scrape_email_templates_api.py', []),
    'landing_pages':    ('Landing Pages',            'scrape_landing_pages.py',       []),
    'scoring_rules':    ('Scoring Rules',            'scrape_scoring_rules.py',       []),
    'page_actions':     ('Page Actions',             'scrape_page_actions.py',        []),
    'custom_redirects': ('Custom Redirects',         'scrape_custom_redirects.py',    []),
    'campaigns':        ('Campaigns',                'scrape_campaigns_api.py',       []),
    'sent_emails':      ('Sent Emails',              'fetch_sent_emails_api.py',      []),
    'snippets':         ('Snippets',                 'scrape_snippets.py',            []),
    'layout_templates': ('Layout Templates',         'scrape_layout_templates.py',    []),
    'files':            ('Files',                    'scrape_files.py',               []),
    'list_memberships': ('List Memberships',         'scrape_list_memberships.py',    []),
    'prospect_stats':   ('Prospect Stats',           'scrape_prospect_stats.py',      []),
    'account_settings': ('Account Settings',         'scrape_account_settings.py',    []),
    'list_emails':      ('List Emails',              'scrape_list_emails.py',         []),
    'preference_center':('Preference Center',        'scrape_preference_center.py',   []),
    'users':            ('Users',                    'scrape_users.py',               []),
    'folders':          ('Folders',                  'scrape_folders.py',             []),
    'profiles':         ('Grading Profiles',         'scrape_profiles.py',            []),
    # ── Salesforce scrapers ────────────────────────────────────────────────
    'sf_campaigns':     ('SF: Campaign Members',     'scrape_sf_campaign_members.py', []),
    'sf_optin':         ('SF: Opt-In Sync Audit',    'scrape_sf_optin_sync_audit.py', []),
    'sf_leads':         ('SF: Lead Quality',         'scrape_sf_lead_quality.py',     []),
    'sf_opps':          ('SF: Opportunity Attr.',    'scrape_sf_opportunity_attribution.py', []),
    'sf_sync_errors':   ('SF: Sync Errors',          'scrape_sf_sync_errors.py',      []),
    'sf_fields':        ('SF: Field Mapping',        'scrape_sf_field_mapping.py',    []),
    'sf_accounts':      ('SF: Account Hierarchy',    'scrape_sf_account_hierarchy.py',[]),
    'sf_tasks':         ('SF: Task / Activity',      'scrape_sf_task_activity.py',    []),
    'sf_reports':       ('SF: Reports Inventory',    'scrape_sf_reports_inventory.py',[]),
    'sf_storage':       ('SF: Storage Usage',        'scrape_sf_storage_usage.py',   []),
    # ── Analysis & enrichment ──────────────────────────────────────────────
    'cross_refs':       ('Cross-Reference Analysis', 'analyze_cross_references.py',   []),
    'gap_analysis':     ('Best Practice Gap Report', 'analyze_best_practices.py',     []),
    'enrich':           ('Enrich Automations',       'enrich_automations.py',         []),
    # ── Visualize & report ─────────────────────────────────────────────────
    'drawio':           ('Generate Draw.io Diagrams','generate_drawio.py',            []),
    'report':           ('Generate HTML Report',     'generate_report.py',            []),
}

_jobs_lock = threading.Lock()
# job_key → {'running', 'returncode', 'lines', 'started_at', 'finished_at'}
_jobs: dict = {}


def _run_job(key, script, extra_args, org):
    proc = subprocess.Popen(
        [_venv_python(), str(BASE / script), '--org', org] + extra_args,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, cwd=str(BASE), bufsize=1
    )
    for raw_line in proc.stdout:
        line = raw_line.rstrip()
        with _jobs_lock:
            _jobs[key]['lines'].append(line)
            if len(_jobs[key]['lines']) > 500:
                _jobs[key]['lines'] = _jobs[key]['lines'][-500:]
    proc.wait()
    with _jobs_lock:
        _jobs[key]['running']     = False
        _jobs[key]['returncode']  = proc.returncode
        _jobs[key]['finished_at'] = datetime.datetime.now().isoformat(timespec='seconds')


def start_job(key, org):
    if key not in JOBS:
        return False, f'Unknown job: {key}'
    label, script, extra_args = JOBS[key]
    with _jobs_lock:
        if _jobs.get(key, {}).get('running'):
            return False, f'{label} is already running.'
        _jobs[key] = {
            'running':     True,
            'returncode':  None,
            'lines':       [f'▶ Starting: {label} (org: {org})'],
            'started_at':  datetime.datetime.now().isoformat(timespec='seconds'),
            'finished_at': None,
        }
    t = threading.Thread(target=_run_job, args=(key, script, extra_args, org), daemon=True)
    t.start()
    return True, 'started'


def all_job_statuses():
    with _jobs_lock:
        return {k: dict(v) for k, v in _jobs.items()}


def job_status(key):
    with _jobs_lock:
        return dict(_jobs.get(key, {}))


# ── CSV / config helpers ──────────────────────────────────────────────────────

def read_csv(path):
    try:
        with open(path, newline='', encoding='utf-8-sig') as f:
            rows = list(csv.DictReader(f))
        return [{k.strip('﻿').strip(): v for k, v in r.items()} for r in rows]
    except Exception as e:
        return [{'_error': str(e)}]

def list_orgs():
    if not CFGS.exists():
        return []
    return sorted(p.stem for p in CFGS.glob('*.env'))

def active_org():
    return ACTIVE.read_text().strip() if ACTIVE.exists() else ''

def read_config(name):
    path = CFGS / f'{name}.env'
    cfg = {}
    if path.exists():
        for line in path.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, _, v = line.partition('=')
                cfg[k.strip()] = v.strip()
    return cfg

def write_config(name, data):
    CFGS.mkdir(exist_ok=True)
    path = CFGS / f'{name}.env'
    lines = [f'{k}={v}' for k, v in data.items() if k and not k.startswith('#')]
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')

def mask_config(cfg):
    return {k: (MASK if k in SENSITIVE and v else v) for k, v in cfg.items()}

def list_screenshots():
    result = {}
    d = BASE / 'screenshots'
    if d.exists():
        for sub in sorted(d.iterdir()):
            if sub.is_dir():
                files = sorted(f.name for f in sub.iterdir()
                               if f.suffix.lower() in ('.png', '.jpg', '.jpeg'))
                if files:
                    result[sub.name] = files
    return result


# ── SF Explorer ───────────────────────────────────────────────────────────────

_sf_login_lock = threading.Lock()
_sf_login_state: dict = {}   # alias → {running, done, error, started_at, finished_at}


def _sf_cli():
    """Return path to sf or sfdx CLI, or None."""
    return shutil.which('sf') or shutil.which('sfdx')


def sf_list_orgs():
    cli = _sf_cli()
    if not cli:
        return None, 'SF CLI (sf/sfdx) nicht gefunden. Bitte installieren: brew install sf'
    try:
        r = subprocess.run([cli, 'org', 'list', '--json'],
                           capture_output=True, text=True, timeout=15)
        data = json.loads(r.stdout or '{}')
        orgs = []
        for section in ('nonScratchOrgs', 'scratchOrgs'):
            for o in data.get('result', {}).get(section, []):
                orgs.append({
                    'alias':           o.get('alias', ''),
                    'username':        o.get('username', ''),
                    'instanceUrl':     o.get('instanceUrl', ''),
                    'isExpired':       o.get('isExpired', False),
                    'connectedStatus': o.get('connectedStatus', ''),
                })
        return orgs, None
    except Exception as e:
        return None, str(e)


def sf_get_token(alias):
    """Return (access_token, instance_url, error).

    Reuses salesforce_api._cli_org_display() to avoid token-extraction duplication.
    """
    import salesforce_api as sfapi
    token, url, err = sfapi._cli_org_display(alias)
    if err:
        # Translate error messages to German for UI consistency
        err_de = err.replace('not found', 'nicht gefunden').replace('missing', 'fehlt')
        return None, None, err_de
    return token, url, None


def _sf_norm_url(u):
    """Normalize an instanceUrl for comparison."""
    u = (u or '').strip().rstrip('/')
    if u and not u.lower().startswith('http'):
        u = 'https://' + u
    return u.lower()


def _sf_resolve_alias(candidate):
    """Return candidate if sf_get_token succeeds for it, else None."""
    if not candidate:
        return None
    token, _, err = sf_get_token(candidate)
    return candidate if (token and not err) else None


def _run_sf_login(alias, instance_url):
    """Run sf org login web, then find the stored org via before/after snapshot."""
    cli = _sf_cli()
    now = lambda: datetime.datetime.now().isoformat(timespec='seconds')
    if instance_url and not instance_url.lower().startswith('http'):
        instance_url = 'https://' + instance_url

    # Snapshot usernames before login so we can detect the newly added org
    orgs_before, _ = sf_list_orgs()
    usernames_before = {o.get('username', '') for o in (orgs_before or [])}

    try:
        result = subprocess.run(
            [cli, 'org', 'login', 'web',
             '--instance-url', instance_url,
             '--alias', alias],
            capture_output=True, text=True, timeout=360
        )

        # 1. Try our generated alias first (works when no existing auth)
        resolved = _sf_resolve_alias(alias)

        # 2. Detect newly added org by comparing org lists before/after
        if not resolved:
            orgs_after, _ = sf_list_orgs()
            for o in (orgs_after or []):
                if o.get('username', '') not in usernames_before:
                    candidate = o.get('alias') or o.get('username')
                    resolved = _sf_resolve_alias(candidate)
                    if resolved:
                        break

        # 3. URL match fallback — only pick orgs whose token actually works
        if not resolved:
            resolved = _sf_find_org_by_url(instance_url)

        if resolved:
            with _sf_login_lock:
                _sf_login_state[alias].update({
                    'running': False, 'done': True, 'error': None,
                    'resolved_alias': resolved,
                    'finished_at': now(),
                })
        else:
            stderr = (result.stderr or '').strip()[:300]
            with _sf_login_lock:
                _sf_login_state[alias].update({
                    'running': False, 'done': False,
                    'error': f'Org nach Login nicht gefunden. sf stderr: {stderr}',
                    'finished_at': now(),
                })
    except subprocess.TimeoutExpired:
        with _sf_login_lock:
            _sf_login_state[alias].update({
                'running': False, 'done': False,
                'error': 'Timeout — Login nicht innerhalb von 6 Minuten abgeschlossen.',
                'finished_at': now(),
            })
    except Exception as e:
        with _sf_login_lock:
            _sf_login_state[alias].update({
                'running': False, 'done': False, 'error': str(e),
                'finished_at': now(),
            })


def _sf_find_org_by_url(instance_url):
    """Return alias/username of a connected org matching instanceUrl (verified via sf_get_token)."""
    orgs, _ = sf_list_orgs()
    if not orgs:
        return None
    host = _sf_norm_url(instance_url)
    # Sort: prefer Connected status, non-expired
    candidates = [
        o for o in orgs
        if _sf_norm_url(o.get('instanceUrl', '')) == host and not o.get('isExpired')
    ]
    candidates.sort(key=lambda o: (
        0 if 'connected' in o.get('connectedStatus', '').lower() else 1
    ))
    for o in candidates:
        candidate = o.get('alias') or o.get('username')
        resolved = _sf_resolve_alias(candidate)
        if resolved:
            return resolved
    return None


def _sf_run(args, timeout=60):
    """Run a SF CLI command, return (parsed_result, error_string)."""
    cli = _sf_cli()
    if not cli:
        return None, 'SF CLI nicht gefunden'
    try:
        r = subprocess.run(
            [cli] + args + ['--json'],
            capture_output=True, text=True, timeout=timeout
        )
        raw = (r.stdout or '').strip()
        if not raw:
            err = (r.stderr or '').strip()[:300]
            return None, f'Kein Output: {err}'
        data = json.loads(raw)
        if data.get('status', 0) != 0 or 'result' not in data:
            msg = data.get('message') or data.get('name') or raw[:300]
            return None, msg
        return data['result'], None
    except json.JSONDecodeError as e:
        return None, f'JSON-Fehler: {e}'
    except subprocess.TimeoutExpired:
        return None, 'Timeout'
    except Exception as e:
        return None, str(e)


# ── SF CLI layer — sobject list/describe ────────────────────────────────────────
#
# Never extract the Bearer token from sf org display and pass it to requests —
# orgs with enhanced session security or My Domain reject it (INVALID_AUTH_HEADER).
# Instead, delegate every API call to SF CLI subcommands which handle auth internally.

def _sf_run(args, timeout=60):
    """Run: sf <args> --json. Returns (result, error)."""
    cli = _sf_cli()
    if not cli:
        return None, 'SF CLI (sf/sfdx) nicht gefunden'
    try:
        r = subprocess.run(
            [cli] + args + ['--json'],
            capture_output=True, text=True, timeout=timeout
        )
        raw = (r.stdout or '').strip()
        if not raw:
            err = (r.stderr or '').strip()[:300]
            return None, f'Kein Output: {err}'
        data = json.loads(raw)
        if data.get('status', 0) != 0 or 'result' not in data:
            msg = data.get('message') or data.get('name') or raw[:300]
            return None, msg
        return data['result'], None
    except json.JSONDecodeError as e:
        return None, f'JSON-Fehler: {e}'
    except subprocess.TimeoutExpired:
        return None, 'Timeout'
    except Exception as e:
        return None, str(e)


def sf_sobject_list(alias):
    """List all SObjects via sf sobject list. Returns ({sobjects:[...]}, error)."""
    result, err = _sf_run(['sobject', 'list', '--target-org', alias])
    if err:
        return None, err
    names = result if isinstance(result, list) else []
    sobjects = [
        {
            'name':                  n,
            'label':                 n,
            'queryable':             True,
            'custom':                n.endswith('__c'),
            'isDeprecatedAndHidden': False,
        }
        for n in names if n
    ]
    return {'sobjects': sobjects}, None


def sf_sobject_describe(alias, sobject):
    """Describe one SObject via sf sobject describe. Returns (describe_dict, error)."""
    return _sf_run(
        ['sobject', 'describe', '--target-org', alias, '--sobject', sobject],
        timeout=30
    )


def sf_findings(org):
    """
    Aggregate per-SObject SF analysis findings (Punkt 3) so the Explorer graph
    can badge nodes with issues the scrapers already found. Reads the org's
    sf_field_mapping / sf_optin_sync_audit / sf_sync_errors JSONs.

    Returns {'objects': {SObject: {total, fieldIssues, optinGaps, syncErrors,
    details:[...]}}}. Missing files are tolerated silently.
    """
    base = BASE / 'output' / org
    objects = {}

    def bump(obj, kind, n, detail):
        if not obj:
            return
        e = objects.setdefault(obj, {
            'total': 0, 'fieldIssues': 0, 'optinGaps': 0, 'syncErrors': 0, 'details': [],
        })
        e[kind] += n
        e['total'] += n
        if detail:
            e['details'].append(detail)

    def _load(name):
        try:
            return json.loads((base / name).read_text(encoding='utf-8'))
        except Exception:
            return None

    # Field-mapping issues → Lead/Contact
    fm = _load('sf_field_mapping.json')
    if isinstance(fm, dict):
        for iss in fm.get('issues', []):
            fld = iss.get('field', '')
            txt = iss.get('issue', '') or ''
            low = txt.lower()
            hit_lead = 'lead' in low
            hit_cont = 'contact' in low
            if not hit_lead and not hit_cont:   # type/picklist drift → both
                hit_lead = hit_cont = True
            if hit_lead:
                bump('Lead', 'fieldIssues', 1, f'{fld}: {txt}')
            if hit_cont:
                bump('Contact', 'fieldIssues', 1, f'{fld}: {txt}')

    # Opt-in field gaps → Lead/Contact
    opt = _load('sf_optin_sync_audit.json')
    if isinstance(opt, list):
        for r in opt:
            of = r.get('optin_field', '')
            br = r.get('brand', '')
            if r.get('lead_field_exists') is False:
                bump('Lead', 'optinGaps', 1, f'Opt-in-Feld fehlt: {of} ({br})')
            if r.get('contact_field_exists') is False:
                bump('Contact', 'optinGaps', 1, f'Opt-in-Feld fehlt: {of} ({br})')

    # Sync errors → per-object if detailed, else attributed to Lead
    se = _load('sf_sync_errors.json')
    if isinstance(se, dict):
        details = se.get('error_event_details', []) or []
        placed = 0
        for det in details:
            obj = det.get('object') or det.get('sobject') or det.get('object_type')
            if obj:
                bump(obj, 'syncErrors', 1,
                     det.get('error') or det.get('message') or 'Sync-Fehler')
                placed += 1
        n = se.get('error_events', 0) or 0
        if n and placed == 0:
            bump('Lead', 'syncErrors', n,
                 f'{n} Sync-Fehler (letzte {se.get("lookback_days", "?")} Tage)')

    return {'objects': objects}


def sf_proxy(alias, path):
    """
    Route REST-style path to the appropriate SF CLI command.
    Never extracts or sends a Bearer token ourselves.
    """
    path = path.strip('/')

    if path == 'sobjects':
        return sf_sobject_list(alias)

    if path.startswith('sobjects/') and path.endswith('/describe'):
        sobject = path[len('sobjects/'):-len('/describe')]
        return sf_sobject_describe(alias, sobject)

    return None, f'Unbekannter SF-Pfad: {path}'


def _sf_proxy_legacy(access_token, instance_url, path):
    """Kept for reference — not called by current routes."""
    try:
        import requests as _req
        url = f"{instance_url}/services/data/v59.0/{path.lstrip('/')}"
        resp = _req.get(url, headers={'Authorization': 'Bearer ' + access_token,
                                      'Accept': 'application/json'}, timeout=30)
        if resp.status_code == 200:
            return resp.json(), None
        return None, f'HTTP {resp.status_code}: {resp.text[:300]}'
    except Exception as e:
        return None, str(e)


# ── HTTP handler ──────────────────────────────────────────────────────────────

class Handler(http.server.BaseHTTPRequestHandler):

    def do_GET(self):
        p = unquote(urlparse(self.path).path)

        if p in ('/', '/index.html'):
            self._file(BASE / 'viewer.html', 'text/html; charset=utf-8')

        elif p == '/api/orgs':
            self._json({'orgs': list_orgs(), 'active': active_org()})

        elif p == '/api/screenshots':
            self._json(list_screenshots())

        elif p.startswith('/api/assets/'):
            # GET /api/assets/<org>  → vereinfachte Asset-Liste für den Komponenten-Picker
            org = p[12:]
            if not org:
                self._err(400)
            else:
                self._json(_load_org_assets(org))

        elif p == '/api/scrape/status':
            self._json(scrape_status())

        elif p.startswith('/api/org/'):
            name = p[9:]
            self._json(mask_config(read_config(name)))

        elif p.startswith('/api/board-state/'):
            # GET /api/board-state/<org> → kompletter gesicherter localStorage-Snapshot der Org
            org = p[len('/api/board-state/'):]
            if not org:
                self._err(400)
            else:
                self._json(_load_board_state(org))

        elif p.startswith('/api/enriched/'):
            parts = p[14:].split('/', 1)
            if len(parts) == 2:
                org, etype = parts
                fname_map = {
                    'automation_rules':    'automation_rules_enriched.json',
                    'dynamic_lists':       'dynamic_lists_enriched.json',
                    'engagement_programs': 'engagement_programs_enriched.json',
                    'formhandlers':        'formhandlers_enriched.json',
                    'campaigns':           'campaigns_enriched.json',
                    'email_templates':     'email_templates_enriched.json',
                    'static_lists':        'static_lists_enriched.json',
                    'forms':               'forms_enriched.json',
                    'dynamic_content':     'dynamic_content_enriched.json',
                    'scoring_rules':       'scoring_rules_enriched.json',
                    'landing_pages':       'landing_pages_enriched.json',
                    'custom_redirects':    'custom_redirects_enriched.json',
                }
                fname = fname_map.get(etype)
                if fname:
                    fp = BASE / 'output' / org / 'enriched' / fname
                    self._json(json.loads(fp.read_text(encoding='utf-8')) if fp.exists() else [])
                else:
                    self._err(400)
            else:
                self._err(400)

        elif p.startswith('/api/section-meta/'):
            parts = p[18:].split('/', 1)
            if len(parts) == 2:
                org, section = parts
                fp = BASE / 'output' / org / f'pardot_{section}_meta.json'
                if fp.exists():
                    self._json(json.loads(fp.read_text(encoding='utf-8')))
                else:
                    self._json({})
            else:
                self._err(400)

        elif p.startswith('/api/data/'):
            parts = p[10:].split('/', 1)
            if len(parts) == 2:
                org, section = parts
                # Engagement Studio: serve rich JSON (has nested steps/rules/actions)
                if section == 'engagement_studio':
                    fp = BASE / 'output' / org / 'pardot_engagement_studio.json'
                    if fp.exists():
                        import json as _json
                        self._json(_json.loads(fp.read_text(encoding='utf-8')))
                    else:
                        self._json([])
                elif section == 'prospect_sync_errors':
                    rp = BASE / 'output' / org / 'pardot_prospect_sync_errors_resolved.csv'
                    fp = rp if rp.exists() else BASE / 'output' / org / 'pardot_prospect_sync_errors.csv'
                    self._json(read_csv(fp) if fp.exists() else [])
                else:
                    fp = BASE / 'output' / org / f'pardot_{section}.csv'
                    self._json(read_csv(fp) if fp.exists() else [])
            else:
                self._err(400)

        elif p.startswith('/api/csv/'):
            parts = p[9:].split('/', 1)
            if len(parts) == 2:
                org, section = parts
                if section == 'engagement_studio':
                    fp = BASE / 'output' / org / 'pardot_engagement_studio.json'
                    ct = 'application/json; charset=utf-8'
                    fname = f'{org}_{section}.json'
                elif section == 'prospect_sync_errors':
                    rp = BASE / 'output' / org / 'pardot_prospect_sync_errors_resolved.csv'
                    fp = rp if rp.exists() else BASE / 'output' / org / 'pardot_prospect_sync_errors.csv'
                    ct = 'text/csv; charset=utf-8'
                    fname = f'{org}_prospect_sync_errors.csv'
                else:
                    fp = BASE / 'output' / org / f'pardot_{section}.csv'
                    ct = 'text/csv; charset=utf-8'
                    fname = f'{org}_{section}.csv'
                if fp.exists():
                    data = fp.read_bytes()
                    self.send_response(200)
                    self.send_header('Content-Type', ct)
                    self.send_header('Content-Disposition', f'inline; filename="{fname}"')
                    self.send_header('Content-Length', str(len(data)))
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    self.wfile.write(data)
                else:
                    self._err(404)
            else:
                self._err(400)

        elif p == '/api/jobs':
            # Return job registry + current statuses
            statuses = all_job_statuses()
            jobs_info = {
                k: {
                    'label':      v[0],
                    'status':     statuses.get(k, {}),
                }
                for k, v in JOBS.items()
            }
            self._json(jobs_info)

        elif p.startswith('/api/job/status/'):
            key = p[16:]
            self._json(job_status(key))

        # ── SF Explorer ──────────────────────────────────────────────────────
        elif p == '/api/sf/cli-check':
            cli = _sf_cli()
            self._json({'available': cli is not None, 'path': cli or ''})

        elif p == '/api/sf/orgs':
            orgs, err = sf_list_orgs()
            if err:
                self._json({'error': err})
            else:
                self._json({'orgs': orgs})

        elif p.startswith('/api/sf/login-status/'):
            alias = unquote(p[21:])
            with _sf_login_lock:
                state = dict(_sf_login_state.get(alias, {
                    'running': False, 'done': False, 'error': None
                }))
            self._json(state)

        elif p.startswith('/api/sf/sobjects/'):
            alias = unquote(p[17:])
            data, err = sf_proxy(alias, 'sobjects')
            self._json({'error': err} if err else data)

        elif p.startswith('/api/sf/describe/'):
            rest = unquote(p[17:])
            parts = rest.split('/', 1)
            if len(parts) == 2:
                alias, sobject = parts
                data, err = sf_proxy(alias, f'sobjects/{sobject}/describe')
                self._json({'error': err} if err else data)
            else:
                self._err(400)

        elif p.startswith('/api/sf/findings/'):
            org = unquote(p[len('/api/sf/findings/'):])
            self._json(sf_findings(org))

        elif p.startswith('/api/sf/logout/'):
            alias = unquote(p[15:])
            cli = _sf_cli()
            if cli:
                subprocess.run([cli, 'org', 'logout', '--no-prompt', '--target-org', alias],
                               capture_output=True, timeout=10)
            with _sf_login_lock:
                _sf_login_state.pop(alias, None)
            _sf_rest_clients.pop(alias, None)   # drop cached REST client too
            self._json({'ok': True})

        elif p.startswith('/api/sf/token-debug/'):
            alias = unquote(p[20:])
            cli = _sf_cli()
            if not cli:
                self._json({'error': 'SF CLI nicht gefunden'})
            else:
                try:
                    r = subprocess.run(
                        [cli, 'org', 'display', '--json', '--target-org', alias],
                        capture_output=True, text=True, timeout=15
                    )
                    raw_stdout = r.stdout or ''
                    token, url, err = sf_get_token(alias)
                    debug = {
                        'raw_stdout_len': len(raw_stdout),
                        'raw_stdout_preview': raw_stdout[:500],
                        'error': err,
                        'instance_url': url,
                        'token_len': len(token) if token else 0,
                        'token_preview': token[:12] + '...' + token[-6:] if token and len(token) > 18 else token,
                        # hex repr of first 20 bytes to detect hidden chars
                        'token_hex_start': token[:20].encode('utf-8').hex() if token else None,
                        'proxy_url': f'{url}/services/data/v59.0/sobjects' if url else None,
                        'auth_header': f'Bearer {token[:10]}...' if token else None,
                    }
                    self._json(debug)
                except Exception as e:
                    self._json({'error': str(e)})

        elif p.startswith('/screenshots/'):
            fp = BASE / p.lstrip('/')
            if fp.exists():
                ext = fp.suffix.lower()
                ct = 'image/jpeg' if ext in ('.jpg', '.jpeg') else 'image/png'
                self._file(fp, ct)
            else:
                self._err(404)

        elif p.startswith('/workboard-images/'):
            # /workboard-images/<org>/<filename> — pasted screenshots on the
            # Workboard. Path-Traversal-Schutz wie bei /branding/: der
            # aufgeloeste Pfad muss unterhalb von output/<org>/workboard_images/
            # liegen (org kommt direkt aus der URL, also nicht vertrauenswuerdig).
            rest = p[len('/workboard-images/'):]
            parts = rest.split('/', 1)
            if len(parts) == 2 and parts[0] and parts[1]:
                org, fname = parts
                wbdir = (BASE / 'output' / org / 'workboard_images').resolve()
                fp = (wbdir / fname).resolve()
                if wbdir in fp.parents and fp.is_file():
                    ext = fp.suffix.lower()
                    ct = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
                          '.gif': 'image/gif', '.webp': 'image/webp'}.get(ext, 'application/octet-stream')
                    self._file(fp, ct)
                else:
                    self._err(404)
            else:
                self._err(404)

        elif p.startswith('/branding/'):
            # Icons + Branding-Assets aus dem branding/-Ordner ausliefern.
            # Verhindert Path-Traversal, indem der aufgeloeste Pfad unterhalb
            # von branding/ liegen muss.
            branding = (BASE / 'branding').resolve()
            fp = (BASE / p.lstrip('/')).resolve()
            if branding in fp.parents and fp.is_file():
                ct = {
                    '.svg':  'image/svg+xml',
                    '.png':  'image/png',
                    '.jpg':  'image/jpeg',
                    '.jpeg': 'image/jpeg',
                    '.json': 'application/json; charset=utf-8',
                    '.md':   'text/markdown; charset=utf-8',
                    '.html': 'text/html; charset=utf-8',
                    '.css':  'text/css; charset=utf-8',
                }.get(fp.suffix.lower(), 'application/octet-stream')
                self._file(fp, ct)
            else:
                self._err(404)

        # ── Process Analysis API ───────────────────────────────────────────
        elif p.startswith('/api/processes/'):
            rest = p[15:]  # e.g. "globex" or "globex/nl_ACM_DE-DE/reanalyze"
            parts = rest.split('/', 2)
            org = parts[0]
            if not org:
                self._err(400)
                return
            try:
                processes, mod = _analyze_processes(org)
                _merge_added_comps(processes, org)
                _merge_user_processes(processes, org)
                if len(parts) == 1:
                    # GET /api/processes/<org> → alle Prozesse
                    self._json(processes)
                elif len(parts) == 2 and parts[1] == 'discover':
                    # GET /api/processes/<org>/discover → ungematchte Asset-Cluster
                    data = mod.load_all(org)
                    candidates = mod.discover_unmatched_processes(org, data, processes)
                    self._json(candidates)
                elif len(parts) >= 3 and parts[2] == 'reanalyze':
                    # GET /api/processes/<org>/<id>/reanalyze?excluded=type_id,…&pinned=type_id,…
                    from urllib.parse import parse_qs, urlparse as _up
                    qs = parse_qs(_up(self.path).query)
                    excluded_keys = set(filter(None, qs.get('excluded', [''])[0].split(',')))
                    pinned_keys   = set(filter(None, qs.get('pinned',   [''])[0].split(',')))

                    proc_id = parts[1]
                    match = next((p for p in processes if p['id'] == proc_id), None)
                    if match and excluded_keys:
                        # Entferne vom User als falsch markierte Komponenten
                        match['components'] = [
                            c for c in match['components']
                            if f"{c['type']}_{c['id']}" not in excluded_keys
                        ]
                        match['reanalyzed_with_feedback'] = True
                        # Score nach Filterung neu berechnen (Rohdaten bleiben gleich)
                    self._json(match if match else {'error': 'Process not found'})
                else:
                    self._err(400)
            except Exception as e:
                self._json({'error': str(e)})

        else:
            self._err(404)

    def do_DELETE(self):
        p = unquote(urlparse(self.path).path)
        if p.startswith('/api/org/'):
            name = p[9:]
            # Only remove the .env config — never touch output/ data
            path = CFGS / f'{name}.env'
            if path.exists():
                path.unlink()
                # Clear active-org marker if it pointed to this org
                if ACTIVE.exists() and ACTIVE.read_text().strip() == name:
                    ACTIVE.write_text('', encoding='utf-8')
                self._json({'ok': True})
            else:
                self._json({'ok': False, 'msg': 'Config not found'})
        elif p.startswith('/api/workboard-image/'):
            # DELETE /api/workboard-image/<org>/<filename> — aufgerufen, wenn
            # ein Bild-Knoten vom Workboard entfernt wird, damit keine
            # verwaisten Dateien in output/<org>/workboard_images/ bleiben.
            rest = p[len('/api/workboard-image/'):]
            parts = rest.split('/', 1)
            if len(parts) == 2 and parts[0] and parts[1]:
                org, fname = parts
                wbdir = (BASE / 'output' / org / 'workboard_images').resolve()
                fp = (wbdir / fname).resolve()
                if wbdir in fp.parents and fp.is_file():
                    fp.unlink()
                    self._json({'ok': True})
                else:
                    self._json({'ok': False, 'msg': 'Datei nicht gefunden'})
            else:
                self._err(400)
        else:
            self._err(404)

    def do_POST(self):
        p = unquote(urlparse(self.path).path)
        length = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(length) or b'{}')

        if p.startswith('/api/scrape/'):
            org = p[12:]
            ok, msg = start_scrape(org)
            self._json({'ok': ok, 'msg': msg})

        elif p.startswith('/api/org/'):
            name = p[9:]
            existing = read_config(name)
            for k in SENSITIVE:
                if body.get(k) == MASK:
                    body[k] = existing.get(k, '')
            # Keys the form doesn't know (e.g. PARDOT_API_BASE) survive a save
            write_config(name, {**existing, **body})
            self._json({'ok': True})

        elif p.startswith('/api/board-state/'):
            # POST /api/board-state/<org> — kompletter localStorage-Snapshot der Org,
            # überschreibt (mit Rotation nach .prev.json) den bisherigen Stand
            org = p[len('/api/board-state/'):]
            if not org:
                self._err(400)
            elif not isinstance(body, dict):
                self._json({'ok': False, 'msg': 'expected a JSON object'})
            else:
                _write_board_state(org, body)
                self._json({'ok': True, 'saved_at': datetime.datetime.utcnow().isoformat()})

        elif p == '/api/active-org':
            ACTIVE.write_text(body.get('org', ''), encoding='utf-8')
            self._json({'ok': True})

        elif p.startswith('/api/run/'):
            key = p[9:]
            org = body.get('org') or active_org()
            if not org:
                self._json({'ok': False, 'msg': 'No active org set.'})
            else:
                ok, msg = start_job(key, org)
                self._json({'ok': ok, 'msg': msg})

        elif p == '/api/sf/login':
            alias        = body.get('alias', f'sfx-{int(datetime.datetime.now().timestamp())}')
            instance_url = body.get('instanceUrl', 'https://login.salesforce.com').strip() or 'https://login.salesforce.com'
            cli = _sf_cli()
            if not cli:
                self._json({'ok': False, 'msg': 'SF CLI (sf/sfdx) nicht gefunden. Bitte installieren.'})
            else:
                with _sf_login_lock:
                    if _sf_login_state.get(alias, {}).get('running'):
                        self._json({'ok': False, 'msg': 'Login läuft bereits.'})
                        return
                    _sf_login_state[alias] = {
                        'running': True, 'done': False, 'error': None,
                        'started_at': datetime.datetime.now().isoformat(timespec='seconds'),
                        'finished_at': None,
                    }
                t = threading.Thread(target=_run_sf_login, args=(alias, instance_url), daemon=True)
                t.start()
                self._json({'ok': True, 'alias': alias})

        # ── Process Status (User-Annotationen) ────────────────────────────
        elif p.startswith('/api/process-status/'):
            # POST /api/process-status/<org>
            org = p[20:]
            if not org:
                self._err(400)
                return
            # body: { proc_id, comp_key, user_status }
            proc_id     = body.get('proc_id', '')
            comp_key    = body.get('comp_key', '')   # e.g. "formhandler_139"
            user_status = body.get('user_status')    # 'ok' | 'error' | 'incomplete' | null
            if not proc_id or not comp_key:
                self._json({'ok': False, 'msg': 'proc_id and comp_key required'})
            else:
                _save_process_status(org, proc_id, comp_key, user_status)
                self._json({'ok': True})

        # ── Workboard: eingefügtes Bild (Zwischenablage) speichern ─────────
        elif p.startswith('/api/workboard-image/'):
            # POST /api/workboard-image/<org>  body: { data: "data:image/png;base64,..." }
            org = p[len('/api/workboard-image/'):]
            data_url = body.get('data', '')
            if not org or not data_url or ',' not in data_url:
                self._json({'ok': False, 'msg': 'org and data (data URL) required'})
            else:
                try:
                    header, b64 = data_url.split(',', 1)
                    ext = '.png'
                    if 'image/jpeg' in header or 'image/jpg' in header:
                        ext = '.jpg'
                    elif 'image/webp' in header:
                        ext = '.webp'
                    elif 'image/gif' in header:
                        ext = '.gif'
                    raw = base64.b64decode(b64)
                    if len(raw) > 15 * 1024 * 1024:
                        self._json({'ok': False, 'msg': 'Bild zu groß (>15 MB).'})
                    else:
                        wbdir = BASE / 'output' / org / 'workboard_images'
                        wbdir.mkdir(parents=True, exist_ok=True)
                        fname = f'{uuid.uuid4().hex}{ext}'
                        (wbdir / fname).write_bytes(raw)
                        self._json({'ok': True, 'filename': fname})
                except Exception as e:
                    self._json({'ok': False, 'msg': f'Fehler beim Speichern: {e}'})

        # ── Process Komponente manuell hinzufügen / entfernen ─────────────
        elif p.startswith('/api/processes/') and p.endswith('/add_comp'):
            # POST /api/processes/<org>/<id>/add_comp  body: {type, id, name, prospect_count?}
            rest = p[15:-9]
            parts = rest.split('/', 1)
            if len(parts) < 2:
                self._err(400); return
            org, proc_id = parts[0], parts[1]
            new_comp = {
                'type': body.get('type', ''),
                'id':   str(body.get('id', '')),
                'name': body.get('name', ''),
            }
            if body.get('prospect_count') is not None:
                new_comp['prospect_count'] = int(body['prospect_count'])
            if not new_comp['type'] or not new_comp['id']:
                self._err(400); return
            data = _load_process_status(org)
            if proc_id not in data:
                data[proc_id] = {}
            added = data[proc_id].setdefault('_added_comps', [])
            # Duplikate verhindern
            if not any(a['type'] == new_comp['type'] and str(a['id']) == new_comp['id'] for a in added):
                added.append(new_comp)
                _write_process_status(org, data)
            self._json({'ok': True, 'proc_id': proc_id, 'added': new_comp})

        elif p.startswith('/api/processes/') and p.endswith('/remove_added_comp'):
            # POST /api/processes/<org>/<id>/remove_added_comp  body: {type, id}
            rest = p[15:-18]
            parts = rest.split('/', 1)
            if len(parts) < 2:
                self._err(400); return
            org, proc_id = parts[0], parts[1]
            rm_type = body.get('type', '')
            rm_id   = str(body.get('id', ''))
            data = _load_process_status(org)
            if proc_id in data and '_added_comps' in data[proc_id]:
                data[proc_id]['_added_comps'] = [
                    a for a in data[proc_id]['_added_comps']
                    if not (a['type'] == rm_type and str(a['id']) == rm_id)
                ]
                _write_process_status(org, data)
            self._json({'ok': True})

        # ── Process Verify / Unverify ──────────────────────────────────────
        elif p.startswith('/api/processes/') and p.endswith('/verify'):
            # POST /api/processes/<org>/<id>/verify
            rest = p[15:-7]  # strip prefix + "/verify"
            parts = rest.split('/', 1)
            if len(parts) < 2:
                self._err(400)
                return
            org, proc_id = parts[0], parts[1]
            verified_comps = body.get('verified_comps', [])
            excluded_comps = body.get('excluded_comps', [])
            _verify_process(org, proc_id, verified_comps, excluded_comps)
            self._json({'ok': True, 'proc_id': proc_id, 'verified': True})

        elif p.startswith('/api/processes/') and p.endswith('/unverify'):
            # POST /api/processes/<org>/<id>/unverify
            rest = p[15:-9]
            parts = rest.split('/', 1)
            if len(parts) < 2:
                self._err(400)
                return
            org, proc_id = parts[0], parts[1]
            _unverify_process(org, proc_id)
            self._json({'ok': True, 'proc_id': proc_id, 'verified': False})

        elif p.startswith('/api/processes/') and p.endswith('/reset'):
            # POST /api/processes/<org>/<id>/reset
            # Löscht ALLE gespeicherten Status-Daten für diesen Prozess (verify, exclude, comp-status)
            # → nächste Analyse startet komplett von vorn, ohne jegliches Feedback
            rest = p[15:-6]
            parts = rest.split('/', 1)
            if len(parts) < 2:
                self._err(400)
                return
            org, proc_id = parts[0], parts[1]
            data = _load_process_status(org)
            if proc_id in data:
                del data[proc_id]
            # Falls es ein user-created Prozess ist: auch aus _user_processes entfernen
            ups = data.get('_user_processes', [])
            data['_user_processes'] = [up for up in ups if up.get('id') != proc_id]
            _write_process_status(org, data)
            self._json({'ok': True, 'proc_id': proc_id, 'reset': True})

        elif p.startswith('/api/processes/') and p.endswith('/create'):
            # POST /api/processes/<org>/create
            # Body: {title, process_type, components: [{type, id, name, ...}]}
            rest = p[15:-7]   # strip '/api/processes/' and '/create'
            org = rest.split('/')[0]
            if not org:
                self._err(400)
                return
            import time as _time
            proc_id = f'user_{int(_time.time() * 1000)}_{body.get("title", "proc")[:20].replace(" ", "_")}'
            new_proc = {
                'id':           proc_id,
                'title':        body.get('title', 'Neuer Prozess'),
                'process_type': body.get('process_type', 'custom'),
                'domain_hint':  '',
                'doi_type':     'unknown',
                'doi_mechanism':'',
                'optin_fields': [],
                'verified':     False,
                'verified_at':  '',
                'verified_comps': [],
                'excluded_comps': [],
                'user_created': True,
                'components':   body.get('components', []),
                'completeness': {'score': 0, 'issues': [], 'has_entry': False,
                                 'has_confirmation': False, 'has_subscriber_list': False,
                                 'has_doi_email': False},
            }
            data = _load_process_status(org)
            ups = data.get('_user_processes', [])
            ups.append(new_proc)
            data['_user_processes'] = ups
            _write_process_status(org, data)
            self._json({'ok': True, 'proc': new_proc})

        else:
            self._err(404)

    # ── send helpers ──

    def _json(self, data):
        b = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(b)

    def _file(self, path, ct):
        try:
            data = Path(path).read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', ct)
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except FileNotFoundError:
            self._err(404)

    def _err(self, code):
        self.send_response(code)
        self.end_headers()

    def log_message(self, *_):
        pass


# ── entry point ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    threading.Timer(0.8, lambda: webbrowser.open(f'http://localhost:{PORT}')).start()
    with socketserver.TCPServer(('', PORT), Handler) as s:
        print(f'Pardot Asset Viewer  →  http://localhost:{PORT}   (Ctrl+C to stop)')
        try:
            s.serve_forever()
        except KeyboardInterrupt:
            print('\nStopped.')
