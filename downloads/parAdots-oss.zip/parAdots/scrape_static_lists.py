"""
Pardot Static List Scraper
===========================
Standalone Playwright scraper for STATIC lists (Dynamic = No) under
Marketing > Segmentation > Lists.

Deliberately independent from scrape_dynamic_lists.py (per project decision
2026-08-05) — no shared discovery code, so nothing here can break, or be
broken by, the dynamic-list rule scraper. Discovery/view-switching logic is
duplicated on purpose, adapted from the proven, bug-fixed pattern in
scrape_dynamic_lists.py (view-filter trap, non-English UI).

For every static list, captures:
  - List Name
  - URL                                       (constructed: /list/read/id/{id})
  - Prospect Count                            (from the Lists table PROSPECTS column)
  - Folder                                    (breadcrumb shown under the name)
  - Created At / Updated At / Updated By      (from the "All Current Lists" table;
                                                falls back to the Details tab if a
                                                tenant's table doesn't expose them)
  - CRM Visible                               (Details tab, per-list page)
  - Usage: Type + Name (+ URL where linked)   (Usage tab, per-list page)

Requires a live, logged-in Pardot session (Playwright + MFA via utils.login) —
this scraper visits every static list's detail page individually (Details +
Usage tab), so runtime scales with static-list count. Wired into run_all.py
as the single authoritative static-list scraper (writes the canonical
pardot_static_lists.* that the rest of the suite consumes).

Output (canonical — consumed by enrich_automations / analyze_cross_references / viewer):
  pardot_static_lists.json
  pardot_static_lists.csv

Usage:
  python3 scrape_static_lists.py
  python3 scrape_static_lists.py --org globex
"""

import argparse
import sys
import time

from playwright.sync_api import sync_playwright

import utils

OUTPUT_JSON     = ""
OUTPUT_CSV      = ""
SCREENSHOTS_DIR = ""

# Set True after the UI-language guard passes on the first list visited in a
# run — see scrape_list_detail() / utils.assert_english_ui.
_LANGUAGE_VERIFIED = False

CSV_HEADERS = (
    "#", "List Name", "List ID", "Prospect Count", "URL", "Folder",
    "Created At", "Updated At", "Updated By", "CRM Visible",
    "Usage Count", "Usage",
)

CACHED_FIELDS = ["crm_visible", "usage"]

LIST_PATH_CANDIDATES = [
    "/list",
    "/prospect-list",
    "/lists",
]

_NEXT_SELECTORS = [
    "a:has-text('Next')",
    "a:has-text('›')",
    "a:has-text('»')",
    "[aria-label='Next page']",
    "[aria-label='Next']",
    ".next a",
    "a[rel='next']",
]

MAX_DISCOVERY_PAGES = 200
MAX_USAGE_PAGES     = 20

# View-filter <select> keywords — bilingual because globex's tenant UI is
# German ("Regeln für dynamische Listen" etc. — see scrape_dynamic_lists.py).
_VIEW_KEYWORDS = {
    "all":     ("all current lists", "alle aktuellen listen", "all", "alle"),
    "dynamic": ("dynamic lists", "dynamische listen", "dynamic", "dynamisch"),
}

# Discovery-table column header keywords (bilingual). Matched by header TEXT,
# not fixed index — a persisted/reordered column layout must not silently
# shift data into the wrong field (see the "Dynamic column" bug this mirrors
# in scrape_dynamic_lists.py).
_COL_KEYWORDS = {
    "dynamic":    ["dynamic", "dynamisch"],
    "prospects":  ["prospects", "interessenten"],
    "created_at": ["created at", "erstellt am"],
    "updated_at": ["updated at", "aktualisiert am", "geändert am"],
    "updated_by": ["updated by", "aktualisiert von", "geändert von"],
}

# Details-tab label keywords (bilingual) — label/value pairs render as two
# consecutive lines in document.body.innerText: label line, then value line.
_LABEL_KEYWORDS = {
    "crm_visible": ["crm visible", "crm sichtbar", "sichtbar im crm", "in crm sichtbar"],
    "created_at":  ["created at", "erstellt am"],
    "updated_at":  ["updated at", "aktualisiert am", "geändert am"],
    "updated_by":  ["updated by", "aktualisiert von", "geändert von"],
    "folder":      ["folder", "ordner"],
}

# Detail-page rules-section headings (bilingual). Their presence means the list
# is actually DYNAMIC — used to exclude a mis-discovered dynamic list from the
# static output, so this scraper agrees with scrape_dynamic_lists.py's
# detail-page classifier rather than trusting the discovery view alone.
_RULES_HEADING_KEYWORDS = (
    "dynamic list rules",
    "regeln für dynamische listen",
    "regeln für dynamische liste",
)

# ── JS: discovery-table row extraction ──────────────────────────────────────
# Reads name/id/folder/dynamic-flag/created/updated/updated-by straight off
# the "All Current Lists" table — no per-record navigation needed for these.
_DISCOVER_JS = r"""(colKeywords) => {
    const headerRow = document.querySelector('table thead tr') ||
                       document.querySelector('table tr');
    const headers = headerRow
        ? Array.from(headerRow.querySelectorAll('th, td')).map(h => h.innerText.trim().toLowerCase())
        : [];

    function findCol(keywords) {
        return headers.findIndex(h => keywords.some(k => h.includes(k)));
    }

    const colDynamic   = findCol(colKeywords.dynamic);
    const colProspects = findCol(colKeywords.prospects);
    const colCreated   = findCol(colKeywords.created_at);
    const colUpdatedAt = findCol(colKeywords.updated_at);
    const colUpdatedBy = findCol(colKeywords.updated_by);

    return Array.from(document.querySelectorAll('table tbody tr, table tr')).flatMap(row => {
        const link = row.querySelector('a[href*="/list/read/id/"], a[href*="/list/edit/id/"]');
        if (!link) return [];
        const href = link.getAttribute('href') || '';
        const m = href.match(/\/list\/(?:read|edit)\/id\/(\d+)/);
        if (!m) return [];

        const cells = Array.from(row.querySelectorAll('td'));
        const linkText = link.innerText.trim();
        const name = linkText || ('List ' + m[1]);
        if (!name) return [];

        // Folder is rendered as a second text line inside the Name cell,
        // below the link (e.g. an icon glyph + "/Uncategorized/Lists").
        let folder = '';
        const nameCell = link.closest('td');
        if (nameCell) {
            const lines = nameCell.innerText.split('\n').map(s => s.trim()).filter(Boolean);
            const extra = lines.filter(l => l !== linkText);
            const folderLine = extra.find(l => l.includes('/'));
            if (folderLine) folder = folderLine;
        }

        const dynVal = colDynamic >= 0 && cells[colDynamic]
            ? cells[colDynamic].innerText.trim().toLowerCase() : '';

        return [{
            id:         m[1],
            name:       name,
            folder:     folder,
            is_dynamic: dynVal === 'yes' || dynVal === 'ja',
            prospect_count: colProspects >= 0 && cells[colProspects] ? cells[colProspects].innerText.trim() : '',
            created_at: colCreated   >= 0 && cells[colCreated]   ? cells[colCreated].innerText.trim()   : '',
            updated_at: colUpdatedAt >= 0 && cells[colUpdatedAt] ? cells[colUpdatedAt].innerText.trim() : '',
            updated_by: colUpdatedBy >= 0 && cells[colUpdatedBy] ? cells[colUpdatedBy].innerText.trim() : '',
        }];
    });
}"""

# Usage-tab extraction itself lives in utils.extract_usage_tab() — shared
# with scrape_dynamic_lists.py (Pattern A, see utils.py's module note above
# extract_usage_tab/extract_usage_inline). Kept here only as a thin call so
# this scraper doesn't duplicate the placeholder-filtering / pagination /
# ID-parsing logic.


# ── View-filter <select> handling ───────────────────────────────────────────
# Adapted from scrape_dynamic_lists.py's fix: the FIRST <select> on the page
# is not reliably the "View:" filter (Lightning pages can render other
# selects — language picker, page size — earlier in the DOM). Identify it by
# scoring its own option contents against known view names, then verify the
# switch actually took by re-reading the selected option afterwards.

def _find_view_select(page):
    try:
        selects = page.query_selector_all("select")
    except Exception:
        return None, []
    best, best_opts, best_score = None, [], 0
    for sel in selects:
        try:
            opts = sel.eval_on_selector_all(
                "option",
                "els => els.map(o => ({value:o.value, text:o.innerText.trim()}))",
            )
        except Exception:
            continue
        score = sum(
            1 for kws in _VIEW_KEYWORDS.values()
            if any(any(k in (o["text"] or "").lower() for k in kws) for o in opts)
        )
        if score > best_score:
            best, best_opts, best_score = sel, opts, score
    if best_score < 1:
        return None, []
    return best, best_opts


def _switch_view(page, view_select, opts, view_key):
    if view_select is None:
        return None
    keywords = _VIEW_KEYWORDS[view_key]
    match = next(
        (o for o in opts if any(k in o["value"].lower() or k in o["text"].lower() for k in keywords)),
        None,
    )
    if not match:
        return None
    try:
        refreshed = utils.select_view_and_wait(page, view_select, match["value"])
    except Exception as e:
        print(f"   ⚠️  select_option('{match['text']}') raised: {e}")
        return None
    if not refreshed:
        print(f"   ⚠️  Switched to '{match['text']}' but the table never re-rendered — not trusting this pass")
        return None
    try:
        selected_now = (view_select.eval_on_selector(
            "option:checked", "o => o.innerText.trim()"
        ) or "").lower()
    except Exception:
        selected_now = ""
    if not any(k in selected_now for k in keywords):
        print(f"   ⚠️  Switched to '{match['text']}' but page shows '{selected_now}' after switching — not trusting this pass")
        return None
    return match["text"]


# ── Discovery ────────────────────────────────────────────────────────────────

def _paginate_current_view(page, label):
    """Paginate whatever Lists view is currently selected and return
    (rows, hit_max_pages). rows are raw _DISCOVER_JS dicts for EVERY row in the
    view — no static/dynamic classification happens here; the caller classifies
    by *which view* this is. (Acme and other tenants expose no per-row
    "Dynamic" column — confirmed via screenshot 2026-09-17 — so item['is_dynamic']
    is unreliable and deliberately ignored.)"""
    rows = []
    seen = set()
    hit_max = False
    page_num = 0
    while True:
        page_num += 1
        try:
            items = page.evaluate(_DISCOVER_JS, _COL_KEYWORDS)
        except Exception:
            items = []

        new_this_page = 0
        for item in items:
            if item["id"] in seen:
                continue
            seen.add(item["id"])
            new_this_page += 1
            rows.append(item)

        print(f"   \U0001F4C4 {label} page {page_num}: {new_this_page} new row(s) "
              f"(running total {len(rows)})")

        if page_num >= MAX_DISCOVERY_PAGES:
            print(f"   ⚠️  Hit MAX_DISCOVERY_PAGES ({MAX_DISCOVERY_PAGES}) — stopping pagination as a safety cap")
            hit_max = True
            break

        next_btn = None
        for sel in _NEXT_SELECTORS:
            try:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    next_btn = btn
                    break
            except Exception:
                continue

        if not next_btn or new_this_page == 0:
            break

        first_id_before = items[0]["id"] if items else None
        try:
            next_btn.click()
        except Exception:
            break

        # Same-page Ajax.Updater pagination: wait until the first row's list ID
        # actually changes rather than trusting networkidle (which can return
        # before the request even starts — see the 2026-09-11 Acme note that
        # silently dropped 57 rows). Fall back to networkidle/timeout only if the
        # row ID never changes (genuinely the last page, or a markup change).
        try:
            if first_id_before is not None:
                page.wait_for_function(
                    """(prevId) => {
                        const row = document.querySelector('table tbody tr, table tr');
                        if (!row) return false;
                        const link = row.querySelector(
                            'a[href*="/list/read/id/"], a[href*="/list/edit/id/"]'
                        );
                        if (!link) return false;
                        const m = (link.getAttribute('href') || '')
                            .match(/\\/list\\/(?:read|edit)\\/id\\/(\\d+)/);
                        return !!m && m[1] !== prevId;
                    }""",
                    arg=first_id_before,
                    timeout=8000,
                )
            else:
                raise RuntimeError("no first-row id to compare against")
        except Exception:
            try:
                page.wait_for_load_state("networkidle", timeout=8000)
            except Exception:
                page.wait_for_timeout(1000)

    return rows, hit_max


def discover_static_lists(page):
    """
    Navigate to Segmentation > Lists and return every STATIC list.

    Classification is driven by the "View:" filter, NOT by a per-row column:
    this tenant's Lists table has no "Dynamic" column at all (screenshot
    2026-09-17), so the previous per-row is_dynamic read was always False and
    every dynamic list leaked into the static output. Instead we follow the
    project's documented pattern ("Unconditional Pass 1b, dedupliziert gegen
    bereits gesehene Dynamic-IDs"):

      Pass 1  — "All Current Lists" view  -> every list (static + dynamic)
      Pass 1b — "Dynamic Lists"    view   -> the dynamic IDs to subtract
      static  = Pass 1  minus  Pass 1b

    Both views are matched locale-independently via _VIEW_KEYWORDS, so this works
    on German ("Dynamische Listen") and English tenants alike.

    Returns (list of dicts, sweep_verified). sweep_verified is False whenever a
    pagination cap was hit or the Dynamic pass could not be verified — that gates
    pruning downstream so an unreliable pass never deletes good records.
    """
    print("\U0001F310 Discovering static lists (All Current Lists minus Dynamic Lists)...")
    collected = []
    sweep_verified = False

    for list_path in LIST_PATH_CANDIDATES:
        list_url = utils.pardot_url(list_path)
        print(f"   Trying {list_url}...")
        utils.navigate(page, list_url, timeout=20000)
        print(f"   ↪︎ landed on: {page.url}")
        try:
            page.wait_for_selector("table, select", timeout=8000)
        except Exception:
            print("   ⚠️  No <table>/<select> appeared within 8s on this URL — "
                  "likely redirected somewhere unexpected (auth prompt, permission "
                  "error, wrong domain). Check the screenshot below.")
        utils.screenshot(page, f"{SCREENSHOTS_DIR}/list_discovery.png")

        view_select, opts = _find_view_select(page)
        if view_select is None:
            print("   ⚠️  Could not identify the 'View:' <select> on this URL — trying next candidate")
            continue

        # -- Pass 1: All Current Lists ------------------------------------
        all_label = _switch_view(page, view_select, opts, "all")
        all_verified = bool(all_label)
        if not all_verified:
            print("   ⚠️  Could not switch to / verify 'All Current Lists' — "
                  "results may reflect a stale filtered view. Re-run headed to inspect.")
            all_label = "All Current Lists (UNVERIFIED)"
        all_rows, hit_max_all = _paginate_current_view(page, all_label)

        # -- Pass 1b: Dynamic Lists (unconditional) -> IDs to exclude ------
        # Re-find the <select>: the pagination Ajax.Updater replaces the table
        # DOM, which can stale the earlier element handle.
        view_select, opts = _find_view_select(page)
        dyn_label = _switch_view(page, view_select, opts, "dynamic") if view_select else None
        dyn_verified = bool(dyn_label)
        dyn_ids = set()
        hit_max_dyn = False
        if dyn_verified:
            dyn_rows, hit_max_dyn = _paginate_current_view(page, dyn_label)
            dyn_ids = {r["id"] for r in dyn_rows}
            print(f"   ✔ Dynamic view: {len(dyn_ids)} dynamic list(s) to exclude")
        else:
            print("   ⚠️  Could not switch to / verify 'Dynamic Lists' — cannot "
                  "reliably exclude dynamic lists this pass.")

        # -- Classify: static = All minus Dynamic -------------------------
        collected = []
        for item in all_rows:
            if item["id"] in dyn_ids:
                continue
            item["url"] = f"{utils.PARDOT_HOME}/list/read/id/{item['id']}"
            item.pop("is_dynamic", None)   # unreliable per-row flag — never trust
            collected.append(item)

        # Sanity guard (documented pitfall): 0 dynamics against a non-empty
        # result almost always means the Dynamic pass silently failed, not that
        # the tenant truly has no dynamic lists.
        suspicious_zero = dyn_verified and not dyn_ids and bool(all_rows)
        if suspicious_zero:
            print("   ⚠️  Dynamic pass returned 0 lists against a non-empty result "
                  "— treating classification as UNVERIFIED (no dynamics excluded).")

        sweep_verified = (
            all_verified and dyn_verified and not suspicious_zero
            and not hit_max_all and not hit_max_dyn
        )

        print(f"   \U0001F4CA {len(all_rows)} total − {len(dyn_ids)} dynamic = {len(collected)} static")
        if collected:
            break  # found a working URL — don't try the other candidates

    tag = "" if sweep_verified else "  (UNVERIFIED — pruning disabled this run)"
    print(f"   {'✅' if collected else '⚠️ '} Found {len(collected)} static list(s){tag}")
    collected.sort(key=lambda r: int(r.get("id", 0)) if str(r.get("id", "")).isdigit() else str(r.get("id", "")))
    return collected, sweep_verified


# ── Per-list detail (Details tab + Usage tab) ───────────────────────────────

def _label_value(lines, keywords):
    """Return the line right after the first line matching any keyword."""
    for i, line in enumerate(lines):
        low = line.lower()
        if any(k in low for k in keywords):
            if i + 1 < len(lines):
                return lines[i + 1].strip()
    return ""


def scrape_list_detail(page, list_id):
    """
    Visit one static list's detail page and collect the fields that are NOT
    available from the discovery table: CRM Visible (Details tab) and Usage
    (Usage tab). Also returns fallback_* values for Created/Updated/Updated
    By/Folder, used only if the discovery table didn't expose them for this
    tenant's "All Current Lists" view.
    """
    url = f"{utils.PARDOT_HOME}/list/read/id/{list_id}"
    utils.navigate(page, url, timeout=15000)
    try:
        page.wait_for_selector("a[href='#details'], #content", timeout=8000)
    except Exception:
        pass

    # ── Details tab ──────────────────────────────────────────────────────
    try:
        page.click("a[href='#details']")
        page.wait_for_timeout(600)
    except Exception:
        pass

    # NOTE: deliberately filter_prospects=False. utils.get_page_text()'s
    # default truncation cuts the text at a line that is EXACTLY "Prospects"
    # (a section-heading guard against dumping prospect rosters). On this
    # Details tab, "Prospects" is just a metadata field label ("Prospects:
    # 102") that appears BEFORE CRM Visible / Created At / Updated At /
    # Updated By in the layout — the default filter would silently discard
    # every field we came here for. This tab has no prospect roster table to
    # guard against, so the filter is safe to skip here.
    text = utils.get_page_text(page, filter_prospects=False)
    lines = [l.strip() for l in text.splitlines() if l.strip()]

    global _LANGUAGE_VERIFIED
    if not _LANGUAGE_VERIFIED:
        utils.assert_english_ui(lines, f"Pardot static list detail page (id {list_id})")
        _LANGUAGE_VERIFIED = True

    result = {
        "crm_visible":         _label_value(lines, _LABEL_KEYWORDS["crm_visible"]),
        "fallback_created":    _label_value(lines, _LABEL_KEYWORDS["created_at"]),
        "fallback_updated":    _label_value(lines, _LABEL_KEYWORDS["updated_at"]),
        "fallback_updated_by": _label_value(lines, _LABEL_KEYWORDS["updated_by"]),
        "fallback_folder":     _label_value(lines, _LABEL_KEYWORDS["folder"]),
        "has_rules":           any(any(h in ln.lower() for h in _RULES_HEADING_KEYWORDS) for ln in lines),
        "usage": [],
    }

    # ── Usage tab ────────────────────────────────────────────────────────
    result["usage"] = utils.extract_usage_tab(page, max_pages=MAX_USAGE_PAGES)

    return result


# ── Output ───────────────────────────────────────────────────────────────────

def _write_outputs(results):
    results.sort(key=lambda r: int(r.get("id", 0)) if str(r.get("id", "")).isdigit() else str(r.get("id", "")))
    utils.save_json(results, OUTPUT_JSON)
    rows = []
    for i, lst in enumerate(results, 1):
        usage = lst.get("usage") or []
        usage_text = "; ".join(f"{u.get('type','')}: {u.get('name','')}" for u in usage)
        rows.append([
            i,
            lst.get("name", ""),
            lst.get("id", ""),
            lst.get("prospect_count", ""),
            lst.get("url", ""),
            lst.get("folder", ""),
            lst.get("created_at", ""),
            lst.get("updated_at", ""),
            lst.get("updated_by", ""),
            lst.get("crm_visible", ""),
            len(usage),
            usage_text,
        ])
    utils.save_csv(rows, CSV_HEADERS, OUTPUT_CSV)


# ── Run (browser-agnostic entry point) ──────────────────────────────────────

def run(page, update: bool = False, max_age_days: int = 7, refresh_limit: int = 25,
        allow_prune: bool = False, dry_run: bool = False):
    """Discover, scrape, and export — no browser lifecycle management.

    In update mode, skips detail pages for unchanged records (unchanged updated_at).
    Outputs are always written via the finally block, even on a partial run,
    so scraping effort already spent is never lost.

    Args:
        page: Playwright page (already logged in)
        update: If True, gate detail pages by updated_at
        max_age_days: Ignored (Tier A has no aging sweep)
        refresh_limit: Ignored (Tier A has no aging sweep)
    """
    global OUTPUT_JSON, OUTPUT_CSV, SCREENSHOTS_DIR
    OUTPUT_JSON     = utils.output_path("pardot_static_lists.json")
    OUTPUT_CSV      = utils.output_path("pardot_static_lists.csv")
    SCREENSHOTS_DIR = utils.output_path("screenshots", "static_lists")
    utils.reset_screenshots(SCREENSHOTS_DIR)

    started_at = utils.now_iso()
    kind = "static_lists"

    cached = utils.load_previous_output(kind) if update else {}
    if cached:
        cached_hash = utils.manifest_entry(f"scrape_{kind}").get("shape_hash")
        if cached_hash and cached_hash != utils.shape_hash(CSV_HEADERS):
            print("   ⚠️  Output shape changed — ignoring cache, full scrape this run")
            cached = {}

    results = []
    ok_ids = set()
    merged = None            # stays None if discovery bails out early
    pruned = []
    all_current_ids = set()
    try:
        lists, sweep_verified = discover_static_lists(page)
        if not lists:
            print("❌ No static lists found. Check the 'All Current Lists' view / credentials.")
            return

        all_current_ids = {lst["id"] for lst in lists}

        def select_ids():
            to_visit = set()
            for lst in lists:
                lid = lst["id"]
                if lid not in cached:
                    to_visit.add(lid)
                elif update and cached.get(lid, {}).get("updated_at") != lst.get("updated_at"):
                    to_visit.add(lid)
            return to_visit

        to_visit = select_ids()
        print(f"\n🔍 Processing {len(lists)} static list(s): {len(to_visit)} visit(s), {len(lists)-len(to_visit)} cached...")

        for i, lst in enumerate(lists, 1):
            lid = lst["id"]
            print(f"   [{i}/{len(lists)}] {lst['name']} (id: {lid})", end="")

            if lid not in to_visit:
                print(" [cached]")
                fresh = utils.merge_record_fields(cached.get(lid, {}), lst, CACHED_FIELDS)
                results.append(fresh)
                continue

            print()
            try:
                detail = scrape_list_detail(page, lid)
            except utils.UnexpectedUILanguageError as e:
                print(str(e))
                sys.exit(1)
            except Exception as e:
                print(f"     ⚠️  detail scrape failed: {e}")
                if update and lid in cached:
                    print(f"     ↪︎ keeping cached values for {lst['name']}")
                    results.append(cached[lid])
                else:
                    detail = {
                        "crm_visible": "", "usage": [],
                        "fallback_created": "", "fallback_updated": "",
                        "fallback_updated_by": "", "fallback_folder": "",
                    }
                    lst["crm_visible"] = ""
                    lst["usage"] = []
                    results.append(lst)
                continue

            if detail.get("has_rules"):
                print("     ↪︎ detail page shows a dynamic-rules section — this is "
                      "actually a DYNAMIC list; excluding from static output")
                continue

            lst["crm_visible"] = detail["crm_visible"]
            lst["usage"]       = detail["usage"]
            lst["created_at"]  = lst.get("created_at") or detail["fallback_created"]
            lst["updated_at"]  = lst.get("updated_at") or detail["fallback_updated"]
            lst["updated_by"]  = lst.get("updated_by") or detail["fallback_updated_by"]
            lst["folder"]      = lst.get("folder") or detail["fallback_folder"]
            results.append(lst)
            ok_ids.add(lid)
            time.sleep(0.5)

        merged = utils.merge_records(cached.values() if update else [], {r["id"]: r for r in results})
        prev = utils.manifest_entry(f"scrape_{kind}")
        record_count = prev.get("record_count", len(merged))
        merged, pruned = utils.apply_prune(
            merged, all_current_ids, sweep_verified=sweep_verified,
            record_count=record_count, allow_prune=allow_prune
        )

        print(f"\n✅ Done! {len(merged)} static list(s)")
    finally:
        if merged is None:
            pass             # nothing discovered/merged — keep existing output untouched
        elif dry_run:
            print(f"   [dry-run] would visit {len(ok_ids)} of {len(all_current_ids)} record(s)")
            print(f"   [dry-run] would merge {len(results)}, prune {len(pruned)}")
            print(f"   [dry-run] no files written")
        else:
            _write_outputs(merged)
            if update and ok_ids:
                utils.mark_scraped(kind, ok_ids)
                utils.write_manifest(f"scrape_{kind}", started_at=started_at,
                                    shape_hash_val=utils.shape_hash(CSV_HEADERS), record_count=len(merged))


# ── Main ─────────────────────────────────────────────────────────────────────

def _looks_authenticated(page):
    """
    Best-effort check that utils.login() actually landed somewhere real
    (Pardot or the Salesforce Lightning shell) instead of sitting on a login
    screen, an auth-challenge page, or a blank tab. utils.login() itself
    only logs a timeout warning and "proceeds anyway" after ~3 minutes —
    it never raises, so a stalled/failed Salesforce login otherwise goes
    unnoticed until discover_static_lists() mysteriously finds nothing.
    """
    try:
        url = (page.url or "").lower()
    except Exception:
        return False
    if not url or url == "about:blank":
        return False
    if any(k in url for k in ("login", "identity", "challenge")):
        return False
    return True


def main():
    parser = argparse.ArgumentParser(description="Scrape Pardot static lists (name, dates, CRM visible, folder, usage).")
    parser.add_argument("--org", metavar="NAME", help="Org config to use — overrides .active-org for this run only.")
    args = parser.parse_args()

    utils.load_org_config(args.org)
    utils.validate_credentials()

    print("\n🚀 Pardot Static List Scraper")
    print("=" * 45)

    with sync_playwright() as pw:
        context = utils.launch_context(pw)
        page    = context.new_page()
        page.set_viewport_size({"width": 1600, "height": 900})
        try:
            utils.login(page)
            print(f"   ↪︎ post-login URL: {page.url}")

            if not _looks_authenticated(page):
                print("⚠️  Doesn't look authenticated after the first login pass "
                      "(still on a login/challenge screen, or blank) — retrying once. "
                      "If MFA approval is slow, approve it now.")
                utils.login(page)
                print(f"   ↪︎ post-retry URL: {page.url}")

            if not _looks_authenticated(page):
                print(
                    "❌ Still not authenticated after two login attempts "
                    f"(current URL: {page.url}). Not proceeding to Segmentation > Lists — "
                    "that would just scrape an unauthenticated/blank page and report "
                    "'0 static lists found'. Check MFA / SF_LOGIN_URL / SF_USERNAME in "
                    "this org's .env and re-run."
                )
                sys.exit(1)

            run(page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
