"""
Pardot Dynamic Content Scraper
================================
BEFORE RUNNING: Set your Pardot UI language to English.
  Account Engagement → Admin → User Management → Users → Edit your user → Language = English

The browser opens and waits for YOU to log in manually (any method —
Salesforce SSO, username/password, MFA). Scraping starts only once the
Pardot dashboard is detected.

Captures per dynamic content item:
  - Name
  - Folder
  - Tracker Domain
  - Tags
  - Based On (the prospect field driving variations)
  - Default Content
  - Variations (label + condition + content for each)
  - Created At / Updated At

Usage:
  python3 scrape_dynamic_content.py
"""

import csv, json, os, re, sys
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright

import utils

# ── Image extraction helpers ──────────────────────────────────────────────────

SOCIAL_PLATFORMS = {
    "facebook", "twitter", "linkedin", "instagram", "youtube",
    "xing", "pinterest", "tiktok", "whatsapp", "vimeo", "snapchat",
}

_ATTR_RE = re.compile(r'([\w-]+)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|(\S+))', re.IGNORECASE)
_IMG_RE  = re.compile(r'<img\b([^>]*?)/?>', re.IGNORECASE | re.DOTALL)
_A_RE    = re.compile(r'<a\b([^>]*?)>', re.IGNORECASE | re.DOTALL)
_ACLOSE  = re.compile(r'</a\s*>', re.IGNORECASE)


def _get_attr(attrs_str, name):
    """Return the value of a named HTML attribute from an attribute string."""
    for m in _ATTR_RE.finditer(attrs_str):
        if m.group(1).lower() == name.lower():
            return m.group(2) or m.group(3) or m.group(4) or ""
    return ""


def _classify_image(src, alt):
    """Classify an image as logo, social_icon, icon, or generic image."""
    combined = (src + " " + alt).lower()
    if any(p in combined for p in SOCIAL_PLATFORMS):
        return "social_icon"
    if "logo" in combined:
        return "logo"
    if "icon" in combined:
        return "icon"
    return "image"


def extract_images(html):
    """
    Parse all <img> tags from an HTML string.
    For each image return: src, alt, link (href of enclosing <a>), type.
    """
    if not html:
        return []
    images = []
    for img_match in _IMG_RE.finditer(html):
        attrs = img_match.group(1)
        src  = _get_attr(attrs, "src")
        alt  = _get_attr(attrs, "alt")

        # Find the innermost <a> that opens before this <img> and hasn't closed yet
        before = html[:img_match.start()]
        a_opens  = list(_A_RE.finditer(before))
        a_closes = list(_ACLOSE.finditer(before))
        link = ""
        if a_opens:
            last_open  = a_opens[-1]
            last_close_end = a_closes[-1].end() if a_closes else 0
            if last_open.start() >= last_close_end:
                link = _get_attr(last_open.group(1), "href")

        images.append({
            "src":  src,
            "alt":  alt,
            "link": link,
            "type": _classify_image(src, alt),
        })
    return images

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))

SF_LOGIN_URL = os.getenv("SF_LOGIN_URL", "https://login.salesforce.com/")
SF_USERNAME  = os.getenv("SF_USERNAME", "")

OUTPUT_JSON       = ""   # set at run() time via utils.output_path()
OUTPUT_CSV        = ""
OUTPUT_IMAGE_CSV  = ""
OUTPUT_IMAGE_HTML = ""
SCREENSHOTS       = ""
CSV_HEADERS = ["id", "name", "folder", "tracker_domain", "tags", "based_on", "default_content", "variations", "created_at", "updated_at", "images"]
LIST_PATH   = "/content"

# ── Wait for manual login ─────────────────────────────────────────────────────

def wait_for_login(page):
    print("=" * 60)
    print("⚠️  BEFORE YOU LOG IN:")
    print("   Make sure your Pardot UI language is set to English.")
    print("   Go to: Admin → User Management → Users → Edit → Language")
    print("=" * 60)
    print()
    print("🌐 Opening browser — credentials will be filled automatically.")
    print("   Approve the MFA notification on your device when prompted.")
    print("   The script continues once the Pardot dashboard is loaded.")
    print()

    # Fill Salesforce login form
    page.goto(SF_LOGIN_URL)
    page.wait_for_timeout(2000)
    try:
        page.fill("#username", SF_USERNAME)
        page.fill("#password", utils.get_password())
        page.click("#Login")
    except Exception:
        pass

    # Wait for MFA approval (30 s) — require Salesforce UI to be rendered
    print("   Waiting for MFA approval (approve on your device)...")
    SF_SESSION_SELECTORS = [
        ".slds-global-header", "#brandBand", "one-app-nav-bar",
        "a[title='App Launcher']", ".appLauncher", "one-app-launcher-header",
    ]
    MFA_KEYWORDS = ("login", "identity", "verification", "challenge", "mfa", "two-factor")
    for _ in range(15):   # 15 × 2 s = 30 s
        page.wait_for_timeout(2000)
        url = page.url.lower()
        if utils.is_pardot_url(url) and "login" not in url:
            break
        if "salesforce.com" in url and not any(k in url for k in MFA_KEYWORDS):
            def sf_ui_present():
                for s in SF_SESSION_SELECTORS:
                    try:
                        if page.query_selector(s):
                            return True
                    except Exception:
                        pass
                return False
            if sf_ui_present():
                break
    else:
        print("⚠️  Timed out waiting for MFA — proceeding anyway.")

    # Navigate to Pardot and handle the "Log in with Salesforce" prompt
    print("   Navigating to Pardot...")
    page.goto(utils.PARDOT_HOME, wait_until="networkidle", timeout=20000)
    page.wait_for_timeout(2000)
    _click_salesforce_login_if_prompted(page)

    # Poll until the Pardot dashboard is fully rendered (30 s)
    print("   Waiting for Pardot dashboard...")
    for _ in range(15):
        page.wait_for_timeout(2000)
        url = page.url.lower()
        if utils.is_pardot_url(url) and "login" not in url:
            if utils.pardot_dashboard_ready(page):
                break
    else:
        print("⚠️  Timed out waiting for dashboard — proceeding anyway.")

    print("✅ Dashboard detected — starting scraper.\n")


def _click_salesforce_login_if_prompted(page):
    """Click 'Log in with Salesforce' if Pardot shows its login chooser page."""
    for selector in [
        "a:has-text('Log in with Salesforce')",
        "button:has-text('Log in with Salesforce')",
        "a:has-text('Login with Salesforce')",
        "button:has-text('Login with Salesforce')",
        "[data-id='sfdc'] a",
        "a[href*='salesforce'][href*='login']",
    ]:
        try:
            el = page.query_selector(selector)
            if el and el.is_visible():
                print("   🔗 Pardot login prompt detected — clicking 'Log in with Salesforce'...")
                before_url = page.url
                el.click()
                try:
                    page.wait_for_function(
                        f"() => window.location.href !== {repr(before_url)}",
                        timeout=15000,
                    )
                except Exception:
                    pass
                page.wait_for_timeout(3000)
                return
        except Exception:
            continue

# ── Discover dynamic content items ───────────────────────────────────────────

def discover_content(page):
    print("📋 Discovering dynamic content items...")
    items = []
    seen  = set()
    hit_max_pages = False

    page.goto(utils.pardot_url(LIST_PATH), wait_until="networkidle", timeout=20000)
    page.wait_for_timeout(2000)

    # Handle possible Salesforce re-auth redirect
    for _ in range(15):
        url = page.url.lower()
        if utils.is_pardot_url(url, LIST_PATH):
            break
        if "salesforce.com" in url or "login" in url or "sso" in url:
            print("   🔑 Salesforce re-authentication detected — please log in...")
            page.wait_for_timeout(3000)
            continue
        page.wait_for_timeout(2000)
    else:
        print("⚠️  Timed out waiting for dynamic content list page.")
        hit_max_pages = True

    # Scroll to load all rows
    for _ in range(6):
        try:
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(700)
        except Exception:
            break

    page.screenshot(path=f"{SCREENSHOTS}/00_list.png", full_page=True)

    anchors = page.query_selector_all("a[href*='/dynamicContent/read/id/']")
    for a in anchors:
        href = a.get_attribute("href") or ""
        m = re.search(r'/dynamicContent/read/id/(\d+)', href)
        if m:
            item_id = m.group(1)
            name    = a.inner_text().strip()
            if item_id not in seen and name:
                seen.add(item_id)
                items.append({"id": item_id, "name": name})

    if not items:
        html = page.content()
        for m in re.finditer(r'/dynamicContent/read/id/(\d+)', html):
            item_id = m.group(1)
            if item_id not in seen:
                seen.add(item_id)
                items.append({"id": item_id, "name": f"DynamicContent {item_id}"})

    # Paginate — Pardot shows 50 items per page
    extra, paginate_hit_max = utils.paginate_collect(page, r'/dynamicContent/read/id/(\d+)', seen)
    items.extend(extra)
    hit_max_pages = hit_max_pages or paginate_hit_max

    sweep_verified = not hit_max_pages
    print(f"   ✅ Found {len(items)} dynamic content item(s)\n")
    return items, sweep_verified

# ── Parse DOM rows into structured data ──────────────────────────────────────

VAR_RE = re.compile(r'^Variation\s+([A-Z])\s*:', re.IGNORECASE)

def parse_rows(rows):
    """
    Convert the list of {key, value, val_html} DOM rows into the final data dict.
    Variation keys look like "Variation A:\nIs True" — split on newline.
    Images (logos, social icons, etc.) are extracted from val_html when present.
    """
    simple = {}
    default_content        = ""
    default_content_images = []
    variations = []

    for row in rows:
        key      = row["key"].strip()
        val      = (row["value"] or "").strip()
        val_html = row.get("val_html") or ""
        kl       = key.lower()
        images   = extract_images(val_html)

        if kl.startswith("name"):
            simple["name"] = val
        elif kl.startswith("folder"):
            simple["folder"] = val
        elif kl.startswith("tracker domain"):
            simple["tracker_domain"] = val
        elif kl.startswith("based on"):
            simple["based_on"] = val
        elif kl.startswith("created at"):
            simple["created_at"] = val
        elif kl.startswith("updated at"):
            simple["updated_at"] = val
        elif kl.startswith("default content"):
            default_content        = val
            default_content_images = images
        else:
            vm = VAR_RE.match(key)
            if vm:
                label = vm.group(1).upper()
                # Condition is the part after the newline (from <br> in the DOM)
                parts = key.split("\n", 1)
                condition = parts[1].strip() if len(parts) > 1 else ""
                variations.append({
                    "label":     label,
                    "condition": condition,
                    "content":   val,
                    "images":    images,
                })

    return {
        "name":                    simple.get("name", ""),
        "folder":                  simple.get("folder", ""),
        "tracker_domain":          simple.get("tracker_domain", ""),
        "based_on":                simple.get("based_on", ""),
        "default_content":         default_content,
        "default_content_images":  default_content_images,
        "variations":              variations,
        "created_at":              simple.get("created_at", ""),
        "updated_at":              simple.get("updated_at", ""),
    }

# ── Scrape a single dynamic content item ──────────────────────────────────────

def scrape_item(page, item_id, item_name):
    detail_url = f"{utils.PARDOT_HOME}/dynamicContent/read/id/{item_id}"
    try:
        page.goto(detail_url, wait_until="networkidle", timeout=15000)
    except Exception:
        try:
            page.goto(detail_url, wait_until="domcontentloaded", timeout=15000)
        except Exception as e:
            print(f"   ⚠️  Could not load {detail_url}: {e}")
            return None

    page.wait_for_timeout(2000)

    # Screenshot 1: top of page
    page.evaluate("window.scrollTo(0, 0)")
    page.wait_for_timeout(400)
    page.screenshot(path=f"{SCREENSHOTS}/dc_{item_id}_1_top.png", full_page=False)

    # Scroll to trigger lazy-loaded iframe renders
    try:
        scroll_height = page.evaluate("document.body.scrollHeight")
        pos = 0
        while pos < scroll_height:
            page.evaluate(f"window.scrollTo(0, {pos})")
            page.wait_for_timeout(200)
            pos += 400
            scroll_height = page.evaluate("document.body.scrollHeight")
        page.wait_for_timeout(600)
    except Exception:
        pass

    # Screenshot 2: variations section
    page.screenshot(path=f"{SCREENSHOTS}/dc_{item_id}_2_variations.png", full_page=False)

    # Extract key/value rows from the DOM table; collect iframe srcs for content cells
    rows = page.evaluate("""() => {
        return Array.from(document.querySelectorAll('table tr'))
            .map(row => {
                const key_el = row.querySelector('td.key');
                const val_el = row.querySelector('td.value');
                if (!key_el || !val_el) return null;
                const iframe = val_el.querySelector('iframe');
                return {
                    key:        key_el.innerText.trim(),
                    value:      iframe ? null : val_el.innerText.trim(),
                    val_html:   iframe ? null : val_el.innerHTML,
                    iframe_src: iframe ? iframe.getAttribute('src') : null
                };
            })
            .filter(r => r !== null && r.key);
    }""")

    # Fetch iframe content by navigating to each preview URL
    for row in rows:
        if row.get("iframe_src"):
            try:
                page.goto(row["iframe_src"], wait_until="domcontentloaded", timeout=10000)
                page.wait_for_timeout(800)
                raw_html = page.evaluate("document.body.innerHTML") or ""
                raw_text = (page.evaluate("document.body.innerText") or "").strip()
                # Defensive: strip any Prospects/Usages chrome if a variation
                # preview happens to render a Pardot-UI fragment.
                row["value"]    = utils.truncate_at_prospects(raw_text)
                row["val_html"] = raw_html
            except Exception:
                row["value"]    = ""
                row["val_html"] = ""

    data = parse_rows(rows)
    return {"id": item_id, "name": item_name, **data}

# ── Export CSV ────────────────────────────────────────────────────────────────

def _format_images(images):
    """Render a list of image dicts as a compact human-readable string for CSV."""
    if not images:
        return ""
    parts = []
    for img in images:
        label = img.get("type", "image").upper()
        src   = img.get("src", "")
        alt   = img.get("alt", "")
        link  = img.get("link", "")
        desc  = f"[{label}] {src}"
        if alt:
            desc += f' alt="{alt}"'
        if link:
            desc += f" → {link}"
        parts.append(desc)
    return " | ".join(parts)


def export_csv(results):
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow([
            "#", "Name", "ID", "Folder", "Tracker Domain", "Based On",
            "Default Content", "Default Images",
            "Variations", "Variation Images",
            "Created At", "Updated At",
        ])
        for i, r in enumerate(results, 1):
            variations_summary = " | ".join(
                f"{v['label']} [{v['condition']}]: {v['content'][:80]}"
                for v in r.get("variations", [])
            )
            variation_images_summary = " | ".join(
                f"{v['label']}: {_format_images(v.get('images', []))}"
                for v in r.get("variations", [])
                if v.get("images")
            )
            w.writerow([
                i,
                r["name"],
                r["id"],
                r.get("folder", ""),
                r.get("tracker_domain", ""),
                r.get("based_on", ""),
                r.get("default_content", "")[:200],
                _format_images(r.get("default_content_images", [])),
                variations_summary,
                variation_images_summary,
                r.get("created_at", ""),
                r.get("updated_at", ""),
            ])
    print(f"✅ Exported {OUTPUT_CSV} ({len(results)} rows)")


# ── Image-inventory CSV (one row per image) ───────────────────────────────────

def export_image_csv(results):
    """Flat CSV: one row per image found across all items and variations."""
    rows = []
    for r in results:
        item_name = r["name"]
        item_id   = r["id"]

        for img in r.get("default_content_images", []):
            rows.append({
                "Item Name":    item_name,
                "Item ID":      item_id,
                "Content Type": "Default",
                "Image Type":   img.get("type", ""),
                "Src":          img.get("src", ""),
                "Alt":          img.get("alt", ""),
                "Link URL":     img.get("link", ""),
            })

        for v in r.get("variations", []):
            label = v.get("label", "")
            cond  = v.get("condition", "")
            for img in v.get("images", []):
                rows.append({
                    "Item Name":    item_name,
                    "Item ID":      item_id,
                    "Content Type": f"Variation {label} ({cond})" if cond else f"Variation {label}",
                    "Image Type":   img.get("type", ""),
                    "Src":          img.get("src", ""),
                    "Alt":          img.get("alt", ""),
                    "Link URL":     img.get("link", ""),
                })

    if not rows:
        print("ℹ️  No images found — image inventory CSV not written.")
        return

    with open(OUTPUT_IMAGE_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=[
            "Item Name", "Item ID", "Content Type",
            "Image Type", "Src", "Alt", "Link URL",
        ])
        w.writeheader()
        w.writerows(rows)
    print(f"✅ Exported {OUTPUT_IMAGE_CSV} ({len(rows)} image rows)")


# ── Image HTML report ─────────────────────────────────────────────────────────

def export_image_html(results):
    """HTML report: one card per dynamic content item that contains images."""
    # Filter to items that have at least one image somewhere
    image_items = [
        r for r in results
        if r.get("default_content_images") or
           any(v.get("images") for v in r.get("variations", []))
    ]

    if not image_items:
        print("ℹ️  No images found — HTML report not written.")
        return

    def _img_card(img):
        src  = img.get("src", "")
        alt  = img.get("alt", "") or img.get("type", "image")
        link = img.get("link", "")
        typ  = img.get("type", "image")
        badge_color = {
            "logo":        "#4A90D9",
            "social_icon": "#27AE60",
            "icon":        "#E67E22",
            "image":       "#7F8C8D",
        }.get(typ, "#7F8C8D")

        img_tag = f'<img src="{src}" alt="{alt}" onerror="this.style.display=\'none\';this.nextSibling.style.display=\'block\'">'
        fallback = f'<span class="img-fallback">⚠ Image not accessible</span>'
        link_tag = f'<a href="{link}" target="_blank" class="img-link">{link}</a>' if link else '<span class="no-link">No link</span>'

        return f"""
        <div class="img-card">
          <span class="badge" style="background:{badge_color}">{typ.replace("_"," ").upper()}</span>
          <div class="img-preview">{img_tag}{fallback}</div>
          <div class="img-meta">
            <div class="img-src" title="{src}">{src}</div>
            <div class="img-link-row">🔗 {link_tag}</div>
            {"" if not alt else f'<div class="img-alt">alt: {alt}</div>'}
          </div>
        </div>"""

    def _section(label, images):
        if not images:
            return ""
        cards = "".join(_img_card(img) for img in images)
        return f'<div class="section"><div class="section-label">{label}</div><div class="img-grid">{cards}</div></div>'

    cards_html = ""
    for r in image_items:
        item_sections = _section("Default", r.get("default_content_images", []))
        for v in r.get("variations", []):
            label = v.get("label", "")
            cond  = v.get("condition", "")
            item_sections += _section(
                f"Variation {label}" + (f" — {cond}" if cond else ""),
                v.get("images", [])
            )

        cards_html += f"""
        <div class="item-card">
          <div class="item-header">
            <span class="item-name">{r["name"]}</span>
            <span class="item-meta">ID {r["id"]} · {r.get("folder","—")} · Based on: {r.get("based_on","—")}</span>
          </div>
          {item_sections}
        </div>"""

    total_images = sum(
        len(r.get("default_content_images", [])) +
        sum(len(v.get("images", [])) for v in r.get("variations", []))
        for r in image_items
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Pardot Dynamic Content — Image Inventory</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
         background: #f4f6f9; color: #2c3e50; margin: 0; padding: 24px; }}
  h1   {{ font-size: 1.4rem; margin-bottom: 4px; }}
  .subtitle {{ color: #7f8c8d; font-size: 0.85rem; margin-bottom: 24px; }}
  .item-card {{ background: #fff; border-radius: 8px; box-shadow: 0 1px 4px rgba(0,0,0,.1);
                margin-bottom: 20px; overflow: hidden; }}
  .item-header {{ background: #2c3e50; color: #fff; padding: 12px 16px; }}
  .item-name  {{ font-weight: 600; font-size: 1rem; display: block; }}
  .item-meta  {{ font-size: 0.75rem; color: #95a5a6; margin-top: 2px; display: block; }}
  .section    {{ padding: 12px 16px; border-bottom: 1px solid #ecf0f1; }}
  .section:last-child {{ border-bottom: none; }}
  .section-label {{ font-size: 0.75rem; font-weight: 600; text-transform: uppercase;
                    letter-spacing: .06em; color: #7f8c8d; margin-bottom: 10px; }}
  .img-grid   {{ display: flex; flex-wrap: wrap; gap: 12px; }}
  .img-card   {{ border: 1px solid #dfe6e9; border-radius: 6px; padding: 10px;
                 width: 260px; background: #fafbfc; position: relative; }}
  .badge      {{ display: inline-block; font-size: 0.65rem; font-weight: 700;
                 color: #fff; border-radius: 3px; padding: 2px 6px; margin-bottom: 8px; }}
  .img-preview {{ height: 80px; display: flex; align-items: center; justify-content: center;
                  margin-bottom: 8px; }}
  .img-preview img {{ max-height: 80px; max-width: 100%; object-fit: contain; }}
  .img-fallback {{ display: none; font-size: 0.75rem; color: #e74c3c; }}
  .img-src    {{ font-size: 0.7rem; color: #636e72; word-break: break-all;
                 white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }}
  .img-link-row {{ font-size: 0.75rem; margin-top: 4px; }}
  .img-link   {{ color: #2980b9; text-decoration: none; word-break: break-all; }}
  .img-link:hover {{ text-decoration: underline; }}
  .no-link    {{ color: #b2bec3; font-style: italic; }}
  .img-alt    {{ font-size: 0.7rem; color: #95a5a6; margin-top: 2px; }}
</style>
</head>
<body>
<h1>Pardot Dynamic Content — Image Inventory</h1>
<div class="subtitle">{len(image_items)} items with images · {total_images} images total</div>
{cards_html}
</body>
</html>"""

    with open(OUTPUT_IMAGE_HTML, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"✅ Exported {OUTPUT_IMAGE_HTML} ({len(image_items)} items, {total_images} images)")


# ── Run (browser-agnostic entry point) ───────────────────────────────────────

def run(page, update: bool = False, max_age_days: int = 7, refresh_limit: int = 25,
        allow_prune: bool = False, dry_run: bool = False):
    """Discover, scrape, and export — no browser lifecycle management."""
    global OUTPUT_JSON, OUTPUT_CSV, OUTPUT_IMAGE_CSV, OUTPUT_IMAGE_HTML, SCREENSHOTS
    OUTPUT_JSON       = utils.output_path("pardot_dynamic_content.json")
    OUTPUT_CSV        = utils.output_path("pardot_dynamic_content.csv")
    OUTPUT_IMAGE_CSV  = utils.output_path("pardot_dynamic_content_images.csv")
    OUTPUT_IMAGE_HTML = utils.output_path("pardot_dynamic_content_images.html")
    SCREENSHOTS       = utils.output_path("screenshots", "dynamic_content")
    utils.reset_screenshots(SCREENSHOTS)

    kind = "dynamic_content"
    started_at = utils.now_iso()
    ok_ids = set()

    # ── Tier C: Load previous output & set up ID-based gating ────────────────────
    cached: dict[str, dict] = {}
    if update:
        cached = utils.load_previous_output(kind)
        cached_hash = utils.manifest_entry(f"scrape_{kind}").get("shape_hash")
        if cached_hash and cached_hash != utils.shape_hash(CSV_HEADERS):
            print("   ⚠️  Output shape changed — ignoring cache, full scrape this run")
            cached = {}
        print(f"   [update] {len(cached)} cached record(s)")

    results = []
    items, sweep_verified = discover_content(page)

    if not items:
        print("❌ No dynamic content found — check that you are on the Pardot list page.")
        return

    # ── Tier C: Determine which items to visit (ID-based + aging sweep) ─────────
    current_ids = {item["id"] for item in items}
    stale = utils.stale_ids(kind, current_ids, max_age_days=max_age_days,
                            limit=refresh_limit) if update else set()
    to_visit = current_ids if not update else (current_ids - set(cached.keys())) | stale

    print(f"🔍 Scraping {len(items)} dynamic content item(s): {len(to_visit)} visit(s), {len(items)-len(to_visit)} cached...")
    for item in items:
        item_id = item["id"]
        print(f"   • {item['name']} (id: {item_id})", end="")

        if update and item_id not in to_visit:
            print(" [cached]")
            fresh = utils.merge_record_fields(cached.get(item_id, {}), item, [])
            results.append(fresh)
            continue

        print()
        result = scrape_item(page, item_id, item["name"])
        if result:
            results.append(result)
            print(f"       ✅ scraped")
            ok_ids.add(item_id)
        page.wait_for_timeout(300)

    # ── Tier C: Merge cached + prune deleted ────────────────────────────────────
    merged = utils.merge_records(cached.values() if update else [], {r["id"]: r for r in results})
    prev = utils.manifest_entry(f"scrape_{kind}")
    record_count = prev.get("record_count", len(merged))
    merged, pruned = utils.apply_prune(
        merged, current_ids, sweep_verified=True,
        record_count=record_count, allow_prune=allow_prune
    )

    results.sort(key=lambda r: int(r.get("id", 0)) if str(r.get("id", "")).isdigit() else str(r.get("id", "")))
    if dry_run:
        print(f"   [dry-run] would visit {len(to_visit)} of {len(current_ids)} record(s)")
        print(f"   [dry-run] would merge {len(results)}, prune {len(pruned)}")
        print(f"   [dry-run] no files written")
    else:
        with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
            json.dump(merged, f, ensure_ascii=False, indent=2)
        print(f"\n✅ Saved {OUTPUT_JSON} ({len(merged)} items)")
        export_csv(merged)
        export_image_csv(merged)
        export_image_html(merged)

        if update and ok_ids:
            utils.mark_scraped(kind, ok_ids)
            utils.write_manifest(f"scrape_{kind}", started_at=started_at,
                                shape_hash_val=utils.shape_hash(CSV_HEADERS), record_count=len(merged))

    print(f"📸 Screenshots: {SCREENSHOTS}/")

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    utils.load_org_config()
    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            wait_for_login(page)
            run(page)
        finally:
            context.close()

if __name__ == "__main__":
    main()
