"""
lookup_sf_ids.py
================
Given a list of names / emails, find their Salesforce Record ID.

Input:  input_lookup.csv  (columns: Email, FirstName, LastName)
Output: output_sf_ids.csv (same columns + SalesforceId, SFObject)

Search order: Contact first, then Lead for any unmatched emails.
Matching is case-insensitive on email.

Usage:
    python lookup_sf_ids.py [input_file] [output_file]

Defaults:
    input_file  = input_lookup.csv
    output_file = output_sf_ids.csv
"""

from __future__ import annotations

import csv
import os
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlencode, quote_plus

from dotenv import load_dotenv
from playwright.sync_api import sync_playwright

import utils
import pardot_api

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))

SF_LOGIN_URL = os.getenv("SF_LOGIN_URL", "https://login.salesforce.com").rstrip("/")
SF_API_VERSION = os.getenv("SF_API_VERSION", "v60.0")
SF_API_BASE = f"{SF_LOGIN_URL}/services/data/{SF_API_VERSION}"

INPUT_FILE  = sys.argv[1] if len(sys.argv) > 1 else "input_lookup.csv"
OUTPUT_FILE = sys.argv[2] if len(sys.argv) > 2 else "output_sf_ids.csv"

BATCH_SIZE = 100  # SOQL IN clause limit per query


# ── SOQL helpers ──────────────────────────────────────────────────────────────

def soql_query(session, token: str, soql: str) -> list[dict]:
    """Run a SOQL query and return all records (handles nextRecordsUrl paging)."""
    url = f"{SF_API_BASE}/query"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    params = {"q": soql}
    records = []

    resp = session.get(url, headers=headers, params=params, timeout=30)
    if resp.status_code != 200:
        print(f"   ⚠️  SOQL error {resp.status_code}: {resp.text[:300]}")
        return records

    data = resp.json()
    records.extend(data.get("records", []))

    while not data.get("done") and data.get("nextRecordsUrl"):
        next_url = SF_LOGIN_URL + data["nextRecordsUrl"]
        resp = session.get(next_url, headers=headers, timeout=30)
        data = resp.json()
        records.extend(data.get("records", []))

    return records


def emails_to_soql_in(emails: list[str]) -> str:
    escaped = ", ".join(f"'{e.replace(chr(39), chr(92)+chr(39))}'" for e in emails)
    return f"({escaped})"


def lookup_by_email(session, token: str, emails: list[str], obj: str) -> dict[str, dict]:
    """
    Return {email_lower: record} for all found records in obj (Contact or Lead).
    Queries in batches of BATCH_SIZE.
    """
    results: dict[str, dict] = {}
    fields = "Id, FirstName, LastName, Email"
    extra = " AND IsConverted = false" if obj == "Lead" else ""

    for i in range(0, len(emails), BATCH_SIZE):
        batch = emails[i : i + BATCH_SIZE]
        in_clause = emails_to_soql_in(batch)
        soql = f"SELECT {fields} FROM {obj} WHERE Email IN {in_clause}{extra}"
        records = soql_query(session, token, soql)
        for r in records:
            key = (r.get("Email") or "").lower()
            if key:
                results[key] = r

    return results


# ── Main ──────────────────────────────────────────────────────────────────────

def run():
    input_path = Path(INPUT_FILE)
    if not input_path.exists():
        print(f"❌ Input file not found: {input_path.resolve()}")
        print()
        print("Create a CSV with columns: Email, FirstName, LastName")
        print("(FirstName and LastName are optional but help disambiguate results)")
        sys.exit(1)

    # ── Read input ────────────────────────────────────────────────────────────
    rows: list[dict] = []
    with open(input_path, newline="", encoding="utf-8-sig") as f:
        sample = f.read(2048)
        f.seek(0)
        delimiter = ";" if sample.count(";") > sample.count(",") else ","
        reader = csv.DictReader(f, delimiter=delimiter)
        fieldnames = reader.fieldnames or []
        for row in reader:
            rows.append(row)

    if not rows:
        print("❌ Input file is empty.")
        sys.exit(1)

    # Normalize: find the email column (case-insensitive header match)
    email_col = next(
        (c for c in fieldnames if c.strip().lower() in ("email", "e-mail", "emailaddress")),
        None,
    )
    if not email_col:
        print(f"❌ Could not find an Email column in: {fieldnames}")
        print("   Make sure the CSV has a column named 'Email'.")
        sys.exit(1)

    emails_raw = [r[email_col].strip() for r in rows if r[email_col].strip()]
    emails_lower = [e.lower() for e in emails_raw]
    unique_emails = list(dict.fromkeys(emails_lower))  # deduplicated, ordered

    print(f"📋 {len(rows)} rows loaded, {len(unique_emails)} unique emails to look up.")

    # ── Auth ──────────────────────────────────────────────────────────────────
    utils.validate_credentials()
    session = pardot_api.make_session()

    with sync_playwright() as pw:
        print("🌐 Launching browser for Salesforce login...")
        ctx = utils.launch_context(pw)
        page = ctx.new_page()
        utils.login(page)
        token = pardot_api.extract_access_token(page)
        ctx.close()

    print(f"\n🔍 Querying Salesforce (Contact then Lead)...")

    # ── Query Contact ─────────────────────────────────────────────────────────
    contact_map = lookup_by_email(session, token, unique_emails, "Contact")
    print(f"   ✅ Contact matches: {len(contact_map)}")

    # ── Query Lead for unmatched ───────────────────────────────────────────────
    unmatched = [e for e in unique_emails if e not in contact_map]
    lead_map: dict[str, dict] = {}
    if unmatched:
        lead_map = lookup_by_email(session, token, unmatched, "Lead")
        print(f"   ✅ Lead matches:    {len(lead_map)}")

    still_missing = [e for e in unique_emails if e not in contact_map and e not in lead_map]
    if still_missing:
        print(f"   ⚠️  Not found in either object: {len(still_missing)}")
        for e in still_missing:
            print(f"      {e}")

    # ── Build output ──────────────────────────────────────────────────────────
    out_rows = []
    for row in rows:
        email_key = row[email_col].strip().lower()
        sf_record = contact_map.get(email_key) or lead_map.get(email_key)
        out_row = dict(row)
        if sf_record:
            out_row["SalesforceId"] = sf_record.get("Id", "")
            out_row["SFObject"]     = "Contact" if email_key in contact_map else "Lead"
            out_row["SF_FirstName"] = sf_record.get("FirstName", "")
            out_row["SF_LastName"]  = sf_record.get("LastName", "")
        else:
            out_row["SalesforceId"] = ""
            out_row["SFObject"]     = "NOT FOUND"
            out_row["SF_FirstName"] = ""
            out_row["SF_LastName"]  = ""
        out_rows.append(out_row)

    out_headers = list(fieldnames) + ["SalesforceId", "SFObject", "SF_FirstName", "SF_LastName"]
    output_path = Path(OUTPUT_FILE)
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=out_headers, extrasaction="ignore", delimiter=delimiter)
        writer.writeheader()
        writer.writerows(out_rows)

    found = sum(1 for r in out_rows if r["SalesforceId"])
    print(f"\n✅ Done! {found}/{len(rows)} records matched.")
    print(f"   Output: {output_path.resolve()}")


if __name__ == "__main__":
    run()
