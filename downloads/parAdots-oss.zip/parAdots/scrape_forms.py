"""
Pardot Form Scraper — hybrid (API + browser)
============================================
Primary data from v5 API (fast, structured).
Browser supplements with completion_actions only (Step 5 wizard per form).

Data sources:
  API  → all fields: campaign, folder, layout, tracker domain, form fields
         (label/type/required), above/below form content, thank you content,
         kiosk mode, submit button text, salesforce ID, updated at
  Browser (Step 5 only) → completion_actions (not exposed by v5 API)

Output:
  pardot_forms.json
  pardot_forms.csv
  screenshots/forms/  (list page + one Step-5 per form)

Usage:
  python3 scrape_forms.py
"""

from __future__ import annotations

import csv, json, os, re, sys
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time via utils.output_path()
OUTPUT_CSV  = ""
SCREENSHOTS = ""
LIST_PATH   = "/form/forms"

CSV_HEADERS = ["id", "name", "folder", "campaign", "status", "created_at", "updated_at", "fields", "prospect_count", "completion_actions"]

# ── v5 API field lists ────────────────────────────────────────────────────────

FORM_FIELDS = [
    "id", "name",
    "campaignId", "folderId",
    "redirectLocation", "trackerDomainId", "layoutTemplateId",
    "thankYouContent", "thankYouCode",
    "beforeFormContent", "afterFormContent",
    "submitButtonText",
    "isCookieless", "isAlwaysDisplay",
    "salesforceId",
    "createdAt", "updatedAt",
]

FORM_FIELD_FIELDS = [
    "id", "formId", "prospectApiFieldId", "label", "type", "isRequired",
    "isAlwaysDisplay", "sortOrder",
]

FOLDER_LOOKUP_FIELDS   = ("id", "name")
CAMPAIGN_LOOKUP_FIELDS = ("id", "name")
TRACKER_LOOKUP_FIELDS  = ("id", "domain")
LAYOUT_LOOKUP_FIELDS   = ("id", "name")

# ── API data layer ────────────────────────────────────────────────────────────

def build_form_fields_index(client: pardot_api.PardotClient) -> dict[str, list[dict]]:
    """One paged sweep of /form-fields, grouped by formId and sorted by sortOrder."""
    index: dict[str, list[dict]] = {}
    for field in pardot_api.paged_get(client, "objects/form-fields", fields=FORM_FIELD_FIELDS):
        fid = str(field.get("formId") or "")
        if fid:
            index.setdefault(fid, []).append(field)
    for fields in index.values():
        fields.sort(key=lambda f: (f.get("sortOrder") or 0, f.get("label") or ""))
    return index


def format_form_fields(fields: list[dict]) -> list[str]:
    out = []
    for f in fields:
        label = (f.get("label") or f.get("prospectApiFieldId") or "").strip()
        ftype = (f.get("type") or "").strip()
        req   = " (required)" if f.get("isRequired") else ""
        if label:
            out.append(f"{label} → {ftype}{req}" if ftype else f"{label}{req}")
    return out


def shape_form(
    form: dict,
    folders: dict,
    campaigns: dict,
    trackers: dict,
    layouts: dict,
    form_fields_index: dict[str, list[dict]],
) -> dict:
    fid = str(form.get("id"))
    return {
        "id":                  fid,
        "name":                form.get("name", ""),
        "campaign":            (campaigns.get(form.get("campaignId")) or {}).get("name", ""),
        "folder":              (folders.get(form.get("folderId")) or {}).get("name", ""),
        "tracker_domain":      (trackers.get(form.get("trackerDomainId")) or {}).get("domain", ""),
        "layout":              (layouts.get(form.get("layoutTemplateId")) or {}).get("name", ""),
        "success_location":    form.get("redirectLocation", "") or "",
        "kiosk_mode":          "Yes" if form.get("isCookieless") else "No",
        "always_display_form": "Yes" if form.get("isAlwaysDisplay") else "No",
        "submit_button_text":  form.get("submitButtonText", "") or "",
        "above_form_content":  form.get("beforeFormContent", "") or "",
        "below_form_content":  form.get("afterFormContent", "") or "",
        "thank_you_content":   form.get("thankYouContent", "") or "",
        "thank_you_code":      form.get("thankYouCode", "") or "",
        "completion_actions":  [],   # filled by browser pass below
        "prospect_count":      "",   # filled by browser pass below
        "form_fields":         format_form_fields(form_fields_index.get(fid, [])),
        "salesforce_id":       form.get("salesforceId", "") or "",
        "updated_at":          form.get("updatedAt", "") or "",
    }

# ── Browser helpers ───────────────────────────────────────────────────────────

def _scroll_full(page):
    try:
        page.evaluate("window.scrollTo(0, 0)")
        page.wait_for_timeout(300)
        height = page.evaluate("document.body.scrollHeight")
        pos = 0
        while pos < height:
            page.evaluate(f"window.scrollTo(0, {pos})")
            page.wait_for_timeout(150)
            pos += 600
            height = page.evaluate("document.body.scrollHeight")
        page.wait_for_timeout(400)
    except Exception:
        pass


def _extract_completion_actions(page) -> list[str]:
    """Parse the Completion Actions section from Step 5's plain-text summary."""
    result = page.evaluate("""() => {
        const completion_actions = [];
        let inActions = false;
        const STOP  = new Set(['name', 'folder', 'campaign', 'confirm & save']);
        const NOISE = new Set(['there are no actions', 'preview form', 'cancel', 'save']);
        document.body.innerText.split('\\n').forEach(raw => {
            const line = raw.trim();
            const ll   = line.toLowerCase();
            if (ll === 'completion actions') { inActions = true; return; }
            if (inActions) {
                if (STOP.has(ll) || NOISE.has(ll) || !line) return;
                completion_actions.push(line);
            }
        });
        return completion_actions;
    }""")
    return result or []


def _extract_form_submissions(page) -> str:
    """Extract form submission/conversion count from the form read page.

    Looks for stats cards or summary text with submission metrics.
    Returns the count as a string, or empty string if not found.
    """
    try:
        result = page.evaluate("""() => {
            const text = document.body.innerText.toLowerCase();
            const lines = text.split('\\n').map(l => l.trim());

            // Look for "conversions" or "submissions" labels with preceding numbers
            const conversionKeywords = ['conversions', 'form conversions', 'submissions', 'form submissions', 'submitted'];

            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                for (const keyword of conversionKeywords) {
                    if (line.includes(keyword)) {
                        // Check previous line for a number
                        if (i > 0) {
                            const prevLine = lines[i - 1].replace(/[,.]/, '');
                            if (/^\\d+$/.test(prevLine)) {
                                return prevLine;
                            }
                        }
                        // Check current line for a number at start
                        const match = line.match(/^(\\d+)[^\\d]/);
                        if (match) {
                            return match[1];
                        }
                    }
                }
            }
            return '';
        }""")
        return result or ""
    except Exception:
        return ""

# ── UI form discovery ─────────────────────────────────────────────────────────

def discover_forms(page) -> list[dict]:
    """Navigate to the forms list page and collect visible form IDs + names."""
    print("📋 Discovering forms from UI list...")
    forms = []
    seen  = set()

    try:
        page.goto(utils.pardot_url(LIST_PATH), wait_until="networkidle", timeout=30000)
    except Exception:
        try:
            page.goto(utils.pardot_url(LIST_PATH), wait_until="domcontentloaded", timeout=30000)
        except Exception:
            pass
    page.wait_for_timeout(2000)

    for _ in range(15):
        url = page.url.lower()
        if utils.is_pardot_url(url, "/form"):
            break
        if "salesforce.com" in url or "login" in url or "sso" in url:
            page.wait_for_timeout(3000)
            continue
        page.wait_for_timeout(2000)

    for _ in range(6):
        try:
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(700)
        except Exception:
            break

    page.screenshot(path=f"{SCREENSHOTS}/00_list.png", full_page=True)

    # Scope to the main forms table only (avoids stale sidebar / recently-viewed links)
    links = page.evaluate("""() => {
        let container = null;
        for (const el of document.querySelectorAll('table, .list-table, [class*="data-table"]')) {
            if (el.innerText.includes('FORMS') || el.innerText.includes('Forms')) {
                container = el;
                break;
            }
        }
        if (!container) container = document.querySelector('.main-content, #main, main') || document.body;
        const results = [];
        container.querySelectorAll('a[href*="/form/read/id/"]').forEach(a => {
            const href = a.getAttribute('href') || '';
            const name = a.innerText.trim().replace(/\\s+/g, ' ');
            if (href && name) results.push({href, name});
        });
        return results;
    }""")

    for link in links:
        m = re.search(r'/form/read/id/(\d+)', link["href"])
        if m:
            fid  = m.group(1)
            name = link["name"]
            if fid not in seen and name:
                seen.add(fid)
                forms.append({"id": fid, "name": name})

    print(f"   ✅ Found {len(forms)} form(s)\n")
    return forms

# ── Browser pass: Step 5 per form for completion_actions ─────────────────────

def fetch_completion_actions(page, form_id: str) -> list[str]:
    """Navigate to wizard Step 5 (Confirm & Save), screenshot, extract completion actions."""
    url = f"{utils.PARDOT_HOME}/form/wizardStep5/object_id/{form_id}/wizardType/9/isRead/true"
    try:
        page.goto(url, wait_until="networkidle", timeout=20000)
    except Exception:
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=20000)
        except Exception as e:
            print(f"   ⚠️  Step 5 load failed for form {form_id}: {e}")
            return []

    page.wait_for_timeout(1500)
    _scroll_full(page)
    page.evaluate("window.scrollTo(0, 0)")
    page.wait_for_timeout(300)
    page.screenshot(
        path=f"{SCREENSHOTS}/form_{form_id}_step5_confirm.png",
        full_page=True,
    )
    return _extract_completion_actions(page)


def fetch_form_submissions(page, form_id: str) -> str:
    """Navigate to the form read page and extract submission/conversion count."""
    url = f"{utils.PARDOT_HOME}/form/read/id/{form_id}"
    try:
        page.goto(url, wait_until="networkidle", timeout=20000)
    except Exception:
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=20000)
        except Exception as e:
            print(f"   ⚠️  Form read page load failed for form {form_id}: {e}")
            return ""

    page.wait_for_timeout(1000)
    _scroll_full(page)
    return _extract_form_submissions(page)

# ── Export ────────────────────────────────────────────────────────────────────

def export_csv(results: list[dict]) -> None:
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow([
            "#", "Name", "ID", "Campaign", "Folder",
            "Tracker Domain", "Layout",
            "Kiosk Mode", "Always Display Form", "Submit Button Text",
            "Success Location",
            "Above Form Content", "Below Form Content",
            "Thank You Content", "Thank You Code",
            "Prospect Count", "Completion Actions", "Form Fields",
            "Salesforce ID", "Updated At",
        ])
        for i, r in enumerate(results, 1):
            w.writerow([
                i,
                r["name"], r["id"],
                r.get("campaign", ""),
                r.get("folder", ""),
                r.get("tracker_domain", ""),
                r.get("layout", ""),
                r.get("kiosk_mode", ""),
                r.get("always_display_form", ""),
                r.get("submit_button_text", ""),
                r.get("success_location", ""),
                r.get("above_form_content", ""),
                r.get("below_form_content", ""),
                r.get("thank_you_content", ""),
                r.get("thank_you_code", ""),
                r.get("prospect_count", ""),
                "\n".join(r.get("completion_actions", [])),
                "\n".join(r.get("form_fields", [])),
                r.get("salesforce_id", ""),
                r.get("updated_at", ""),
            ])
    print(f"✅ Exported {OUTPUT_CSV} ({len(results)} rows)")

# ── Orchestrator ──────────────────────────────────────────────────────────────

def run(page, client: pardot_api.PardotClient | None = None,
        update: bool = False, max_age_days: int = 7, refresh_limit: int = 25,
        allow_prune: bool = False, dry_run: bool = False) -> None:
    global OUTPUT_JSON, OUTPUT_CSV, SCREENSHOTS
    OUTPUT_JSON = utils.output_path("pardot_forms.json")
    OUTPUT_CSV  = utils.output_path("pardot_forms.csv")
    SCREENSHOTS = utils.output_path("screenshots", "forms")
    utils.reset_screenshots(SCREENSHOTS)

    kind = "forms"
    started_at = utils.now_iso()
    ok_ids = set()

    # ── Tier B: Load previous output & set up API + aging gating ────────────────
    cached: dict[str, dict] = {}
    if update:
        cached = utils.load_previous_output(kind)
        cached_hash = utils.manifest_entry(f"scrape_{kind}").get("shape_hash")
        if cached_hash and cached_hash != utils.shape_hash(CSV_HEADERS):
            print("   ⚠️  Output shape changed — ignoring cache, full scrape this run")
            cached = {}
        print(f"   [update] {len(cached)} cached record(s)")

    # 1. Build API client from the logged-in browser session
    if client is None:
        client = pardot_api.client_from_page(page)

    # 2. API sweep — all form data except completion_actions
    print("📚 Pre-loading reference data...")
    folders   = pardot_api.lookup_map(client, "objects/folders",          FOLDER_LOOKUP_FIELDS)
    campaigns = pardot_api.lookup_map(client, "objects/campaigns",        CAMPAIGN_LOOKUP_FIELDS)
    trackers  = pardot_api.lookup_map(client, "objects/tracker-domains",  TRACKER_LOOKUP_FIELDS)
    layouts   = pardot_api.lookup_map(client, "objects/layout-templates", LAYOUT_LOOKUP_FIELDS)
    print(f"   ✅ {len(folders)} folders / {len(campaigns)} campaigns / "
          f"{len(trackers)} trackers / {len(layouts)} layouts")

    print("📚 Indexing form fields...")
    form_fields_index = build_form_fields_index(client)
    print(f"   ✅ {sum(len(v) for v in form_fields_index.values())} field rows "
          f"across {len(form_fields_index)} form(s)")

    print("📋 Fetching forms via API...")
    api_forms: dict[str, dict] = {}
    api_error = False
    try:
        for form in pardot_api.paged_get(client, "objects/forms", fields=FORM_FIELDS):
            record = shape_form(form, folders, campaigns, trackers, layouts, form_fields_index)
            api_forms[record["id"]] = record
    except Exception:
        api_error = True
    sweep_verified = not api_error
    print(f"   ✅ {len(api_forms)} form(s)\n")

    # 3. UI validation — discover active forms from the live list page
    ui_forms = discover_forms(page)
    if not ui_forms:
        print("❌ No forms found on UI list page.")
        return

    # ── Tier B: Determine which forms to visit (API updatedAt + aging sweep) ────
    current_ids = {f["id"] for f in ui_forms}
    stale = utils.stale_ids(kind, current_ids, max_age_days=max_age_days,
                            limit=refresh_limit) if update else set()

    def should_visit_form(fid: str, api_record: dict) -> bool:
        if not update:
            return True
        if fid not in cached:
            return True
        if fid in stale:
            return True
        cached_updated = cached.get(fid, {}).get("updated_at", "")
        api_updated = api_record.get("updated_at", "")
        return cached_updated != api_updated

    # 4. Browser pass — per form, fetch submission count and completion_actions (Step 5)
    print(f"🔍 Fetching form metrics for {len(ui_forms)} form(s)...\n")
    results = []
    for f in ui_forms:
        fid    = f["id"]
        record = api_forms.get(fid, {"id": fid, "name": f["name"]})

        if update and fid in cached and not should_visit_form(fid, record):
            print(f"   [{fid}] {record.get('name', 'Unknown')} [cached]")
            fresh = utils.merge_record_fields(cached.get(fid, {}), record, ["prospect_count", "completion_actions"])
            results.append(fresh)
            continue

        record["prospect_count"]     = fetch_form_submissions(page, fid)
        record["completion_actions"] = fetch_completion_actions(page, fid)
        results.append(record)
        print(f"   ✅ {record['name']}")
        ok_ids.add(fid)
        page.wait_for_timeout(300)

    # ── Tier B: Merge cached + prune deleted ────────────────────────────────────
    merged = utils.merge_records(cached.values() if update else [], {r["id"]: r for r in results})
    prev = utils.manifest_entry(f"scrape_{kind}")
    record_count = prev.get("record_count", len(merged))
    merged, pruned = utils.apply_prune(
        merged, current_ids, sweep_verified=sweep_verified,
        record_count=record_count, allow_prune=allow_prune
    )

    # 5. Export
    merged.sort(key=lambda r: int(r.get("id", 0)) if str(r.get("id", "")).isdigit() else str(r.get("id", "")))
    if dry_run:
        print(f"   [dry-run] would visit {len(ok_ids)} of {len(current_ids)} record(s)")
        print(f"   [dry-run] would merge {len(results)}, prune {len(pruned)}")
        print(f"   [dry-run] no files written")
    else:
        with open(OUTPUT_JSON, "w", encoding="utf-8") as fh:
            json.dump(merged, fh, ensure_ascii=False, indent=2)
        print(f"\n✅ Saved {OUTPUT_JSON} ({len(merged)} forms)")
        export_csv(merged)

        if update and ok_ids:
            utils.mark_scraped(kind, ok_ids)
            utils.write_manifest(f"scrape_{kind}", started_at=started_at,
                                shape_hash_val=utils.shape_hash(CSV_HEADERS), record_count=len(merged))

    print(f"📸 Screenshots: {SCREENSHOTS}/")


def main() -> None:
    utils.load_org_config()
    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
