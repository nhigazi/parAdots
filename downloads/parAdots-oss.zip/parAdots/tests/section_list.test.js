/* TDD harness for pickListColumns() and splitHidden() — view mode helpers.
 * Extracts the marked block and evaluates in an isolated vm context. */
const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadFunctions() {
  const html = fs.readFileSync(path.join(__dirname, '..', 'viewer.html'), 'utf8');
  const m = html.match(/\/\* @section-list-start \*\/([\s\S]*?)\/\* @section-list-end \*\//);
  if (!m) throw new Error('section-list markers not found in viewer.html');
  const ctx = {};
  vm.createContext(ctx);
  vm.runInContext(m[1] + '\nthis.pickListColumns = pickListColumns; this.splitHidden = splitHidden;', ctx);
  return { pickListColumns: ctx.pickListColumns, splitHidden: ctx.splitHidden };
}

const { pickListColumns, splitHidden } = loadFunctions();
const norm = (v) => JSON.parse(JSON.stringify(v));

/* ════════════════════════════════════════════════════════════════
   pickListColumns(def)
═════════════════════════════════════════════════════════════════ */

test('pickListColumns: no w — returns primary, idCol, badge, metrics (truncated to 3 meta)', () => {
  const def = {
    cols: [
      { id: 'Name',    primary: true },
      { id: 'ID',      idCol: true },
      { id: 'Status',  badge: true },
      { id: 'Count',   metric: true },
      { id: 'Updated', meta: true },
      { id: 'Folder',  meta: true },
      { id: 'Path',    meta: true },
      { id: 'Notes',   meta: true },
    ]
  };
  const cols = norm(pickListColumns(def));
  const ids = cols.map(c => c.id);
  assert.deepStrictEqual(ids, ['Name', 'ID', 'Status', 'Count', 'Updated', 'Folder', 'Path']);
});

test('pickListColumns: body cols never returned', () => {
  const def = {
    cols: [
      { id: 'Name',   primary: true },
      { id: 'ID',     idCol: true },
      { id: 'Desc',   body: true },
      { id: 'Notes',  body: true },
      { id: 'Rules',  body: true },
    ]
  };
  const cols = norm(pickListColumns(def));
  const ids = cols.map(c => c.id);
  assert(!ids.includes('Desc'), 'body col should not be included');
  assert(!ids.includes('Notes'), 'body col should not be included');
  assert(!ids.includes('Rules'), 'body col should not be included');
});

test('pickListColumns: cols with w preserve all cols and widths', () => {
  const def = {
    cols: [
      { id: 'Name', primary: true, w: 150 },
      { id: 'ID', idCol: true, w: 70 },
      { id: 'Status', badge: true, w: 80 },
      { id: 'Count', metric: true, w: 60 },
    ]
  };
  const cols = norm(pickListColumns(def));
  assert.strictEqual(cols.length, 4);
  assert.strictEqual(cols[0].w, 150);
  assert.strictEqual(cols[1].w, 70);
});

test('pickListColumns: missing primary falls back to first col', () => {
  const def = {
    cols: [
      { id: 'Seq', label: 'Sequence' },
      { id: 'Name', label: 'Name' },
      { id: 'ID', idCol: true },
    ]
  };
  const cols = norm(pickListColumns(def));
  const ids = cols.map(c => c.id);
  assert.strictEqual(ids[0], 'Seq', 'first col is primary when no primary flag');
  assert(ids.includes('ID'), 'idCol should be present');
});

test('pickListColumns: missing idCol — no crash, continue', () => {
  const def = {
    cols: [
      { id: 'Name', primary: true },
      { id: 'Status', badge: true },
    ]
  };
  const cols = norm(pickListColumns(def));
  const ids = cols.map(c => c.id);
  assert(ids.includes('Name'));
  assert(ids.includes('Status'));
});

test('pickListColumns: audit and truncate flags survive on returned cols', () => {
  const def = {
    cols: [
      { id: 'Name', primary: true, audit: v => v === '0' },
      { id: 'ID', idCol: true, truncate: true },
      { id: 'Status', badge: true },
    ]
  };
  const cols = pickListColumns(def);
  const byId = Object.fromEntries(cols.map(c => [c.id, c]));
  assert.strictEqual(typeof byId.Name.audit, 'function', 'audit function should survive');
  assert.strictEqual(byId.ID.truncate, true, 'truncate flag should survive');
});

/* ════════════════════════════════════════════════════════════════
   splitHidden(rows, hiddenSet, idColId)
═════════════════════════════════════════════════════════════════ */

test('splitHidden: normal split — ids in set go to hidden, rest to visible', () => {
  const rows = [
    { id: '1', name: 'A' },
    { id: '2', name: 'B' },
    { id: '3', name: 'C' },
  ];
  const hidden = new Set(['2']);
  const result = norm(splitHidden(rows, hidden, 'id'));
  assert.strictEqual(result.visible.length, 2);
  assert.strictEqual(result.hidden.length, 1);
  assert.deepStrictEqual(result.visible.map(r => r.id), ['1', '3']);
  assert.deepStrictEqual(result.hidden.map(r => r.id), ['2']);
});

test('splitHidden: empty hidden set — all in visible', () => {
  const rows = [
    { id: '1', name: 'A' },
    { id: '2', name: 'B' },
  ];
  const result = norm(splitHidden(rows, new Set(), 'id'));
  assert.strictEqual(result.visible.length, 2);
  assert.strictEqual(result.hidden.length, 0);
});

test('splitHidden: ids compared as strings', () => {
  const rows = [
    { id: 1, name: 'A' },
    { id: 2, name: 'B' },
  ];
  const hidden = new Set(['1']);
  const result = norm(splitHidden(rows, hidden, 'id'));
  assert.strictEqual(result.visible.length, 1);
  assert.strictEqual(result.hidden.length, 1);
  assert.deepStrictEqual(result.hidden[0].id, 1);
});

test('splitHidden: idColId === null — everything visible', () => {
  const rows = [
    { id: '1', name: 'A' },
    { id: '2', name: 'B' },
  ];
  const hidden = new Set(['1']);
  const result = norm(splitHidden(rows, hidden, null));
  assert.strictEqual(result.visible.length, 2);
  assert.strictEqual(result.hidden.length, 0);
});

test('splitHidden: ids in hidden set that don\'t exist in rows are ignored', () => {
  const rows = [
    { id: '1', name: 'A' },
    { id: '2', name: 'B' },
  ];
  const hidden = new Set(['2', '999']);
  const result = norm(splitHidden(rows, hidden, 'id'));
  assert.strictEqual(result.visible.length, 1);
  assert.strictEqual(result.hidden.length, 1);
  assert.deepStrictEqual(result.hidden.map(r => r.id), ['2']);
});

test('splitHidden: original order preserved in both lists', () => {
  const rows = [
    { id: 'A', seq: 1 },
    { id: 'B', seq: 2 },
    { id: 'C', seq: 3 },
    { id: 'D', seq: 4 },
  ];
  const hidden = new Set(['B', 'D']);
  const result = norm(splitHidden(rows, hidden, 'id'));
  assert.deepStrictEqual(result.visible.map(r => r.seq), [1, 3]);
  assert.deepStrictEqual(result.hidden.map(r => r.seq), [2, 4]);
});
