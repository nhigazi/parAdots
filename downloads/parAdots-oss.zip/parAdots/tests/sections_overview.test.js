/* TDD harness for buildSectionCards() in viewer.html — powers the single-page
 * "all Pardot objects" canvas (replaces the 3 component tabs).
 * Extracts the marked block and evaluates it in an isolated vm context,
 * then asserts behaviour through the public function only. */
const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadBuildSectionCards() {
  const html = fs.readFileSync(path.join(__dirname, '..', 'viewer.html'), 'utf8');
  const m = html.match(/\/\* @sections-overview-start \*\/([\s\S]*?)\/\* @sections-overview-end \*\//);
  if (!m) throw new Error('sections-overview markers not found in viewer.html');
  const ctx = {};
  vm.createContext(ctx);
  vm.runInContext(m[1] + '\nthis.buildSectionCards = buildSectionCards;', ctx);
  return ctx.buildSectionCards;
}

const _build = loadBuildSectionCards();
// Normalise across the vm realm boundary (array/prototype identity differs otherwise)
const buildSectionCards = (...args) => JSON.parse(JSON.stringify(_build(...args)));

// Slice 1 (tracer bullet): excludes non-object sections (dashboard/workboard),
// sorts remaining real Pardot object sections alphabetically by label.
test('excludes dashboard/workboard, sorts remaining sections alphabetically by label', () => {
  const defs = {
    dashboard:  { label: 'Dashboard',  icon: 'layout-dashboard' },
    workboard:  { label: 'Workboard',  icon: 'workboard' },
    forms:      { label: 'Forms',      icon: 'forms' },
    campaigns:  { label: 'Campaigns',  icon: 'speakerphone' },
    dynamic_lists: { label: 'Dynamic Lists', icon: 'filter' },
  };
  const cards = buildSectionCards(defs, {}, {});
  assert.deepStrictEqual(cards.map(c => c.key), ['campaigns', 'dynamic_lists', 'forms']);
});

// Slice 2: status derived from counts/flags — flagged beats scraped beats empty.
test('status: flagged when flags present, scraped when count>0, empty otherwise', () => {
  const defs = {
    forms:     { label: 'Forms',     icon: 'forms' },
    campaigns: { label: 'Campaigns', icon: 'speakerphone' },
    files:     { label: 'Files',     icon: 'photo' },
  };
  const counts = { forms: 3, campaigns: 102, files: 0 };
  const flags  = { campaigns: ['a', 'b'] }; // 2 flagged items
  const cards = buildSectionCards(defs, counts, flags);
  const byKey = Object.fromEntries(cards.map(c => [c.key, c]));
  assert.strictEqual(byKey.campaigns.status, 'flagged');
  assert.strictEqual(byKey.campaigns.flagCount, 2);
  assert.strictEqual(byKey.forms.status, 'scraped');
  assert.strictEqual(byKey.files.status, 'empty');
});

// Slice 3: icon is passed through unchanged from the section def (needed to
// render the icon on each card — an explicit requirement).
test('icon is passed through from the section definition', () => {
  const defs = { snippets: { label: 'Snippets', icon: 'code' } };
  const cards = buildSectionCards(defs, {}, {});
  assert.strictEqual(cards[0].icon, 'code');
});
