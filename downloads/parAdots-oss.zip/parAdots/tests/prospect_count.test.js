/* TDD harness for prospectInfo() in viewer.html
 * Extracts the marked block and evaluates it in an isolated vm context,
 * then asserts behaviour through the public function only. */
const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadProspectInfo() {
  const html = fs.readFileSync(path.join(__dirname, '..', 'viewer.html'), 'utf8');
  const m = html.match(/\/\* @prospect-logic-start \*\/([\s\S]*?)\/\* @prospect-logic-end \*\//);
  if (!m) throw new Error('prospect-logic markers not found in viewer.html');
  const ctx = {};
  vm.createContext(ctx);
  vm.runInContext(m[1] + '\nthis.prospectInfo = prospectInfo;', ctx);
  return ctx.prospectInfo;
}

const _pi = loadProspectInfo();
// Normalise across the vm realm boundary (prototype differs otherwise)
const prospectInfo = (k, row, idx) => {
  const r = _pi(k, row, idx);
  return r == null ? null : { count: r.count, estimated: r.estimated, audit: r.audit };
};

// Slice 1: native count column (dynamic_lists)
test('dynamic_lists: native Prospect Count is exact', () => {
  const r = prospectInfo('dynamic_lists', { 'List ID': '4774', 'Prospect Count': '1234' }, {});
  assert.deepStrictEqual(r, { count: 1234, estimated: false, audit: false });
});

// Slice 2: automation_rules native "Prospects Matched"
test('automation_rules: Prospects Matched is exact', () => {
  const r = prospectInfo('automation_rules', { 'Rule ID': '5', 'Prospects Matched': '42' }, {});
  assert.deepStrictEqual(r, { count: 42, estimated: false, audit: false });
});

// Slice 3: static_lists native count (Kat. B — bisher nur Tabellenspalte)
test('static_lists: Prospect Count is exact', () => {
  const r = prospectInfo('static_lists', { 'List ID': '4774', 'Prospect Count': '7' }, {});
  assert.deepStrictEqual(r, { count: 7, estimated: false, audit: false });
});

// formhandlers + custom_redirects ebenfalls nativ
test('formhandlers + custom_redirects: native exact', () => {
  assert.deepStrictEqual(prospectInfo('formhandlers',     { 'Prospect Count': '3' }, {}), { count: 3, estimated: false, audit: false });
  assert.deepStrictEqual(prospectInfo('custom_redirects', { 'Prospect Count': '9' }, {}), { count: 9, estimated: false, audit: false });
});

// Slice 4: campaigns = Leads + Contacts, geschätzt
test('campaigns: Leads + Contacts summed, estimated', () => {
  const r = prospectInfo('campaigns', { Leads: '120', Contacts: '30' }, {});
  assert.deepStrictEqual(r, { count: 150, estimated: true, audit: false });
});
test('campaigns: missing Contacts still sums Leads', () => {
  const r = prospectInfo('campaigns', { Leads: '5', Contacts: '' }, {});
  assert.deepStrictEqual(r, { count: 5, estimated: true, audit: false });
});

// Slice 5: engagement_studio = Σ entry_lists − suppression, geschätzt
test('engagement_studio: sum of matched entry lists minus suppression', () => {
  const idx = { 'Monthly Newsletter': 100, 'Customers': 50, 'DE Kunde': 10, 'Partners': 20 };
  const row = { 'Program ID': '1', 'Entry Lists': 'Monthly Newsletter\nCustomers\nDE Kunde', 'Suppression Lists': 'Partners' };
  const r = prospectInfo('engagement_studio', row, idx);
  assert.deepStrictEqual(r, { count: 140, estimated: true, audit: false }); // 160 - 20
});
test('engagement_studio: unresolved list names ignored, never negative', () => {
  const idx = { 'Customers': 50 };
  const row = { 'Entry Lists': 'Customers\nGhost List', 'Suppression Lists': 'Huge\n' };
  const r = prospectInfo('engagement_studio', row, idx);
  assert.deepStrictEqual(r, { count: 50, estimated: true, audit: false });
});
test('engagement_studio: no entry lists → null', () => {
  assert.strictEqual(prospectInfo('engagement_studio', { 'Entry Lists': '' }, {}), null);
});

// Slice 6: Sektionen ohne Quelle & nicht ableitbar → null
test('non-derivable sections return null', () => {
  for (const k of ['sent_emails', 'email_templates', 'dynamic_content', 'fields']) {
    assert.strictEqual(prospectInfo(k, { Name: 'x', 'Prospect Count': '5' }, {}), null,
      `${k} must not surface a count`);
  }
});

// Slice 6b: forms + landing_pages seit 2026-07-08 nativ (Scraper liefert Counts)
test('forms: native Prospect Count is exact', () => {
  const r = prospectInfo('forms', { ID: '9', 'Prospect Count': '5' }, {});
  assert.deepStrictEqual(r, { count: 5, estimated: false, audit: false });
});
test('landing_pages: native Conversions is exact', () => {
  const r = prospectInfo('landing_pages', { ID: '3', 'Conversions': '12' }, {});
  assert.deepStrictEqual(r, { count: 12, estimated: false, audit: false });
});
test('forms/landing_pages: missing column (old CSVs) → null', () => {
  assert.strictEqual(prospectInfo('forms', { Name: 'x' }, {}), null);
  assert.strictEqual(prospectInfo('landing_pages', { Name: 'x' }, {}), null);
});

// Slice 7: nicht-numerischer / leerer Wert → null (kein NaN)
test('non-numeric native value → null', () => {
  assert.strictEqual(prospectInfo('dynamic_lists', { 'Prospect Count': '' }, {}), null);
  assert.strictEqual(prospectInfo('dynamic_lists', { 'Prospect Count': '—' }, {}), null);
  assert.strictEqual(prospectInfo('dynamic_lists', {}, {}), null);
});

// Slice 8: Audit-Flag bei count === 0
test('audit flag is true only when count is 0', () => {
  assert.strictEqual(prospectInfo('dynamic_lists', { 'Prospect Count': '0' }, {}).audit, true);
  assert.strictEqual(prospectInfo('dynamic_lists', { 'Prospect Count': '5' }, {}).audit, false);
  assert.strictEqual(prospectInfo('campaigns', { Leads: '0', Contacts: '0' }, {}).audit, true);
});
