// Test-Harness: extrahiert den Bild-Export-Block aus viewer.html und testet die puren Funktionen
const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'viewer.html'), 'utf8');
const start = src.indexOf('/* ── Export: Board als Bild');
const end = src.indexOf('/* ── Render ──');
if (start < 0 || end < 0 || end <= start) { console.error('FAIL: Export-Block nicht gefunden'); process.exit(1); }
const block = src.slice(start, end);

// Stubs für Browser-Globals
const BOARD_COLORS = [
  { label: 'Weiß', bg: '#ffffff', dot: '#d1d5db' }, { label: 'Rot', bg: '#fef2f2', dot: '#f87171' },
  { label: 'Orange', bg: '#fff7ed', dot: '#fb923c' }, { label: 'Gelb', bg: '#fefce8', dot: '#facc15' },
  { label: 'Grün', bg: '#f0fdf4', dot: '#4ade80' }, { label: 'Blau', bg: '#eff6ff', dot: '#60a5fa' },
  { label: 'Lila', bg: '#faf5ff', dot: '#a78bfa' }, { label: 'Pink', bg: '#fdf2f8', dot: '#f472b6' },
  { label: 'Grau', bg: '#f8f9fa', dot: '#9ca3af' }, { label: 'Schwarz', bg: '#1e293b', dot: '#1e293b' },
];
// Kopie der Produktiv-Implementierung (liegt in viewer.html außerhalb des Export-Blocks)
function _wbEdgePoint(r, tx, ty) {
  const cx = r.x + r.w / 2, cy = r.y + r.h / 2, dx = tx - cx, dy = ty - cy;
  if (dx === 0 && dy === 0) return { x: cx, y: cy };
  const sx = dx !== 0 ? (r.w / 2) / Math.abs(dx) : Infinity;
  const sy = dy !== 0 ? (r.h / 2) / Math.abs(dy) : Infinity;
  const s = Math.min(sx, sy);
  return { x: cx + dx * s, y: cy + dy * s };
}
const _loadHidden = () => new Set();
const _loadWorkboard = () => [];
const _loadWbEdges = () => [];
const _loadBoardColors = () => ({});
const _wbActiveName = () => 'Test Board';
const _wbNodeRect = () => null;
const document = undefined, alert = undefined, Image = undefined, Blob = undefined;

eval(block);

let failed = 0;
const check = (name, cond, extra) => {
  if (cond) console.log('PASS ' + name);
  else { failed++; console.log('FAIL ' + name + (extra ? ' — ' + extra : '')); }
};

// ── _wbWrap
check('wrap: leer', _wbWrap('', 20, 2).length === 0);
check('wrap: einzeilig', JSON.stringify(_wbWrap('kurz', 20, 2)) === '["kurz"]');
const wl = _wbWrap('NL ACM DE Wieder-Anmeldebestätigung für inaktive Prospects', 20, 2);
check('wrap: max 2 Zeilen', wl.length === 2, JSON.stringify(wl));
check('wrap: Ellipsis bei Kürzung', wl[1].endsWith('…'), JSON.stringify(wl));
check('wrap: Zeilenlänge eingehalten', wl.every(l => l.length <= 21), JSON.stringify(wl));
check('wrap: Überlanges Wort gekürzt', _wbWrap('Superkalifragilistisch', 10, 1)[0].length <= 10);
check('wrap: terminiert bei vielen Wörtern', _wbWrap('a '.repeat(500), 10, 3).length === 3);

// ── Testgraph mit gemessenen Rects (wie aus _wbNodeRect)
const g = {
  nodes: [
    { iid: 'a', kind: 'start', label: 'Start' },
    { iid: 'b', kind: 'card', name: 'NL ACM DE - Reengagement & "Aufforderung"', srcLabel: 'Email Templates', status: 'Running', props: [{ label: 'Prospects', value: '1409' }, { label: 'Types', value: 'List Email; Drip' }] },
    { iid: 'c', kind: 'decision', label: 'Hat Custom Redirect <Consent> geklickt?' },
    { iid: 'd', kind: 'stop', label: 'Stopp' },
    { iid: 'e', kind: 'note', text: 'Feld: Opt-Out Request = true setzen' },
    { iid: 'f', kind: 'card', name: 'Manuell', srcLabel: 'Forms', status: '', manual: true, props: [] },
  ],
  edges: [
    { eid: 'e1', from: 'a', to: 'b', label: '' },
    { eid: 'e2', from: 'b', to: 'c', label: '14 Tage warten' },
    { eid: 'e3', from: 'c', to: 'd', label: 'Nein: Email & <senden>' },
    { eid: 'e4', from: 'c', to: 'b', label: '' }, // Zyklus
  ],
};
const rects = {
  a: { x: 500, y: 20, w: 120, h: 44 },
  b: { x: 450, y: 120, w: 254, h: 180 },
  c: { x: 480, y: 360, w: 220, h: 96 },
  d: { x: 510, y: 520, w: 120, h: 44 },
  e: { x: 900, y: 120, w: 180, h: 140 },
  f: { x: 60, y: 120, w: 254, h: 90 },
};
const svg = wbBuildExportSVG(g, rects, { b: 4, f: 9 });
console.log('\n===== SVG (gekürzt) =====\n' + svg.slice(0, 400) + '…\n=========================\n');

check('SVG erzeugt', typeof svg === 'string' && svg.startsWith('<svg'));
check('Keine CSS-Variablen', !svg.includes('var(--'));
check('Namespace gesetzt', svg.includes('xmlns="http://www.w3.org/2000/svg"'));
check('Arrow-Marker definiert', svg.includes('id="wbx-arrow"'));
check('4 Kanten', (svg.match(/<line /g) || []).length === 4);
check('Kantenlabel vorhanden', svg.includes('14 Tage warten'));
check('XML-Escaping & im Label', svg.includes('Email &amp; &lt;senden&gt;'));
check('XML-Escaping " im Namen', svg.includes('&quot;'));
check('Decision als Polygon', (svg.match(/<polygon /g) || []).length === 1);
check('Decision-Label escaped', svg.includes('&lt;Consent&gt;'));
check('Start/Stopp als Pille (rx=h/2)', (svg.match(/rx="22"/g) || []).length === 2);
check('Start grün / Stopp rot', svg.includes('stroke="#16a34a"') && svg.includes('stroke="#e11d48"'));
check('Card-Farbe Grün (b=4)', svg.includes('fill="#f0fdf4"'));
check('Schwarze Karte mit weißem Text (f=9)', svg.includes('fill="#1e293b"') && svg.includes('fill="#ffffff"'));
check('Props gerendert', svg.includes('Prospects: 1409'));
check('Status im Untertitel', svg.includes('Email Templates · Running'));
check('Manuell-Badge', svg.includes('Forms · neu'));
check('Notiz-Text', svg.includes('Opt-Out'));
check('Koordinaten verschoben (PAD=40, min=60/20)', svg.includes(`width="${900 + 180 - 60 + 80}"`), svg.match(/width="\d+"/)[0]);
check('Leerer Graph → null', wbBuildExportSVG({ nodes: [], edges: [] }, {}, {}) === null);
check('Knoten ohne Rect wird übersprungen', wbBuildExportSVG({ nodes: [{ iid: 'x', kind: 'card', name: 'X' }, { iid: 'y', kind: 'card', name: 'Y' }], edges: [{ eid: 'q', from: 'x', to: 'y', label: '' }] }, { x: { x: 0, y: 0, w: 100, h: 50 } }, {}).indexOf('<line') === -1);

// Wohlgeformtheit: optional mit jsdom prüfen, sonst Tag-Balance
let wellformed = null;
try {
  const { JSDOM } = require('jsdom');
  const dom = new JSDOM('<!DOCTYPE html><body></body>');
  const doc = new dom.window.DOMParser().parseFromString(svg, 'image/svg+xml');
  wellformed = doc.querySelector('parsererror') === null && doc.documentElement.tagName === 'svg';
} catch (e) {
  const opens = (svg.match(/<(svg|defs|marker|text)\b/g) || []).length;
  const closes = (svg.match(/<\/(svg|defs|marker|text)>/g) || []).length;
  wellformed = opens === closes;
}
check('SVG wohlgeformt', wellformed === true);

console.log(failed ? `\n${failed} TEST(S) FAILED` : '\nALLE TESTS OK');
process.exit(failed ? 1 : 0);
