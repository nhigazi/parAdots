/* TDD harness for the @board-state marker block in viewer.html —
 * server-side board-state persistence (Board-Positionen, Notizen, Todos, …).
 * Extracts the marked block and evaluates it in an isolated vm context with
 * a fake localStorage, then asserts behaviour through the public functions
 * (matchesOrg / collectBoardState / applyBoardState / hasOrgState) only. */
const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// Mimics real localStorage: getItem/setItem are non-enumerable, so
// Object.keys(localStorage) only ever returns the stored data keys —
// exactly the behaviour collectBoardState/hasOrgState rely on.
function makeFakeLocalStorage(initial) {
  const store = Object.assign({}, initial);
  Object.defineProperty(store, 'getItem', {
    value: k => (Object.prototype.hasOwnProperty.call(store, k) ? store[k] : null),
    enumerable: false,
  });
  Object.defineProperty(store, 'setItem', {
    value: (k, v) => { store[k] = String(v); },
    enumerable: false,
  });
  return store;
}

function loadBoardStateFns(fakeLocalStorage) {
  const html = fs.readFileSync(path.join(__dirname, '..', 'viewer.html'), 'utf8');
  const m = html.match(/\/\* @board-state-start \*\/([\s\S]*?)\/\* @board-state-end \*\//);
  if (!m) throw new Error('board-state markers not found in viewer.html');
  const ctx = { localStorage: fakeLocalStorage };
  vm.createContext(ctx);
  vm.runInContext(
    m[1] + '\nthis.matchesOrg=matchesOrg;this.collectBoardState=collectBoardState;' +
      'this.applyBoardState=applyBoardState;this.hasOrgState=hasOrgState;',
    ctx
  );
  return ctx;
}

test('matchesOrg matches only keys with an org boundary (no substring false positives)', () => {
  const ctx = loadBoardStateFns(makeFakeLocalStorage({}));
  assert.strictEqual(ctx.matchesOrg('pardot_todos_globex', 'globex'), true);
  assert.strictEqual(ctx.matchesOrg('pardot_board_pos_globex_automation_rules', 'globex'), true);
  // Substring trap: "globex" must not match "globex2" or "acme-globex-test"-style prefixes
  assert.strictEqual(ctx.matchesOrg('pardot_todos_globex2', 'globex'), false);
  assert.strictEqual(ctx.matchesOrg('pardot_todos_globextest', 'globex'), false);
  // SFX keys are keyed by SFX.alias, not S.org — must never be swept up here
  assert.strictEqual(ctx.matchesOrg('sfx-graph-globex-preset1', 'globex'), false);
});

test('collectBoardState sammelt nur Keys der aktuellen Org, org-übergreifend nichts', () => {
  const fake = makeFakeLocalStorage({
    pardot_todos_globex: '[]',
    pardot_board_pos_globex_automation_rules: '{"1":{"x":10,"y":20}}',
    pardot_todos_acme: '[{"id":1}]',
    'sfx-graph-globex-preset1': 'irrelevant-shape', // real SFX key shape uses hyphens, not "_globex_"
    pardot_org_order: '["globex","acme"]', // global key, not org-scoped
  });
  const ctx = loadBoardStateFns(fake);
  const collected = ctx.collectBoardState('globex');
  assert.deepStrictEqual(Object.keys(collected).sort(), [
    'pardot_board_pos_globex_automation_rules',
    'pardot_todos_globex',
  ]);
  assert.strictEqual(collected.pardot_todos_globex, '[]');
});

test('applyBoardState schreibt jeden Key zurück in localStorage', () => {
  const fake = makeFakeLocalStorage({});
  const ctx = loadBoardStateFns(fake);
  ctx.applyBoardState({ pardot_todos_globex: '[]', pardot_board_pos_globex_x: '{}' });
  assert.strictEqual(fake.getItem('pardot_todos_globex'), '[]');
  assert.strictEqual(fake.getItem('pardot_board_pos_globex_x'), '{}');
});

test('hasOrgState erkennt fehlenden Zustand korrekt — hängt an KEINEM einzelnen festen Key', () => {
  const empty = loadBoardStateFns(makeFakeLocalStorage({}));
  assert.strictEqual(empty.hasOrgState('globex'), false);

  // Nur ein Todo-Key vorhanden -> true
  const onlyTodos = loadBoardStateFns(makeFakeLocalStorage({ pardot_todos_globex: '[]' }));
  assert.strictEqual(onlyTodos.hasOrgState('globex'), true);

  // Kein Todo-Key, aber eine Board-Position -> muss trotzdem true sein
  // (deckt exakt die im Review benannte Lücke ab: Prüfung darf nicht an
  // einem einzigen, willkürlich gewählten Key wie "todos" hängen)
  const onlyBoardPos = loadBoardStateFns(
    makeFakeLocalStorage({ pardot_board_pos_globex_automation_rules: '{}' })
  );
  assert.strictEqual(onlyBoardPos.hasOrgState('globex'), true);

  // Andere Org vorhanden, aber nicht die gefragte -> false
  const otherOrgOnly = loadBoardStateFns(makeFakeLocalStorage({ pardot_todos_acme: '[]' }));
  assert.strictEqual(otherOrgOnly.hasOrgState('globex'), false);
});
