/* Integration test for the display layer: _prospectBadgeHTML().
 * Loads the marked block from viewer.html with stubbed S + esc (no browser),
 * verifying the actual badge strings users see across all view types. */
const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadRender(stateData) {
  const html = fs.readFileSync(path.join(__dirname, '..', 'viewer.html'), 'utf8');
  const m = html.match(/\/\* @prospect-logic-start \*\/([\s\S]*?)\/\* @prospect-logic-end \*\//);
  if (!m) throw new Error('prospect-logic markers not found');
  const ctx = {
    S: { data: stateData || {} },
    esc: s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])),
  };
  vm.createContext(ctx);
  vm.runInContext(m[1] + '\nthis._badge = _prospectBadgeHTML;', ctx);
  return ctx._badge;
}

test('native count renders 👥 + exact, no tilde, accent class', () => {
  const badge = loadRender();
  const h = badge('dynamic_lists', { 'Prospect Count': '1234' });
  assert.match(h, /👥/);
  assert.match(h, /1\.234/);            // de-DE grouping
  assert.doesNotMatch(h, /~/);
  assert.match(h, /class="pc-badge"/);  // not zero, not est
});

test('estimated count is prefixed with ~ and marked pc-est', () => {
  const badge = loadRender();
  const h = badge('campaigns', { Leads: '100', Contacts: '50' });
  assert.match(h, /~150/);
  assert.match(h, /pc-est/);
});

test('zero count gets pc-zero (audit) class', () => {
  const badge = loadRender();
  const h = badge('formhandlers', { 'Prospect Count': '0' });
  assert.match(h, /pc-zero/);
});

test('no source: empty string by default, dash badge with {dash:true}', () => {
  const badge = loadRender();
  assert.strictEqual(badge('forms', { Name: 'x' }), '');
  const h = badge('forms', { Name: 'x' }, { dash: true });
  assert.match(h, /pc-empty/);
  assert.match(h, /👥 —/);
});

test('sections without a count concept never render the badge, even with {dash:true}', () => {
  const badge = loadRender();
  for (const k of ['prospect_sync_errors', 'fields', 'sent_emails', 'email_templates', 'users']) {
    assert.strictEqual(badge(k, { Name: 'x', 'Prospect Count': '5' }), '', `${k} (no dash)`);
    assert.strictEqual(badge(k, { Name: 'x', 'Prospect Count': '5' }, { dash: true }), '', `${k} (dash:true)`);
  }
});

test('ES badge uses live _listIndex built from S.data lists', () => {
  const badge = loadRender({
    dynamic_lists: [{ 'List Name': 'Customers', 'Prospect Count': '50' }],
    static_lists:  [{ 'List Name': 'DE Kunde',  'Prospect Count': '10' }],
  });
  const h = badge('engagement_studio', { 'Entry Lists': 'Customers\nDE Kunde', 'Suppression Lists': '' });
  assert.match(h, /~60/);
});
