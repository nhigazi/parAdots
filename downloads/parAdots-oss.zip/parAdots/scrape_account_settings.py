"""
Pardot Account Settings & Scoring Configuration Scraper — v5 API
=================================================================
Captures account-level configuration that is not covered by any other scraper.

Three resource groups:

  1. Scoring Categories  (/api/v5/objects/scoring-categories)
     The existing scrape_scoring_rules.py scrapes scoring *rules* via the UI
     (activity type → point adjustment). Scoring *categories* are higher-level
     groupings (e.g. "Email Engagement", "Content Interaction") that bucket
     related rules and support separate MQL scoring thresholds. The gap
     analysis flags "fewer than 5 activity types" — this scraper provides the
     authoritative list of configured categories so the gap report is accurate.

  2. Tracker Domains  (/api/v5/objects/tracker-domains)
     Already used internally as a lookup table by other scrapers but never
     persisted as a standalone output. Tracker domain configuration (vanity
     domains, HTTPS status, SSL certificate state) affects email deliverability
     and landing page trust signals.

  3. Business Unit / Account Metadata  (/api/v5/account)
     Captures the Pardot business unit ID, account name, Salesforce org ID,
     timezone, and whether key features (scoring, grading, AI) are enabled.
     This provides a stable anchor for multi-org comparisons and documents
     which instance the scraped data belongs to.

Output:
  pardot_account_settings.json   — combined JSON
  pardot_scoring_categories.csv  — scoring categories
  pardot_tracker_domains.csv     — tracker domains
  pardot_account_metadata.csv    — account / business unit info

Usage (standalone):
  python3 scrape_account_settings.py

Called from run_all.py:
  from scrape_account_settings import run
  run(page=page)
"""

from __future__ import annotations

import csv
import json
import sys
from datetime import datetime, timezone

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON          = ""
CSV_CATEGORIES       = ""
CSV_TRACKER_DOMAINS  = ""
CSV_ACCOUNT          = ""

# ── Field lists ───────────────────────────────────────────────────────────────

SCORING_CAT_FIELDS = [
    "id", "name", "description", "maxScore", "passScore",
    "createdAt", "updatedAt",
]

TRACKER_DOMAIN_FIELDS = [
    "id", "domain", "isDomainVerified", "isHttpsEnabled",
    "httpsStatus", "isMixedHttp", "folderId",
    "createdAt", "updatedAt",
]

ACCOUNT_FIELDS = [
    "id", "name", "email", "website", "timezone",
    "isProspectAuditEnabled", "isScoringEnabled", "isGradingEnabled",
    "isAiEnabled", "salesforceOrganizationId",
    "createdAt",
]


# ── Per-resource fetchers ─────────────────────────────────────────────────────

def _fetch_scoring_categories(client: pardot_api.PardotClient) -> list[dict]:
    print("\n📊 Fetching scoring categories...")
    try:
        cats = list(pardot_api.paged_get(
            client, "objects/scoring-categories", fields=SCORING_CAT_FIELDS,
        ))
        print(f"   ✅ {len(cats)} scoring category/ies found")
        return cats
    except Exception as e:
        print(f"   ⚠️  Scoring categories endpoint unavailable: {e}")
        return []


def _fetch_tracker_domains(client: pardot_api.PardotClient) -> list[dict]:
    print("\n🌐 Fetching tracker domains...")
    try:
        domains = list(pardot_api.paged_get(
            client, "objects/tracker-domains", fields=TRACKER_DOMAIN_FIELDS,
        ))
        print(f"   ✅ {len(domains)} tracker domain(s) found")
        for d in domains:
            https_ok  = "✅" if d.get("isHttpsEnabled") else "❌"
            verified  = "✅" if d.get("isDomainVerified") else "❌"
            print(f"      {https_ok} HTTPS  {verified} verified  {d.get('domain', '')}")
        return domains
    except Exception as e:
        print(f"   ⚠️  Tracker domains endpoint unavailable: {e}")
        return []


def _fetch_account_metadata(client: pardot_api.PardotClient) -> dict:
    """
    Try /api/v5/account first (single-record endpoint, no pagination).
    Falls back to /api/v5/objects/businessUnits if the former isn't available.
    """
    print("\n🏢 Fetching account / business unit metadata...")

    # Strategy 1: direct /account endpoint
    for endpoint in ("account", "objects/businessUnits"):
        url = f"{pardot_api.PARDOT_API_BASE}/{endpoint}"
        params = {"fields": ",".join(ACCOUNT_FIELDS)} if endpoint == "account" else {"fields": "id,name"}
        resp = client.session.get(
            url,
            headers=client.headers(),
            params=params,
            timeout=pardot_api.DEFAULT_TIMEOUT,
        )
        if resp.status_code == 200:
            body = resp.json()
            # /account returns the record directly; /businessUnits returns {values:[...]}
            if "values" in body:
                records = body["values"]
                data = records[0] if records else {}
            else:
                data = body
            print(f"   ✅ Account metadata from /{endpoint}")
            _print_account_summary(data)
            return data
        else:
            print(f"   ↪︎ /{endpoint} returned {resp.status_code} — trying next")

    print("   ⚠️  No account metadata endpoint available — returning env-derived info")
    return {
        "id":   utils.OUTPUT_DIR.split("/")[-1] if utils.OUTPUT_DIR else "",
        "name": "(unavailable)",
        "note": "Neither /api/v5/account nor /api/v5/objects/businessUnits responded.",
    }


def _print_account_summary(data: dict) -> None:
    for key in ("name", "email", "timezone", "salesforceOrganizationId"):
        val = data.get(key)
        if val:
            print(f"      {key:<30} {val}")
    feature_flags = {
        "isScoringEnabled": "Lead scoring",
        "isGradingEnabled": "Profile grading",
        "isAiEnabled":      "AI features",
    }
    for flag, label in feature_flags.items():
        val = data.get(flag)
        if val is not None:
            icon = "✅" if val else "❌"
            print(f"      {icon} {label}")


# ── Export helpers ────────────────────────────────────────────────────────────

def _export_scoring_categories(cats: list[dict]) -> None:
    if not cats:
        print("   (no scoring categories to export)")
        return
    headers = ["#", "Name", "ID", "Description", "Max Score", "Pass Score",
               "Created At", "Updated At"]
    rows = [
        [
            i + 1,
            c.get("name", ""), c.get("id", ""),
            c.get("description", "") or "",
            c.get("maxScore", "") if c.get("maxScore") is not None else "",
            c.get("passScore", "") if c.get("passScore") is not None else "",
            c.get("createdAt", "") or "",
            c.get("updatedAt", "") or "",
        ]
        for i, c in enumerate(cats)
    ]
    with open(CSV_CATEGORIES, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {CSV_CATEGORIES} ({len(rows)} rows)")


def _export_tracker_domains(domains: list[dict]) -> None:
    if not domains:
        print("   (no tracker domains to export)")
        return
    headers = ["#", "Domain", "ID", "HTTPS Enabled", "Domain Verified",
               "HTTPS Status", "Mixed HTTP", "Created At", "Updated At"]
    rows = [
        [
            i + 1,
            d.get("domain", ""), d.get("id", ""),
            "Yes" if d.get("isHttpsEnabled") else "No",
            "Yes" if d.get("isDomainVerified") else "No",
            d.get("httpsStatus", "") or "",
            "Yes" if d.get("isMixedHttp") else "No",
            d.get("createdAt", "") or "",
            d.get("updatedAt", "") or "",
        ]
        for i, d in enumerate(domains)
    ]
    with open(CSV_TRACKER_DOMAINS, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {CSV_TRACKER_DOMAINS} ({len(rows)} rows)")


def _export_account(account: dict) -> None:
    rows = [[k, str(v)] for k, v in account.items() if v is not None]
    with open(CSV_ACCOUNT, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(["Setting", "Value"])
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {CSV_ACCOUNT} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, CSV_CATEGORIES, CSV_TRACKER_DOMAINS, CSV_ACCOUNT
    OUTPUT_JSON         = utils.output_path("pardot_account_settings.json")
    CSV_CATEGORIES      = utils.output_path("pardot_scoring_categories.csv")
    CSV_TRACKER_DOMAINS = utils.output_path("pardot_tracker_domains.csv")
    CSV_ACCOUNT         = utils.output_path("pardot_account_metadata.csv")

    print("\n🚀 Pardot Account Settings & Scoring Config Scraper (v5 API)")
    print("=" * 55)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    scraped_at = datetime.now(timezone.utc).isoformat()

    scoring_categories = _fetch_scoring_categories(client)
    tracker_domains    = _fetch_tracker_domains(client)
    account_metadata   = _fetch_account_metadata(client)

    # ── Gap analysis helpers ──────────────────────────────────────────────────
    n_categories = len(scoring_categories)
    https_ok     = all(d.get("isHttpsEnabled") for d in tracker_domains) if tracker_domains else None
    scoring_on   = account_metadata.get("isScoringEnabled")
    grading_on   = account_metadata.get("isGradingEnabled")

    print("\n📋 Configuration summary:")
    print(f"   Scoring categories configured : {n_categories}")
    if n_categories < 5:
        print(f"   ⚠️  Best practice requires ≥ 5 scoring categories (gap identified)")
    print(f"   All tracker domains HTTPS     : {'Yes' if https_ok else 'No' if https_ok is False else 'N/A'}")
    if scoring_on is not None:
        print(f"   Lead scoring enabled          : {'Yes' if scoring_on else 'No'}")
    if grading_on is not None:
        print(f"   Profile grading enabled       : {'Yes' if grading_on else '⚠️  No — gap identified'}")

    # ── Persist ───────────────────────────────────────────────────────────────
    output = {
        "scraped_at":          scraped_at,
        "account_metadata":    account_metadata,
        "scoring_categories":  scoring_categories,
        "tracker_domains":     tracker_domains,
        "gap_flags": {
            "scoring_categories_count":       n_categories,
            "scoring_categories_gap":         n_categories < 5,
            "all_tracker_domains_https":      https_ok,
            "lead_scoring_enabled":           scoring_on,
            "profile_grading_enabled":        grading_on,
        },
    }

    utils.save_json(output, OUTPUT_JSON)
    _export_scoring_categories(scoring_categories)
    _export_tracker_domains(tracker_domains)
    _export_account(account_metadata)

    print(f"\n✅ Account settings scrape complete.")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
