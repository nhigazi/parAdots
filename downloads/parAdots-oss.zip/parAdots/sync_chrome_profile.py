#!/usr/bin/env python3
"""
Bootstrap or refresh an org's saved Salesforce/Pardot session by borrowing
cookies from a real, already-logged-in Chrome profile instead of running
the interactive MFA login flow in utils.login().

Background: Chrome 136+ refuses --remote-debugging-port against the
*default* Chrome data directory (the one holding your everyday logins),
so we can never attach automation directly to the Chrome window you
actually browse in. Instead this script:

  1. Copies the Chrome profile named by CHROME_PROFILE in
     configs/{org}.env (e.g. "Profile 4" -- find yours via chrome://version)
     into a throwaway temp directory. The live profile is only read, never
     modified.
  2. Launches the REAL Google Chrome binary (not Playwright's bundled
     Chromium/"Chrome for Testing") against that temp copy with a remote
     debugging port. Because the temp dir is not Chrome's default data
     directory, the Chrome 136+ restriction doesn't apply -- and because
     it's genuinely Chrome, it can decrypt its own Keychain-protected
     cookies exactly as it would for a normal launch.
  3. Connects Playwright to that throwaway Chrome over CDP, reads back
     only the Salesforce/Pardot/force.com cookies (nothing else from the
     source profile is ever written to disk), and saves them into
     configs/{org}.storage_state.json.
  4. Clears configs/{org}_chrome_profile/ so the next scraper run treats
     the automation profile as fresh and imports this session (see the
     `launch_context()` legacy-import logic in utils.py) instead of
     running the interactive login()/MFA flow.
  5. Shuts the throwaway Chrome down and deletes the temp copy.

Run this in a Terminal ON YOUR MAC -- not through a remote/cloud session --
because step 2 needs macOS Keychain access, which only a locally running
process can use. The first run will show a one-time macOS prompt
("Chrome Safe Storage wants to access a key in your keychain..."); choose
"Always Allow" so future syncs don't nag you.

The named Chrome profile can stay open in your normal daily use while
this runs -- copying its files doesn't require closing it. If a sync ever
produces a session that fails to authenticate, quit that profile's
windows first and re-run once, which rules out an unlucky read of the
cookie database mid-write.

Usage:
    python3 sync_chrome_profile.py --org globex
    python3 sync_chrome_profile.py --all

--all syncs every org under configs/*.env. Orgs that share the same
CHROME_PROFILE value are batched together -- the (slow) copy-and-relaunch
step runs once per distinct Chrome profile, not once per org, and the
resulting cookies get fanned out to every org using that profile.
"""
import argparse
import glob
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

from dotenv import load_dotenv

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_CHROME_USER_DATA = os.path.expanduser("~/Library/Application Support/Google/Chrome")
_CHROME_BINARY = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

# Cookie domains worth pulling out of the real profile. Keep this tight --
# anything not matched here is never read out of the source profile's
# cookie jar into this project, on purpose.
_RELEVANT_DOMAIN_SUFFIXES = ("salesforce.com", "force.com", "pardot.com")


class SyncError(RuntimeError):
    pass


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_cdp(port: int, timeout: float = 20) -> bool:
    url = f"http://127.0.0.1:{port}/json/version"
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(url, timeout=1)
            return True
        except Exception:
            time.sleep(0.3)
    return False


def _is_relevant(cookie: dict) -> bool:
    domain = (cookie.get("domain") or "").lstrip(".")
    return any(domain == s or domain.endswith("." + s) for s in _RELEVANT_DOMAIN_SUFFIXES)


def _list_org_names() -> list:
    configs_dir = os.path.join(_BASE_DIR, "configs")
    names = []
    for path in sorted(glob.glob(os.path.join(configs_dir, "*.env"))):
        base = os.path.basename(path)
        if base.startswith("."):
            continue
        names.append(base[:-4])  # strip ".env"
    return names


def _org_chrome_profile(org: str) -> str:
    config_path = os.path.join(_BASE_DIR, "configs", f"{org}.env")
    if not os.path.exists(config_path):
        raise SyncError(f"configs/{org}.env not found")
    load_dotenv(dotenv_path=config_path, override=True)
    return os.getenv("CHROME_PROFILE", "").strip()


def _extract_cookies_for_profile(chrome_profile: str) -> list:
    """Copy + relaunch + CDP-read once for a given real Chrome profile name."""
    if sys.platform != "darwin":
        raise SyncError("This script only supports macOS (Keychain-backed Chrome decryption).")

    source_dir = os.path.join(_CHROME_USER_DATA, chrome_profile)
    if not os.path.isdir(source_dir):
        raise SyncError(f"Chrome profile not found on disk: {source_dir}")
    if not os.path.exists(_CHROME_BINARY):
        raise SyncError(f"Google Chrome not found at {_CHROME_BINARY}")

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise SyncError("playwright not installed in this environment -- pip install playwright")

    print(f"  Copying '{chrome_profile}' to a scratch directory (source is left untouched)...")
    tmp = tempfile.mkdtemp(prefix="pardot_chrome_sync_")
    relevant = []
    try:
        local_state = os.path.join(_CHROME_USER_DATA, "Local State")
        if os.path.exists(local_state):
            shutil.copy2(local_state, os.path.join(tmp, "Local State"))
        shutil.copytree(source_dir, os.path.join(tmp, chrome_profile))

        port = _free_port()
        print(f"  Launching a throwaway Chrome on the copy (debug port {port})...")
        proc = subprocess.Popen(
            [
                _CHROME_BINARY,
                f"--remote-debugging-port={port}",
                f"--profile-directory={chrome_profile}",
                f"--user-data-dir={tmp}",
                "--no-first-run",
                "--no-default-browser-check",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            if not _wait_for_cdp(port):
                raise SyncError("Throwaway Chrome did not come up in time.")

            with sync_playwright() as pw:
                browser = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}")
                ctx = browser.contexts[0] if browser.contexts else browser.new_context()
                all_cookies = ctx.cookies()
                relevant = [c for c in all_cookies if _is_relevant(c)]
                ctx.close()
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    if not relevant:
        raise SyncError(
            f"No Salesforce/Pardot cookies found in '{chrome_profile}'. "
            f"Log into Salesforce/Pardot in that profile first, then re-run."
        )
    return relevant


def _apply_cookies_to_org(org: str, cookies: list) -> str:
    state_path = os.path.join(_BASE_DIR, "configs", f"{org}.storage_state.json")
    with open(state_path, "w", encoding="utf-8") as f:
        json.dump({"cookies": cookies, "origins": []}, f, indent=2)

    profile_dir = os.path.join(_BASE_DIR, "configs", f"{org}_chrome_profile")
    if os.path.isdir(profile_dir):
        shutil.rmtree(profile_dir)

    return state_path


def sync_one(org: str) -> None:
    chrome_profile = _org_chrome_profile(org)
    if not chrome_profile:
        raise SyncError(
            f"CHROME_PROFILE not set in configs/{org}.env -- "
            f"add e.g. CHROME_PROFILE=Profile 4 (find yours via chrome://version)."
        )
    cookies = _extract_cookies_for_profile(chrome_profile)
    _apply_cookies_to_org(org, cookies)
    print(f"OK Synced '{org}' from '{chrome_profile}' -- {len(cookies)} cookie(s).")


def sync_all() -> None:
    orgs = _list_org_names()
    if not orgs:
        sys.exit("No org configs found under configs/*.env")

    groups = {}
    skipped = []
    for org in orgs:
        try:
            profile = _org_chrome_profile(org)
        except SyncError as e:
            skipped.append((org, str(e)))
            continue
        if not profile:
            skipped.append((org, "CHROME_PROFILE not set in configs/<org>.env"))
            continue
        groups.setdefault(profile, []).append(org)

    results = []
    for profile, org_list in groups.items():
        print(f"\n=== {profile}  ({', '.join(org_list)}) ===")
        try:
            cookies = _extract_cookies_for_profile(profile)
        except SyncError as e:
            for org in org_list:
                results.append((org, False, str(e)))
            continue
        for org in org_list:
            _apply_cookies_to_org(org, cookies)
            results.append((org, True, f"{len(cookies)} cookie(s)"))

    print("\n--- Summary ---")
    for org, ok, msg in results:
        print(f"  {'OK  ' if ok else 'FAIL'}  {org}: {msg}")
    for org, reason in skipped:
        print(f"  SKIP  {org}: {reason}")

    if any(not ok for _, ok, _ in results):
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--org", help="Sync a single org (matches configs/<org>.env)")
    group.add_argument("--all", action="store_true", help="Sync every org under configs/*.env")
    args = parser.parse_args()

    if args.all:
        sync_all()
    else:
        try:
            sync_one(args.org)
        except SyncError as e:
            sys.exit(f"XX {e}")
