"""
Pardot Layout Template Scraper — v5 API
=========================================
Pulls all layout templates from /api/v5/objects/layout-templates.

Layout templates are the base wrappers (header/footer/CSS) applied to
email templates and landing pages. Capturing them enables:
  • Cross-reference: which email templates and landing pages use each layout
  • Brand consistency audit: detect layouts missing brand-required elements
  • Orphan detection: layouts not referenced by any email template or page

Two-pass approach:
  Pass 1 — paged_get() lists all layout templates with core metadata.
  Pass 2 — get_one() fetches the full layoutContent (HTML) per record,
            which is absent from list responses.

Captured fields:
  id, name, layoutContent (HTML), isEnabled,
  folder, campaign, createdAt, updatedAt

Output:
  pardot_layout_templates.json
  pardot_layout_templates.csv

Usage (standalone):
  python3 scrape_layout_templates.py

Called from run_all.py:
  from scrape_layout_templates import run
  run(page=page)
"""

from __future__ import annotations

import csv
import json
import sys

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time
OUTPUT_CSV  = ""

LIST_FIELDS = [
    "id", "name", "isEnabled", "folderId", "campaignId",
    "createdAt", "updatedAt",
]

DETAIL_FIELDS = [
    "id", "name", "layoutContent", "isEnabled",
    "folderId", "campaignId", "createdAt", "updatedAt",
]

FOLDER_FIELDS   = ["id", "name"]
CAMPAIGN_FIELDS = ["id", "name"]


# ── Shaping ───────────────────────────────────────────────────────────────────

def shape_layout(
    layout: dict,
    detail: dict,
    folder_map: dict,
    campaign_map: dict,
) -> dict:
    folder_name   = (folder_map.get(layout.get("folderId"))   or {}).get("name", "")
    campaign_name = (campaign_map.get(layout.get("campaignId")) or {}).get("name", "")
    html = detail.get("layoutContent") or layout.get("layoutContent") or ""

    return {
        "id":             str(layout.get("id", "")),
        "name":           layout.get("name", "") or "",
        "is_enabled":     bool(layout.get("isEnabled")),
        "layout_html":    html,
        "layout_html_chars": len(html),
        "folder":         folder_name,
        "campaign":       campaign_name,
        "created_at":     layout.get("createdAt", "") or "",
        "updated_at":     layout.get("updatedAt", "") or "",
    }


# ── Export ────────────────────────────────────────────────────────────────────

def export_csv(results: list[dict]) -> None:
    headers = [
        "#", "Name", "ID", "Enabled",
        "Layout HTML (chars)", "Folder", "Campaign",
        "Created At", "Updated At",
    ]
    rows = [
        [
            i + 1,
            r["name"], r["id"],
            "Yes" if r["is_enabled"] else "No",
            r["layout_html_chars"],
            r["folder"], r["campaign"],
            r["created_at"], r["updated_at"],
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_layout_templates.json")
    OUTPUT_CSV  = utils.output_path("pardot_layout_templates.csv")

    print("\n🚀 Pardot Layout Template Scraper (v5 API)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    print("📁 Pre-loading folders...")
    folder_map = pardot_api.lookup_map(client, "objects/folders", fields=FOLDER_FIELDS)
    print(f"   ✅ {len(folder_map)} folder(s)")

    print("📋 Pre-loading campaigns...")
    campaign_map = pardot_api.lookup_map(client, "objects/campaigns", fields=CAMPAIGN_FIELDS)
    print(f"   ✅ {len(campaign_map)} campaign(s)")

    print("\n🖼️  Fetching layout templates (list pass)...")
    layouts = list(pardot_api.paged_get(client, "objects/layout-templates", fields=LIST_FIELDS))
    print(f"   ✅ {len(layouts)} layout template(s) found")

    if not layouts:
        print("⚠️  No layout templates returned.")
        utils.save_json([], OUTPUT_JSON)
        export_csv([])
        return

    print(f"\n🔍 Fetching HTML content for {len(layouts)} layout(s)...")
    results = []
    skipped = 0
    for i, layout in enumerate(layouts, 1):
        l_id   = layout.get("id")
        l_name = layout.get("name", f"layout_{l_id}")
        print(f"   [{i}/{len(layouts)}] {l_name} (id: {l_id})")

        detail = pardot_api.get_one(
            client, "objects/layout-templates", l_id, fields=DETAIL_FIELDS,
        )
        if detail is None:
            print(f"     ⚠️  detail read returned None — using list data")
            detail = layout
            skipped += 1

        results.append(shape_layout(layout, detail, folder_map, campaign_map))

    utils.save_json(results, OUTPUT_JSON)
    export_csv(results)

    if skipped:
        print(f"⚠️  {skipped} layout(s) had no detail response (HTML may be empty)")

    print(f"\n✅ Layout template scrape complete — {len(results)} captured.")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
