"""
Pardot Snippet Scraper — v5 API
================================
Pulls all snippets from /api/v5/objects/snippets.

Snippets are reusable content blocks (text/HTML) embedded inside email
templates. Capturing them enables cross-reference analysis to determine:
  • Which email templates use each snippet
  • Orphaned snippets not referenced by any template
  • Brand/language coverage gaps

Two-pass approach:
  Pass 1 — paged_get() lists all snippets with core metadata.
  Pass 2 — get_one() fetches full content body per snippet (value field
            is not always populated in list responses).

Captured fields:
  id, name, value (content), folder, campaign, tracker domain,
  salesforceId, createdAt, updatedAt

Output:
  pardot_snippets.json
  pardot_snippets.csv

Usage (standalone):
  python3 scrape_snippets.py

Called from run_all.py:
  from scrape_snippets import run
  run(page=page)
"""

from __future__ import annotations

import csv
import json
import sys

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time
OUTPUT_CSV  = ""

LIST_FIELDS = [
    "id", "name", "folderId", "campaignId", "salesforceId",
    "createdAt", "updatedAt",
]

DETAIL_FIELDS = ["id", "name", "value", "folderId", "campaignId", "salesforceId",
                 "createdAt", "updatedAt"]

FOLDER_FIELDS   = ["id", "name"]
CAMPAIGN_FIELDS = ["id", "name"]


# ── Shaping ───────────────────────────────────────────────────────────────────

def shape_snippet(
    snippet: dict,
    detail: dict,
    folder_map: dict,
    campaign_map: dict,
) -> dict:
    folder_name   = (folder_map.get(snippet.get("folderId"))   or {}).get("name", "")
    campaign_name = (campaign_map.get(snippet.get("campaignId")) or {}).get("name", "")
    value = detail.get("value") or snippet.get("value") or ""

    return {
        "id":           str(snippet.get("id", "")),
        "name":         snippet.get("name", "") or "",
        "value":        value,
        "value_chars":  len(value),
        "folder":       folder_name,
        "campaign":     campaign_name,
        "salesforce_id": snippet.get("salesforceId") or "",
        "created_at":   snippet.get("createdAt", "") or "",
        "updated_at":   snippet.get("updatedAt", "") or "",
    }


# ── Export ────────────────────────────────────────────────────────────────────

def export_csv(results: list[dict]) -> None:
    headers = [
        "#", "Name", "ID", "Value (chars)", "Value Preview",
        "Folder", "Campaign", "Salesforce ID",
        "Created At", "Updated At",
    ]
    rows = [
        [
            i + 1,
            r["name"], r["id"],
            r["value_chars"],
            r["value"][:120].replace("\n", " "),
            r["folder"], r["campaign"],
            r["salesforce_id"],
            r["created_at"], r["updated_at"],
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_snippets.json")
    OUTPUT_CSV  = utils.output_path("pardot_snippets.csv")

    print("\n🚀 Pardot Snippet Scraper (v5 API)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    print("📁 Pre-loading folders...")
    folder_map = pardot_api.lookup_map(client, "objects/folders", fields=FOLDER_FIELDS)
    print(f"   ✅ {len(folder_map)} folder(s)")

    print("📋 Pre-loading campaigns...")
    campaign_map = pardot_api.lookup_map(client, "objects/campaigns", fields=CAMPAIGN_FIELDS)
    print(f"   ✅ {len(campaign_map)} campaign(s)")

    print("\n✂️  Fetching snippets (list pass)...")
    snippets = list(pardot_api.paged_get(client, "objects/snippets", fields=LIST_FIELDS))
    print(f"   ✅ {len(snippets)} snippet(s) found")

    if not snippets:
        print("⚠️  No snippets returned — snippets may not be in use.")
        utils.save_json([], OUTPUT_JSON)
        export_csv([])
        return

    print(f"\n🔍 Fetching detail for {len(snippets)} snippet(s)...")
    results = []
    skipped = 0
    for i, snippet in enumerate(snippets, 1):
        s_id   = snippet.get("id")
        s_name = snippet.get("name", f"snippet_{s_id}")
        print(f"   [{i}/{len(snippets)}] {s_name} (id: {s_id})")

        detail = pardot_api.get_one(client, "objects/snippets", s_id, fields=DETAIL_FIELDS)
        if detail is None:
            print(f"     ⚠️  detail read returned None — using list data")
            detail = snippet

        results.append(shape_snippet(snippet, detail, folder_map, campaign_map))

    utils.save_json(results, OUTPUT_JSON)
    export_csv(results)

    if skipped:
        print(f"⚠️  {skipped} snippet(s) skipped")

    print(f"\n✅ Snippet scrape complete — {len(results)} captured.")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
