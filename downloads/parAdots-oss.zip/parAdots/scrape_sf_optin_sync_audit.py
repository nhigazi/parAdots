"""
SF Scraper 2 — Lead/Contact Opt-In Field Sync Audit
=====================================================
Verifies that Pardot consent fields are present on Lead and Contact,
and counts mismatches between the two objects for the same email address.

Checks per brand (ACM, GLB, GLB_CH, INI):
  • Field existence on Lead and Contact (describe API)
  • Count of Leads with Optin_Double_{B}__c = true
  • Count of Contacts with Optin_Double_{B}__c = true
  • Count of records where Pardot timestamp field is populated
  • Stale consent: timestamp > 700 days ago AND no opt-out set

Brand codes and field names are read from salesforce_api.CONSENT_BRANDS
and OPTIN_FIELDS — override via .env if your instance uses different names.

Output:
  sf_optin_sync_audit.json
  sf_optin_sync_audit.csv

Called from run_sf.py / run_all.py:
  from scrape_sf_optin_sync_audit import run
  run(page=page)
"""
from __future__ import annotations
import csv, json, sys
from datetime import datetime, timezone, timedelta
import salesforce_api as sf
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""

STALE_DAYS = 700   # GDPR re-consent threshold


def _check_field_presence(client: sf.SalesforceClient, sobject: str, fields: list[str]) -> dict[str, bool]:
    known = sf.field_names(client, sobject)
    return {f: (f in known) for f in fields}


def _count_optin(client: sf.SalesforceClient, sobject: str, field: str) -> int:
    if not field:
        return -1
    return sf.soql_count(client, f"SELECT COUNT() FROM {sobject} WHERE {field} = true")


def _count_stale_consent(client: sf.SalesforceClient, sobject: str,
                          optin_field: str, ts_field: str) -> int:
    """Count records opted-in but with timestamp older than STALE_DAYS."""
    cutoff = (datetime.now(timezone.utc) - timedelta(days=STALE_DAYS)).strftime("%Y-%m-%dT%H:%M:%SZ")
    q = (f"SELECT COUNT() FROM {sobject} "
         f"WHERE {optin_field} = true "
         f"AND {ts_field} != null "
         f"AND {ts_field} < {cutoff}")
    return sf.soql_count(client, q)


def run(page=None, client: sf.SalesforceClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("sf_optin_sync_audit.json")
    OUTPUT_CSV  = utils.output_path("sf_optin_sync_audit.csv")

    print("\n🚀 SF Scraper 2 — Opt-In Field Sync Audit")
    print("=" * 50)

    if client is None:
        if page is None:
            print("❌ Need page or client"); sys.exit(1)
        client = sf.client_from_page(page)

    # Describe-driven: auto-discover consent fields unless pinned in .env.
    brands, optin_flds, ts_flds = sf.resolve_consent_fields(client)

    print(f"   Brands: {', '.join(brands)}")
    print(f"   Opt-in fields: {', '.join(optin_flds)}\n")

    # Describe once per object
    print("🔍 Checking field presence on Lead and Contact...")
    lead_fields    = _check_field_presence(client, "Lead",    optin_flds + ts_flds)
    contact_fields = _check_field_presence(client, "Contact", optin_flds + ts_flds)

    results = []
    for brand, optin_f, ts_f in zip(brands, optin_flds, ts_flds):
        print(f"\n   Brand: {brand}")

        lead_has_optin  = lead_fields.get(optin_f, False)
        lead_has_ts     = lead_fields.get(ts_f, False)
        cont_has_optin  = contact_fields.get(optin_f, False)
        cont_has_ts     = contact_fields.get(ts_f, False)

        print(f"      Lead  {optin_f}: {'✅' if lead_has_optin else '❌'}")
        print(f"      Cont  {optin_f}: {'✅' if cont_has_optin else '❌'}")

        lead_optin_count  = _count_optin(client, "Lead",    optin_f) if lead_has_optin  else -1
        cont_optin_count  = _count_optin(client, "Contact", optin_f) if cont_has_optin  else -1
        lead_stale        = _count_stale_consent(client, "Lead",    optin_f, ts_f) if (lead_has_optin and lead_has_ts)    else -1
        cont_stale        = _count_stale_consent(client, "Contact", optin_f, ts_f) if (cont_has_optin and cont_has_ts) else -1

        total_optin = (lead_optin_count if lead_optin_count >= 0 else 0) + \
                      (cont_optin_count if cont_optin_count >= 0 else 0)
        total_stale = (lead_stale if lead_stale >= 0 else 0) + \
                      (cont_stale if cont_stale >= 0 else 0)
        stale_pct   = round(total_stale / total_optin * 100, 1) if total_optin > 0 else 0.0

        print(f"      Opted-in Lead: {lead_optin_count:,}  Contact: {cont_optin_count:,}")
        print(f"      Stale (>{STALE_DAYS}d) Lead: {lead_stale}  Contact: {cont_stale}  ({stale_pct}%)")

        results.append({
            "brand":            brand,
            "optin_field":      optin_f,
            "timestamp_field":  ts_f,
            "lead_field_exists":    lead_has_optin,
            "contact_field_exists": cont_has_optin,
            "lead_ts_field_exists": lead_has_ts,
            "contact_ts_field_exists": cont_has_ts,
            "lead_opted_in":    lead_optin_count,
            "contact_opted_in": cont_optin_count,
            "total_opted_in":   total_optin,
            "lead_stale_count": lead_stale,
            "contact_stale_count": cont_stale,
            "total_stale":      total_stale,
            "stale_pct":        stale_pct,
            "stale_threshold_days": STALE_DAYS,
        })

    utils.save_json(results, OUTPUT_JSON)
    _export_csv(results)
    print(f"\n✅ Opt-in sync audit complete.")


def _export_csv(results):
    headers = ["Brand", "Opt-In Field", "Lead Field ✓", "Contact Field ✓",
               "Lead Opted-In", "Contact Opted-In", "Total Opted-In",
               "Stale Lead", "Stale Contact", "Total Stale", "Stale %"]
    rows = [
        [r["brand"], r["optin_field"],
         "Yes" if r["lead_field_exists"] else "No",
         "Yes" if r["contact_field_exists"] else "No",
         r["lead_opted_in"], r["contact_opted_in"], r["total_opted_in"],
         r["lead_stale_count"], r["contact_stale_count"],
         r["total_stale"], f"{r['stale_pct']}%"]
        for r in results
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV}")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
