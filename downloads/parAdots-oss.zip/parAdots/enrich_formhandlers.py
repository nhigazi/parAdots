"""
enrich_formhandlers.py — Extract human-readable descriptions from form handler data
====================================================================================

Reads structured JSON exports and extracts plain-language descriptions by parsing
the form handler data. No external API calls.

Outputs enriched JSON files with descriptions + edit tracking:
  - formhandlers_enriched.json
  - formhandlers_enriched.csv

Re-run behavior:
  - Items with edited=true are always skipped (preserves user edits)
  - Items with edited=false are regenerated (fresh descriptions each run)
  - --skip-existing flag skips items with edited=false
  - --force flag regenerates everything, even user-edited items

Usage:
  python enrich_formhandlers.py --org umbrella
  python enrich_formhandlers.py --org umbrella --skip-existing
  python enrich_formhandlers.py --org umbrella --force
"""

import argparse
import csv
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import utils


def _ca_action_label(ca: str) -> str:
    """Convert a single completion-action string to a short German label."""
    prefix = ca.split(":")[0].strip()
    rest = ca[len(prefix) + 1:].strip() if ":" in ca else ""
    t = ca.lower()
    if prefix in ("Notify user",) or t.startswith("send autoresponder"):
        return f"sendet E-Mail '{rest}'" if rest else "sendet Benachrichtigung"
    if prefix == "Add to list":
        return f"→ Liste '{rest}'" if rest else "→ Liste"
    if prefix == "Remove from list":
        return f"entfernt aus Liste '{rest}'" if rest else "entfernt aus Liste"
    if prefix == "Change prospect custom field value":
        return f"Feld {rest}" if rest else "setzt custom field"
    if prefix == "Change prospect default field value":
        return f"Feld {rest}" if rest else "setzt Standardfeld"
    if prefix == "Add tags":
        return f"Tag '{rest}'" if rest else "setzt Tag"
    if prefix in ("Assign to user", "Assign to queue"):
        return f"Queue: {rest}" if rest else "weist zu"
    if prefix == "Add to CRM Campaign":
        return f"CRM-Kampagne: {rest}" if rest else "CRM-Kampagne"
    return ca[:60]


def _parse_conditional(cond_str: str) -> str:
    """
    Parse 'Conditional Parameters: If [field_type] [field_name] [operator] [value]'
    → 'Source = newsletter'
    """
    inner = cond_str.replace("Conditional Parameters:", "").strip()
    inner = inner.lstrip("If").strip()
    # Remove surrounding brackets from each token
    import re
    tokens = re.findall(r'\[([^\]]+)\]', inner)
    if len(tokens) >= 4:
        # tokens: [field_type, field_name, operator, value]
        return f"{tokens[1]} {tokens[2]} '{tokens[3]}'"
    if len(tokens) == 3:
        return f"{tokens[0]} {tokens[1]} '{tokens[2]}'"
    return inner


def _format_completion_actions(completion_actions: list) -> str:
    """
    Group completion_actions into conditional blocks and format as a readable string.
    Returns empty string if no actions.
    """
    if not completion_actions:
        return ""

    # Split into blocks: each "Conditional Parameters" starts a new block.
    # Actions before the first conditional go into an unconditional block (key=None).
    blocks = []  # list of (condition_str_or_None, [action_labels])
    current_cond = None
    current_actions = []

    for ca in completion_actions:
        if not isinstance(ca, str):
            # dict fallback — just render inline
            t = (ca.get("type") or ca.get("designation") or "").lower()
            lbl = (
                "sendet Benachrichtigung" if ("email" in t or "notify" in t) else
                "fügt zu Liste hinzu" if ("list" in t and "add" in t) else
                "entfernt aus Liste" if ("list" in t and "remove" in t) else
                "aktualisiert Feld" if ("field" in t or "change" in t) else
                "setzt Tag" if "tag" in t else str(ca)[:40]
            )
            current_actions.append(lbl)
            continue

        if ca.startswith("Conditional Parameters"):
            # Save previous block
            if current_actions or current_cond is not None:
                blocks.append((current_cond, current_actions))
            current_cond = _parse_conditional(ca)
            current_actions = []
        else:
            current_actions.append(_ca_action_label(ca))

    # Save last block
    if current_actions or current_cond is not None:
        blocks.append((current_cond, current_actions))

    if not blocks:
        return ""

    parts = []
    for cond, actions in blocks:
        action_str = ", ".join(actions[:4]) if actions else "—"
        if cond:
            parts.append(f"Wenn {cond}: {action_str}")
        else:
            parts.append(action_str)

    return " Nach Absenden: " + "; ".join(parts) + "."


def extract_formhandler_description(fh: dict) -> str:
    """
    Extract business-focused description for form handlers.
    Explains WHAT the form handler does and HOW data flows.
    """
    name = (fh.get("name") or "").strip()
    campaign = (fh.get("campaign") or "").strip()
    field_mappings = fh.get("field_mappings") or []
    completion_actions = fh.get("completion_actions") or []
    is_always_email = fh.get("is_always_email", False)
    is_data_forwarded = fh.get("is_data_forwarded", False)
    prospect_count = fh.get("prospect_count", "0") or "0"
    name_lower = name.lower()

    # Infer purpose from name
    purpose = ""
    if "newsletter" in name_lower or "nl" in name_lower:
        purpose = "Newsletter-Anmeldung"
    elif "kontakt" in name_lower or "contact" in name_lower:
        purpose = "Kontaktformular"
    elif "unsubscrib" in name_lower or "abmeld" in name_lower:
        purpose = "Abmelde-Formular"
    elif "event" in name_lower or "messe" in name_lower or "webinar" in name_lower:
        purpose = "Event-Registrierung"
    elif "download" in name_lower or "whitepaper" in name_lower or "katalog" in name_lower:
        purpose = "Download-Formular"
    elif "survey" in name_lower or "umfrage" in name_lower:
        purpose = "Umfrage"
    elif "login" in name_lower or "portal" in name_lower:
        purpose = "Portal-Zugang"
    else:
        purpose = "Formular"

    # Field summary
    field_names = []
    for fm in field_mappings[:5]:
        if isinstance(fm, str):
            parts = fm.split("→")
            label = parts[-1].strip() if len(parts) > 1 else fm
            # Clean up internal field names
            label = label.split("(")[0].strip()
            if len(label) < 40:
                field_names.append(label)

    fields_desc = f" Erfasst: {', '.join(field_names[:4])}." if field_names else ""

    ca_desc = _format_completion_actions(completion_actions)

    flags = []
    if is_always_email:
        flags.append("immer E-Mail-Benachrichtigung")
    if is_data_forwarded:
        flags.append("Daten-Weiterleitung aktiv")
    flags_desc = f" ({', '.join(flags)})" if flags else ""

    campaign_desc = f" Kampagne: {campaign}." if campaign else ""

    return (
        f"{purpose}{flags_desc}: Verarbeitet Formulareinreichungen{campaign_desc}"
        f"{fields_desc}{ca_desc} {prospect_count} Kontakte erfasst."
    ).strip()


def _load_json_for_csv(json_path: Path):
    try:
        with open(json_path) as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError, FileNotFoundError):
        return []


def _nl_to_pipe(value: str) -> str:
    """Replace newlines with ' | ' for clean CSV cells."""
    if not value:
        return value
    return " | ".join(line.strip() for line in value.splitlines() if line.strip())


def export_formhandlers_to_csv(json_path: Path, csv_path: Path):
    """
    Export enriched form handlers to CSV.
    Columns: #, Name, ID, Campaign, Prospect Count, Is Always Email, Is Data Forwarded, Description, Edited, Generated At
    """
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "#", "Name", "ID", "Campaign", "Prospect Count",
            "Is Always Email", "Is Data Forwarded", "Description", "Edited", "Generated At",
        ])
        for idx, item in enumerate(items, 1):
            writer.writerow([
                idx,
                item.get("name", ""),
                item.get("id", ""),
                item.get("campaign", ""),
                item.get("prospect_count", ""),
                "Yes" if item.get("is_always_email") else "No",
                "Yes" if item.get("is_data_forwarded") else "No",
                item.get("description", ""),
                "Yes" if item.get("edited") else "No",
                item.get("generated_at", ""),
            ])


def load_existing_enriched(filepath: Path) -> dict:
    """
    Load existing enriched JSON file, indexed by id.
    Returns empty dict if file doesn't exist.
    """
    if not filepath.exists():
        return {}

    try:
        with open(filepath) as f:
            items = json.load(f)
        return {item.get("id"): item for item in items}
    except (json.JSONDecodeError, IOError):
        return {}


def enrich_formhandlers(org: str, skip_existing: bool = False, force: bool = False):
    """
    Main enrichment pipeline for form handlers.
    Extracts descriptions from form handler structure without external API calls.
    """
    # Output paths
    output_dir = Path(utils.OUTPUT_DIR)
    enriched_dir = output_dir / "enriched"
    enriched_dir.mkdir(parents=True, exist_ok=True)

    print("\n🔄 Enriching Form Handlers...")
    formhandlers_path = output_dir / "pardot_formhandlers.json"
    enriched_formhandlers_path = enriched_dir / "formhandlers_enriched.json"
    csv_path = enriched_dir / "formhandlers_enriched.csv"

    if not formhandlers_path.exists():
        print(f"   ⚠️  Source file not found: {formhandlers_path}")
        return

    with open(formhandlers_path) as f:
        formhandlers = json.load(f)

    existing = load_existing_enriched(enriched_formhandlers_path)
    enriched = []

    for handler in formhandlers:
        handler_id = handler.get("id")
        handler_name = handler.get("name", "Unknown")

        # Source fields always reflect current source data
        source_fields = {
            "id": handler_id,
            "name": handler_name,
            "campaign": handler.get("campaign", ""),
            "folder": handler.get("folder", ""),
            "is_always_email": handler.get("is_always_email", False),
            "is_data_forwarded": handler.get("is_data_forwarded", False),
            "prospect_count": handler.get("prospect_count", "0"),
            "field_mappings": handler.get("field_mappings", []),
            "completion_actions": handler.get("completion_actions", []),
        }

        # Check if we should reuse existing description
        if handler_id in existing:
            existing_item = existing[handler_id]
            if existing_item.get("edited") and not force:
                print(f"   ⊘ {handler_name} (user-edited, preserving description)")
                enriched.append({**source_fields, "description": existing_item.get("description", ""), "edited": True, "generated_at": existing_item.get("generated_at", "")})
                continue
            elif skip_existing and not existing_item.get("edited"):
                print(f"   ⊘ {handler_name} (exists, skipping)")
                enriched.append({**source_fields, "description": existing_item.get("description", ""), "edited": False, "generated_at": existing_item.get("generated_at", "")})
                continue

        # Extract description from form handler structure
        print(f"   ▶  {handler_name}...", end=" ", flush=True)
        try:
            description = extract_formhandler_description(handler)
            print("✅")
        except Exception as e:
            print(f"❌ ({e})")
            description = "Error extracting description."

        enriched.append({
            **source_fields,
            "description": description,
            "edited": False,
            "generated_at": datetime.now().isoformat(),
        })

    with open(enriched_formhandlers_path, "w") as f:
        json.dump(enriched, f, indent=2, ensure_ascii=False)

    print(f"   ✅ Saved: {enriched_formhandlers_path}")

    export_formhandlers_to_csv(enriched_formhandlers_path, csv_path)
    print(f"   ✅ Saved: {csv_path}")

    print("\n" + "=" * 50)
    print("✅ Formhandler enrichment complete.")


def main():
    parser = argparse.ArgumentParser(
        description="Enrich form handler data with rule-extracted plain-language descriptions."
    )
    parser.add_argument(
        "--org", metavar="NAME",
        help="Org config to use (e.g. 'globex'). Overrides .active-org for this run only.",
    )
    parser.add_argument(
        "--skip-existing", action="store_true",
        help="Skip items with edited=false (avoids unnecessary reprocessing).",
    )
    parser.add_argument(
        "--force", action="store_true",
        help="Regenerate everything, even user-edited items.",
    )
    args = parser.parse_args()

    org = utils.load_org_config(args.org)
    print(f"🌐 Org: {org}")

    enrich_formhandlers(org, skip_existing=args.skip_existing, force=args.force)


if __name__ == "__main__":
    main()
