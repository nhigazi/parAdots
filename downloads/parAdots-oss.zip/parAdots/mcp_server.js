#!/usr/bin/env node
/**
 * Pardot Analyzer MCP Server
 * ============================
 * Exposes tools to Copilot Chat via the Model Context Protocol:
 *
 *   1. scrape_pardot_lists     – Run the Python scraper for dynamic lists
 *   2. explain_list_rules      – Explain a specific list's filter rules
 *   3. get_gap_analysis        – Return the full best-practice gap analysis
 *   4. get_cross_references    – Query which assets reference a given list/form/email
 *   5. get_orphaned_assets     – Return all assets not referenced anywhere
 *   6. get_consent_coverage    – Return consent status summary by brand × locale
 *   7. get_use_case_summary    – Return the auto-generated use case descriptions
 *   8. search_assets           – Full-text search across all scraped Pardot objects
 *
 * Registered in .vscode/mcp.json so Copilot Chat can call these tools.
 */

const { McpServer } = require("@modelcontextprotocol/sdk/server/mcp.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const { z } = require("zod");
const { execSync, spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

const PROJECT_DIR = __dirname;
const OUTPUT_FILE = path.join(PROJECT_DIR, "pardot_dynamic_lists.json");
const SCRAPER     = path.join(PROJECT_DIR, "scraper.py");

// ── Helper: load a JSON output file (returns null if missing) ─────────────────
function loadJson(filename) {
  const p = path.join(PROJECT_DIR, filename);
  if (!fs.existsSync(p)) return null;
  try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return null; }
}

// ── MCP Server setup ──────────────────────────────────────────────────────────

const server = new McpServer({
  name: "pardot-list-analyzer",
  version: "1.0.0",
});

// ── Tool 1: scrape_pardot_lists ───────────────────────────────────────────────

server.tool(
  "scrape_pardot_lists",
  "Logs into Pardot and scrapes all dynamic list filter rules. " +
  "Opens a browser window — be ready to enter your MFA code when prompted in the terminal.",
  {},
  async () => {
    // Check .env exists
    const envPath = path.join(PROJECT_DIR, ".env");
    if (!fs.existsSync(envPath)) {
      return {
        content: [{
          type: "text",
          text: "❌ .env file not found.\n\n" +
                "Please create it first:\n" +
                `  cp ${PROJECT_DIR}/.env.template ${envPath}\n` +
                "Then fill in your Salesforce credentials.",
        }],
      };
    }

    // Run the Python scraper
    try {
      execSync(`python3 "${SCRAPER}"`, {
        cwd: PROJECT_DIR,
        stdio: "inherit",   // Lets the user see the browser + enter MFA code
        timeout: 300_000,   // 5 minute timeout
      });
    } catch (err) {
      return {
        content: [{
          type: "text",
          text: `❌ Scraper failed: ${err.message}\n\nCheck the terminal for details.`,
        }],
      };
    }

    // Read results
    if (!fs.existsSync(OUTPUT_FILE)) {
      return {
        content: [{
          type: "text",
          text: "❌ Scraper finished but no output file was created. Check the terminal for errors.",
        }],
      };
    }

    const results = JSON.parse(fs.readFileSync(OUTPUT_FILE, "utf8"));
    const summary = results.map(l =>
      `• ${l.name} (id: ${l.id}) — ${l.rules?.length ?? 0} rule(s) found`
    ).join("\n");

    return {
      content: [{
        type: "text",
        text: `✅ Scraping complete. Found ${results.length} dynamic list(s):\n\n${summary}\n\n` +
              `Full results saved to: ${OUTPUT_FILE}\n\n` +
              `Use the explain_list_rules tool to get a plain-text explanation of any list.`,
      }],
    };
  }
);

// ── Tool 2: explain_list_rules ────────────────────────────────────────────────

server.tool(
  "explain_list_rules",
  "Reads the scraped Pardot dynamic list rules and explains them in simple, marketer-friendly language. " +
  "Run scrape_pardot_lists first.",
  {
    list_name: z.string().describe(
      'Name of the dynamic list to explain, or "all" to explain every list.'
    ),
  },
  async ({ list_name }) => {
    if (!fs.existsSync(OUTPUT_FILE)) {
      return {
        content: [{
          type: "text",
          text: "❌ No results file found. Please run scrape_pardot_lists first.",
        }],
      };
    }

    const results = JSON.parse(fs.readFileSync(OUTPUT_FILE, "utf8"));

    // Filter by name (or return all)
    const targets = list_name.toLowerCase() === "all"
      ? results
      : results.filter(l => l.name.toLowerCase().includes(list_name.toLowerCase()));

    if (targets.length === 0) {
      const available = results.map(l => `• ${l.name}`).join("\n");
      return {
        content: [{
          type: "text",
          text: `❌ No list found matching "${list_name}".\n\nAvailable lists:\n${available}`,
        }],
      };
    }

    // Build a rich prompt payload for Copilot to explain
    const sections = targets.map(lst => {
      const rulesText = lst.rules?.length
        ? JSON.stringify(lst.rules, null, 2)
        : "(no rules captured — check screenshots folder)";

      return (
        `## List: ${lst.name}\n` +
        (lst.description ? `Description: ${lst.description}\n` : "") +
        `\nFilter rules (raw):\n\`\`\`json\n${rulesText}\n\`\`\`\n` +
        `\nCurrent plain-text explanation:\n${lst.explanation ?? "none"}`
      );
    }).join("\n\n---\n\n");

    return {
      content: [{
        type: "text",
        text:
          `Here are the dynamic list rules for: ${list_name}\n\n` +
          `${sections}\n\n` +
          `---\n` +
          `Please explain each list's rules in simple terms a marketer can understand, ` +
          `describing WHO would be included in the list based on these criteria.`,
      }],
    };
  }
);

// ── Tool 3: get_gap_analysis ──────────────────────────────────────────────────

server.tool(
  "get_gap_analysis",
  "Returns the Pardot best-practice gap analysis. Shows which MCAE features are not yet " +
  "used and the severity of each gap (critical / high / medium / low). " +
  "Run run_all.py first to generate the data.",
  {
    severity_filter: z.string().optional().describe(
      'Filter by severity: "critical", "high", "medium", "low", or "all" (default).'
    ),
  },
  async ({ severity_filter = "all" }) => {
    const data = loadJson("pardot_gap_analysis.json");
    if (!data) {
      return { content: [{ type: "text", text:
        "❌ pardot_gap_analysis.json not found.\n\nRun: python3 run_all.py\n" +
        "Or standalone: python3 analyze_best_practices.py"
      }]};
    }

    let checks = data.checks || [];
    if (severity_filter !== "all") {
      checks = checks.filter(c => c.severity === severity_filter);
    }

    const failing = checks.filter(c => c.status !== "pass" && c.status !== "ok");
    const passing = checks.filter(c => c.status === "pass" || c.status === "ok");

    const formatCheck = (c) => {
      const sev = c.severity.toUpperCase().padEnd(8);
      const lines = [`[${sev}] ${c.title} — ${c.status}`];
      if (c.detail) lines.push(`  Issue: ${c.detail}`);
      if (c.recommendation) lines.push(`  Fix: ${c.recommendation.split("\n")[0]}`);
      return lines.join("\n");
    };

    const summary = data.summary || {};
    const text = [
      `## Pardot Gap Analysis — ${data.generated_at || ""}`,
      `Critical: ${summary.critical_gaps} · High: ${summary.high_gaps} · Medium: ${summary.medium_gaps}`,
      "",
      "### Gaps to address:",
      ...failing.map(formatCheck),
      "",
      `### Passing (${passing.length} checks):`,
      ...passing.map(c => `✅ ${c.title}`),
    ].join("\n");

    return { content: [{ type: "text", text }] };
  }
);

// ── Tool 4: get_cross_references ──────────────────────────────────────────────

server.tool(
  "get_cross_references",
  "Query which Pardot assets (automations, programs, forms) reference a given list, form, or email template. " +
  "Also detects orphaned assets. Run run_all.py first.",
  {
    asset_name: z.string().describe(
      'Name or partial name of a list, form, or email to look up. Use "orphans" to see all orphaned assets.'
    ),
  },
  async ({ asset_name }) => {
    const data = loadJson("pardot_cross_references.json");
    if (!data) {
      return { content: [{ type: "text", text:
        "❌ pardot_cross_references.json not found.\n\nRun: python3 analyze_cross_references.py"
      }]};
    }

    if (asset_name.toLowerCase() === "orphans") {
      const o = data.orphans || {};
      const lines = [
        `## Orphaned Pardot Assets`,
        "",
        `**Lists not referenced anywhere (${(o.lists_not_referenced_anywhere||[]).length}):**`,
        ...(o.lists_not_referenced_anywhere||[]).map(i => `  • ${i.name} (id: ${i.id})`),
        "",
        `**Paused automations (${(o.paused_automations||[]).length}):**`,
        ...(o.paused_automations||[]).map(i => `  • ${i.name} (id: ${i.id})`),
        "",
        `**Forms without completion actions (${(o.forms_without_completion_actions||[]).length}):**`,
        ...(o.forms_without_completion_actions||[]).map(i => `  • ${i.name} (id: ${i.id})`),
      ];
      return { content: [{ type: "text", text: lines.join("\n") }] };
    }

    const query = asset_name.toLowerCase();
    const results = [];

    for (const [category, refs] of [
      ["list", data.list_references || {}],
      ["form", data.form_references || {}],
      ["email", data.email_references || {}],
    ]) {
      for (const [name, refList] of Object.entries(refs)) {
        if (name.toLowerCase().includes(query)) {
          results.push(`**${category}: "${name}"** is referenced by:`);
          refList.forEach(r => results.push(`  → ${r.type}: ${r.name} (id: ${r.id})${r.role ? ` [${r.role}]` : ""}`));
          results.push("");
        }
      }
    }

    if (!results.length) {
      return { content: [{ type: "text", text:
        `No references found for "${asset_name}".\n` +
        `This asset may be orphaned or not yet in the cross-reference data.\n` +
        `Try: get_cross_references with asset_name = "orphans"`
      }]};
    }

    return { content: [{ type: "text", text: results.join("\n") }] };
  }
);

// ── Tool 5: get_orphaned_assets ───────────────────────────────────────────────

server.tool(
  "get_orphaned_assets",
  "Returns all Pardot assets (lists, automations, forms) that are not referenced by any other asset. " +
  "These are candidates for cleanup or archiving.",
  {},
  async () => {
    const data = loadJson("pardot_cross_references.json");
    if (!data) {
      return { content: [{ type: "text", text:
        "❌ pardot_cross_references.json not found.\n\nRun: python3 analyze_cross_references.py"
      }]};
    }
    const o = data.orphans || {};
    const s = data.summary || {};
    const text = [
      `## Orphaned Asset Report`,
      `Generated: ${data.generated_at || ""}`,
      "",
      `**${(o.lists_not_referenced_anywhere||[]).length} orphan list(s)** (not used in any automation, program, or form):`,
      ...(o.lists_not_referenced_anywhere||[]).map(i => `  • ${i.name}`),
      "",
      `**${(o.paused_automations||[]).length} paused automation(s)** (may be obsolete):`,
      ...(o.paused_automations||[]).slice(0, 20).map(i => `  • ${i.name}`),
      "",
      `**${(o.forms_without_completion_actions||[]).length} form(s) with no completion actions:**`,
      ...(o.forms_without_completion_actions||[]).map(i => `  • ${i.name}`),
    ].join("\n");
    return { content: [{ type: "text", text }] };
  }
);

// ── Tool 6: get_consent_coverage ─────────────────────────────────────────────

server.tool(
  "get_consent_coverage",
  "Returns a summary of consent management coverage: which brands and locales have " +
  "DOI forms, consent lists, and automation rules configured.",
  {},
  async () => {
    const lists  = loadJson("pardot_dynamic_lists.json") || [];
    const autos  = loadJson("pardot_automation_rules.json") || [];
    const forms  = loadJson("pardot_forms.json") || [];

    const brands  = ["ACM", "GLB", "GLB-CH", "INI"];
    const locales = ["DE-DE", "AT-DE", "CH-DE", "CH-FR", "CH-IT", "CZ-CS"];

    const lines = ["## Consent Coverage by Brand × Locale", ""];

    for (const brand of brands) {
      const bl = brand.toLowerCase();
      const consentLists  = lists.filter(l => l.name.toLowerCase().includes(bl) && l.name.toLowerCase().includes("consent"));
      const consentAutos  = autos.filter(a => a.name.toLowerCase().includes("consent") && a.name.toLowerCase().includes(bl));
      const doiForms      = forms.filter(f => f.name.toLowerCase().includes("doi") && f.name.toLowerCase().includes(bl.replace("-", "")));

      lines.push(`### ${brand}`);
      lines.push(`  Consent lists: ${consentLists.length} | Consent automations: ${consentAutos.length} | DOI forms: ${doiForms.length}`);

      const coveredLocales = locales.filter(loc =>
        consentAutos.some(a => a.name.includes(loc)) ||
        doiForms.some(f => f.name.includes(loc))
      );
      lines.push(`  Covered locales: ${coveredLocales.join(", ") || "none detected"}`);
      const missing = locales.filter(l => !coveredLocales.includes(l));
      if (missing.length) lines.push(`  ⚠️  Possibly missing: ${missing.join(", ")}`);
      lines.push("");
    }

    return { content: [{ type: "text", text: lines.join("\n") }] };
  }
);

// ── Tool 7: get_use_case_summary ─────────────────────────────────────────────

server.tool(
  "get_use_case_summary",
  "Returns a human-readable summary of the 10 current marketing use cases " +
  "active in this Pardot instance, derived from the scraped data.",
  {},
  async () => {
    const lists    = loadJson("pardot_dynamic_lists.json") || [];
    const autos    = loadJson("pardot_automation_rules.json") || [];
    const forms    = loadJson("pardot_forms.json") || [];
    const programs = loadJson("pardot_engagement_studio.json") || [];
    const fh       = loadJson("pardot_formhandlers.json") || [];
    const dyn      = loadJson("pardot_dynamic_content.json") || [];

    const text = [
      `## Pardot Instance — Active Use Cases`,
      `Based on: ${lists.length} lists · ${autos.length} automations · ${forms.length} forms · ` +
      `${fh.length} form handlers · ${programs.length} programs · ${dyn.length} dynamic content blocks`,
      "",
      "**UC-1: GDPR Double Opt-In (DOI) Consent Management**",
      `  ${forms.filter(f => f.name.toLowerCase().includes("doi")).length} DOI forms · ` +
      `${autos.filter(a => a.name.toLowerCase().includes("consent")).length} consent automations · ` +
      `4 brands × 6 locales (DE-DE, AT-DE, CH-DE, CH-FR, CH-IT, CZ-CS)`,
      "",
      "**UC-2: Multi-Brand Newsletter Segmentation**",
      `  ${lists.filter(l => l.name.toLowerCase().includes("newsletter")).length} newsletter lists covering ACM, GLB, GLB-CH, INI`,
      "",
      "**UC-3: B2B Buyer Persona Segmentation**",
      `  ${lists.filter(l => ["architekt","planer","handwerk","wowi","hauptziel"].some(k => l.name.toLowerCase().includes(k))).length} persona lists (Architects, Planners, Handwerk, Wohnungswirtschaft)`,
      "",
      "**UC-4: Competitor & Spam Suppression**",
      `  ${lists.filter(l => l.name.toLowerCase().includes("suppression")).length} suppression lists · ` +
      `${autos.filter(a => a.name.toLowerCase().includes("spam")).length} spam detection rules`,
      "",
      "**UC-5: Trade Show & Event Marketing**",
      `  ${forms.filter(f => ["ish","gewinnspiel","event","wp-pre"].some(k => f.name.toLowerCase().includes(k))).length} event forms`,
      "",
      "**UC-6: Press / Media Newsletter Outreach**",
      `  ${lists.filter(l => l.name.toLowerCase().includes("presse")).length} press lists`,
      "",
      "**UC-7: Lead Lifecycle & Data Quality**",
      `  ${programs.length} Engagement Studio programs · bounce/opt-out lifecycle management`,
      "",
      "**UC-8: CRM Sync & Language Mapping**",
      `  ${autos.filter(a => ["sync","crm","set ","filter"].some(k => a.name.toLowerCase().includes(k))).length} CRM sync automations`,
      "",
      "**UC-9: Consent Source Tracking**",
      "  Optin Source {Brand} field records acquisition channel per brand",
      "",
      "**UC-10: Internal Employee Exclusion**",
      `  ${lists.filter(l => l.name.toLowerCase().includes("mitarbeiter")).length} employee suppression list(s)`,
    ].join("\n");

    return { content: [{ type: "text", text }] };
  }
);

// ── Tool 8: search_assets ─────────────────────────────────────────────────────

server.tool(
  "search_assets",
  "Full-text search across all scraped Pardot objects " +
  "(lists, automations, forms, form handlers, programs, dynamic content). " +
  "Returns matching asset names and types.",
  {
    query: z.string().describe("Search term to find across all Pardot asset names and content."),
  },
  async ({ query }) => {
    const allFiles = [
      ["list",            "pardot_dynamic_lists.json"],
      ["automation",      "pardot_automation_rules.json"],
      ["form",            "pardot_forms.json"],
      ["form_handler",    "pardot_formhandlers.json"],
      ["program",         "pardot_engagement_studio.json"],
      ["dynamic_content", "pardot_dynamic_content.json"],
      ["email_template",  "pardot_email_templates.json"],
      ["landing_page",    "pardot_landing_pages.json"],
      ["campaign",        "pardot_campaigns.json"],
    ];

    const q = query.toLowerCase();
    const hits = [];

    for (const [assetType, filename] of allFiles) {
      const data = loadJson(filename);
      if (!data || !Array.isArray(data)) continue;
      for (const item of data) {
        const searchText = JSON.stringify(item).toLowerCase();
        if (searchText.includes(q)) {
          hits.push(`[${assetType}] ${item.name || item.id} (id: ${item.id || "?"})`);
        }
      }
    }

    if (!hits.length) {
      return { content: [{ type: "text", text: `No results found for "${query}".` }] };
    }

    return { content: [{ type: "text", text:
      `## Search results for "${query}" — ${hits.length} match(es)\n\n` + hits.join("\n")
    }]};
  }
);

// ── Start ─────────────────────────────────────────────────────────────────────

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

main().catch(console.error);
