"""
Pardot Folder Scraper — v5 API
================================
Exports the full Pardot folder structure from /api/v5/objects/folders.

Folders organize all Pardot assets (forms, emails, lists, landing pages, etc.)
into a hierarchy. Auditing the folder structure reveals:
  • How well-organized the org is (flat vs. nested, naming conventions)
  • Folders with suspiciously many or few assets
  • Orphaned top-level folders suggesting abandoned projects or brands

Captured fields:
  id, name, parentFolderId, path, usePermissions, createdAt, updatedAt

Fixed 2026-07-02: FOLDER_FIELDS used two field names that don't exist on the
v5 `objects/folders` object — `parentId` (real name: `parentFolderId`) and
`isRoot` (doesn't exist at all; a root folder is one where `parentFolderId`
is null — see the `parentFolderIdIsNull` filter in the official docs). A
single invalid field name 400s the whole request; pardot_api.paged_get()
swallows that silently and returns an empty list, which run_all.py then logs
as a false success — same failure mode found in scrape_list_emails.py the
same day. Confirmed against the official docs:
https://developer.salesforce.com/docs/marketing/pardot/guide/folder-v5.html

Bonus from the docs: `path` is returned pre-built by the API ("Folder1 /
Folder2 / ..."), so the manual parent-chain walk to build a path is no
longer needed — kept only to resolve `parent_name` and `depth`.

Output:
  pardot_folders.json    — full folder tree with asset counts
  pardot_folders.csv     — flat table, one row per folder

Usage (standalone):
  python3 scrape_folders.py

Called from run_all.py:
  from scrape_folders import run
  run(page=page)
"""

from __future__ import annotations

import csv
import json
import os
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""

FOLDER_FIELDS = [
    "id", "name", "parentFolderId", "path", "usePermissions",
    "createdAt", "updatedAt", "createdById", "updatedById",
]

# Other scraper output files that contain a folderId field — used for asset counting
ASSET_SOURCES = [
    ("pardot_email_templates.json",  "email_templates"),
    ("pardot_forms.json",            "forms"),
    ("pardot_formhandlers.json",     "form_handlers"),
    ("pardot_landing_pages.json",    "landing_pages"),
    ("pardot_dynamic_content.json",  "dynamic_content"),
    ("pardot_custom_redirects.json", "custom_redirects"),
    ("pardot_snippets.json",         "snippets"),
    ("pardot_files.json",            "files"),
    ("pardot_layout_templates.json", "layout_templates"),
    ("pardot_list_emails.json",      "list_emails"),
    ("pardot_campaigns.json",        "campaigns"),
]


# ── Asset count cross-reference ───────────────────────────────────────────────

def _build_folder_asset_counts() -> dict[str, dict[str, int]]:
    """
    Scan existing output JSONs and count assets per folder_id.
    Returns {folder_id: {asset_type: count}}.
    """
    counts: dict[str, dict[str, int]] = {}
    out_dir = utils.OUTPUT_DIR

    for filename, label in ASSET_SOURCES:
        path = os.path.join(out_dir, filename)
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding="utf-8") as f:
                items = json.load(f)
            if not isinstance(items, list):
                continue
            for item in items:
                fid = str(item.get("folderId") or item.get("folder_id") or "")
                if not fid:
                    continue
                if fid not in counts:
                    counts[fid] = {}
                counts[fid][label] = counts[fid].get(label, 0) + 1
        except Exception:
            pass

    return counts


# ── Shaping ───────────────────────────────────────────────────────────────────

def shape_folder(
    f: dict,
    all_folders: dict[str, dict],
    asset_counts: dict[str, dict[str, int]],
) -> dict:
    f_id      = str(f.get("id", ""))
    parent_id = str(f.get("parentId") or f.get("parentFolderId") or "")
    parent    = all_folders.get(parent_id, {})
    parent_name = parent.get("name", "") if parent_id else "(root)"
    is_root   = not parent_id  # no `isRoot` field on the v5 object — root == no parentFolderId

    counts    = asset_counts.get(f_id, {})
    total_assets = sum(counts.values())

    # `path` now comes straight from the API — count separators for depth
    # instead of manually walking the parent chain.
    path = f.get("path", "") or f.get("name", "")
    depth = max(path.count("/"), 0)

    return {
        "id":           f_id,
        "name":         f.get("name", "") or "",
        "parent_id":    parent_id,
        "parent_name":  parent_name,
        "is_root":      is_root,
        "depth":        depth,
        "path":         path,
        "total_assets": total_assets,
        "asset_counts": counts,
        "created_at":   f.get("createdAt", "") or "",
        "updated_at":   f.get("updatedAt", "") or "",
    }


# ── Export ────────────────────────────────────────────────────────────────────

def export_csv(results: list[dict]) -> None:
    # Collect all asset type labels seen
    all_labels = sorted(set(
        label
        for r in results
        for label in r["asset_counts"].keys()
    ))

    base_headers = [
        "#", "Name", "ID", "Parent Name", "Parent ID",
        "Is Root", "Depth", "Path",
        "Total Assets", "Created At", "Updated At",
    ]
    headers = base_headers + all_labels

    rows = []
    for i, r in enumerate(results):
        base = [
            i + 1,
            r["name"], r["id"],
            r["parent_name"], r["parent_id"],
            "Yes" if r["is_root"] else "No",
            r["depth"],
            r["path"],
            r["total_assets"],
            r["created_at"], r["updated_at"],
        ]
        asset_cols = [r["asset_counts"].get(lbl, 0) for lbl in all_labels]
        rows.append(base + asset_cols)

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_folders.json")
    OUTPUT_CSV  = utils.output_path("pardot_folders.csv")

    print("\n📁 Pardot Folder Scraper (v5 API)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    print("📂 Fetching folders...")
    raw = list(pardot_api.paged_get(client, "objects/folders", fields=FOLDER_FIELDS))
    print(f"   ✅ {len(raw)} folder(s) found")

    if not raw:
        utils.save_json([], OUTPUT_JSON)
        export_csv([])
        return

    # Build id → raw dict for path resolution
    all_folders_by_id = {str(f.get("id", "")): f for f in raw}

    print("🔗 Cross-referencing asset counts from existing outputs...")
    asset_counts = _build_folder_asset_counts()
    folders_with_data = len([fid for fid in asset_counts if fid in all_folders_by_id])
    print(f"   ✅ {folders_with_data} folder(s) have assets counted")

    results = [
        shape_folder(f, all_folders_by_id, asset_counts)
        for f in raw
    ]
    # Sort: root first, then by depth, then alphabetically
    results.sort(key=lambda r: (r["depth"], r["name"].lower()))

    utils.save_json(results, OUTPUT_JSON)
    export_csv(results)

    # ── Summary ───────────────────────────────────────────────────────────────
    root_folders   = [r for r in results if r["is_root"] or r["depth"] == 0]
    empty_folders  = [r for r in results if r["total_assets"] == 0]
    max_depth      = max((r["depth"] for r in results), default=0)
    top_by_assets  = sorted(results, key=lambda r: r["total_assets"], reverse=True)[:5]

    print(f"\n── Folder summary ─────────────────────────")
    print(f"   Total folders   : {len(results)}")
    print(f"   Root folders    : {len(root_folders)}")
    print(f"   Empty folders   : {len(empty_folders)}")
    print(f"   Max depth       : {max_depth}")
    if top_by_assets:
        print(f"\n   📦 Top folders by asset count:")
        for r in top_by_assets:
            if r["total_assets"] > 0:
                print(f"      • {r['name']} — {r['total_assets']} assets ({r['path']})")

    if empty_folders:
        print(f"\n   ⚠️  Empty folders ({len(empty_folders)}) — possible hygiene gap:")
        for r in empty_folders[:10]:
            print(f"      • {r['path']}")
        if len(empty_folders) > 10:
            print(f"      ... and {len(empty_folders) - 10} more")

    print(f"\n✅ Folder scrape complete — {len(results)} folder(s).")


# ── Standalone ────────────────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
