"""
Pardot File Library Scraper — v5 API
======================================
Pulls all files from /api/v5/objects/files (Pardot's hosted file/image library).

Files are images, PDFs, and other assets hosted by Pardot and embedded in
emails, landing pages, or forms. Capturing them enables:
  • Orphan detection: files not referenced by any email/landing page
  • Storage audit: total file count and estimated size
  • Broken-link risk: old or renamed files still referenced in templates

Captured fields:
  id, name, vanityUrl (public URL), fileType, size (bytes),
  folder, campaign, isCroppingEnabled, createdAt, updatedAt

Output:
  pardot_files.json
  pardot_files.csv

Usage (standalone):
  python3 scrape_files.py

Called from run_all.py:
  from scrape_files import run
  run(page=page)
"""

from __future__ import annotations

import csv
import json
import sys

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time
OUTPUT_CSV  = ""

LIST_FIELDS = [
    "id", "name", "vanityUrl", "fileType", "size",
    "folderId", "campaignId", "isCroppingEnabled",
    "createdAt", "updatedAt",
]

FOLDER_FIELDS   = ["id", "name"]
CAMPAIGN_FIELDS = ["id", "name"]


# ── Helpers ───────────────────────────────────────────────────────────────────

def _human_size(size_bytes) -> str:
    """Convert bytes to a readable string."""
    if size_bytes is None:
        return ""
    try:
        b = int(size_bytes)
    except (TypeError, ValueError):
        return str(size_bytes)
    if b < 1024:
        return f"{b} B"
    elif b < 1024 ** 2:
        return f"{b / 1024:.1f} KB"
    else:
        return f"{b / 1024 ** 2:.1f} MB"


# ── Shaping ───────────────────────────────────────────────────────────────────

def shape_file(
    file: dict,
    folder_map: dict,
    campaign_map: dict,
) -> dict:
    folder_name   = (folder_map.get(file.get("folderId"))   or {}).get("name", "")
    campaign_name = (campaign_map.get(file.get("campaignId")) or {}).get("name", "")

    size_bytes = file.get("size")
    return {
        "id":                str(file.get("id", "")),
        "name":              file.get("name", "") or "",
        "vanity_url":        file.get("vanityUrl") or "",
        "file_type":         file.get("fileType") or "",
        "size_bytes":        size_bytes,
        "size_human":        _human_size(size_bytes),
        "is_cropping_enabled": bool(file.get("isCroppingEnabled")),
        "folder":            folder_name,
        "campaign":          campaign_name,
        "created_at":        file.get("createdAt", "") or "",
        "updated_at":        file.get("updatedAt", "") or "",
    }


# ── Export ────────────────────────────────────────────────────────────────────

def export_csv(results: list[dict]) -> None:
    headers = [
        "#", "Name", "ID", "File Type", "Size",
        "Vanity URL", "Folder", "Campaign",
        "Created At", "Updated At",
    ]
    rows = [
        [
            i + 1,
            r["name"], r["id"],
            r["file_type"], r["size_human"],
            r["vanity_url"],
            r["folder"], r["campaign"],
            r["created_at"], r["updated_at"],
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_files.json")
    OUTPUT_CSV  = utils.output_path("pardot_files.csv")

    print("\n🚀 Pardot File Library Scraper (v5 API)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    print("📁 Pre-loading folders...")
    folder_map = pardot_api.lookup_map(client, "objects/folders", fields=FOLDER_FIELDS)
    print(f"   ✅ {len(folder_map)} folder(s)")

    print("📋 Pre-loading campaigns...")
    campaign_map = pardot_api.lookup_map(client, "objects/campaigns", fields=CAMPAIGN_FIELDS)
    print(f"   ✅ {len(campaign_map)} campaign(s)")

    print("\n📂 Fetching files...")
    files = list(pardot_api.paged_get(client, "objects/files", fields=LIST_FIELDS))
    print(f"   ✅ {len(files)} file(s) found")

    if not files:
        print("⚠️  No files returned — hosted file library may be empty.")
        utils.save_json([], OUTPUT_JSON)
        export_csv([])
        return

    results = [shape_file(f, folder_map, campaign_map) for f in files]

    # Summary stats
    total_bytes = sum(r["size_bytes"] or 0 for r in results if r["size_bytes"] is not None)
    type_counts: dict[str, int] = {}
    for r in results:
        ft = r["file_type"] or "Unknown"
        type_counts[ft] = type_counts.get(ft, 0) + 1

    print(f"\n📊 File summary:")
    print(f"   Total files : {len(results)}")
    print(f"   Total size  : {_human_size(total_bytes)}")
    for ft, count in sorted(type_counts.items(), key=lambda x: -x[1]):
        print(f"   {ft:<20} {count}")

    utils.save_json(results, OUTPUT_JSON)
    export_csv(results)
    print(f"\n✅ File scrape complete — {len(results)} files captured.")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
