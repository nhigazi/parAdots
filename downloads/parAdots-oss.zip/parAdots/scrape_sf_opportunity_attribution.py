"""
SF Scraper 4 — Opportunity Influence / Pipeline Attribution
============================================================
Maps Opportunities to Pardot campaigns to answer: "what revenue did
each Pardot-linked campaign generate?"

Also captures:
  • Pipeline by stage for Pardot-attributed opps
  • Win rate per campaign type
  • Opps with no campaign attribution (quantifies the attribution gap)
  • Average deal size per campaign

Without this, the gap analysis can flag missing campaign attribution
but cannot quantify the financial cost of the gap.

Output:
  sf_opportunity_attribution.json
  sf_opportunity_attribution.csv

Called from run_sf.py / run_all.py:
  from scrape_sf_opportunity_attribution import run
  run(page=page)
"""
from __future__ import annotations
import csv, json, sys
import salesforce_api as sf
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""


def run(page=None, client: sf.SalesforceClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("sf_opportunity_attribution.json")
    OUTPUT_CSV  = utils.output_path("sf_opportunity_attribution.csv")

    print("\n🚀 SF Scraper 4 — Opportunity Attribution")
    print("=" * 50)

    if client is None:
        if page is None:
            print("❌ Need page or client"); sys.exit(1)
        client = sf.client_from_page(page)

    # ── Global opp stats ──────────────────────────────────────────────────────
    print("💼 Global opportunity stats...")
    total_opps       = sf.soql_count(client, "SELECT COUNT() FROM Opportunity")
    attributed_opps  = sf.soql_count(client, "SELECT COUNT() FROM Opportunity WHERE CampaignId != null")
    unattributed     = total_opps - attributed_opps if total_opps >= 0 and attributed_opps >= 0 else -1
    attr_pct         = round(attributed_opps / total_opps * 100, 1) if total_opps > 0 else 0.0

    print(f"   Total opps          : {total_opps:,}")
    print(f"   With campaign (attr): {attributed_opps:,}  ({attr_pct}%)")
    print(f"   Without attribution : {unattributed:,}")

    # ── By campaign ───────────────────────────────────────────────────────────
    print("\n📊 Revenue by campaign...")
    q = """
        SELECT CampaignId, Campaign.Name, Campaign.Type,
               StageName, IsWon, IsClosed,
               COUNT(Id) opp_count,
               SUM(Amount) total_amount
        FROM   Opportunity
        WHERE  CampaignId != null
        GROUP  BY CampaignId, Campaign.Name, Campaign.Type,
                  StageName, IsWon, IsClosed
        ORDER  BY Campaign.Name, StageName
    """
    rows = sf.soql_all(client, q)
    print(f"   ✅ {len(rows)} campaign × stage combinations")

    # Roll up by campaign
    campaigns: dict[str, dict] = {}
    for r in rows:
        cid   = r.get("CampaignId","")
        camp  = r.get("Campaign") or {}
        cname = r.get("Name") or camp.get("Name") or cid
        ctype = r.get("Type") or camp.get("Type", "")
        stage = r.get("StageName","")
        won   = r.get("IsWon", False)
        cnt   = r.get("opp_count") or r.get("expr0", 0)
        amt   = r.get("total_amount") or r.get("expr1") or 0

        if cid not in campaigns:
            campaigns[cid] = {
                "id": cid, "name": cname, "type": ctype,
                "total_opps": 0, "total_amount": 0,
                "won_opps": 0, "won_amount": 0,
                "stages": {},
            }
        campaigns[cid]["total_opps"]   += cnt
        campaigns[cid]["total_amount"] += amt or 0
        if won:
            campaigns[cid]["won_opps"]   += cnt
            campaigns[cid]["won_amount"] += amt or 0
        campaigns[cid]["stages"][stage] = campaigns[cid]["stages"].get(stage, 0) + cnt

    results = sorted(campaigns.values(), key=lambda x: -(x["won_amount"] or 0))

    # Add derived metrics
    for c in results:
        c["win_rate_pct"] = round(c["won_opps"] / c["total_opps"] * 100, 1) if c["total_opps"] > 0 else 0.0
        c["avg_deal_size"] = round(c["won_amount"] / c["won_opps"], 0) if c["won_opps"] > 0 else 0

    # ── Stage distribution for unattributed opps ──────────────────────────────
    print("\n📋 Stage distribution for unattributed opps...")
    q_unattr = """
        SELECT StageName, COUNT(Id) cnt, SUM(Amount) amt
        FROM   Opportunity
        WHERE  CampaignId = null
        GROUP  BY StageName
        ORDER  BY SUM(Amount) DESC
    """
    unattr_rows = sf.soql_all(client, q_unattr)
    unattr_stages = [
        {"stage": r.get("StageName",""), "count": r.get("cnt") or r.get("expr0",0),
         "amount": r.get("amt") or r.get("expr1") or 0}
        for r in unattr_rows
    ]

    total_won   = sum(c["won_amount"] or 0 for c in results)
    total_pipe  = sum(c["total_amount"] or 0 for c in results)
    print(f"\n📊 Attribution summary:")
    print(f"   Attributed campaigns    : {len(results)}")
    print(f"   Total attributed rev    : {total_pipe:,.0f}")
    print(f"   Won attributed rev      : {total_won:,.0f}")
    print(f"   Attribution gap         : {attr_pct}% of opps have a campaign")

    output = {
        "global": {
            "total_opps": total_opps,
            "attributed_opps": attributed_opps,
            "unattributed_opps": unattributed,
            "attribution_pct": attr_pct,
            "total_won_amount": total_won,
            "total_pipeline_amount": total_pipe,
        },
        "by_campaign":       results,
        "unattributed_stages": unattr_stages,
    }

    utils.save_json(output, OUTPUT_JSON)
    _export_csv(output)
    print(f"\n✅ Opportunity attribution complete.")


def _export_csv(output):
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)

        g = output["global"]
        w.writerow(["=== GLOBAL ==="])
        for k, v in g.items():
            w.writerow([k, v])

        w.writerow([])
        w.writerow(["=== BY CAMPAIGN ==="])
        w.writerow(["#","Campaign","Type","Total Opps","Total Amount",
                    "Won Opps","Won Amount","Win Rate %","Avg Deal Size"])
        for i, c in enumerate(output["by_campaign"], 1):
            w.writerow([i, c["name"], c.get("type",""),
                        c["total_opps"], c.get("total_amount") or "",
                        c["won_opps"], c.get("won_amount") or "",
                        c["win_rate_pct"], c.get("avg_deal_size","") or ""])

        if output["unattributed_stages"]:
            w.writerow([])
            w.writerow(["=== UNATTRIBUTED OPP STAGES ==="])
            w.writerow(["Stage","Count","Total Amount"])
            for s in output["unattributed_stages"]:
                w.writerow([s["stage"], s["count"], s.get("amount","") or ""])

    print(f"✅ Exported {OUTPUT_CSV}")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
