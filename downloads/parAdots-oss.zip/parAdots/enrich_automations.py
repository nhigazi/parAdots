"""
enrich_automations.py — Extract human-readable descriptions from structured automation data
============================================================================================

Reads structured JSON exports and extracts plain-language descriptions by parsing
the existing rule/action data. No external API calls.

Outputs enriched JSON files with descriptions + edit tracking:
  - automation_rules_enriched.json
  - dynamic_lists_enriched.json
  - engagement_programs_enriched.json
  - formhandlers_enriched.json
  - campaigns_enriched.json
  - email_templates_enriched.json
  - static_lists_enriched.json
  - forms_enriched.json
  - dynamic_content_enriched.json
  - scoring_rules_enriched.json
  - landing_pages_enriched.json

Re-run behavior:
  - Items with edited=true are always skipped (preserves user edits)
  - Items with edited=false are regenerated (fresh descriptions each run)
  - --skip-existing flag skips items with edited=false
  - --force flag regenerates everything, even user-edited items

Usage:
  python enrich_automations.py --org umbrella
  python enrich_automations.py --org umbrella --skip-existing
  python enrich_automations.py --org umbrella --force
"""

import argparse
import csv
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import utils


def extract_automation_description(rule: dict) -> str:
    """
    Extract business-focused description for non-technical users.
    Explains WHAT the rule does and WHY, not the technical implementation.
    """
    rule_name = rule.get("name", "Unknown").strip()
    sections = rule.get("sections", {})
    content = sections.get("content", "").strip()

    # Try to extract existing description from content
    description_text = ""
    if content:
        for line in content.split("\n"):
            if line.startswith("Description"):
                parts = line.split("→", 1)
                if len(parts) > 1:
                    description_text = parts[1].strip()
                    if description_text:
                        break

    # If we have a good description in the data, use it
    if description_text:
        return description_text

    # Otherwise, infer purpose from name
    name_lower = rule_name.lower()

    # CONSENT & OPT-IN/OUT RULES
    if "consent" in name_lower and "send" in name_lower and "confirmation" in name_lower:
        # Extract region/brand
        region = ""
        if "ch-de" in name_lower or "ch-fr" in name_lower or "ch-it" in name_lower:
            region = "Schweiz"
        elif "at-de" in name_lower:
            region = "Österreich"
        elif "de-de" in name_lower:
            region = "Deutschland"
        elif "cz" in name_lower or "pl" in name_lower:
            region = "Osteuropa"

        brand = ""
        if "acm" in name_lower:
            brand = "ACME"
        elif "glb" in name_lower:
            brand = "GLOBEX"
        elif "ini" in name_lower:
            brand = "INI"

        location = f" ({region})" if region else ""
        brand_text = f" {brand}" if brand else ""
        return f"Double-Opt-in Bestätigung{brand_text}{location}: Versendet Bestätigungs-E-Mail an neue Abonnenten und wartet auf deren Bestätigung. Kontakte müssen den Bestätigungslink klicken, um in Newsletter-Listen aktiviert zu werden."

    elif "consent" in name_lower and "optin" in name_lower and "confirm" in name_lower:
        brand = "ACME" if "acm" in name_lower else "GLOBEX" if "glb" in name_lower else "INI" if "ini" in name_lower else "Marke"
        return f"Bestätigung speichern ({brand}): Wenn ein Kontakt seinen Bestätigungslink klickt, wird die Einwilligung aktiviert. System protokolliert Datum/Zeit und aktualisiert CRM-Kampagnenstatus."

    elif "consent" in name_lower and "optout" in name_lower:
        brand = "ACME" if "acm" in name_lower else "GLOBEX" if "glb" in name_lower else "INI" if "ini" in name_lower else "Marke"
        return f"Abmeldung verarbeiten ({brand}): Wenn Kontakt sich abmeldet, wird Einwilligung deaktiviert und Kontakt sofort aus aktiven Newsletter-Listen entfernt. Sperre verhindert zukünftige E-Mails."

    elif "consent" in name_lower and "clear" in name_lower:
        brand = "ACME" if "acm" in name_lower else "GLOBEX" if "glb" in name_lower else "INI" if "ini" in name_lower else "Marke"
        return f"Veraltete Daten bereinigen ({brand}): Löscht alte Opt-in-Anfrage-Felder bei Kontakten, deren Bestätigung ausblieb. Verhindert verwaiste Daten, die zu Verwirrung führen."

    elif "consent" in name_lower and "doi" in name_lower and "timestamp" in name_lower:
        brand = "ACME" if "acm" in name_lower else "GLOBEX" if "glb" in name_lower else "Marke"
        return f"Rückwirkende Bestätigung aktivieren ({brand}): Kontakte mit Bestätigungs-Zeitstempel, deren Einwilligung aber nie aktiviert wurde, werden nachträglich aktiviert. Behebt Datensätze aus alten Migrationsprozessen."

    # FILTER RULES
    elif "filter" in name_lower and "remove" in name_lower and ("contact" in name_lower or "lead" in name_lower):
        contact_type = "Kontakte" if "contact" in name_lower else "Leads"
        return f"E-Mail-Sperre aufheben für berechtigte {contact_type}: Hebt die 'Nicht anschreiben'-Sperre auf, wenn {contact_type} eine gültige Einwilligung haben oder in ausstehenden Bestätigungen registriert sind. Ermöglicht E-Mail-Versand an mit Einwilligung versehene Zielgruppen."

    elif "filter" in name_lower and "remove" in name_lower:
        return "E-Mail-Sperre aufheben: Entfernt die 'Nicht anschreiben'-Markierung für Kontakte mit Einwilligung. Aktiviert E-Mail-Kontakt für diese Zielgruppe."

    elif "filter" in name_lower and ("corporation" in name_lower or "dummy" in name_lower):
        if "dummy" in name_lower:
            return "Dummy-Kontakte blockieren: Sperrt Test- und Placeholder-E-Mail-Adressen (z.B. test@example.com) von E-Mail-Versand. Verhindert versehentliche Kontakte mit Testdaten."
        else:
            return "Nicht-relevante Geschäftseinheiten ausschließen: Sperrt E-Mail-Versand für Kontakte von Tochterunternehmen und internen Organisationseinheiten, die nicht Zielgruppe sind."

    elif "filter" in name_lower:
        return "Datenschutz-Filter: Setzt E-Mail-Sperre für Kontakte ohne Einwilligung. Verhindert unerwünschte E-Mail-Kontakte und schützt vor Compliance-Verstößen."

    # SPAM DETECTION
    elif "spam" in name_lower or "blockbounce" in name_lower:
        return "Spam- und Bot-Erkennung: Identifiziert verdächtige Einträge mit Bot-Namen, Spam-Indikatoren oder Hardbounces. Blockiert diese automatisch, um Datenbankqualität zu schützen."

    # AUDIT RULES
    elif "audit" in name_lower and "blockbounce" in name_lower:
        brand = "ACME" if "acm" in name_lower else "GLOBEX" if "glb" in name_lower else "Marke"
        return f"Audit-Korrektur ({brand}): Behebt widersprüchliche Einwilligungsstatus (z.B. Bestätigungsdatum vorhanden, aber Status nicht aktiviert). Erhöht Datenqualität vor Audits."

    elif "audit" in name_lower:
        return "Audit-Datenvorbereitung: Markiert und vorbereitet Kontakte für Audit-Prozesse. Aktiviert Prüf- und Korrektur-Workflows für Datenvalidierung."

    # SET/CHANGE FIELD RULES
    elif "set" in name_lower and "active" in name_lower:
        return "Aktivität tracken: Markiert Kontakte sofort als 'aktiv' nach Formularversand. Hilft, kürzlich engagierte Kontakte zu identifizieren für gezielte Follow-ups."

    elif "set" in name_lower and ("salutation" in name_lower or "anrede" in name_lower):
        return "Anrede standardisieren: Vereinheitlicht unterschiedliche Schreibweisen von Herr/Frau (Mr./Mr/Mr. → Mr). Sorgt für korrekte, höfliche E-Mail-Ansprache in allen Kampagnen."

    elif "set" in name_lower and "language" in name_lower:
        return "CRM-Sprache automatisch setzen: Bestimmt Sprache basierend auf Länder-Code (z.B. DE-DE → Deutsch). Ermöglicht automatische Segmentierung nach Sprache in Salesforce."

    else:
        return "Automatisierte Datenregel: Verwaltet Kontaktinformationen basierend auf vordefinierten Bedingungen und Aktionen."


def extract_dynamic_list_description(dlist: dict) -> str:
    """
    Extract business-focused description for dynamic lists.
    Explains WHO is in the list and WHY they're there (not technical filter rules).
    """
    list_name = dlist.get("name", "Unknown").strip()
    prospect_count = dlist.get("prospect_count", "0")
    name_lower = list_name.lower()

    # Infer purpose and create human-readable description from list name

    # NEWSLETTER LISTS
    if "newsletter" in name_lower:
        brand = ""
        region = ""

        if "acm" in name_lower:
            brand = "ACME"
        elif "glb" in name_lower:
            brand = "GLOBEX"
        elif "ini" in name_lower:
            brand = "INI"

        if "cz" in name_lower:
            region = "(Tschechien)"
        elif "pl" in name_lower:
            region = "(Polen)"
        elif "at" in name_lower:
            region = "(Österreich)"
        elif "de" in name_lower:
            region = "(Deutschland)"
        elif "ch" in name_lower:
            region = "(Schweiz)"

        return f"Newsletter-Abonnenten {brand} {region}: Aktiv bestätigte Abonnenten dieses Newsletters. Sie erhalten regelmäßige Mitteilungen und Angebote. ({prospect_count} Kontakte)"

    # SUPPRESSION & EXCLUSION LISTS
    elif "suppression" in name_lower or "exclusion" in name_lower:
        if "consent" in name_lower:
            brand = "ACME" if "acm" in name_lower else "GLOBEX" if "glb" in name_lower else "INI" if "ini" in name_lower else ""
            return f"Ausschluss-Liste {brand}: Kontakte OHNE gültige Einwilligung. An diese wird NIEMALS eine E-Mail versendet. Schutzliste für Compliance und Datenschutz. ({prospect_count} Kontakte)"
        elif "competitor" in name_lower or "wettbewerb" in name_lower:
            return f"Konkurrenz-Ausschluss: Mitarbeiter von Wettbewerbern und externen Konzernen. Ausgeschlossen von Kampagnen. ({prospect_count} Kontakte)"
        elif "hardbounce" in name_lower:
            return f"Hardbounce-Liste: Kontakte mit ungültigen/defekten E-Mail-Adressen. Werden nicht angeschrieben, um IP-Reputation zu schützen. ({prospect_count} Kontakte)"
        else:
            return f"Ausschluss-Liste: Kontakte, die von E-Mail-Kampagnen ausgenommen werden sollen. ({prospect_count} Kontakte)"

    # AUDIT LISTS
    elif "audit" in name_lower:
        if "release" in name_lower or "prüfliste" in name_lower:
            return f"Audit-Prüfliste: Kontakte, deren Daten in der laufenden Audit-Überprüfung validiert, korrigiert oder genehmigt wurden. ({prospect_count} Kontakte)"
        elif "inactive" in name_lower or "inaktiv" in name_lower:
            return f"Inaktive Audit-Liste: Sehr alte Kontakte mit langer Inaktivität (>2 Jahre). Kandidaten für Datenbereinigung oder Re-Engagement. ({prospect_count} Kontakte)"
        elif "nicht in" in name_lower or "not in" in name_lower:
            return f"Audit-Ausschluss-Liste: Kontakte, die NICHT in aktiven Listen, Key-Segmenten oder als Mitarbeiter gelistet sind. Für Audit und Bereinigung. ({prospect_count} Kontakte)"
        else:
            return f"Audit-Liste: Kontakte für interne Audit-, Validierungs- und Bereinigungsprozesse. ({prospect_count} Kontakte)"

    # PRESS & MEDIA LISTS
    elif "marketing" in name_lower and ("presse" in name_lower or "press" in name_lower or "media" in name_lower):
        if "b2b" in name_lower:
            return f"Presse B2B: Geschäftsmedien, Fachzeitschriften und Branchenpublikationen. Zielgruppe für PR und Pressemitteilungen. ({prospect_count} Kontakte)"
        elif "b2c" in name_lower:
            return f"Presse B2C: Konsummedien, Online-Magazine und Lifestyle-Publisher. Für Consumer-Kampagnen. ({prospect_count} Kontakte)"
        elif "architekten" in name_lower or "architekt" in name_lower:
            return f"Presse Architekten: Architektur-Magazine, Design-Publikationen und Fachmedien für Planer. ({prospect_count} Kontakte)"
        elif "wirtschaft" in name_lower or "wirtschaft" in name_lower:
            return f"Presse Wirtschaft: Wirtschafts- und Finanzmedien für B2B-Kommunikation. ({prospect_count} Kontakte)"
        elif "regional" in name_lower:
            return f"Presse Regional: Regionale Medienvertreter und lokale Publikationen. ({prospect_count} Kontakte)"
        else:
            return f"Presse & Medien: Journalisten und Redaktionen für PR-Kampagnen und Pressemitteilungen. ({prospect_count} Kontakte)"

    # TARGET GROUPS (HAUPTZIELGRUPPE)
    elif "hauptzielgruppe" in name_lower or "target" in name_lower and "group" in name_lower:
        if "architekt" in name_lower:
            return f"Kernzielgruppe Architekten: Architekturbüros, Designfirmen und Planer. Primäre Kundengruppe für Heizungs- und Lüftungslösungen. ({prospect_count} Kontakte)"
        elif "ingenieur" in name_lower or "planer" in name_lower:
            return f"Kernzielgruppe Planer/Ingenieure: Technische Projektleiter, Haustechniker und Planer. Wichtige Entscheidungsträger. ({prospect_count} Kontakte)"
        elif "wowi" in name_lower or "wohnungsw" in name_lower:
            return f"Kernzielgruppe Wohnungswirtschaft: Immobilien- und Wohnungsbauunternehmen. Zielgruppe für Modernisierungsprojekte. ({prospect_count} Kontakte)"
        else:
            return f"Kernzielgruppe: Primäre Kundengruppe für strategische Kampagnen und Fokus-Aktivitäten. ({prospect_count} Kontakte)"

    # CONSENT & OPT-IN LISTS
    elif "consent" in name_lower or "optin" in name_lower:
        brand = ""
        if "acm" in name_lower:
            brand = " ACME"
        elif "glb" in name_lower:
            brand = " GLOBEX"
        elif "ini" in name_lower:
            brand = " INI"

        if "waiting" in name_lower or "not confirmed" in name_lower or "ausstehend" in name_lower:
            return f"Ausstehende Bestätigungen{brand}: Kontakte, die sich neu angemeldet haben, aber noch nicht auf den Bestätigungslink geklickt haben. Warten auf Aktivierung oder Timeout. ({prospect_count} Kontakte)"
        elif "request" in name_lower or "anfrage" in name_lower:
            return f"Einwilligungsanfragen{brand}: Kontakte mit aktiven, aber noch nicht bestätigten Opt-in-Anfragen. Werden gepflegt, bis sie bestätigen oder ablehnen. ({prospect_count} Kontakte)"
        else:
            return f"Mit aktiver Einwilligung{brand}: Kontakte, die ausdrücklich zugestimmt haben, E-Mails zu erhalten. Dürfen angeschrieben werden. ({prospect_count} Kontakte)"

    # K1 COMMUNITY LISTS
    elif "k1" in name_lower:
        if "gründung" in name_lower or "founding" in name_lower:
            return f"K1 Gründungsmitglieder: Frühe Mitglieder der K1 Acmunity. Exklusive Gruppe für spezielle Kampagnen. ({prospect_count} Kontakte)"
        elif "mitglied" in name_lower or "member" in name_lower:
            return f"K1 Mitglieder: Registrierte Teilnehmer der K1 Community. Zugang zu speziellen Inhalten und Events. ({prospect_count} Kontakte)"
        elif "wärmepumpe" in name_lower:
            return f"K1 Interessenten Wärmepumpen: Community-Mitglieder mit Interesse an Wärmepumpentechnologie. ({prospect_count} Kontakte)"
        else:
            return f"K1 Community: Mitglieder der ACME K1 Community-Plattform. ({prospect_count} Kontakte)"

    # VALIDATION & CHECK LISTS
    elif "check" in name_lower or "validation" in name_lower or "validierungs" in name_lower:
        if "consent" in name_lower:
            return f"Validierung Einwilligung: Kontakte zur Überprüfung ihres Consent-Status. Für Datenqualität und Compliance-Audits. ({prospect_count} Kontakte)"
        elif "lead" in name_lower or "contact" in name_lower:
            return f"Validierung {('Leads' if 'lead' in name_lower else 'Kontakte')}: Prüfung auf Konsistenz, Vollständigkeit und Duplikate. Für Datenbankpflege. ({prospect_count} Kontakte)"
        else:
            return f"Validierungs-Liste: Technische Prüfliste für Datenqualität und Konsistenzüberprüfungen. ({prospect_count} Kontakte)"

    # EMPLOYEE LISTS
    elif "mitarbeiter" in name_lower or "employee" in name_lower:
        return f"Mitarbeiter & Partner: Interne Mitarbeiter und Partnerunternehmen. Ausgeschlossen von Kundenkampagnen. Verhindert versehentliche Kontakte mit Kollegen. ({prospect_count} Kontakte)"

    # HANDWERKER (TRADESPEOPLE)
    elif "handwerker" in name_lower or "craftsperson" in name_lower:
        return f"Handwerker & Installateure: Installateure, Heizungstechnik und Handwerksbetriebe. Zielgruppe für technische Produkte und Schulungen. ({prospect_count} Kontakte)"

    else:
        return f"Dynamische Zielgruppe: Automatisch gefilterte Kontakte basierend auf definierten Kriterien. ({prospect_count} Kontakte)"


def extract_engagement_program_description(program: dict) -> str:
    """
    Extract detailed business-focused description from engagement program.
    Describes entry, flow, conditions, and outcomes.
    """
    name = (program.get("name") or "Unknown").strip()
    entry_lists_text = (program.get("entry_lists") or "").strip()
    suppression_lists_text = (program.get("suppression_lists") or "").strip()
    steps = program.get("steps", [])
    program_type = (program.get("type") or "").upper()
    description_text = (program.get("description") or "").strip()

    # Infer program category from name
    name_lower = name.lower()
    category = ""

    if "consent" in name_lower or "optin" in name_lower:
        category = "Einwilligungsverwaltung"
    elif "newsletter" in name_lower or "nl" in name_lower:
        category = "Newsletter-Journey"
    elif "nurture" in program_type.lower():
        category = "Nurture-Programm"
    elif "event" in name_lower or "messe" in name_lower:
        category = "Event-Programm"
    elif "cold" in name_lower or "prospect" in name_lower:
        category = "Lead-Nurturing"
    else:
        category = "Engagement-Programm"

    # Extract entry lists
    entry_lists = [l.strip() for l in entry_lists_text.split("\n") if l.strip()]
    entry_desc = ""
    if len(entry_lists) == 1:
        entry_desc = f"Kontakte aus der Liste '{entry_lists[0]}'"
    elif len(entry_lists) > 1:
        entry_desc = f"Kontakte aus {len(entry_lists)} Listen: {', '.join(entry_lists[:3])}"
        if len(entry_lists) > 3:
            entry_desc += f" + {len(entry_lists) - 3} weitere"
    else:
        entry_desc = "Kontakte ohne spezifische Listeneinschränkung"

    # Extract suppression lists
    suppression_desc = ""
    if suppression_lists_text:
        suppression_lists = [l.strip() for l in suppression_lists_text.split("\n") if l.strip()]
        if suppression_lists:
            suppression_desc = f" Ausgeschlossen: {', '.join(suppression_lists[:2])}"

    # Extract steps with specific details
    step_summary = []
    action_details = []
    action_count = 0
    trigger_count = 0
    wait_count = 0
    send_email_count = 0
    decision_count = 0

    for step in steps[:20]:  # First 20 steps for comprehensive view
        designation = step.get("designation", "").upper()
        label = step.get("label", "").strip()
        actions = step.get("actions", [])
        rules = step.get("rules", [])

        if designation == "ACTION":
            action_count += 1
            # Extract specific action details from object_name
            for action in actions:
                action_type = action.get("designation", "") or ""
                object_name = (action.get("object_name") or "").strip()

                if "SEND" in action_type and "email" in label.lower():
                    send_email_count += 1
                    if object_name:
                        step_summary.append(f"Sendet E-Mail '{object_name}'")
                elif "CHANGE_PROSPECT_FIELD" in action_type and object_name:
                    value = action.get("value", "") or ""
                    if value:
                        action_details.append(f"{object_name} = {value}")
                    else:
                        action_details.append(f"Setzt {object_name}")
                elif "REMOVE_PROSPECT_LIST" in action_type and object_name:
                    action_details.append(f"Entfernt aus Liste '{object_name}'")
                elif "ADD_PROSPECT_LIST" in action_type and object_name:
                    action_details.append(f"Fügt zu Liste '{object_name}' hinzu")
                elif label:
                    step_summary.append(label)

        elif designation == "TRIGGER":
            trigger_count += 1
            decision_count += 1
            # Extract rule conditions
            for rule in rules:
                rule_obj_name = (rule.get("object_name") or "").strip()
                if rule_obj_name:
                    step_summary.append(f"Wenn: {rule_obj_name}")
        elif designation == "DECISION":
            decision_count += 1
            for rule in rules:
                rule_obj_name = (rule.get("object_name") or "").strip()
                if rule_obj_name:
                    step_summary.append(f"Wenn: {rule_obj_name}")
        elif "WAIT" in designation:
            wait_count += 1
            timeout = step.get("timeout", 0)
            if timeout:
                hours = timeout / 3600
                step_summary.append(f"Wartet {int(hours)}h")

    # Build journey description with action details
    journey_parts = step_summary + action_details
    journey_desc = ""
    if journey_parts:
        journey_desc = " → ".join(journey_parts[:8])
        if len(journey_parts) > 8:
            journey_desc += f" → ... ({len(steps)} Schritte insgesamt)"

    # Summarize program purpose
    purpose = ""
    if send_email_count > 0 and "newsletter" in name_lower:
        purpose = "Newsletter-Versand und -Verwaltung"
    elif send_email_count > 0 and "consent" in name_lower:
        purpose = "Versand von Opt-in-Bestätigungen"
    elif "consent" in name_lower or "optin" in name_lower:
        purpose = "Automatisierte Einwilligungsverwaltung"
    elif decision_count > 0:
        purpose = "Abhängig von Bedingungen: verzweigtes Verhalten"
    else:
        purpose = "Automatisierte Kontaktverwaltung"

    # Summarize program structure
    structure = f"{action_count} Aktionen"
    if decision_count > 0:
        structure += f", {decision_count} Bedingungen"
    if wait_count > 0:
        structure += f", {wait_count} Wartezeiten"

    # Build final description - business-focused for non-technical users
    if description_text:
        return f"{description_text} ({entry_lists[0] if entry_lists else 'Verschiedene Listen'})"

    # Generate human-readable description based on program name and purpose
    if "newsletter" in name_lower and "confirm" in name_lower or "anmeld" in name_lower:
        return f"Newsletter-Bestätigung: Erinnert neue Abonnenten, ihre Anmeldung zu bestätigen und sperrt unbestätigte Nutzer aus dem Newsletter."
    elif "consent" in name_lower and "waiting" in name_lower:
        return f"Verwaltung ausstehender Einwilligungen: Behandelt Kontakte, die sich angemeldet haben, aber ihre Bestätigung noch nicht aktiviert haben. System wartet auf Bestätigung oder Abmeldung."
    elif "opt out" in name_lower or "optout" in name_lower or "abmeldung" in name_lower:
        return f"Abmelde-Verarbeitung: Verarbeitet Abmeldewünsche sofort - deaktiviert Einwilligung und entfernt Kontakte aus allen aktiven Kampagnen."
    elif "global" in name_lower and ("opt" in name_lower or "bounced" in name_lower or "hardbounce" in name_lower):
        return f"Hardbounce & Abmeldungs-Verwaltung: Entfernt automatisch Kontakte mit defekten E-Adressen oder globalen Abmeldungen aus Newsletter-Listen."
    elif "cold" in name_lower or "prospect" in name_lower and "nurture" in name_lower:
        return f"Lead-Nurturing: Aufwärmungskampagne für inaktive oder neue Kontakte mit mehreren E-Mails über Zeit zur Aktivierung."
    elif "event" in name_lower or "messe" in name_lower:
        return f"Event-Programm: Verwaltung von Event-Anmeldungen mit Bestätigungen und Follow-up-Kommunikation nach dem Event."
    else:
        return f"{category}: Automatisierte Kontakt-Journey basierend auf definierten Triggern und Bedingungen."


def _ca_action_label(ca: str) -> str:
    """Convert a single completion-action string to a short German label."""
    prefix = ca.split(":")[0].strip()
    rest = ca[len(prefix) + 1:].strip() if ":" in ca else ""
    t = ca.lower()
    if prefix in ("Notify user",) or t.startswith("send autoresponder"):
        return f"sendet E-Mail '{rest}'" if rest else "sendet Benachrichtigung"
    if prefix == "Add to list":
        return f"→ Liste '{rest}'" if rest else "→ Liste"
    if prefix == "Remove from list":
        return f"entfernt aus Liste '{rest}'" if rest else "entfernt aus Liste"
    if prefix == "Change prospect custom field value":
        return f"Feld {rest}" if rest else "setzt custom field"
    if prefix == "Change prospect default field value":
        return f"Feld {rest}" if rest else "setzt Standardfeld"
    if prefix == "Add tags":
        return f"Tag '{rest}'" if rest else "setzt Tag"
    if prefix in ("Assign to user", "Assign to queue"):
        return f"Queue: {rest}" if rest else "weist zu"
    if prefix == "Add to CRM Campaign":
        return f"CRM-Kampagne: {rest}" if rest else "CRM-Kampagne"
    return ca[:60]


def _parse_conditional(cond_str: str) -> str:
    """
    Parse 'Conditional Parameters: If [field_type] [field_name] [operator] [value]'
    → 'Source = newsletter'
    """
    inner = cond_str.replace("Conditional Parameters:", "").strip()
    inner = inner.lstrip("If").strip()
    # Remove surrounding brackets from each token
    import re
    tokens = re.findall(r'\[([^\]]+)\]', inner)
    if len(tokens) >= 4:
        # tokens: [field_type, field_name, operator, value]
        return f"{tokens[1]} {tokens[2]} '{tokens[3]}'"
    if len(tokens) == 3:
        return f"{tokens[0]} {tokens[1]} '{tokens[2]}'"
    return inner


def _format_completion_actions(completion_actions: list) -> str:
    """
    Group completion_actions into conditional blocks and format as a readable string.
    Returns empty string if no actions.
    """
    if not completion_actions:
        return ""

    # Split into blocks: each "Conditional Parameters" starts a new block.
    # Actions before the first conditional go into an unconditional block (key=None).
    blocks = []  # list of (condition_str_or_None, [action_labels])
    current_cond = None
    current_actions = []

    for ca in completion_actions:
        if not isinstance(ca, str):
            # dict fallback — just render inline
            t = (ca.get("type") or ca.get("designation") or "").lower()
            lbl = (
                "sendet Benachrichtigung" if ("email" in t or "notify" in t) else
                "fügt zu Liste hinzu" if ("list" in t and "add" in t) else
                "entfernt aus Liste" if ("list" in t and "remove" in t) else
                "aktualisiert Feld" if ("field" in t or "change" in t) else
                "setzt Tag" if "tag" in t else str(ca)[:40]
            )
            current_actions.append(lbl)
            continue

        if ca.startswith("Conditional Parameters"):
            # Save previous block
            if current_actions or current_cond is not None:
                blocks.append((current_cond, current_actions))
            current_cond = _parse_conditional(ca)
            current_actions = []
        else:
            current_actions.append(_ca_action_label(ca))

    # Save last block
    if current_actions or current_cond is not None:
        blocks.append((current_cond, current_actions))

    if not blocks:
        return ""

    parts = []
    for cond, actions in blocks:
        action_str = ", ".join(actions[:4]) if actions else "—"
        if cond:
            parts.append(f"Wenn {cond}: {action_str}")
        else:
            parts.append(action_str)

    return " Nach Absenden: " + "; ".join(parts) + "."


def extract_formhandler_description(fh: dict) -> str:
    name = (fh.get("name") or "").strip()
    campaign = (fh.get("campaign") or "").strip()
    field_mappings = fh.get("field_mappings") or []
    completion_actions = fh.get("completion_actions") or []
    is_always_email = fh.get("is_always_email", False)
    is_data_forwarded = fh.get("is_data_forwarded", False)
    prospect_count = fh.get("prospect_count", "0") or "0"
    name_lower = name.lower()

    # Infer purpose from name
    purpose = ""
    if "newsletter" in name_lower or "nl" in name_lower:
        purpose = "Newsletter-Anmeldung"
    elif "kontakt" in name_lower or "contact" in name_lower:
        purpose = "Kontaktformular"
    elif "unsubscrib" in name_lower or "abmeld" in name_lower:
        purpose = "Abmelde-Formular"
    elif "event" in name_lower or "messe" in name_lower or "webinar" in name_lower:
        purpose = "Event-Registrierung"
    elif "download" in name_lower or "whitepaper" in name_lower or "katalog" in name_lower:
        purpose = "Download-Formular"
    elif "survey" in name_lower or "umfrage" in name_lower:
        purpose = "Umfrage"
    elif "login" in name_lower or "portal" in name_lower:
        purpose = "Portal-Zugang"
    else:
        purpose = "Formular"

    # Field summary
    field_names = []
    for fm in field_mappings[:5]:
        if isinstance(fm, str):
            parts = fm.split("→")
            label = parts[-1].strip() if len(parts) > 1 else fm
            # Clean up internal field names
            label = label.split("(")[0].strip()
            if len(label) < 40:
                field_names.append(label)

    fields_desc = f" Erfasst: {', '.join(field_names[:4])}." if field_names else ""

    ca_desc = _format_completion_actions(completion_actions)

    flags = []
    if is_always_email:
        flags.append("immer E-Mail-Benachrichtigung")
    if is_data_forwarded:
        flags.append("Daten-Weiterleitung aktiv")
    flags_desc = f" ({', '.join(flags)})" if flags else ""

    campaign_desc = f" Kampagne: {campaign}." if campaign else ""

    return (
        f"{purpose}{flags_desc}: Verarbeitet Formulareinreichungen{campaign_desc}"
        f"{fields_desc}{ca_desc} {prospect_count} Kontakte erfasst."
    ).strip()


def extract_campaign_description(campaign: dict) -> str:
    name = (campaign.get("name") or "").strip()
    ctype = (campaign.get("type") or "").strip()
    status = (campaign.get("status") or "").strip()
    description = (campaign.get("description") or "").strip()
    num_leads = campaign.get("num_leads") or ""
    num_contacts = campaign.get("num_contacts") or ""
    num_opps = campaign.get("num_opportunities") or ""
    num_won = campaign.get("num_won_opportunities") or ""
    linked_total = campaign.get("linked_assets_total") or 0
    linked_by_type = campaign.get("linked_assets_by_type") or {}
    start_date = (campaign.get("start_date") or "").strip()
    end_date = (campaign.get("end_date") or "").strip()

    if description:
        return description

    name_lower = name.lower()

    # Infer purpose
    purpose = ""
    if "newsletter" in name_lower:
        purpose = "Newsletter-Kampagne"
    elif "event" in name_lower or "messe" in name_lower or "webinar" in name_lower:
        purpose = "Event-Kampagne"
    elif "tracking" in name_lower or "website" in name_lower:
        purpose = "Website-Tracking-Kampagne"
    elif "nurture" in name_lower or "lead" in name_lower:
        purpose = "Lead-Nurturing-Kampagne"
    elif "email" in name_lower:
        purpose = "E-Mail-Kampagne"
    elif "social" in name_lower:
        purpose = "Social-Media-Kampagne"
    elif "paid" in name_lower or "ads" in name_lower or "sem" in name_lower:
        purpose = "Paid-Kampagne"
    elif "content" in name_lower:
        purpose = "Content-Kampagne"
    else:
        purpose = f"Kampagne" + (f" ({ctype})" if ctype else "")

    # Activity summary
    activity_parts = []
    if num_leads and str(num_leads) not in ("", "0"):
        activity_parts.append(f"{num_leads} Leads")
    if num_contacts and str(num_contacts) not in ("", "0"):
        activity_parts.append(f"{num_contacts} Kontakte")
    if num_opps and str(num_opps) not in ("", "0"):
        won_info = f" ({num_won} gewonnen)" if num_won and str(num_won) not in ("", "0") else ""
        activity_parts.append(f"{num_opps} Opportunities{won_info}")
    activity_desc = f" Aktivität: {', '.join(activity_parts)}." if activity_parts else ""

    # Linked assets
    asset_parts = []
    if isinstance(linked_by_type, dict):
        for atype, count in linked_by_type.items():
            if count and int(count) > 0:
                asset_parts.append(f"{count} {atype}")
    assets_desc = f" Verknüpft: {', '.join(asset_parts[:4])}." if asset_parts else ""

    # Date range
    date_desc = ""
    if start_date:
        date_desc = f" Zeitraum: {start_date[:10]}"
        if end_date:
            date_desc += f" – {end_date[:10]}"
        date_desc += "."

    status_desc = f" Status: {status}." if status else ""

    return f"{purpose}.{status_desc}{date_desc}{activity_desc}{assets_desc}".strip()


def extract_email_template_description(tmpl: dict) -> str:
    name = (tmpl.get("name") or "").strip()
    subject = (tmpl.get("subject") or "").strip()
    from_name = (tmpl.get("from_name") or "").strip()
    campaign = (tmpl.get("campaign") or "").strip()
    types = (tmpl.get("types") or "").strip()
    is_drip = tmpl.get("is_drip_email", False)
    is_auto = tmpl.get("is_autoresponder_email", False)
    is_list = tmpl.get("is_list_email", False)
    name_lower = name.lower()

    # Usage type
    usage_parts = []
    if is_drip:
        usage_parts.append("Engagement Studio")
    if is_auto:
        usage_parts.append("Auto-Responder")
    if is_list:
        usage_parts.append("Listen-E-Mail")
    usage = " / ".join(usage_parts) if usage_parts else "E-Mail-Template"

    # Purpose from name
    purpose = ""
    if "newsletter" in name_lower or "nl" in name_lower:
        purpose = "Newsletter"
    elif "confirm" in name_lower or "bestät" in name_lower:
        purpose = "Bestätigungs-E-Mail"
    elif "welcome" in name_lower or "willkommen" in name_lower:
        purpose = "Willkommens-E-Mail"
    elif "unsubscrib" in name_lower or "abmeld" in name_lower:
        purpose = "Abmelde-Bestätigung"
    elif "event" in name_lower or "messe" in name_lower or "einladung" in name_lower:
        purpose = "Event-Einladung/-Bestätigung"
    elif "follow" in name_lower or "nurture" in name_lower:
        purpose = "Follow-up / Nurture"
    elif "dev" in name_lower or "test" in name_lower or name_lower.startswith("z"):
        purpose = "Test-/Entwicklungs-Template"
    else:
        purpose = "E-Mail-Template"

    subject_desc = f" Betreff: \"{subject}\"." if subject else ""
    sender_desc = f" Absender: {from_name}." if from_name else ""
    campaign_desc = f" Kampagne: {campaign}." if campaign else ""

    return f"{purpose} ({usage}).{subject_desc}{sender_desc}{campaign_desc}".strip()


def extract_static_list_description(slist: dict) -> str:
    name = (slist.get("name") or "").strip()
    description = (slist.get("description") or "").strip()
    prospect_count = slist.get("prospect_count") or "0"
    name_lower = name.lower()

    if description:
        return f"{description} ({prospect_count} Kontakte)"

    # Similar logic to dynamic lists — infer from name
    purpose = ""
    if "newsletter" in name_lower:
        brand = "ACME" if "acm" in name_lower else "GLOBEX" if "glb" in name_lower else "UMBRELLA" if "umb" in name_lower else ""
        purpose = f"Newsletter-Versandliste {brand}".strip()
    elif "messe" in name_lower or "event" in name_lower or "power2drive" in name_lower or "intersolar" in name_lower:
        purpose = "Event-/Messe-Liste"
    elif "employee" in name_lower or "mitarbeiter" in name_lower:
        purpose = "Mitarbeiter-Liste"
    elif "suppression" in name_lower or "exclusion" in name_lower or "ausschluss" in name_lower:
        purpose = "Ausschluss-/Sperrliste"
    elif "hardbounce" in name_lower:
        purpose = "Hardbounce-Liste"
    elif "import" in name_lower:
        purpose = "Import-Liste"
    elif "test" in name_lower or name_lower.startswith("z"):
        purpose = "Test-/Entwicklungsliste"
    elif "k1" in name_lower:
        purpose = "K1 Community-Liste"
    elif "handwerker" in name_lower:
        purpose = "Handwerker-/Installateur-Liste"
    elif "presse" in name_lower or "press" in name_lower or "media" in name_lower:
        purpose = "Presse-/Medienliste"
    elif any(x in name_lower for x in ["zm", "zielgruppe", "target"]):
        purpose = "Zielgruppenliste"
    elif "partner" in name_lower:
        purpose = "Partner-Liste"
    else:
        purpose = "Statische Liste"

    return f"{purpose}: Manuell gepflegte Kontaktliste. ({prospect_count} Kontakte)"


def extract_form_description(form: dict) -> str:
    name = (form.get("name") or "").strip()
    campaign = (form.get("campaign") or "").strip()
    folder = (form.get("folder") or "").strip()
    submit_btn = (form.get("submit_button_text") or "").strip()
    form_fields = form.get("form_fields") or []
    completion_actions = form.get("completion_actions") or []
    success_location = (form.get("success_location") or "").strip()
    name_lower = name.lower()

    # Purpose
    if "newsletter" in name_lower:
        purpose = "Newsletter-Anmeldung"
    elif "unsubscrib" in name_lower or "abmeld" in name_lower:
        purpose = "Newsletter-Abmeldung"
    elif "contact" in name_lower or "kontakt" in name_lower:
        purpose = "Kontaktformular"
    elif "event" in name_lower or "messe" in name_lower or "registration" in name_lower:
        purpose = "Event-Registrierung"
    elif "download" in name_lower:
        purpose = "Download-Formular"
    elif "survey" in name_lower or "umfrage" in name_lower:
        purpose = "Umfrage"
    elif "login" in name_lower:
        purpose = "Login-Formular"
    else:
        purpose = "Pardot-Formular"

    # Fields
    field_labels = []
    for ff in form_fields[:6]:
        if isinstance(ff, dict):
            lbl = (ff.get("label") or ff.get("name") or "").strip()
            if lbl and len(lbl) < 40:
                field_labels.append(lbl)
    fields_desc = f" Felder: {', '.join(field_labels[:5])}." if field_labels else ""

    # CTA
    cta_desc = f" CTA: \"{submit_btn}\"." if submit_btn else ""

    ca_desc = _format_completion_actions(completion_actions)

    campaign_desc = f" Kampagne: {campaign}." if campaign else ""

    return f"{purpose}.{campaign_desc}{fields_desc}{cta_desc}{ca_desc}".strip()


def extract_dynamic_content_description(dc: dict) -> str:
    name = (dc.get("name") or "").strip()
    based_on = (dc.get("based_on") or "").strip()
    default_content = (dc.get("default_content") or "").strip()
    variations = dc.get("variations") or []

    # Variations summary
    var_parts = []
    for v in variations[:4]:
        if isinstance(v, dict):
            condition = (v.get("condition") or "").strip()
            content = (v.get("content") or "").strip()[:60]
            if condition:
                var_parts.append(f"{condition}: \"{content}\"")
    var_desc = f" Varianten: {'; '.join(var_parts)}." if var_parts else ""

    count = len(variations)
    default_desc = f" Standard: \"{default_content[:80]}\"." if default_content else ""
    based_desc = f" Personalisierung basierend auf: {based_on}." if based_on else ""

    return (
        f"Dynamischer Inhalt: Zeigt {count} verschiedene Inhalte abhängig von Kontakteigenschaften."
        f"{based_desc}{default_desc}{var_desc}"
    ).strip()


def extract_scoring_rule_description(rule: dict) -> str:
    """For scoring rules — data is minimal (raw page text), so describe generically."""
    activity = (rule.get("activity") or "").strip()
    score = (rule.get("score") or "").strip()
    category = (rule.get("category") or "").strip()

    if activity and activity != "Raw page text (needs manual review)":
        score_desc = f" (+{score} Punkte)" if score else ""
        cat_desc = f" Kategorie: {category}." if category and category != "Unparsed" else ""
        return f"Scoring-Regel: {activity}{score_desc}.{cat_desc}"
    else:
        return "Scoring-Regel (automatisch aus Pardot exportiert). Bitte manuell prüfen."


def extract_landing_page_description(lp: dict) -> str:
    name = (lp.get("name") or "").strip()
    status = (lp.get("status") or "").strip()
    campaign = (lp.get("campaign") or "").strip()
    form = (lp.get("form") or "").strip()
    url = (lp.get("url") or "").strip()
    snippet = (lp.get("raw_text_snippet") or "").strip()
    name_lower = name.lower()

    # Purpose
    if "newsletter" in name_lower:
        purpose = "Newsletter-Landing-Page"
    elif "unsubscrib" in name_lower or "abmeld" in name_lower:
        purpose = "Abmelde-Landing-Page"
    elif "event" in name_lower or "messe" in name_lower or "registration" in name_lower:
        purpose = "Event-Registrierungsseite"
    elif "download" in name_lower or "whitepaper" in name_lower:
        purpose = "Download-Landing-Page"
    elif "thank" in name_lower or "danke" in name_lower:
        purpose = "Danke-Seite"
    elif "confirm" in name_lower or "bestät" in name_lower:
        purpose = "Bestätigungsseite"
    else:
        purpose = "Landing Page"

    status_desc = f" Status: {status}." if status else ""
    campaign_desc = f" Kampagne: {campaign}." if campaign else ""
    form_desc = f" Formular: {form}." if form else ""
    url_desc = f" URL: {url}." if url else ""

    return f"{purpose}.{status_desc}{campaign_desc}{form_desc}{url_desc}".strip()


def load_existing_enriched(filepath: Path) -> dict:
    """
    Load existing enriched JSON file, indexed by id.
    Returns empty dict if file doesn't exist.
    """
    if not filepath.exists():
        return {}

    try:
        with open(filepath) as f:
            items = json.load(f)
        return {item.get("id"): item for item in items}
    except (json.JSONDecodeError, IOError):
        return {}


def _load_json_for_csv(json_path: Path):
    try:
        with open(json_path) as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError, FileNotFoundError):
        return []


def _nl_to_pipe(value: str) -> str:
    """Replace newlines with ' | ' for clean CSV cells."""
    if not value:
        return value
    return " | ".join(line.strip() for line in value.splitlines() if line.strip())


def export_automations_to_csv(json_path: Path, csv_path: Path):
    """
    Export enriched automation rules to CSV.
    Columns: #, Name, ID, Status, Prospects Matched, Rules (Criteria), Actions, Description, Edited, Generated At
    """
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "#", "Name", "ID", "Status", "Prospect Count",
            "Rules (Criteria)", "Actions", "Description", "Edited", "Generated At",
        ])
        for idx, item in enumerate(items, 1):
            writer.writerow([
                idx,
                item.get("name", ""),
                item.get("id", ""),
                item.get("status", ""),
                item.get("prospect_count", ""),
                _nl_to_pipe(item.get("rules", "")),
                _nl_to_pipe(item.get("actions", "")),
                item.get("description", ""),
                "Yes" if item.get("edited") else "No",
                item.get("generated_at", ""),
            ])


def export_dynamic_lists_to_csv(json_path: Path, csv_path: Path):
    """
    Export enriched dynamic lists to CSV.
    Columns: #, Name, ID, Prospect Count, Rules (Plain Text), Description, Edited, Generated At
    """
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "#", "Name", "ID", "Prospect Count",
            "Rules (Plain Text)", "Description", "Edited", "Generated At",
        ])
        for idx, item in enumerate(items, 1):
            writer.writerow([
                idx,
                item.get("name", ""),
                item.get("id", ""),
                item.get("prospect_count", ""),
                _nl_to_pipe(item.get("rules", "")),
                item.get("description", ""),
                "Yes" if item.get("edited") else "No",
                item.get("generated_at", ""),
            ])


def export_engagement_programs_to_csv(json_path: Path, csv_path: Path):
    """
    Export enriched engagement programs to CSV.
    Columns: #, Name, ID, Type, Status, Last Updated, Entry Lists, Suppression Lists, Step Count, Description, Edited, Generated At
    """
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "#", "Name", "ID", "Type", "Status", "Last Updated",
            "Entry Lists", "Suppression Lists", "Step Count",
            "Description", "Edited", "Generated At",
        ])
        for idx, item in enumerate(items, 1):
            writer.writerow([
                idx,
                item.get("name", ""),
                item.get("id", ""),
                item.get("type", ""),
                item.get("status", ""),
                item.get("last_updated", ""),
                _nl_to_pipe(item.get("entry_lists", "")),
                _nl_to_pipe(item.get("suppression_lists", "")),
                item.get("step_count", ""),
                item.get("description", ""),
                "Yes" if item.get("edited") else "No",
                item.get("generated_at", ""),
            ])


def export_formhandlers_to_csv(json_path: Path, csv_path: Path):
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["#", "Name", "ID", "Campaign", "Prospect Count", "Is Always Email", "Is Data Forwarded", "Field Mappings", "Description", "Edited", "Generated At"])
        for idx, item in enumerate(items, 1):
            writer.writerow([idx, item.get("name", ""), item.get("id", ""), item.get("campaign", ""), item.get("prospect_count", ""), item.get("is_always_email", ""), item.get("is_data_forwarded", ""), _nl_to_pipe(str(item.get("field_mappings", ""))), item.get("description", ""), "Yes" if item.get("edited") else "No", item.get("generated_at", "")])


def export_campaigns_to_csv(json_path: Path, csv_path: Path):
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["#", "Name", "ID", "Type", "Status", "Start Date", "End Date", "Num Leads", "Num Contacts", "Num Opportunities", "Linked Assets Total", "Description", "Edited", "Generated At"])
        for idx, item in enumerate(items, 1):
            writer.writerow([idx, item.get("name", ""), item.get("id", ""), item.get("type", ""), item.get("status", ""), item.get("start_date", ""), item.get("end_date", ""), item.get("num_leads", ""), item.get("num_contacts", ""), item.get("num_opportunities", ""), item.get("linked_assets_total", ""), item.get("description", ""), "Yes" if item.get("edited") else "No", item.get("generated_at", "")])


def export_email_templates_to_csv(json_path: Path, csv_path: Path):
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["#", "Name", "ID", "Subject", "From Name", "Campaign", "Types", "Is Drip", "Is Autoresponder", "Is List Email", "Description", "Edited", "Generated At"])
        for idx, item in enumerate(items, 1):
            writer.writerow([idx, item.get("name", ""), item.get("id", ""), item.get("subject", ""), item.get("from_name", ""), item.get("campaign", ""), item.get("types", ""), item.get("is_drip_email", ""), item.get("is_autoresponder_email", ""), item.get("is_list_email", ""), item.get("description", ""), "Yes" if item.get("edited") else "No", item.get("generated_at", "")])


def export_static_lists_to_csv(json_path: Path, csv_path: Path):
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["#", "Name", "ID", "Prospect Count", "Description", "Edited", "Generated At"])
        for idx, item in enumerate(items, 1):
            writer.writerow([idx, item.get("name", ""), item.get("id", ""), item.get("prospect_count", ""), item.get("description", ""), "Yes" if item.get("edited") else "No", item.get("generated_at", "")])


def export_forms_to_csv(json_path: Path, csv_path: Path):
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["#", "Name", "ID", "Campaign", "Folder", "Submit Button", "Description", "Edited", "Generated At"])
        for idx, item in enumerate(items, 1):
            writer.writerow([idx, item.get("name", ""), item.get("id", ""), item.get("campaign", ""), item.get("folder", ""), item.get("submit_button_text", ""), item.get("description", ""), "Yes" if item.get("edited") else "No", item.get("generated_at", "")])


def export_dynamic_content_to_csv(json_path: Path, csv_path: Path):
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["#", "Name", "ID", "Based On", "Default Content", "Variation Count", "Description", "Edited", "Generated At"])
        for idx, item in enumerate(items, 1):
            writer.writerow([idx, item.get("name", ""), item.get("id", ""), item.get("based_on", ""), item.get("default_content", "")[:100], item.get("variation_count", ""), item.get("description", ""), "Yes" if item.get("edited") else "No", item.get("generated_at", "")])


def export_scoring_rules_to_csv(json_path: Path, csv_path: Path):
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["#", "Activity", "Score", "Category", "Description", "Edited", "Generated At"])
        for idx, item in enumerate(items, 1):
            writer.writerow([idx, item.get("activity", ""), item.get("score", ""), item.get("category", ""), item.get("description", ""), "Yes" if item.get("edited") else "No", item.get("generated_at", "")])


def export_landing_pages_to_csv(json_path: Path, csv_path: Path):
    items = _load_json_for_csv(json_path)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["#", "Name", "ID", "Status", "Campaign", "Form", "URL", "Description", "Edited", "Generated At"])
        for idx, item in enumerate(items, 1):
            writer.writerow([idx, item.get("name", ""), item.get("id", ""), item.get("status", ""), item.get("campaign", ""), item.get("form", ""), item.get("url", ""), item.get("description", ""), "Yes" if item.get("edited") else "No", item.get("generated_at", "")])


def _enrich_generic(
    source_path: Path,
    enriched_path: Path,
    csv_path: Path,
    id_field: str,
    name_field: str,
    source_fields_fn,
    extract_fn,
    export_fn,
    skip_existing: bool = False,
    force: bool = False,
):
    """Generic enrichment pipeline for any Pardot object type."""
    if not source_path.exists():
        print(f"   ⚠️  Source file not found: {source_path}")
        return

    try:
        with open(source_path) as f:
            items = json.load(f)
    except json.JSONDecodeError as e:
        print(f"   ⚠️  Source file is empty or invalid JSON, skipping: {source_path} ({e})")
        return

    existing = load_existing_enriched(enriched_path)
    enriched = []

    for item in items:
        item_id = item.get(id_field)
        item_name = item.get(name_field, "Unknown")
        source_fields = source_fields_fn(item)

        if item_id in existing:
            ex = existing[item_id]
            if ex.get("edited") and not force:
                print(f"   ⊘ {item_name} (user-edited, preserving description)")
                enriched.append({**source_fields, "description": ex.get("description", ""), "edited": True, "generated_at": ex.get("generated_at", "")})
                continue
            elif skip_existing and not ex.get("edited"):
                print(f"   ⊘ {item_name} (exists, skipping)")
                enriched.append({**source_fields, "description": ex.get("description", ""), "edited": False, "generated_at": ex.get("generated_at", "")})
                continue

        print(f"   ▶  {item_name}...", end=" ", flush=True)
        try:
            desc = extract_fn(item)
            print("✅")
        except Exception as e:
            print(f"❌ ({e})")
            desc = "Error extracting description."

        enriched.append({**source_fields, "description": desc, "edited": False, "generated_at": datetime.now().isoformat()})

    with open(enriched_path, "w") as f:
        json.dump(enriched, f, indent=2, ensure_ascii=False)
    print(f"   ✅ Saved: {enriched_path}")

    export_fn(enriched_path, csv_path)
    print(f"   ✅ Saved: {csv_path}")


def enrich_automations(org: str, skip_existing: bool = False, force: bool = False):
    """
    Main enrichment pipeline for all Pardot objects.
    Extracts descriptions from rule structure without external API calls.
    """
    # Output paths
    output_dir = Path(utils.OUTPUT_DIR)
    enriched_dir = output_dir / "enriched"
    enriched_dir.mkdir(parents=True, exist_ok=True)

    # ─────────────────────────────────────────────────────────────────────────
    # 1. Automation Rules
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Automation Rules...")
    automations_path = output_dir / "pardot_automation_rules.json"
    enriched_automations_path = enriched_dir / "automation_rules_enriched.json"

    if not automations_path.exists():
        print(f"   ⚠️  Source file not found: {automations_path}")
    else:
        try:
            with open(automations_path) as f:
                automations = json.load(f)
        except json.JSONDecodeError as e:
            print(f"   ⚠️  Source file is empty or invalid JSON, skipping: {automations_path} ({e})")
            automations = []

        existing = load_existing_enriched(enriched_automations_path)
        enriched = []

        for rule in automations:
            rule_id = rule.get("id")
            rule_name = rule.get("name", "Unknown")
            sections = rule.get("sections", {})

            # Source fields always reflect current source data
            source_fields = {
                "id": rule_id,
                "name": rule_name,
                "status": rule.get("status", ""),
                "prospect_count": rule.get("prospect_count", ""),
                "rules": sections.get("rules", ""),
                "actions": sections.get("actions", ""),
            }

            # Check if we should reuse existing description
            if rule_id in existing:
                existing_item = existing[rule_id]
                if existing_item.get("edited") and not force:
                    print(f"   ⊘ {rule_name} (user-edited, preserving description)")
                    enriched.append({**source_fields, "description": existing_item.get("description", ""), "edited": True, "generated_at": existing_item.get("generated_at", "")})
                    continue
                elif skip_existing and not existing_item.get("edited"):
                    print(f"   ⊘ {rule_name} (exists, skipping)")
                    enriched.append({**source_fields, "description": existing_item.get("description", ""), "edited": False, "generated_at": existing_item.get("generated_at", "")})
                    continue

            # Extract description from rule structure
            print(f"   ▶  {rule_name}...", end=" ", flush=True)
            try:
                description = extract_automation_description(rule)
                print("✅")
            except Exception as e:
                print(f"❌ ({e})")
                description = "Error extracting description."

            enriched.append({
                **source_fields,
                "description": description,
                "edited": False,
                "generated_at": datetime.now().isoformat(),
            })

        with open(enriched_automations_path, "w") as f:
            json.dump(enriched, f, indent=2, ensure_ascii=False)

        print(f"   ✅ Saved: {enriched_automations_path}")

        # Export to CSV
        csv_path = enriched_dir / "automation_rules_enriched.csv"
        export_automations_to_csv(enriched_automations_path, csv_path)
        print(f"   ✅ Saved: {csv_path}")

    # ─────────────────────────────────────────────────────────────────────────
    # 2. Dynamic Lists
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Dynamic Lists...")
    lists_path = output_dir / "pardot_dynamic_lists.json"
    enriched_lists_path = enriched_dir / "dynamic_lists_enriched.json"

    if not lists_path.exists():
        print(f"   ⚠️  Source file not found: {lists_path}")
    else:
        try:
            with open(lists_path) as f:
                lists = json.load(f)
        except json.JSONDecodeError as e:
            print(f"   ⚠️  Source file is empty or invalid JSON, skipping: {lists_path} ({e})")
            lists = []

        existing = load_existing_enriched(enriched_lists_path)
        enriched = []

        for dlist in lists:
            list_id = dlist.get("id")
            list_name = dlist.get("name", "Unknown")

            # Source fields always reflect current source data
            rules_list = dlist.get("rules") or []
            raw_rules = rules_list[0].get("raw_page_text", "") if rules_list else ""
            source_fields = {
                "id": list_id,
                "name": list_name,
                "prospect_count": dlist.get("prospect_count", ""),
                "rules": raw_rules,
            }

            # Check if we should reuse existing description
            if list_id in existing:
                existing_item = existing[list_id]
                if existing_item.get("edited") and not force:
                    print(f"   ⊘ {list_name} (user-edited, preserving description)")
                    enriched.append({**source_fields, "description": existing_item.get("description", ""), "edited": True, "generated_at": existing_item.get("generated_at", "")})
                    continue
                elif skip_existing and not existing_item.get("edited"):
                    print(f"   ⊘ {list_name} (exists, skipping)")
                    enriched.append({**source_fields, "description": existing_item.get("description", ""), "edited": False, "generated_at": existing_item.get("generated_at", "")})
                    continue

            # Extract description from list structure
            print(f"   ▶  {list_name}...", end=" ", flush=True)
            try:
                description = extract_dynamic_list_description(dlist)
                print("✅")
            except Exception as e:
                print(f"❌ ({e})")
                description = "Error extracting description."

            enriched.append({
                **source_fields,
                "description": description,
                "edited": False,
                "generated_at": datetime.now().isoformat(),
            })

        with open(enriched_lists_path, "w") as f:
            json.dump(enriched, f, indent=2, ensure_ascii=False)

        print(f"   ✅ Saved: {enriched_lists_path}")

        # Export to CSV
        csv_path = enriched_dir / "dynamic_lists_enriched.csv"
        export_dynamic_lists_to_csv(enriched_lists_path, csv_path)
        print(f"   ✅ Saved: {csv_path}")

    # ─────────────────────────────────────────────────────────────────────────
    # 3. Engagement Programs
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Engagement Programs...")
    programs_path = output_dir / "pardot_engagement_studio.json"
    enriched_programs_path = enriched_dir / "engagement_programs_enriched.json"

    if not programs_path.exists():
        print(f"   ⚠️  Source file not found: {programs_path}")
    else:
        try:
            with open(programs_path) as f:
                programs = json.load(f)
        except json.JSONDecodeError as e:
            print(f"   ⚠️  Source file is empty or invalid JSON, skipping: {programs_path} ({e})")
            programs = []

        existing = load_existing_enriched(enriched_programs_path)
        enriched = []

        for program in programs:
            program_id = program.get("id")
            program_name = program.get("name", "Unknown")

            # Source fields always reflect current source data
            source_fields = {
                "id": program_id,
                "name": program_name,
                "type": program.get("type", ""),
                "status": program.get("status", ""),
                "last_updated": program.get("last_updated", ""),
                "entry_lists": program.get("entry_lists", ""),
                "suppression_lists": program.get("suppression_lists", ""),
                "step_count": len(program.get("steps", [])),
            }

            # Check if we should reuse existing description
            if program_id in existing:
                existing_item = existing[program_id]
                if existing_item.get("edited") and not force:
                    print(f"   ⊘ {program_name} (user-edited, preserving description)")
                    enriched.append({**source_fields, "description": existing_item.get("description", ""), "edited": True, "generated_at": existing_item.get("generated_at", "")})
                    continue
                elif skip_existing and not existing_item.get("edited"):
                    print(f"   ⊘ {program_name} (exists, skipping)")
                    enriched.append({**source_fields, "description": existing_item.get("description", ""), "edited": False, "generated_at": existing_item.get("generated_at", "")})
                    continue

            # Extract description from program structure
            print(f"   ▶  {program_name}...", end=" ", flush=True)
            try:
                description = extract_engagement_program_description(program)
                print("✅")
            except Exception as e:
                print(f"❌ ({e})")
                description = "Error extracting description."

            enriched.append({
                **source_fields,
                "description": description,
                "edited": False,
                "generated_at": datetime.now().isoformat(),
            })

        with open(enriched_programs_path, "w") as f:
            json.dump(enriched, f, indent=2, ensure_ascii=False)

        print(f"   ✅ Saved: {enriched_programs_path}")

        # Export to CSV
        csv_path = enriched_dir / "engagement_programs_enriched.csv"
        export_engagement_programs_to_csv(enriched_programs_path, csv_path)
        print(f"   ✅ Saved: {csv_path}")

    # ─────────────────────────────────────────────────────────────────────────
    # 4. Form Handlers
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Form Handlers...")
    _enrich_generic(
        source_path=output_dir / "pardot_formhandlers.json",
        enriched_path=enriched_dir / "formhandlers_enriched.json",
        csv_path=enriched_dir / "formhandlers_enriched.csv",
        id_field="id",
        name_field="name",
        source_fields_fn=lambda r: {
            "id": r.get("id"), "name": r.get("name", ""), "campaign": r.get("campaign", ""),
            "folder": r.get("folder", ""), "is_always_email": r.get("is_always_email", False),
            "is_data_forwarded": r.get("is_data_forwarded", False),
            "prospect_count": r.get("prospect_count", "0"),
            "field_mappings": r.get("field_mappings", []),
            "completion_actions": r.get("completion_actions", []),
        },
        extract_fn=extract_formhandler_description,
        export_fn=export_formhandlers_to_csv,
        skip_existing=skip_existing, force=force,
    )

    # ─────────────────────────────────────────────────────────────────────────
    # 5. Campaigns
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Campaigns...")
    _enrich_generic(
        source_path=output_dir / "pardot_campaigns.json",
        enriched_path=enriched_dir / "campaigns_enriched.json",
        csv_path=enriched_dir / "campaigns_enriched.csv",
        id_field="id",
        name_field="name",
        source_fields_fn=lambda r: {
            "id": r.get("id"), "name": r.get("name", ""), "type": r.get("type", ""),
            "status": r.get("status", ""), "is_active": r.get("is_active", ""),
            "start_date": r.get("start_date", ""), "end_date": r.get("end_date", ""),
            "num_leads": r.get("num_leads", ""), "num_contacts": r.get("num_contacts", ""),
            "num_opportunities": r.get("num_opportunities", ""),
            "num_won_opportunities": r.get("num_won_opportunities", ""),
            "linked_assets_total": r.get("linked_assets_total", 0),
            "linked_assets_by_type": r.get("linked_assets_by_type", {}),
        },
        extract_fn=extract_campaign_description,
        export_fn=export_campaigns_to_csv,
        skip_existing=skip_existing, force=force,
    )

    # ─────────────────────────────────────────────────────────────────────────
    # 6. Email Templates
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Email Templates...")
    _enrich_generic(
        source_path=output_dir / "pardot_email_templates.json",
        enriched_path=enriched_dir / "email_templates_enriched.json",
        csv_path=enriched_dir / "email_templates_enriched.csv",
        id_field="id",
        name_field="name",
        source_fields_fn=lambda r: {
            "id": r.get("id"), "name": r.get("name", ""), "subject": r.get("subject", ""),
            "from_name": r.get("from_name", ""), "from_email": r.get("from_email", ""),
            "campaign": r.get("campaign", ""), "folder": r.get("folder", ""),
            "types": r.get("types", ""),
            "is_drip_email": r.get("is_drip_email", False),
            "is_autoresponder_email": r.get("is_autoresponder_email", False),
            "is_list_email": r.get("is_list_email", False),
        },
        extract_fn=extract_email_template_description,
        export_fn=export_email_templates_to_csv,
        skip_existing=skip_existing, force=force,
    )

    # ─────────────────────────────────────────────────────────────────────────
    # 7. Static Lists
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Static Lists...")
    _enrich_generic(
        source_path=output_dir / "pardot_static_lists.json",
        enriched_path=enriched_dir / "static_lists_enriched.json",
        csv_path=enriched_dir / "static_lists_enriched.csv",
        id_field="id",
        name_field="name",
        source_fields_fn=lambda r: {
            "id": r.get("id"), "name": r.get("name", ""),
            "description": r.get("description", ""),
            "prospect_count": r.get("prospect_count", "0"),
        },
        extract_fn=extract_static_list_description,
        export_fn=export_static_lists_to_csv,
        skip_existing=skip_existing, force=force,
    )

    # ─────────────────────────────────────────────────────────────────────────
    # 8. Forms
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Forms...")
    _enrich_generic(
        source_path=output_dir / "pardot_forms.json",
        enriched_path=enriched_dir / "forms_enriched.json",
        csv_path=enriched_dir / "forms_enriched.csv",
        id_field="id",
        name_field="name",
        source_fields_fn=lambda r: {
            "id": r.get("id"), "name": r.get("name", ""), "campaign": r.get("campaign", ""),
            "folder": r.get("folder", ""), "submit_button_text": r.get("submit_button_text", ""),
            "form_fields": r.get("form_fields", []),
            "completion_actions": r.get("completion_actions", []),
            "success_location": r.get("success_location", ""),
        },
        extract_fn=extract_form_description,
        export_fn=export_forms_to_csv,
        skip_existing=skip_existing, force=force,
    )

    # ─────────────────────────────────────────────────────────────────────────
    # 9. Dynamic Content
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Dynamic Content...")
    _enrich_generic(
        source_path=output_dir / "pardot_dynamic_content.json",
        enriched_path=enriched_dir / "dynamic_content_enriched.json",
        csv_path=enriched_dir / "dynamic_content_enriched.csv",
        id_field="id",
        name_field="name",
        source_fields_fn=lambda r: {
            "id": r.get("id"), "name": r.get("name", ""), "folder": r.get("folder", ""),
            "based_on": r.get("based_on", ""), "default_content": r.get("default_content", ""),
            "variation_count": len(r.get("variations", [])),
            "variations": r.get("variations", []),
        },
        extract_fn=extract_dynamic_content_description,
        export_fn=export_dynamic_content_to_csv,
        skip_existing=skip_existing, force=force,
    )

    # ─────────────────────────────────────────────────────────────────────────
    # 10. Scoring Rules
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Scoring Rules...")
    scoring_path = output_dir / "pardot_scoring_rules.json"
    enriched_scoring_path = enriched_dir / "scoring_rules_enriched.json"
    if not scoring_path.exists():
        print(f"   ⚠️  Source file not found: {scoring_path}")
    else:
        try:
            with open(scoring_path) as f:
                raw = json.load(f)
        except json.JSONDecodeError as e:
            print(f"   ⚠️  Source file is empty or invalid JSON, skipping: {scoring_path} ({e})")
            raw = {}
        # scoring_rules.json is a dict with key "scoring_rules"
        rules_list = raw.get("scoring_rules", []) if isinstance(raw, dict) else raw

        existing = load_existing_enriched(enriched_scoring_path)
        enriched = []
        for idx_r, rule in enumerate(rules_list):
            rule_id = rule.get("id") or idx_r
            rule_name = rule.get("activity", f"Rule {idx_r}")[:60]
            source_fields = {
                "id": rule_id, "activity": rule.get("activity", ""), "score": rule.get("score", ""),
                "category": rule.get("category", ""), "notes": rule.get("notes", ""),
            }
            if rule_id in existing:
                ex = existing[rule_id]
                if ex.get("edited") and not force:
                    enriched.append({**source_fields, "description": ex.get("description", ""), "edited": True, "generated_at": ex.get("generated_at", "")})
                    continue
                elif skip_existing and not ex.get("edited"):
                    enriched.append({**source_fields, "description": ex.get("description", ""), "edited": False, "generated_at": ex.get("generated_at", "")})
                    continue
            print(f"   ▶  {rule_name}...", end=" ", flush=True)
            try:
                desc = extract_scoring_rule_description(rule)
                print("✅")
            except Exception as e:
                print(f"❌ ({e})")
                desc = "Error extracting description."
            enriched.append({**source_fields, "description": desc, "edited": False, "generated_at": datetime.now().isoformat()})
        with open(enriched_scoring_path, "w") as f:
            json.dump(enriched, f, indent=2, ensure_ascii=False)
        print(f"   ✅ Saved: {enriched_scoring_path}")
        csv_path = enriched_dir / "scoring_rules_enriched.csv"
        export_scoring_rules_to_csv(enriched_scoring_path, csv_path)
        print(f"   ✅ Saved: {csv_path}")

    # ─────────────────────────────────────────────────────────────────────────
    # 11. Landing Pages
    # ─────────────────────────────────────────────────────────────────────────

    print("\n🔄 Enriching Landing Pages...")
    _enrich_generic(
        source_path=output_dir / "pardot_landing_pages.json",
        enriched_path=enriched_dir / "landing_pages_enriched.json",
        csv_path=enriched_dir / "landing_pages_enriched.csv",
        id_field="id",
        name_field="name",
        source_fields_fn=lambda r: {
            "id": r.get("id"), "name": r.get("name", ""), "status": r.get("status", ""),
            "campaign": r.get("campaign", ""), "form": r.get("form", ""),
            "url": r.get("url", ""), "folder": r.get("folder", ""),
        },
        extract_fn=extract_landing_page_description,
        export_fn=export_landing_pages_to_csv,
        skip_existing=skip_existing, force=force,
    )

    print("\n" + "=" * 50)
    print("✅ Enrichment complete.")


def main():
    parser = argparse.ArgumentParser(
        description="Enrich automation data with rule-extracted plain-language descriptions."
    )
    parser.add_argument(
        "--org", metavar="NAME",
        help="Org config to use (e.g. 'globex'). Overrides .active-org for this run only.",
    )
    parser.add_argument(
        "--skip-existing", action="store_true",
        help="Skip items with edited=false (avoids unnecessary reprocessing).",
    )
    parser.add_argument(
        "--force", action="store_true",
        help="Regenerate everything, even user-edited items.",
    )
    args = parser.parse_args()

    org = utils.load_org_config(args.org)
    print(f"🌐 Org: {org}")

    enrich_automations(org, skip_existing=args.skip_existing, force=args.force)


if __name__ == "__main__":
    main()
