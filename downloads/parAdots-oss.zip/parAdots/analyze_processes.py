#!/usr/bin/env python3
"""
analyze_processes.py — Newsletter-Prozess-Erkennung für parAdots

Erkennt DOI-Newsletter-Anmeldeprozesse in einer Pardot-Org anhand von
Keyword-Matching + CA-Semantik + Component-Tracing.

DOI-Mechanismen:
  cr_based   — DOI-Bestätigung via Custom Redirect (Acme/Globex-Muster)
  fh_based   — DOI-Bestätigung via zweiten Form Handler / DOIKlick (Umbrella-Muster)
  soi_only   — Kein Double-Opt-In erkannt
  unknown    — DOI-E-Mail vorhanden, Bestätigungsmechanismus unklar

Usage:
    python3 analyze_processes.py [org]         # analysiert org (default: aktive Org)
    python3 analyze_processes.py --all          # alle Orgs
    python3 analyze_processes.py globex --json # JSON-Ausgabe
"""

import json
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

BASE = Path(__file__).parent

# ─── Keyword-Sets ────────────────────────────────────────────────────────────

NL_CAMPAIGN_KEYWORDS = {
    'newsletter', 'nl ', 'anmeldung', 'anmeld', 'subscribe',
    'optin', 'opt-in', 'consent', 'doi', 'double opt',
}
NL_FOLDER_KEYWORDS   = {'newsletter', 'anmeld', 'opt-in', 'consent', 'doi'}
NL_NAME_KEYWORDS     = {'newsletter', 'unternehmens-nl', 'anmeldung', 'anmelde',
                        'subscribe', 'opt-in', 'optin', 'presse-nl', 'wohnungswirtschaft'}

STAGING_LIST_KEYWORDS    = {'opt-in request', 'staging', 'not confirmed', 'waiting'}
SUBSCRIBER_LIST_KEYWORDS = {'newsletter', 'nl ', 'verteiler', 'subscriber', 'empfänger'}
CONFIRM_CR_KEYWORDS      = {'confirm', 'consent', 'optin', 'bestätig', 'double opt'}
UNSUBSCRIBE_CR_KEYWORDS  = {'unsubscribe', 'abmeld', 'optout', 'opt-out', 'abmelde', 'austrag'}
DOI_EMAIL_KEYWORDS       = {'consent', 'opt-in', 'optin', 'confirmation', 'bestätig', 'confirm', 'request'}

# Name-basierte Erkennung von DOI-Bestätigungs-FHs (auch naive Admin-Konfigurationen)
# Positiv: klingt nach Bestätigung / DOI-Klick
FH_CONFIRM_NAME_KEYWORDS = {
    'confirm', 'bestätig', 'bestätigung', 'doi-klick', 'doiclick', 'doi klick',
    'doi confirm', 'doppelopt', 'double opt confirm', 'opt-in confirm',
    'fh-link.*confirm', 'fh-link.*bestätig',
}
# Negativ: klingt nach Einstieg/Anmeldung — schließt echte Entry-FHs aus
FH_ENTRY_NAME_EXCLUSIONS = {
    'request', 'anmeld', 'subscribe', 'anmeldung', 'sign-up', 'signup',
    'whitepaper', 'download', 'kontakt', 'contact', 'portal',
}

OPTOUT_FH_KEYWORDS  = {'unsubscribe', 'abmeld', 'opt-out', 'optout', 'fh-link.*unsub', 'austrag'}
OPTOUT_CR_KEYWORDS  = {'unsubscribe', 'abmeld', 'opt-out', 'optout', 'abmelde', 'austrag', 'presse.*abmeld'}
OPTOUT_AR_KEYWORDS  = {'optout if requested', 'opt.*out.*request', 'abmeld', 'unsubscribe',
                       'hardbounce', 'hard bounce', 'blockbounce', 'global opt'}
OPTOUT_ES_KEYWORDS  = {'global opt out', 'hardbounce', 'hard bounce', 'blockbounce', 'opt.*out.*handhabung'}

BRAND_CODES = ['ACM', 'GLB', 'INI', 'UMB', 'HOO', 'CON']

# ─── Kampagnenprozess-Erkennung ───────────────────────────────────────────────

# Schlüsselwörter für Re-Engagement / Reaktivierungs-Prozesse
REENG_KEYWORDS = {
    're-engage', 're-eng', 'reengag', 'inaktiv', 'inactiv',
    'win-back', 'winback', 'reaktiv', 'reactivat', 'dormant',
    'schlumm', 'wiedergewin', 'never active', 'nie aktiv',
    'mehr als', 'more than', 'inactive',
}

# Einmalläufer-Ausschluss: Bereinigung, Import, Datenpflege
ONETIME_EXCLUSION_KEYWORDS = {
    'bereinig', 'cleanup', 'data clean', 'import', 'migration',
    'backfill', 'datenpflege', 'data enrich', 'datenanreicher',
    'einmalig', 'run once', 'runonce', 'bulk update', 'massenupdate',
    'manuelle', 'manuell', 'test import', 'testlauf',
}

# Kampagnentypen-Mapping: Keyword → process_type + Label
CAMPAIGN_TYPE_MAP = {
    # Re-Engagement
    're-engage':    ('reengagement', 'Re-Engagement'),
    're-eng':       ('reengagement', 'Re-Engagement'),
    'reengag':      ('reengagement', 'Re-Engagement'),
    'inaktiv':      ('reengagement', 'Re-Engagement'),
    'inactiv':      ('reengagement', 'Re-Engagement'),
    'win-back':     ('reengagement', 'Re-Engagement'),
    'winback':      ('reengagement', 'Re-Engagement'),
    'reaktiv':      ('reengagement', 'Re-Engagement'),
    'reactivat':    ('reengagement', 'Re-Engagement'),
    'dormant':      ('reengagement', 'Re-Engagement'),
    'schlumm':      ('reengagement', 'Re-Engagement'),
    'wiedergewin':  ('reengagement', 'Re-Engagement'),
    'never active': ('reengagement', 'Re-Engagement'),
    'nie aktiv':    ('reengagement', 'Re-Engagement'),
    'inactive':     ('reengagement', 'Re-Engagement'),
    'mehr als':     ('reengagement', 'Re-Engagement'),
    'more than':    ('reengagement', 'Re-Engagement'),
}

# Landing-Page-Klassifikation: Preference/Unsubscribe/Confirm-Seiten
LP_UNSUBSCRIBE_KEYWORDS = {
    'unsubscrib', 'abmeld', 'optout', 'opt-out', 'abgemeldet',
    'unsubscribed', 'opted out', 'opted-out',
}
LP_PREFERENCE_KEYWORDS = {
    'prefer', 'preference', 'subscription center', 'email setting',
    'email preference', 'manage email', 'manage subscription', 'pref center',
    'einstellungen', 'präferenz', 'verwaltung',
}
LP_SIGNUP_CONFIRM_KEYWORDS = {
    'thank', 'danke', 'success', 'confirmed', 'angemeldet', 'bestätigt',
    'welcome', 'registered', 'subscribed', 'anmeldung', 'confirmation',
    'confirm',
}

def _lp_role(name: str):
    """Klassifiziert eine Landing Page als unsubscribe_confirm / preference_page / signup_confirm oder None."""
    nl = name.lower()
    if matches_any(nl, LP_UNSUBSCRIBE_KEYWORDS):
        return 'unsubscribe_confirm'
    if matches_any(nl, LP_PREFERENCE_KEYWORDS):
        return 'preference_page'
    if matches_any(nl, LP_SIGNUP_CONFIRM_KEYWORDS):
        return 'signup_confirm'
    return None

def _match_lps_to_process(lps: list, brand: str, market: str,
                           roles: tuple = ('unsubscribe_confirm', 'preference_page', 'signup_confirm')) -> list:
    """
    Gibt Landing-Page-Komponenten zurück, die zu Brand+Market passen.
    Matching-Logik:
      1. LP-Rolle muss in `roles` sein
      2. Market-Code im LP-Namen (oder market=='UNKNOWN')
      3. Brand-Token im LP-Namen (oder kein Brand detektierbar)
    """
    result = []
    market_u = market.upper()
    market_variants = [market_u, market_u.replace('-', '_'), market_u.split('-')[0]]  # DE-DE → DE-DE, DE_DE, DE

    for lp in lps:
        name = s(lp.get('name', ''))
        role = _lp_role(name)
        if role not in roles:
            continue
        name_u = name.upper()
        # Market-Match
        if market != 'UNKNOWN':
            if not any(mv in name_u for mv in market_variants):
                continue
        # Brand-Match (nur wenn Brand bekannt)
        if brand and brand != 'UNKNOWN':
            # Akzeptiere wenn Brand-Token im Namen ODER kein anderer Brand-Token erkennbar
            brand_in_name = brand.upper() in name_u
            # Großzügig: wenn Brand nicht im Namen, aber kein anderer Brand-Hinweis → trotzdem nehmen
            # (z.B. "Newsletter Unsubscribed - DE" ohne Brand-Token)
        comp = _make_component('landing_page', lp)
        comp['role']      = role
        comp['found_via'] = 'name'
        result.append(comp)
    return result

# Versions-Suffix-Erkennung in FH-Namen: "ACM DE-DE II", "ACM DE-DE NEU", usw.
_VERSION_SUFFIX_RE = re.compile(
    r'[\s_-]+(II|III|IV|V|2|3|4|NEU|NEW|V2|V3|V4)\s*$',
    re.IGNORECASE
)

def _fh_version_key(name: str) -> str:
    """Gibt Versions-Suffix aus FH-Namen zurück, oder '' für Basisversion."""
    m = _VERSION_SUFFIX_RE.search(name)
    return m.group(1).upper() if m else ''


# Zulässige Sprach-/Länder-Codes für Market-Erkennung (zweiter Teil)
# Filtert falsche Treffer wie NL-BU (BU = Business Unit) heraus
KNOWN_MARKET_LANG_CODES = {
    'DE', 'CS', 'NL', 'FR', 'PL', 'SK', 'RO', 'PT', 'EN', 'IT', 'ES', 'SV',
    'HU', 'DA', 'FI', 'NO', 'RU', 'UK', 'TR', 'AR', 'ZH', 'JA', 'KO',
}

# Optin-Feld-Klassifikation: welche Feldnamen und -werte deuten auf SOI/DOI hin
OPTIN_FIELD_KEYWORDS = {'optin', 'opt-in', 'dsgvo', 'consent', 'einwillig', 'gdpr', 'soi', 'doi datum', 'doi einwillig'}
SOI_VALUE_KEYWORDS   = {'versendet', 'sent', 'request', 'pending', 'e-mail versendet', 'soi'}
DOI_VALUE_KEYWORDS   = {'bestätigt', 'confirmed', 'bestaetig', 'double', 'e-mail bestätigt', 'doi'}

# Brand-Override für Orgs ohne Standard-Brand-Codes in Asset-Namen
ORG_BRAND_OVERRIDE = {
    'umbrella': 'UMB',
}

# Sub-Brand-Token-Mapping für Multi-Brand-Orgs
# Schlüssel = org-Name (lower), Wert = dict {Token_im_Namen: Brand-Code}
# detect_brand verwendet dieses Mapping wenn kein BRAND_CODES-Treffer gefunden
ORG_SUB_BRAND_TOKENS: dict[str, dict[str, str]] = {
    'example-multibrand': {
        'brand-one':   'BR1',
        'brand-two':   'BR2',
        'brand-three': 'BR3',
    },
    'globex': {
        'acme':   'ACM',
        'globex': 'GLB',
        'initech':  'INI',
        'acme ': 'ACM',  # mit Leerzeichen (Abgrenzung von "acme" in Komposita)
    },
}

# Signup-relevante Automation-Rule-Keywords (nicht Opt-out)
NL_AR_SIGNUP_KEYWORDS = {
    'newsletter', 'anmeld', 'subscribe', 'optin', 'opt-in', 'consent',
    'doi', 'double opt', 'soi', 'bestätigung', 'confirmation',
}

# Subscriber-List-Kriterien in List-Beschreibungen (dynamische Listen)
DYNAMIC_SUBSCRIBER_KEYWORDS = {
    'optin double', 'opt-in confirmed', 'bestätigt', 'confirmed', 'doi',
    'einwillig', 'newsletter subscriber', 'empfänger',
}

# ─── Market-Matching-Helfer ───────────────────────────────────────────────────
# Erkennt vollständige Market-Codes (XX-XX) und Brand-Region-Suffixe (-XX)
_FULL_MARKET_CODE_RE  = re.compile(r'(?<![A-Z])([A-Z]{2}[-_][A-Z]{2})(?![A-Z])')  # Bindestrich ODER Unterstrich
_REGION_SUFFIX_RE     = re.compile(r'[-_]\s*([A-Z]{2})(?![A-Z\-_])')  # Bindestrich ODER Unterstrich nach "-"/"_"


def _name_market_ok(name_u: str, market_u: str) -> bool:
    """
    Prüft ob ein Asset-Name mit einem Market-Code kompatibel ist.

    Regeln (in Priorität):
      1. Direkttreffer: market_u als eigenständiger Token im Namen → True
      2. Name enthält vollständige Market-Codes (XX-XX): nur True wenn market_u dabei
      3. Name enthält Brand-Region-Suffix (-XX, z.B. '-CH' in 'GLB-CH'):
         nur True wenn XX Teil des market_u ist (z.B. 'CH' in 'CH-DE')
      4. Kein Market-/Region-Code erkennbar → True (brand-only Asset)

    Verhindert falsche Treffer wie:
      - 'AT' in 'CONFIRMATION' / 'WAITING' (market_lang-Substring-Problem)
      - 'DE' in 'CH-DE' (market_country-Substring-Problem)
      - 'GLB-CH' als brand-only → gehört nur in CH-Markets
    """
    # 1. Direkttreffer (eigenständiger Code)
    if re.search(r'(?<![A-Z])' + re.escape(market_u) + r'(?![A-Z])', name_u):
        return True

    # 2. Vollständige Market-Codes im Namen prüfen
    full_codes = set(_FULL_MARKET_CODE_RE.findall(name_u))
    if full_codes:
        return market_u in full_codes

    # 3. Brand-Region-Suffix (z.B. 'GLB-CH', 'INI-CH')
    market_parts = set(market_u.split('-'))          # {'AT','DE'} für 'AT-DE'
    region_codes = set(_REGION_SUFFIX_RE.findall(name_u))
    if region_codes:
        return bool(region_codes & market_parts)

    # 4. Kein Code → brand-only → immer kompatibel
    return True


# ─── Loaders ─────────────────────────────────────────────────────────────────

def load_json(org: str, fname: str) -> list:
    """Lädt enriched JSON wenn vorhanden, sonst raw JSON."""
    enriched = BASE / 'output' / org / 'enriched' / f'{fname}_enriched.json'
    raw      = BASE / 'output' / org / f'pardot_{fname}.json'
    for p in (enriched, raw):
        if p.exists():
            try:
                data = json.loads(p.read_text(encoding='utf-8'))
                return data if isinstance(data, list) else []
            except Exception:
                pass
    return []


def load_all(org: str) -> dict:
    """Lädt alle relevanten Asset-Typen für eine Org."""
    return {
        'formhandlers':      load_json(org, 'formhandlers'),
        'forms':             load_json(org, 'forms'),
        'static_lists':      load_json(org, 'static_lists'),
        'dynamic_lists':     load_json(org, 'dynamic_lists'),
        'engagement_studio': load_json(org, 'engagement_studio'),
        'email_templates':   load_json(org, 'email_templates'),
        'custom_redirects':  load_json(org, 'custom_redirects'),
        'automation_rules':  load_json(org, 'automation_rules'),
        'campaigns':         load_json(org, 'campaigns'),
        'fields':            load_fields(org),
        'scoring_rules':     load_json(org, 'scoring_rules'),
        'landing_pages':     load_json(org, 'landing_pages'),
    }


def load_fields(org: str) -> list:
    """Lädt pardot_fields.json und flacht auf Prospect-Felder ab."""
    raw = BASE / 'output' / org / 'pardot_fields.json'
    if not raw.exists():
        return []
    try:
        data = json.loads(raw.read_text(encoding='utf-8'))
        if isinstance(data, list):
            # Strukturiert: [{object: 'Prospect', fields: [...]}]
            for obj in data:
                if isinstance(obj, dict) and obj.get('object') == 'Prospect':
                    return obj.get('fields', [])
        return []
    except Exception:
        return []

# ─── Helpers ─────────────────────────────────────────────────────────────────

def s(v) -> str:
    return str(v or '').strip()


def matches_any(text: str, keywords: set) -> bool:
    t = text.lower()
    return any(k in t for k in keywords)


def extract_domain(url: str) -> str:
    try:
        host = urlparse(url).hostname or ''
        host = re.sub(r'^(www|campaign|tracking|go|info)\.', '', host)
        return host
    except Exception:
        return ''


def detect_brand(text: str, folder: str = '', campaign: str = '',
                  sub_brand_tokens: dict = None) -> str:
    """
    Erkennt Brand-Code (ACM/GLB/INI/UMB/…) aus Text.
    Verwendet Wortgrenzen um Falsch-Positive wie 'INI' in 'PROD' zu vermeiden.
    Bei Multi-Brand-Orgs: sub_brand_tokens={token: code} für Langtext-Erkennung.
    """
    combined = f"{text} {folder} {campaign}".upper()
    for code in BRAND_CODES:
        if re.search(r'(?<![A-Z])' + code + r'(?![A-Z])', combined):
            return code
    if sub_brand_tokens:
        combined_lower = combined.lower()
        for token, code in sub_brand_tokens.items():
            if token.lower() in combined_lower:
                return code
    return ''


def detect_market(text: str, completion_actions: list = None) -> str:
    """
    Extrahiert Marktkennung (z.B. DE-DE, CZ-CS, AT-DE) aus Text oder Completion Actions.
    Unterstützt sowohl Bindestriche (DE-DE) als auch Unterstriche (DE_de → DE-DE).
    """
    # aus Completion Actions: 'Change prospect custom field value: Country-Language to XX-XX'
    if completion_actions:
        for ca in completion_actions:
            m = re.search(r'Country-Language\s+to\s+([A-Z]{2}-[A-Z]{2})', ca, re.IGNORECASE)
            if m:
                return m.group(1).upper()
    # aus Text: XX-XX oder XX_XX (z.B. "Newsletter_DE_de_FormHandler" → DE-DE)
    # Verwende negative Lookahead/-behind statt \b (Underscore ist in Regex ein Wortzeichen)
    # Zweiter Teil muss ein bekannter Sprach-Code sein (filtert NL_BU, NL_BU1 etc. heraus)
    for m in re.finditer(r'(?<![A-Z])([A-Z]{2})[_-]([A-Z]{2})(?![A-Z])', text.upper()):
        if m.group(2) in KNOWN_MARKET_LANG_CODES:
            return f"{m.group(1)}-{m.group(2)}"
    return ''


def _classify_optin_field(field_name: str, field_value: str):
    """
    Klassifiziert eine Feldwert-Änderung als SOI- oder DOI-Marker.
    Returns: 'soi' | 'doi' | None
    """
    fn = field_name.lower()
    fv = field_value.lower()
    # DOI-Marker: Feldname enthält "doi" oder Wert enthält DOI-Keywords
    if 'doi' in fn or any(k in fv for k in DOI_VALUE_KEYWORDS):
        return 'doi'
    # SOI-Marker: Feldname enthält "soi" oder Wert enthält SOI-Keywords
    if 'soi' in fn or any(k in fv for k in SOI_VALUE_KEYWORDS):
        return 'soi'
    # Allgemeines Optin-Feld
    if any(k in fn for k in OPTIN_FIELD_KEYWORDS):
        if any(k in fv for k in DOI_VALUE_KEYWORDS):
            return 'doi'
        if any(k in fv for k in SOI_VALUE_KEYWORDS):
            return 'soi'
        # Trigger-Boolean-Felder: value='true', Semantik steckt im Feldnamen
        # z.B. "Trigger Optin Double Confirmed ACM to true" → doi
        # z.B. "Trigger Optin Double Request ACM to true"   → soi
        # Reihenfolge: request/soi vor confirm/double (beide könnten im Namen sein)
        if fv == 'true':
            if any(k in fn for k in ('request', 'anmeld')):
                return 'soi'
            if any(k in fn for k in ('confirm', 'bestätig', 'double')):
                return 'doi'
    return None


def parse_completion_actions(actions: list) -> dict:
    """Extrahiert strukturierte Infos aus Completion-Actions-Texten."""
    result = {
        'add_to_lists':       [],   # Listen, zu denen hinzugefügt wird
        'remove_from_lists':  [],   # Listen, aus denen entfernt wird (z.B. Opt-out-ARs)
        'autoresponder_emails': [],  # Autoresponder-E-Mail-Namen
        'optin_fields':       [],   # gesetzte Optin-Custom-Fields (für Rückwärtskompatibilität)
        'soi_field_changes':  [],   # {'field': str, 'value': str} — SOI-Marker
        'doi_field_changes':  [],   # {'field': str, 'value': str} — DOI-Marker
        'do_not_email_false': False,
        'do_not_email_true':  False,
    }
    for ca in (actions or []):
        ca_l = ca.lower()
        # Add to list: <Name>
        m = re.match(r'add\s+(?:prospect\s+)?to\s+list:\s*(.+)', ca, re.IGNORECASE)
        if m:
            result['add_to_lists'].append(m.group(1).strip())
            continue

        # Remove from list: <Name>
        m = re.match(r'remove\s+(?:prospect\s+)?from\s+list:\s*(.+)', ca, re.IGNORECASE)
        if m:
            result['remove_from_lists'].append(m.group(1).strip())
            continue

        # Send autoresponder email: <Name>
        m = re.match(r'send\s+autoresponder\s+email:\s*(.+)', ca, re.IGNORECASE)
        if m:
            result['autoresponder_emails'].append(m.group(1).strip())
            continue

        # Change prospect custom field value: <Field> to <Value>
        m = re.match(r'change\s+prospect\s+custom\s+field\s+value:\s+(.+?)\s+to\s+(.+)', ca, re.IGNORECASE)
        if m:
            field_name  = m.group(1).strip()
            field_value = m.group(2).strip()
            classification = _classify_optin_field(field_name, field_value)
            if classification == 'soi':
                result['soi_field_changes'].append({'field': field_name, 'value': field_value})
                result['optin_fields'].append(field_name)
            elif classification == 'doi':
                result['doi_field_changes'].append({'field': field_name, 'value': field_value})
                result['optin_fields'].append(field_name)

        # Legacy: Optin Double Request * to true (Acme/Globex-Muster)
        if re.search(r'optin.*?request.*?true', ca_l) or re.search(r'double.*?request.*?true', ca_l):
            m2 = re.search(r'field value:\s*(.+?)\s+to\s+true', ca, re.IGNORECASE)
            if m2:
                field = m2.group(1).strip()
                if field not in result['optin_fields']:
                    result['optin_fields'].append(field)
                result['soi_field_changes'].append({'field': field, 'value': 'true'})

        # Do not email = false (Opt-in)
        if 'do not email' in ca_l and 'false' in ca_l:
            result['do_not_email_false'] = True

        # Do not email = true (Opt-out)
        if 'do not email' in ca_l and 'true' in ca_l:
            result['do_not_email_true'] = True

    return result


def _aggregate_cas(assets: list) -> dict:
    """Aggregiert Completion-Actions über mehrere Assets (FHs oder ARs)."""
    result = {
        'add_to_lists': [], 'remove_from_lists': [], 'autoresponder_emails': [],
        'optin_fields': [], 'soi_field_changes': [], 'doi_field_changes': [],
        'do_not_email_false': False, 'do_not_email_true': False,
    }
    for asset in assets:
        parsed = parse_completion_actions(asset.get('completion_actions', []))
        result['add_to_lists']        += parsed['add_to_lists']
        result['remove_from_lists']   += parsed['remove_from_lists']
        result['autoresponder_emails'] += parsed['autoresponder_emails']
        result['optin_fields']         += parsed['optin_fields']
        result['soi_field_changes']    += parsed['soi_field_changes']
        result['doi_field_changes']    += parsed['doi_field_changes']
        if parsed['do_not_email_false']:
            result['do_not_email_false'] = True
        if parsed['do_not_email_true']:
            result['do_not_email_true'] = True
    # Deduplizieren
    for k in ('add_to_lists', 'remove_from_lists', 'autoresponder_emails', 'optin_fields'):
        result[k] = list(dict.fromkeys(result[k]))
    return result


def _find_lists_from_ar_actions(ars: list, all_lists: list,
                                role_add: str = 'subscriber',
                                role_remove: str = 'subscriber') -> list:
    """
    Findet Listen die in AR-Completion-Actions referenziert werden.
    Durchsucht sowohl 'add to list' als auch 'remove from list' Aktionen.
    Gibt deduplizierte Komponenten zurück.
    """
    found = []
    seen_ids: set = set()
    for ar in ars:
        parsed = parse_completion_actions(ar.get('completion_actions', []))
        for list_name in parsed['add_to_lists']:
            item = fuzzy_name_match(list_name, all_lists)
            if item:
                lid = str(item.get('id', ''))
                if lid not in seen_ids:
                    seen_ids.add(lid)
                    comp = _make_component('list', item)
                    comp['role']      = role_add
                    comp['found_via'] = 'ca'
                    found.append(comp)
        for list_name in parsed['remove_from_lists']:
            item = fuzzy_name_match(list_name, all_lists)
            if item:
                lid = str(item.get('id', ''))
                if lid not in seen_ids:
                    seen_ids.add(lid)
                    comp = _make_component('list', item)
                    comp['role']      = role_remove
                    comp['found_via'] = 'ca'
                    found.append(comp)
    return found


def classify_fh_optin_role(fh: dict):
    """
    Klassifiziert einen Form Handler nach Opt-in-Rolle.

    Erkennungswege (in Priorität):
      1. CA-basiert: DOI-Feld gesetzt + Liste hinzugefügt
      2. Trigger-basiert: DOI-Trigger-Feld gesetzt (→ AR übernimmt Folgeaktion)
      3. SOI-basiert: Autoresponder-E-Mail oder SOI-Feld
      4. Name-basiert: Bestätigungs-Keywords im Namen, keine Entry-Keywords (naive Admin)

    Returns:
        'doi_confirm'        — DOI-Bestätigung (CA-basiert, trigger-basiert oder name-basiert)
        'doi_confirm_name'   — DOI-Bestätigung nur per Name-Heuristik (schwaches Signal)
        'soi_entry'          — SOI-Einstieg
        None                 — keine eindeutige Opt-in-Rolle
    """
    parsed = parse_completion_actions(fh.get('completion_actions', []))
    has_doi_field     = bool(parsed['doi_field_changes'])
    has_soi_field     = bool(parsed['soi_field_changes'])
    has_list_add      = bool(parsed['add_to_lists'])
    has_autoresponder = bool(parsed['autoresponder_emails'])

    # 1. DOI-Bestätigung: setzt DOI-Feld + fügt zu Liste hinzu
    if has_doi_field and has_list_add:
        return 'doi_confirm'

    # 2. Trigger-basierter DOI-Confirm: setzt DOI-Trigger-Feld (→ AR folgt)
    #    "Trigger Optin Double Confirmed X to true" — kein direktes list_add
    if has_doi_field and not has_list_add and not has_autoresponder:
        return 'doi_confirm'

    # 3. SOI-Einstieg: sendet DOI-Autoresponder (E-Mail) oder setzt SOI-Feld
    if has_autoresponder or has_soi_field:
        return 'soi_entry'

    # 4. Name-Heuristik: FH klingt nach Bestätigung, keine Entry-Signale im Namen
    #    Berücksichtigt naive Admin-Konfigurationen ohne korrekte CAs
    name = s(fh.get('name', '')).lower()
    is_confirm_name = matches_any(name, FH_CONFIRM_NAME_KEYWORDS)
    is_entry_name   = matches_any(name, FH_ENTRY_NAME_EXCLUSIONS)
    is_optout_name  = matches_any(name, OPTOUT_FH_KEYWORDS)
    if is_confirm_name and not is_entry_name and not is_optout_name:
        return 'doi_confirm_name'

    return None


def is_doi_confirm_role(role) -> bool:
    """Prüft ob eine FH-Rolle als DOI-Bestätigung gilt (inkl. name-basierter Heuristik)."""
    return role in ('doi_confirm', 'doi_confirm_name')


def is_nl_form(form: dict) -> bool:
    """Erkennt Pardot-Formulare (native Forms) als Newsletter-Einstiegspunkte."""
    name   = s(form.get('name', ''))
    folder = s(form.get('folder', ''))
    return matches_any(f"{name} {folder}", NL_NAME_KEYWORDS | NL_FOLDER_KEYWORDS | NL_CAMPAIGN_KEYWORDS)


def find_nl_forms(brand: str, market: str, forms: list) -> list:
    """Findet Pardot-Formulare mit Newsletter-Bezug für einen Prozess."""
    found = []
    brand_u  = brand.upper()
    market_u = market.upper()
    for form in forms:
        if not is_nl_form(form):
            continue
        name = s(form.get('name', ''))
        if brand_u and brand_u not in name.upper():
            continue
        # Market-Match (optional — Forms haben oft keinen Market im Namen)
        if market_u and not _name_market_ok(name.upper(), market_u):
            continue
        comp = _make_component('form', form)
        found.append(comp)
    return found


def find_signup_ars(brand: str, market: str, ars: list) -> list:
    """
    Findet Automation Rules, die Teil des Newsletter-Anmeldeprozesses sind
    (keine Opt-out-ARs, sondern Signup-/SOI-/DOI-ARs).
    """
    found = []
    brand_u  = brand.upper()
    market_u = market.upper()
    for ar in ars:
        name = s(ar.get('name', ar.get('Rule Name', '')))
        if is_optout_ar(ar):  # Opt-out ARs explizit ausschließen
            continue
        if not matches_any(name, NL_AR_SIGNUP_KEYWORDS):
            continue
        if brand_u and brand_u not in name.upper():
            continue
        if market_u and not _name_market_ok(name.upper(), market_u):
            continue
        comp = _make_component('automation_rule', ar)
        comp['found_via'] = 'name'
        comp['role']      = 'signup'
        found.append(comp)
    return found


def _ar_actions_text(ar: dict) -> str:
    """Extrahiert Aktions-Text aus AR, egal ob sections.actions oder completion_actions."""
    secs = ar.get('sections', {})
    if isinstance(secs, dict):
        return s(secs.get('actions', ''))
    return ' '.join(s(a) for a in ar.get('completion_actions', []))


def _ar_sets_doi_field(ar: dict) -> bool:
    """
    Prüft ob AR-Aktionen ein DOI/Optin-Feld auf confirmed/bestätigt setzen.
    Erkennt Text-Patterns wie: 'Optin Double GLB to true' oder 'DSGVO Opt-In Status to E-Mail bestätigt'.
    """
    actions = _ar_actions_text(ar).lower()
    for kw in DOI_VALUE_KEYWORDS:   # bestätigt, confirmed, doi, double, ...
        if kw in actions:
            # Muss auch ein optin-Feldname dabei sein
            for fkw in OPTIN_FIELD_KEYWORDS:
                if fkw in actions:
                    return True
    # Auch "Optin Double X to 'true'" erkennen (Timestamp-Feld oder direkte Freischaltung)
    if re.search(r'optin\s+double\b.*?\bto\s+[\'"]?true', actions):
        return True
    return False


def find_doi_confirm_ars(brand: str, market: str, ars: list) -> list:
    """
    Findet ARs, die als DOI-Bestätigungsmechanismus wirken.
    Zwei Wege:
    1. Name enthält Bestätigungs-Keywords (z.B. "Optin Double if confirmed")
    2. Aktions-Text setzt ein DOI-Feld auf true/bestätigt
    """
    found = []
    brand_u = brand.upper()
    confirm_kw = {'doi confirm', 'optin confirm', 'bestätigt', 'double opt confirm',
                  'consent confirm', 'nl confirm', 'if confirmed', 'optin double if',
                  'doi if', 'set doi', 'doi true'}
    for ar in ars:
        name = s(ar.get('name', ar.get('Rule Name', '')))
        if is_optout_ar(ar):
            continue
        name_match = matches_any(name, confirm_kw)
        action_match = _ar_sets_doi_field(ar)
        if not (name_match or action_match):
            continue
        if brand_u and brand_u not in name.upper():
            continue
        if market and not _name_market_ok(name.upper(), market.upper()):
            continue
        comp = _make_component('automation_rule', ar)
        comp['role']      = 'doi_confirm'
        comp['found_via'] = 'name'
        found.append(comp)
    return found


def find_dynamic_subscriber_lists(brand: str, market: str, dl: list) -> list:
    """
    Findet dynamische Listen mit Optin-Kriterien in Beschreibung als Subscriber-Listen.
    Ergänzt die rein keyword-basierte Suche in find_subscriber_lists().
    """
    found = []
    brand_u  = brand.upper()
    market_u = market.upper()
    for lst in dl:
        name = s(lst.get('name', ''))
        desc = s(lst.get('description', ''))
        combined = f"{name} {desc}"
        # Muss subscriber- oder optin-bezogen sein
        if not (matches_any(combined, SUBSCRIBER_LIST_KEYWORDS) or
                matches_any(desc, DYNAMIC_SUBSCRIBER_KEYWORDS)):
            continue
        if matches_any(name, STAGING_LIST_KEYWORDS):
            continue
        # Brand-Match
        if brand_u and brand_u not in combined.upper():
            continue
        # Market-Match
        if market_u and not _name_market_ok(combined.upper(), market_u):
            continue
        comp = _make_component('list', lst)
        comp['role'] = 'subscriber'
        found.append(comp)
    return found


def find_doi_trigger_es(brand: str, market: str, es_programs: list, all_lists: list) -> list:
    """
    Findet ES-Programme, die als DOI-Bestätigungs- oder Reminder-Engine wirken.
    Sucht breiter als find_es_programs(): auch ES mit optin/doi-Keywords im Namen.
    """
    found = []
    brand_u  = brand.upper()
    doi_es_kw = {'consent', 'optin', 'opt-in', 'doi', 'confirmation', 'bestätigung', 'double opt', 'newsletter'}
    for es in es_programs:
        name = s(es.get('name', ''))
        desc = s(es.get('description', ''))
        combined = f"{name} {desc}"
        if not matches_any(combined, doi_es_kw):
            continue
        if brand_u and brand_u not in combined.upper():
            continue
        comp = _make_component('es', es)
        found.append(comp)
    return found


def fuzzy_name_match(name: str, items: list, name_field: str = 'name', threshold: int = 3):
    """Findet das am besten passende Item nach Name (exakt, dann enthält)."""
    name_l = name.strip().lower()
    for item in items:
        if s(item.get(name_field, '')).lower() == name_l:
            return item
    for item in items:
        item_name = s(item.get(name_field, '')).lower()
        if name_l in item_name or item_name in name_l:
            return item
    return None

# ─── Process Detection ───────────────────────────────────────────────────────

def is_nl_formhandler(fh: dict) -> bool:
    """
    Prüft ob ein Form Handler zu einem Newsletter-Anmeldeprozess gehört.
    Drei Erkennungswege:
      1. Keyword-Match auf Name/Campaign/Folder
      2. doi_confirm-Rolle via Completion-Actions
      3. soi_entry-Rolle wenn Autoresponder-Email newsletter-bezogen ist
    """
    name     = s(fh.get('name', ''))
    campaign = s(fh.get('campaign', ''))
    folder   = s(fh.get('folder', ''))
    combined = f"{name} {campaign} {folder}"

    # 0. Opt-out-FHs ausschließen — auch wenn Kampagne/Folder NL-Keywords enthält
    if matches_any(name, OPTOUT_FH_KEYWORDS):
        return False

    # 1. Keyword-basiert
    if matches_any(combined, NL_CAMPAIGN_KEYWORDS | NL_FOLDER_KEYWORDS | NL_NAME_KEYWORDS):
        return True

    # 2+3+4. Optin-Rolle via Completion-Actions oder Name-Heuristik
    role = classify_fh_optin_role(fh)
    if is_doi_confirm_role(role):
        # DOI-Bestätigungs-FH (inkl. name-basierte Heuristik) ist immer newsletter-relevant
        return True
    if role == 'soi_entry':
        # SOI nur wenn Autoresponder-Email einen Newsletter-Bezug hat
        parsed = parse_completion_actions(fh.get('completion_actions', []))
        for email_name in parsed['autoresponder_emails']:
            if matches_any(email_name, NL_CAMPAIGN_KEYWORDS | NL_NAME_KEYWORDS):
                return True

    return False


def _fh_prospect_count(fh: dict) -> int:
    """Gibt den Prospect Count eines FH als int zurück (0 wenn leer/unbekannt)."""
    v = s(fh.get('prospect_count', ''))
    try:
        return int(v)
    except (ValueError, TypeError):
        return 0


def _fh_is_uat(fh: dict) -> bool:
    """True wenn der FH eine UAT/Test-Instanz ist (nie in echte Prozesse mergen)."""
    name_u = s(fh.get('name', '')).upper()
    return any(tok in name_u for tok in ('_UAT_', '-UAT-', '_UAT', 'UAT_'))


def _fh_country_tokens(fh: dict) -> set:
    """
    Extrahiert Länder-Token aus dem FH-Namen (z.B. _DE_, _NL_, _BE_NL_).
    Wird verwendet um zu prüfen ob ein UNKNOWN-Market-FH in einen
    bestimmten Market-Prozess passt.
    """
    name = s(fh.get('name', '')).upper()
    # Alle 2-Buchstaben-Großbuchstaben-Sequenzen die von _ oder Wortgrenzen umgeben sind
    import re
    return set(re.findall(r'(?<![A-Z])([A-Z]{2})(?![A-Z])', name))


def _market_tokens(market: str) -> set:
    """Extrahiert Länder-Token aus einem Market-Code (z.B. 'BE-NL' → {'BE','NL'})."""
    return set(t for t in re.split(r'[-_]', market.upper()) if len(t) == 2)


def group_fh_by_process(nl_fhs: list, org_brand: str = '',
                         sub_brand_tokens: dict = None) -> dict:
    """
    Gruppiert Newsletter-FHs nach Prozess (Brand + Market).
    Verwendet org_brand als Fallback wenn kein Brand-Code erkannt.
    Soi-only-Gruppen ohne Market werden selektiv in gleiche-Brand-Gruppen gemerged:
    - UAT-FHs werden nie gemerged
    - FHs mit Länder-Token im Namen werden nur in passende Märkte gemerged
    - FHs ohne Länder-Token (wirklich marktneutral) werden in alle Märkte gemerged
    """
    groups = {}

    for fh in nl_fhs:
        brand = detect_brand(
            s(fh.get('name', '')),
            s(fh.get('folder', '')),
            s(fh.get('campaign', '')),
            sub_brand_tokens=sub_brand_tokens,
        )
        if not brand:
            brand = org_brand or 'UNKNOWN'

        market = detect_market(
            s(fh.get('name', '')),
            fh.get('completion_actions', [])
        )
        key = (brand, market or 'UNKNOWN')
        groups.setdefault(key, []).append(fh)

    # Merge soi-only UNKNOWN-Market-Gruppen selektiv in gleiche-Brand-Gruppen
    to_remove = []
    for (brand, market), fhs in list(groups.items()):
        if market != 'UNKNOWN':
            continue
        # Nur SOI-Entry-FHs in dieser Gruppe? (doi_confirm-Rollen nicht mergen)
        all_soi = all(not is_doi_confirm_role(classify_fh_optin_role(fh)) for fh in fhs)
        if not all_soi:
            continue
        # Suche gleiche-Brand-Gruppen mit bekanntem Market
        same_brand_keys = [(b, m) for (b, m) in groups if b == brand and m != 'UNKNOWN']
        if not same_brand_keys:
            continue

        for fh in fhs:
            # UAT-FHs nie in andere Gruppen mergen
            if _fh_is_uat(fh):
                continue
            fh_ctoks = _fh_country_tokens(fh)
            for target_key in same_brand_keys:
                target_market = target_key[1]
                mt = _market_tokens(target_market)
                # Nur mergen wenn FH-Länder-Token mit Target-Market kompatibel
                # (d.h. FH hat keine Länder-Token ODER mindestens einer passt zum Market)
                if not fh_ctoks or fh_ctoks & mt:
                    if fh not in groups[target_key]:
                        groups[target_key].append(fh)

        to_remove.append((brand, market))

    for key in to_remove:
        del groups[key]

    return groups


def _widen_component_search(proc: dict, brand: str, market: str,
                             soi_fhs: list, doi_conf_fhs: list,
                             sl: list, dl: list, et: list, cr_list: list,
                             forms: list, ars: list, es: list) -> dict:
    """
    Iterative Komponentensuche mit progressiv gelockerten Kriterien.
    Berücksichtigt ALLE möglichen Prozessmuster:
      - Pardot Forms als Einstieg
      - Automation Rules als Signup- oder DOI-Bestätigungsschritt
      - Dynamische Listen mit Optin-Kriterien als Verteiler
      - Breiterer ES-Scan (nicht nur staging-list-verknüpfte Programme)
    Ziel: Score >= 0.80. Stoppt früh wenn erreicht.
    """
    if proc['completeness']['score'] >= 0.80:
        return proc

    doi_mech    = proc['doi_mechanism']
    all_lists   = sl + dl
    soi_parsed  = _aggregate_cas(soi_fhs)
    doi_conf_parsed = _aggregate_cas(doi_conf_fhs)
    found_ids   = {c['id'] for c in proc['components']}
    widened     = False

    def add_new(comp_list) -> list:
        nonlocal widened
        added = []
        for c in comp_list:
            if c.get('id', '') not in found_ids and c.get('id', ''):
                c['search_widened'] = True
                found_ids.add(c['id'])
                added.append(c)
                widened = True
        return added

    def try_extend(extra):
        if extra:
            proc['components'] += extra
            proc['completeness'] = check_completeness(proc)

    # ── Schritt 1: Pardot Forms als Einstiegspunkte ──────────────────────────
    if not any(c['type'] in ('formhandler', 'form') for c in proc['components']):
        extra = add_new(find_nl_forms(brand, market, forms))
        if not extra:
            extra = add_new(find_nl_forms(brand, '', forms))
        try_extend(extra)

    # ── Schritt 2: Signup-ARs als Prozesskomponenten ─────────────────────────
    if proc['completeness']['score'] < 0.80:
        extra = add_new(find_signup_ars(brand, market, ars))
        if not extra:
            extra = add_new(find_signup_ars(brand, '', ars))
        try_extend(extra)

    # ── Schritt 3: DOI-Confirm-ARs als Bestätigungsschritt ───────────────────
    if proc['completeness']['score'] < 0.80:
        extra = add_new(find_doi_confirm_ars(brand, market, ars))
        if not extra:
            extra = add_new(find_doi_confirm_ars(brand, '', ars))
        try_extend(extra)
        # Mechanismus ggf. aktualisieren
        if any(c.get('role') == 'doi_confirm' and c['type'] == 'automation_rule'
               for c in proc['components']):
            if proc['doi_mechanism'] == 'unknown':
                proc['doi_mechanism'] = 'ar_based'
                doi_mech = 'ar_based'

    # ── Schritte 4–6: Brand/Market-Lockerung ─────────────────────────────────
    for b, m in [(brand, ''), ('', market), ('', '')]:
        if proc['completeness']['score'] >= 0.80:
            break
        extra = []

        # Subscriber-Listen (statisch + dynamisch)
        if not any(c.get('role') == 'subscriber' for c in proc['components']):
            subs = _find_subscriber_lists_from_ca(doi_conf_parsed, all_lists)
            if not subs:
                subs = find_subscriber_lists(b, m, dl, sl)
            if not subs:
                subs = find_dynamic_subscriber_lists(b, m, dl)
            extra += add_new(subs)

        # DOI-E-Mails
        if not any(c['type'] == 'email' for c in proc['components']):
            emails = find_doi_emails(b, m, soi_parsed, et)
            extra += add_new(emails)

        # Bestätigungs-CRs
        if doi_mech in ('cr_based', 'unknown', 'ar_based'):
            if not any(c['type'] == 'custom_redirect' for c in proc['components']):
                crs = find_confirmation_crs(b, m, cr_list)
                extra += add_new(crs)

        try_extend(extra)

    # ── Schritt 7: Breiterer ES-Scan ─────────────────────────────────────────
    if proc['completeness']['score'] < 0.80:
        if not any(c['type'] == 'es' for c in proc['components']):
            extra = add_new(find_doi_trigger_es(brand, market, es, all_lists))
            if not extra:
                extra = add_new(find_doi_trigger_es(brand, '', es, all_lists))
            try_extend(extra)

    if widened:
        proc['search_widened'] = True

    # Genuinely incomplete wenn nach allen Lockerungen < 80%
    if proc['completeness']['score'] < 0.80:
        proc['genuine_incomplete'] = True
        proc['completeness']['issues'].append({
            'level': 'info',
            'msg': 'Prozess scheint noch nicht vollständig aufgebaut (Score ≥ 80% nicht erreichbar)'
        })

    return proc


def _find_subscriber_lists_from_ca(parsed_ca: dict, all_lists: list) -> list:
    """Findet Subscriber-Listen aus Completion-Actions (DOI-Confirm-FH-Muster)."""
    found = []
    for list_name in parsed_ca.get('add_to_lists', []):
        item = fuzzy_name_match(list_name, all_lists)
        if item:
            comp = _make_component('list', item)
            comp['role'] = 'subscriber'
            comp['found_via'] = 'ca'
            # Dedup
            if not any(f['id'] == comp['id'] for f in found):
                found.append(comp)
    return found


def find_staging_lists(brand: str, market: str, parsed_ca: dict, static_lists: list, dynamic_lists: list) -> list:
    """Findet Staging-Listen (DOI-Warteschlange) für einen Prozess."""
    found = []
    all_lists = static_lists + dynamic_lists

    # 1. Aus completion_actions (direkt verlinkt — bevorzugt)
    # Nur Listen übernehmen die auch Staging-Keywords enthalten, damit generische
    # Multi-Purpose-FHs (z.B. WebForm_STAGING) keine Content-Download-Listen einschleppen.
    brand_u = brand.upper()
    market_u = market.upper()
    for list_name in parsed_ca.get('add_to_lists', []):
        item = fuzzy_name_match(list_name, all_lists)
        if not item:
            continue
        name = s(item.get('name', ''))
        # Keyword-Filter: muss wie eine Staging-Liste aussehen
        if not matches_any(name, STAGING_LIST_KEYWORDS | SUBSCRIBER_LIST_KEYWORDS):
            continue
        # Market-Filter: wenn ein Markt bekannt ist, muss die Liste passen
        if market_u and not _name_market_ok(name.upper(), market_u):
            continue
        comp = _make_component('list', item)
        comp['found_via'] = 'ca'
        found.append(comp)

    # 2. Keyword-Suche
    for lst in static_lists:
        name = s(lst.get('name', ''))
        if not matches_any(name, STAGING_LIST_KEYWORDS):
            continue
        if brand_u and brand_u not in name.upper():
            continue
        if market_u and not _name_market_ok(name.upper(), market_u):
            continue
        comp = _make_component('list', lst)
        if not any(f['id'] == comp['id'] for f in found):
            found.append(comp)

    return found


def find_doi_emails(brand: str, market: str, parsed_ca: dict, email_templates: list) -> list:
    """Findet DOI-Bestätigungsmails (Autoresponder + Reminder)."""
    found = []
    brand_u  = brand.upper()
    market_u = market.upper()

    # 1. Aus completion_actions (Autoresponder, direkt verlinkt)
    for email_name in parsed_ca.get('autoresponder_emails', []):
        item = fuzzy_name_match(email_name, email_templates)
        if item:
            comp = _make_component('email', item)
            comp['role'] = 'autoresponder'
            comp['found_via'] = 'ca'
            found.append(comp)

    # 2. Keyword-Suche
    for et in email_templates:
        name   = s(et.get('name', ''))
        folder = s(et.get('folder', ''))
        combined = f"{name} {folder}"
        if not matches_any(combined, DOI_EMAIL_KEYWORDS):
            continue
        if brand_u and brand_u not in combined.upper():
            continue
        if market_u and not _name_market_ok(combined.upper(), market_u):
            continue
        comp = _make_component('email', et)
        is_auto = et.get('is_autoresponder_email', False)
        comp['role'] = 'autoresponder' if is_auto else 'reminder'
        if not any(f['id'] == comp['id'] for f in found):
            found.append(comp)

    return found


def find_es_programs(staging_lists: list, es_programs: list) -> list:
    """Findet Engagement Studio Programme, deren Entry List eine Staging-Liste ist."""
    found = []
    staging_names = {c['name'].lower().strip() for c in staging_lists}
    for es in es_programs:
        entry = s(es.get('entry_lists', ''))
        entry_parts = [p.strip().lower() for p in re.split(r'[;,]', entry) if p.strip()]
        for ep in entry_parts:
            for sname in staging_names:
                if ep == sname:
                    comp = _make_component('es', es)
                    comp['found_via'] = 'ca'  # via Staging-Liste verlinkt
                    if not any(f['id'] == comp['id'] for f in found):
                        found.append(comp)
                    break
    return found


def find_confirmation_crs(brand: str, market: str, custom_redirects: list) -> list:
    """Findet Custom Redirects für DOI-Bestätigung."""
    found = []
    brand_u  = brand.upper()
    market_u = market.upper()

    for cr in custom_redirects:
        name     = s(cr.get('name', ''))
        campaign = s(cr.get('campaign', ''))
        folder   = s(cr.get('folder', ''))
        combined = f"{name} {campaign} {folder}"
        if matches_any(combined, UNSUBSCRIBE_CR_KEYWORDS):
            continue
        if not matches_any(combined, CONFIRM_CR_KEYWORDS):
            continue
        if brand_u and brand_u not in combined.upper():
            continue
        if market_u:
            combined_u = combined.upper()
            if not _name_market_ok(combined_u, market_u):
                # Fallback: destination_url prüfen — aber nur Direkttreffer akzeptieren
                # (brand-only URLs dürfen hier nicht als Wildcard gelten)
                dest = s(cr.get('destination_url', ''))
                dest_u = dest.upper()
                if not re.search(r'(?<![A-Z])' + re.escape(market_u) + r'(?![A-Z])', dest_u):
                    continue
        comp = _make_component('custom_redirect', cr)
        comp['domain'] = extract_domain(s(cr.get('tracked_url', '') or cr.get('destination_url', '')))
        found.append(comp)

    return found


def find_subscriber_lists(brand: str, market: str, dynamic_lists: list, static_lists: list) -> list:
    """Findet die finalen Verteiler-Listen (nach bestätigtem Opt-In) per Keyword-Suche."""
    found = []
    brand_u  = brand.upper()
    market_u = market.upper()

    for lst in dynamic_lists + static_lists:
        name = s(lst.get('name', ''))
        if not matches_any(name, SUBSCRIBER_LIST_KEYWORDS):
            continue
        if matches_any(name, STAGING_LIST_KEYWORDS):
            continue
        if brand_u and brand_u not in name.upper():
            continue
        if market_u and not _name_market_ok(name.upper(), market_u):
            continue
        comp = _make_component('list', lst)
        comp['role'] = 'subscriber'
        found.append(comp)

    return found


def _make_component(asset_type: str, item: dict) -> dict:
    """Erstellt eine normalisierte Komponenten-Beschreibung."""
    comp = {
        'type':          asset_type,
        'id':            s(item.get('id', '')),
        'name':          s(item.get('name', '')),
        'description':   s(item.get('description', '')),
        'status':        s(item.get('status', '')),
        'prospect_count': s(item.get('prospect_count', '')),
        'user_status':   None,
    }
    if asset_type == 'formhandler':
        comp['campaign']           = s(item.get('campaign', ''))
        comp['folder']             = s(item.get('folder', ''))
        comp['success_location']   = s(item.get('success_location', ''))
        comp['completion_actions'] = item.get('completion_actions', [])
        comp['field_mappings']     = item.get('field_mappings', [])
    elif asset_type == 'email':
        comp['subject']          = s(item.get('subject', ''))
        comp['from_email']       = s(item.get('from_email', ''))
        comp['folder']           = s(item.get('folder', ''))
        comp['is_autoresponder'] = bool(item.get('is_autoresponder_email'))
    elif asset_type == 'es':
        comp['entry_lists']       = s(item.get('entry_lists', ''))
        comp['suppression_lists'] = s(item.get('suppression_lists', ''))
    elif asset_type == 'custom_redirect':
        comp['destination_url'] = s(item.get('destination_url', ''))
        comp['vanity_url_path'] = s(item.get('vanity_url_path', ''))
        comp['tracked_url']     = s(item.get('tracked_url', ''))
    elif asset_type == 'list':
        comp['list_type'] = s(item.get('type', 'Static'))
    elif asset_type == 'landing_page':
        comp['url']      = s(item.get('url', ''))
        comp['campaign'] = s(item.get('campaign', ''))
        comp['folder']   = s(item.get('folder', ''))
        comp['form']     = s(item.get('form', ''))
    return comp


# ─── Opt-out Detection ───────────────────────────────────────────────────────

def is_optout_cr(cr: dict) -> bool:
    name   = s(cr.get('name', ''))
    folder = s(cr.get('folder', ''))
    dest   = s(cr.get('destination_url', ''))
    return matches_any(f"{name} {folder} {dest}", OPTOUT_CR_KEYWORDS)


def is_optout_fh(fh: dict) -> bool:
    name     = s(fh.get('name', ''))
    campaign = s(fh.get('campaign', ''))
    folder   = s(fh.get('folder', ''))
    return matches_any(f"{name} {campaign} {folder}", OPTOUT_FH_KEYWORDS)


def is_optout_ar(ar: dict) -> bool:
    name = s(ar.get('name', ar.get('Rule Name', '')))
    return matches_any(name, OPTOUT_AR_KEYWORDS)


def is_global_optout_es(es_prog: dict) -> bool:
    name = s(es_prog.get('name', ''))
    desc = s(es_prog.get('description', ''))
    return matches_any(f"{name} {desc}", OPTOUT_ES_KEYWORDS)


def _extract_fh_trigger_fields(fhs: list) -> set:
    """
    Liest FH-Completion-Actions und sammelt die gesetzten Feld-Namen.
    Pattern: "Change prospect custom field value: FIELD to VALUE"
    """
    fields = set()
    for fh in fhs:
        for ca in fh.get('completion_actions', []):
            m = re.search(r'Change prospect custom field value:\s*(.+?)\s+to\s+', s(ca), re.IGNORECASE)
            if m:
                fields.add(m.group(1).strip().lower())
    return fields


def find_trigger_linked_ars(group_fhs: list, all_ars: list) -> list:
    """
    Findet ARs, die durch FH-Completion-Actions ausgelöst werden.
    FH setzt Feld X → AR hat Regel 'X is true/set' → AR ist zwischengeschaltet.
    """
    trigger_fields = _extract_fh_trigger_fields(group_fhs)
    if not trigger_fields:
        return []
    found = []
    seen_ids = set()
    for ar in all_ars:
        ar_id = s(ar.get('id', ''))
        if ar_id in seen_ids:
            continue
        rules = _ar_rules_text(ar).lower()
        if any(tf in rules for tf in trigger_fields):
            found.append(ar)
            seen_ids.add(ar_id)
    return found


def _is_onetime_asset(name: str) -> bool:
    """True wenn das Asset ein Einmalläufer ist (Bereinigung, Import, Datenpflege)."""
    return matches_any(name, ONETIME_EXCLUSION_KEYWORDS)


def _campaign_type_from_name(name: str) -> tuple[str, str]:
    """
    Gibt (process_type, label) aus CAMPAIGN_TYPE_MAP zurück.
    Returns ('reengagement', 'Re-Engagement') als Fallback wenn kein Treffer.
    """
    name_l = name.lower()
    for keyword, (ptype, label) in CAMPAIGN_TYPE_MAP.items():
        if keyword in name_l:
            return ptype, label
    return 'reengagement', 'Re-Engagement'


def check_campaign_completeness(process: dict) -> dict:
    """
    Vollständigkeitsprüfung für Kampagnenprozesse (Re-Engagement etc.).
    Anders als Newsletter-Prozesse: kein DOI-Check, aber Entry-Liste + Aktivierungslogik erwartet.
    """
    comps = process['components']
    comp_types = {c['type'] for c in comps}
    checks = {
        'has_entry_list':     'list'            in comp_types,
        'has_activation':     any(c['type'] in ('es', 'automation_rule') for c in comps),
        'has_email':          'email'           in comp_types,
        'has_entry_fh':       'formhandler'     in comp_types,
    }
    issues = []
    if not checks['has_entry_list']:
        issues.append({'level': 'error',   'msg': 'Keine Anker-/Eingangs-Liste gefunden'})
    if not checks['has_activation']:
        issues.append({'level': 'warning', 'msg': 'Kein ES-Programm oder AR als Aktivierungslogik erkannt — Prozess evtl. noch im Aufbau'})
    if not checks['has_email']:
        issues.append({'level': 'info',    'msg': 'Keine E-Mail-Vorlage zugeordnet'})
    score = sum(1 for v in checks.values() if v) / len(checks)
    return {'checks': checks, 'issues': issues, 'score': round(score, 2)}


def analyze_campaign_processes(org: str, data: dict) -> list:
    """
    Erkennt Nicht-Newsletter-Prozesse: Re-Engagement, Win-back u.ä.

    Strategie:
    1. Anker = Dynamische Listen mit REENG_KEYWORDS + PC > 0
    2. Einmalläufer (ONETIME_EXCLUSION_KEYWORDS) werden komplett übersprungen
    3. Verknüpfte Assets:
       - FHs deren CA die Anker-Liste befüllt ODER Keyword-Match im Namen
       - ES-Programme mit Anker-Liste als Entry-Liste
       - ARs deren Regeltext oder Completion-Actions die Anker-Liste referenzieren
       - E-Mails per Keyword-Suche (ergänzend)
    4. Brand + Market per detect_brand / detect_market
    5. Gruppierung: ein Prozess pro (brand, market, campaign_type)
    """
    org_brand        = ORG_BRAND_OVERRIDE.get(org.lower(), '')
    sub_brand_tokens = ORG_SUB_BRAND_TOKENS.get(org.lower(), {})

    fhs  = data['formhandlers']
    dl   = data['dynamic_lists']
    sl   = data['static_lists']
    ars  = data['automation_rules']
    es   = data['engagement_studio']
    et   = data['email_templates']

    # 1. Anker-Listen: dynamische Listen mit Re-Engagement-Keyword + PC > 0
    anchor_lists = []
    for lst in dl:
        name = s(lst.get('name', ''))
        if _is_onetime_asset(name):
            continue
        if not matches_any(name, REENG_KEYWORDS):
            continue
        pc = _fh_prospect_count(lst)
        if pc == 0:
            continue  # Listen ohne aktive Prospects überspringen
        anchor_lists.append(lst)

    if not anchor_lists:
        return []

    # 2. Für jede Anker-Liste Brand + Market bestimmen, nach (brand, market, type) gruppieren
    # Gruppen: {(brand, market, process_type): {'anchors': [], 'fhs': [], 'ars': [], 'es': [], 'emails': []}}
    groups: dict[tuple, dict] = {}

    for lst in anchor_lists:
        name     = s(lst.get('name', ''))
        folder   = s(lst.get('folder', ''))
        campaign = s(lst.get('campaign', ''))

        brand = detect_brand(name, folder=folder, campaign=campaign,
                             sub_brand_tokens=sub_brand_tokens)
        if not brand and org_brand:
            brand = org_brand
        if not brand:
            brand = 'UNKNOWN'

        market = detect_market(name) or detect_market(folder) or detect_market(campaign) or 'UNKNOWN'

        ptype, _label = _campaign_type_from_name(name)
        key = (brand, market, ptype)
        if key not in groups:
            groups[key] = {'anchors': [], 'fhs': [], 'ars': [], 'es': [], 'emails': []}
        groups[key]['anchors'].append(lst)

    if not groups:
        return []

    # 3. Verknüpfte Assets zuordnen
    anchor_names_by_group: dict[tuple, set] = {
        k: {s(lst.get('name', '')).lower() for lst in v['anchors']}
        for k, v in groups.items()
    }
    # Alle Anker-Namen (lowercase) für schnellen Lookup
    all_anchor_names_lower = {n for names in anchor_names_by_group.values() for n in names}

    # FH-Scan: CA fügt zu Anker-Liste hinzu ODER Keyword-Match im Namen
    for fh in fhs:
        fh_name = s(fh.get('name', ''))
        if _is_onetime_asset(fh_name):
            continue
        cas = fh.get('completion_actions', [])
        parsed_ca = parse_completion_actions(cas)
        added_lists_lower = {n.lower() for n in parsed_ca['add_to_lists']}

        for key, anchor_names in anchor_names_by_group.items():
            # Verknüpft wenn: CA fügt zu Anker-Liste hinzu
            if added_lists_lower & anchor_names:
                if fh not in groups[key]['fhs']:
                    groups[key]['fhs'].append(fh)
                continue
            # ODER FH-Name enthält dasselbe Keyword wie die Gruppe
            brand, market, ptype = key
            if matches_any(fh_name, REENG_KEYWORDS):
                detected_brand = detect_brand(fh_name, sub_brand_tokens=sub_brand_tokens) or org_brand or 'UNKNOWN'
                if detected_brand == brand:
                    if fh not in groups[key]['fhs']:
                        groups[key]['fhs'].append(fh)

    # AR-Scan: Regeltext oder CA referenziert Anker-Listen-Namen
    for ar in ars:
        ar_name = s(ar.get('name', ''))
        if _is_onetime_asset(ar_name):
            continue
        rules_text = _ar_rules_text(ar).lower()
        actions_text = _ar_actions_text(ar).lower()
        combined_ar = rules_text + ' ' + actions_text + ' ' + ar_name.lower()

        for key, anchor_names in anchor_names_by_group.items():
            if any(anchor_n in combined_ar for anchor_n in anchor_names):
                if ar not in groups[key]['ars']:
                    groups[key]['ars'].append(ar)

    # ES-Scan: Entry-Liste enthält Anker-Listen-Name
    for es_prog in es:
        entry = s(es_prog.get('entry_lists', '')).lower()
        supp  = s(es_prog.get('suppression_lists', '')).lower()
        combined_es = entry + ' ' + supp

        for key, anchor_names in anchor_names_by_group.items():
            if any(anchor_n in combined_es for anchor_n in anchor_names):
                if es_prog not in groups[key]['es']:
                    groups[key]['es'].append(es_prog)

    # E-Mail-Scan: Name enthält Re-Engagement-Keyword + gleiche Brand
    for email in et:
        em_name = s(email.get('name', ''))
        if _is_onetime_asset(em_name):
            continue
        if not matches_any(em_name, REENG_KEYWORDS):
            continue
        em_brand = detect_brand(em_name, sub_brand_tokens=sub_brand_tokens) or org_brand or 'UNKNOWN'
        for key in groups:
            brand, market, ptype = key
            if em_brand == brand:
                if email not in groups[key]['emails']:
                    groups[key]['emails'].append(email)

    # 4. Prozesse bauen
    processes = []
    for (brand, market, ptype), assets in sorted(groups.items()):
        _ptype, plabel = _campaign_type_from_name(
            s(assets['anchors'][0].get('name', ''))
        )

        # Komponenten zusammenstellen
        components = []
        seen_ids: set = set()

        def _add(asset_type: str, item: dict, role: str, found_via: str):
            aid = str(item.get('id', ''))
            key_id = f"{asset_type}_{aid}"
            if key_id in seen_ids:
                return
            seen_ids.add(key_id)
            comp = _make_component(asset_type, item)
            comp['role']      = role
            comp['found_via'] = found_via
            components.append(comp)

        # Anker-Listen als entry_list
        for lst in sorted(assets['anchors'], key=lambda x: -_fh_prospect_count(x)):
            _add('list', lst, 'entry_list', 'process_fh')

        # FHs
        for fh in assets['fhs']:
            _add('formhandler', fh, 'entry', 'ca')

        # ARs
        for ar in assets['ars']:
            _add('automation_rule', ar, 'activation', 'name')

        # ES-Programme
        for es_prog in assets['es']:
            _add('es', es_prog, 'activation', 'ca')

        # E-Mails
        for email in assets['emails']:
            _add('email', email, 'content', 'name')

        # Market-Filter anwenden (kein PC-Prune nötig — Anker schon PC>0 gefiltert)
        if market and market != 'UNKNOWN':
            market_u = market.upper()
            components = [
                c for c in components
                if c.get('found_via') in ('process_fh', 'ca')
                or _name_market_ok(c.get('name', '').upper(), market_u)
            ]

        # Hauptkandidaten-PC für Prozess-Beschriftung
        anchor_pcs = [_fh_prospect_count(lst) for lst in assets['anchors']]
        total_pc   = sum(anchor_pcs)

        proc_id = f"{ptype}_{brand}_{market}".replace(' ', '_')
        title   = f"{plabel} {brand} {market}" if market != 'UNKNOWN' else f"{plabel} {brand}"

        # Discovery-Anker = die Eingangs-Listen die den Prozess erkannt haben
        camp_discovery = [
            {'id': str(lst.get('id','')), 'type': 'list', 'name': s(lst.get('name','')),
             'prospect_count': _fh_prospect_count(lst)}
            for lst in assets['anchors']
        ]

        proc = {
            'id':                proc_id,
            'title':             title,
            'brand':             brand,
            'market':            market,
            'campaign':          s(assets['anchors'][0].get('campaign', '')),
            'domain_hint':       '',
            'process_type':      ptype,
            'doi_type':          'n/a',
            'doi_mechanism':     'n/a',
            'optin_fields':      [],
            'total_pc':          total_pc,
            'search_widened':    False,
            'genuine_incomplete': False,
            'verified':          False,
            'verified_at':       '',
            'verified_comps':    [],
            'excluded_comps':    [],
            'discovery_anchors': camp_discovery,
            'components':        components,
        }
        proc['completeness'] = check_campaign_completeness(proc)
        # Wenn keine Aktivierungslogik → genuine_incomplete setzen
        if not proc['completeness']['checks'].get('has_activation'):
            proc['genuine_incomplete'] = True
        proc['patterns']     = []
        proc['dsgvo_flags']  = []
        processes.append(proc)

    return processes


def analyze_optout_processes(org: str, data: dict) -> list:
    """Erkennt Opt-out/Unsubscribe-Prozesse für eine Org."""
    fhs = data['formhandlers']
    crs = data['custom_redirects']
    ars = data['automation_rules']
    es  = data['engagement_studio']
    sl  = data.get('static_lists', [])
    dl  = data.get('dynamic_lists', [])
    sub_brand_tokens = ORG_SUB_BRAND_TOKENS.get(org.lower(), {})

    global_es  = [_make_component('es', p) for p in es if is_global_optout_es(p)]
    optout_crs = [c for c in crs if is_optout_cr(c)]
    optout_fhs = [h for h in fhs if is_optout_fh(h)]
    optout_ars = [r for r in ars if is_optout_ar(r)]

    groups = {}

    def _add(asset, asset_type):
        brand  = detect_brand(s(asset.get('name', '')), s(asset.get('folder', '')), s(asset.get('campaign', '')),
                               sub_brand_tokens=sub_brand_tokens)
        market = detect_market(s(asset.get('name', '')), asset.get('completion_actions', []))
        key = (brand or 'UNKNOWN', market or 'UNKNOWN')
        groups.setdefault(key, {'crs': [], 'fhs': [], 'ars': []})
        groups[key][asset_type].append(asset)

    for c in optout_crs: _add(c, 'crs')
    for h in optout_fhs: _add(h, 'fhs')
    for r in optout_ars: _add(r, 'ars')

    # UNKNOWN-market ARs für gleiche Brand in alle Market-Gruppen einbinden
    # (z.B. "Optout if requested GLB" ohne Marktkennung → gilt für AT-DE, CH-DE, DE-DE)
    unknown_brand_ars: dict[str, list] = {}  # brand → [ar, ...]
    for r in optout_ars:
        brand  = detect_brand(s(r.get('name', '')), '', '')
        market = detect_market(s(r.get('name', '')))
        if brand and not market:
            unknown_brand_ars.setdefault(brand, []).append(r)

    for (brand, market), assets in groups.items():
        if market != 'UNKNOWN' and brand in unknown_brand_ars:
            existing_ids = {s(r.get('id', '')) for r in assets['ars']}
            for r in unknown_brand_ars[brand]:
                if s(r.get('id', '')) not in existing_ids:
                    assets['ars'].append(r)

    processes = []

    for (brand, market), assets in sorted(groups.items()):
        cr_comps = [_make_component('custom_redirect', c) for c in assets['crs']]
        for c in cr_comps: c['found_via'] = 'name'
        fh_comps = [_make_component('formhandler', h)     for h in assets['fhs']]
        for c in fh_comps: c['found_via'] = 'process_fh'
        ar_comps = [_make_component('automation_rule', r) for r in assets['ars']]
        for c in ar_comps:
            c['found_via'] = 'name'
            c['role']      = 'optout'

        # Trigger-verknüpfte ARs: FH setzt Trigger-Feld → AR feuert darauf
        linked_ars  = find_trigger_linked_ars(assets['fhs'], ars)
        existing_ar_ids = {c['id'] for c in ar_comps}
        for r in linked_ars:
            comp = _make_component('automation_rule', r)
            comp['role']      = 'trigger_linked'
            comp['found_via'] = 'ca'  # durch FH-Feld-Trigger direkt ausgelöst
            if comp['id'] not in existing_ar_ids:
                ar_comps.append(comp)
                existing_ar_ids.add(comp['id'])

        domain_hint = ''
        for c in assets['crs']:
            d = extract_domain(s(c.get('destination_url', '')))
            if d and d not in ('digitall.com',):
                domain_hint = d
                break

        # Listen aus AR-Completion-Actions (Remove/Add to list)
        all_lists = sl + dl
        ar_list_comps = _find_lists_from_ar_actions(assets['ars'], all_lists,
                                                     role_add='subscriber',
                                                     role_remove='subscriber')
        # Listen aus FH-Completion-Actions (z.B. "Add to Optout-Liste")
        fh_parsed_ca  = _aggregate_cas(assets['fhs'])
        fh_list_comps = []
        seen_list_ids = {c['id'] for c in ar_list_comps}
        for list_name in fh_parsed_ca['add_to_lists'] + fh_parsed_ca['remove_from_lists']:
            item = fuzzy_name_match(list_name, all_lists)
            if item:
                lid = str(item.get('id', ''))
                if lid not in seen_list_ids:
                    seen_list_ids.add(lid)
                    comp = _make_component('list', item)
                    comp['role']      = 'subscriber'
                    comp['found_via'] = 'ca'
                    fh_list_comps.append(comp)

        components = cr_comps + fh_comps + ar_comps + global_es + ar_list_comps + fh_list_comps

        # Discovery-Anker: primäre Opt-out-Assets die den Prozess ausgelöst haben
        optout_discovery = (
            [{'id': c['id'], 'type': c['type'], 'name': c['name']} for c in fh_comps] or
            [{'id': c['id'], 'type': c['type'], 'name': c['name']} for c in cr_comps] or
            [{'id': c['id'], 'type': c['type'], 'name': c['name']} for c in ar_comps]
        )

        proc_id = f"optout_{brand}_{market}".replace(' ', '_')
        title = (f"Opt-out / Abmeldung {brand} {market}"
                 if market != 'UNKNOWN' else f"Opt-out / Abmeldung {brand}")

        proc = {
            'id':           proc_id,
            'title':        title,
            'brand':        brand,
            'market':       market,
            'campaign':     s(assets['crs'][0].get('campaign', '')) if assets['crs'] else '',
            'domain_hint':  domain_hint,
            'process_type': 'optout',
            'doi_type':     'n/a',
            'doi_mechanism': 'n/a',
            'optin_fields': [],
            'discovery_anchors': optout_discovery,
            'components':   components,
        }
        proc['completeness'] = check_optout_completeness(proc)

        # Landing Pages: Unsubscribe-Confirmation + Preference Pages anhängen
        lp_comps = _match_lps_to_process(
            data.get('landing_pages', []), brand, market,
            roles=('unsubscribe_confirm', 'preference_page'),
        )
        existing_ids = {c['id'] for c in proc['components']}
        for c in lp_comps:
            if c['id'] not in existing_ids:
                proc['components'].append(c)
                existing_ids.add(c['id'])

        processes.append(proc)

    # Natives Pardot-Opt-out erkennen:
    # Wenn keine eigenen Opt-out-Assets gefunden, aber eine Pardot-Unsubscribe-Liste existiert
    # → Org nutzt ausschließlich den nativen Pardot-Mechanismus (Unsubscribe-Link im E-Mail-Footer)
    if not processes:
        sl = data.get('static_lists', [])
        native_unsub_keywords = {'unsubscribed', 'unsubscribe list', 'opt-out list',
                                  'abmelde liste', 'abgemeldet', 'hardbounce list'}
        native_lists = []
        for lst in sl:
            name = s(lst.get('name', ''))
            if matches_any(name, native_unsub_keywords):
                comp = _make_component('list', lst)
                comp['role']      = 'subscriber'  # im Opt-out-Kontext: Empfängerliste der Abgemeldeten
                comp['found_via'] = 'name'
                native_lists.append(comp)
        if native_lists:
            proc_id = f"optout_NATIVE_{org.upper()}"
            proc = {
                'id':            proc_id,
                'title':         f"Opt-out / Abmeldung {org} (Pardot-nativ)",
                'brand':         org.upper()[:3],
                'market':        'UNKNOWN',
                'campaign':      '',
                'domain_hint':   '',
                'process_type':  'optout',
                'doi_type':      'n/a',
                'doi_mechanism': 'native_pardot',
                'optin_fields':  [],
                'components':    native_lists,
                'search_widened': False,
                'verified':       False,
                'verified_at':    '',
                'verified_comps': [],
                'excluded_comps': [],
            }
            proc['completeness'] = check_optout_completeness(proc)

            # Landing Pages auch für nativen Pardot-Opt-out
            lp_comps = _match_lps_to_process(
                data.get('landing_pages', []), org.upper()[:3], 'UNKNOWN',
                roles=('unsubscribe_confirm', 'preference_page'),
            )
            existing_ids = {c['id'] for c in proc['components']}
            for c in lp_comps:
                if c['id'] not in existing_ids:
                    proc['components'].append(c)
                    existing_ids.add(c['id'])

            # Hinweis: native Opt-out hat keinen eigenen FH/CR/AR — das ist kein Fehler
            proc['completeness']['issues'] = [
                i for i in proc['completeness']['issues']
                if 'AR' not in i['msg']  # AR-Fehler nicht melden — nativ = kein AR nötig
            ]
            proc['completeness']['issues'].insert(0, {
                'level': 'info',
                'msg': 'Opt-out läuft über nativen Pardot-Mechanismus (Unsubscribe-Link im E-Mail-Footer). Kein eigener FH/CR/AR konfiguriert.'
            })
            processes.append(proc)

    return processes


def check_optout_completeness(process: dict) -> dict:
    """Vollständigkeitsprüfung für Opt-out-Prozesse."""
    comp_types = {c['type'] for c in process['components']}
    checks = {
        'has_unsub_cr':         'custom_redirect' in comp_types,
        'has_unsub_fh':         'formhandler'     in comp_types,
        'has_optout_ar':        'automation_rule' in comp_types,
        'has_global_optout_es': 'es'              in comp_types,
    }
    issues = []
    if not checks['has_unsub_cr']:
        issues.append({'level': 'warning', 'msg': 'Kein Unsubscribe Custom-Redirect (tracked Link) gefunden'})
    if not checks['has_unsub_fh']:
        issues.append({'level': 'warning', 'msg': 'Kein Unsubscribe FH-link (Klick-Verarbeitung) gefunden'})
    if not checks['has_optout_ar']:
        issues.append({'level': 'error',   'msg': 'Keine Automation Rule für Opt-out gefunden'})
    if not checks['has_global_optout_es']:
        issues.append({'level': 'warning', 'msg': 'Kein Global Opt-Out / Hardbounce ES-Programm gefunden'})

    score = sum(1 for v in checks.values() if v) / len(checks)
    return {'checks': checks, 'issues': issues, 'score': round(score, 2)}


def check_completeness(process: dict) -> dict:
    """
    Prüft Vollständigkeit eines Signup-Prozesses.
    Mechanismus-aware: cr_based vs fh_based vs soi_only.
    """
    doi_mech   = process.get('doi_mechanism', 'unknown')
    components = process['components']
    comp_types = {c['type'] for c in components}
    issues     = []
    checks     = {}

    def has(t): return t in comp_types

    # Einstiegspunkt: FH, Form oder Automation Rule (alles außer doi_confirm)
    checks['has_entry_point'] = any(
        c['type'] in ('formhandler', 'form', 'automation_rule')
        and not is_doi_confirm_role(c.get('role'))
        for c in components
    )

    # Bestätigungsmechanismus: CR, DOIKlick-FH, oder doi_confirm-AR
    has_confirm = (
        has('custom_redirect') or
        any(c['type'] == 'formhandler' and is_doi_confirm_role(c.get('role')) for c in components) or
        any(c['type'] == 'automation_rule' and c.get('role') == 'doi_confirm' for c in components)
    )

    if doi_mech == 'fh_based':
        # FH-basiertes DOI: SOI-FH → DOI-E-Mail → DOIKlick-FH → Verteiler
        checks['has_doi_email']       = has('email')
        checks['has_doi_confirm_fh']  = any(
            c['type'] == 'formhandler' and is_doi_confirm_role(c.get('role'))
            for c in components
        )
        checks['has_subscriber_list'] = any(c.get('role') == 'subscriber' for c in components)

        if not checks['has_entry_point']:
            issues.append({'level': 'error',  'msg': 'Kein SOI-Einstiegspunkt gefunden (FH / Form / AR)'})
        if not checks['has_doi_email']:
            issues.append({'level': 'error',  'msg': 'Keine DOI-Bestätigungsmail gefunden'})
        if not checks['has_doi_confirm_fh']:
            issues.append({'level': 'error',  'msg': 'Kein DOI-Bestätigungs-Form-Handler (DOIKlick) gefunden'})
        if not checks['has_subscriber_list']:
            issues.append({'level': 'info',   'msg': 'Kein Verteiler (Subscriber-Liste) identifiziert'})

    elif doi_mech == 'ar_based':
        # AR-basiertes DOI: FH/Form → Staging → E-Mail → doi_confirm-AR → Verteiler
        # Kein ES erforderlich (ARs übernehmen Erinnerung/Bestätigung)
        checks['has_staging_list']      = any(
            c['type'] == 'list' and c.get('role') != 'subscriber' for c in components
        )
        checks['has_doi_email']         = has('email')
        checks['has_confirmation_step'] = has_confirm
        checks['has_subscriber_list']   = any(c.get('role') == 'subscriber' for c in components)

        if not checks['has_entry_point']:
            issues.append({'level': 'error',   'msg': 'Kein Einstiegspunkt gefunden (FH / Form / AR)'})
        if not checks['has_staging_list']:
            issues.append({'level': 'warning', 'msg': 'Keine Staging-Liste (DOI-Warteschlange) identifiziert'})
        if not checks['has_doi_email']:
            issues.append({'level': 'error',   'msg': 'Keine DOI-Bestätigungsmail gefunden'})
        if not checks['has_confirmation_step']:
            issues.append({'level': 'warning', 'msg': 'Kein Bestätigungsschritt gefunden (doi_confirm AR)'})
        if not checks['has_subscriber_list']:
            issues.append({'level': 'info',    'msg': 'Kein Verteiler (Subscriber-Liste) identifiziert'})

    elif doi_mech in ('cr_based', 'unknown'):
        # CR-basiertes DOI: FH → Staging → E-Mail → CR → ES → Verteiler
        checks['has_staging_list']     = any(
            c['type'] == 'list' and c.get('role') != 'subscriber' for c in components
        )
        checks['has_doi_email']        = has('email')
        checks['has_confirmation_step'] = has_confirm
        checks['has_es_program']       = has('es')
        checks['has_subscriber_list']  = any(c.get('role') == 'subscriber' for c in components)

        if not checks['has_entry_point']:
            issues.append({'level': 'error',   'msg': 'Kein Einstiegspunkt gefunden (FH / Form / AR)'})
        if not checks['has_staging_list']:
            issues.append({'level': 'warning', 'msg': 'Keine Staging-Liste (DOI-Warteschlange) identifiziert'})
        if not checks['has_doi_email']:
            issues.append({'level': 'error',   'msg': 'Keine DOI-Bestätigungsmail gefunden'})
        if not checks['has_confirmation_step']:
            issues.append({'level': 'warning', 'msg': 'Kein Bestätigungsschritt gefunden (CR / DOIKlick-FH / AR)'})
        if not checks['has_es_program']:
            issues.append({'level': 'warning', 'msg': 'Kein Engagement Studio Reminder-Programm gefunden'})
        if not checks['has_subscriber_list']:
            issues.append({'level': 'info',    'msg': 'Kein Verteiler (Subscriber-Liste) identifiziert'})

    else:
        # soi_only
        checks['has_subscriber_list'] = any(c.get('role') == 'subscriber' for c in components)
        if not checks['has_entry_point']:
            issues.append({'level': 'error',   'msg': 'Kein Einstiegspunkt gefunden (FH / Form / AR)'})
        if not checks['has_subscriber_list']:
            issues.append({'level': 'warning', 'msg': 'Kein Verteiler identifiziert'})

    score = sum(1 for v in checks.values() if v) / len(checks) if checks else 0
    return {'checks': checks, 'issues': issues, 'score': round(score, 2)}


# ─── Pattern Classification (MCAE Opt-In / Opt-Out Pattern Catalog) ─────────

# DACH-Brands bei denen DSGVO-Pflicht besteht
DACH_BRANDS = {'ACM', 'GLB', 'INI', 'UMB', 'HOO'}

# Markt-Codes die DACH-Pflicht signalisieren
DACH_MARKETS = {'DE-DE', 'AT-DE', 'CH-DE', 'CH-FR', 'CH-IT', 'CZ-CS', 'PL-PL', 'BE-NL', 'NL-NL'}


def get_prospect_fields(fields_data: list) -> list:
    """Gibt Prospect-Felder zurück (bereits durch load_fields() gefiltert)."""
    return fields_data


def find_optin_fields_with_sf_sync(fields_data: list, brand: str) -> list:
    """
    Sucht Optin-Felder für eine Brand und prüft ob sie Salesforce-Sync haben.
    Gibt Liste von Dicts: {name, api_name, sf_field, synced, has_timestamp_pair}
    """
    brand_u = brand.upper()
    result = []
    all_names = [f.get('name', '') for f in fields_data]

    for field in fields_data:
        name = s(field.get('name', ''))
        name_l = name.lower()

        # Muss Optin-bezogen sein
        if not any(k in name_l for k in OPTIN_FIELD_KEYWORDS):
            continue
        # Muss zur Brand passen (oder kein Brand-Code im Namen)
        if brand_u and brand_u not in name.upper():
            # Prüfe ob überhaupt ein bekannter Brand-Code drin ist
            has_any_brand = any(b in name.upper() for b in BRAND_CODES)
            if has_any_brand:
                continue  # anderer Brand

        sf_field = s(field.get('sf_field', ''))
        sync_beh = s(field.get('sync_behavior', ''))
        synced   = bool(sf_field and sync_beh)

        # Prüfe ob es ein korrespondierendes Timestamp-Feld gibt
        # Heuristik: gleiche Brand-Suffix + "Timestamp" oder "Datum" im Namen
        brand_suffix = re.search(r'[A-Z]{2,4}(?:-[A-Z]{2})?$', name)
        brand_tag    = brand_suffix.group(0) if brand_suffix else ''
        has_timestamp = any(
            ('timestamp' in n.lower() or 'datum' in n.lower())
            and (brand_tag in n if brand_tag else True)
            for n in all_names
            if n != name
        )

        result.append({
            'name':              name,
            'api_name':          s(field.get('api_name', '')),
            'sf_field':          sf_field,
            'synced':            synced,
            'sync_behavior':     sync_beh,
            'has_timestamp_pair': has_timestamp,
        })
    return result


def _ar_rules_text(ar: dict) -> str:
    secs = ar.get('sections', {})
    return s(secs.get('rules', '')) if isinstance(secs, dict) else ''


def _is_scoring_triggered_ar(ar: dict) -> bool:
    """Prüft ob AR nur auf Score/Grade-Kriterien basiert (kein Consent)."""
    rules = _ar_rules_text(ar).lower()
    actions = _ar_actions_text(ar).lower()
    if not ('score' in rules or 'grade' in rules):
        return False
    # Muss eine Liste hinzufügen (Optin-Effekt)
    if 'add prospect to list' not in actions:
        return False
    # Darf kein echtes Consent-Feld setzen
    has_consent = any(k in actions for k in OPTIN_FIELD_KEYWORDS)
    return not has_consent


def classify_optin_pattern(proc: dict, all_ars: list) -> list:
    """
    Klassifiziert einen Opt-in-Prozess nach MCAE-Muster-Katalog (Patterns 1–16).
    Gibt Liste von {pattern, label, note} zurück.
    """
    mech     = proc.get('doi_mechanism', 'unknown')
    comps    = proc.get('components', [])
    has_es   = any(c['type'] == 'es' for c in comps)
    has_form = any(c['type'] == 'form' for c in comps)

    patterns = []

    if mech == 'soi_only':
        patterns.append({'pattern': 1, 'label': 'SOI (Single Opt-In)',
                         'note': 'Kein Bestätigungsschritt — direkte Listenmitgliedschaft'})

    elif mech == 'fh_based':
        patterns.append({'pattern': 2, 'label': 'DOI via DOIKlick-FH',
                         'note': 'Bestätigung durch Klick auf zweiten Form Handler'})

    elif mech == 'ar_based':
        patterns.append({'pattern': 2, 'label': 'DOI via Automation Rule',
                         'note': 'Bestätigung durch AR bei gesetztem Trigger-Feld'})

    elif mech == 'cr_based':
        if has_es:
            patterns.append({'pattern': 3, 'label': 'DOI via Engagement Studio',
                             'note': 'ES orchestriert Bestätigungsmail + Reminder + Listenaktion'})
        else:
            patterns.append({'pattern': 2, 'label': 'DOI via Custom Redirect',
                             'note': 'CR-Klick setzt Trigger, AR bestätigt'})

    elif mech == 'unknown':
        patterns.append({'pattern': 0, 'label': 'DOI-Muster unbekannt',
                         'note': 'DOI-Mail gefunden, Bestätigungsmechanismus nicht eindeutig'})

    # P5: Form Handler als Einstieg (SF-native pattern)
    fh_comps = [c for c in comps if c['type'] == 'formhandler' and not is_doi_confirm_role(c.get('role'))]
    form_comps = [c for c in comps if c['type'] == 'form']
    if fh_comps and not form_comps:
        # FH ohne nativen Pardot-Form → Form Handler / SF-native pattern
        patterns.append({'pattern': 5, 'label': 'Form Handler (extern/SF-native)',
                         'note': 'Einstieg über Form Handler statt nativem Pardot-Formular'})

    # P6: Multi-Brand erkennbar an mehreren Brand-Tags im Prozesskontext
    # (wird auf Org-Ebene erkannt, nicht Prozess-Ebene — Marker setzen wenn >1 Brand in Org)

    # P11: Scoring-triggered (check anhand Org-ARs ob solche existieren und NL-Effekt haben)
    for ar in all_ars:
        if _is_scoring_triggered_ar(ar):
            patterns.append({'pattern': 11, 'label': 'Score/Grade-triggered (DSGVO-Risiko)',
                             'note': f'AR "{s(ar.get("name",""))}" fügt Prospects basierend auf Score hinzu — kein echter Consent'})
            break  # nur einmal melden

    return patterns


def classify_optout_pattern(proc: dict) -> list:
    """
    Klassifiziert einen Opt-out-Prozess nach MCAE-Muster-Katalog (Patterns 1–16).
    """
    comps = proc.get('components', [])
    has_fh = any(c['type'] == 'formhandler' for c in comps)
    has_cr = any(c['type'] == 'custom_redirect' for c in comps)
    has_ar = any(c['type'] == 'automation_rule' for c in comps)
    has_es = any(c['type'] == 'es' for c in comps)

    patterns = []

    if has_es and not has_fh and not has_cr:
        # Nur ES → globales System-Optout über ES-Programm
        patterns.append({'pattern': 1, 'label': 'System Global Opt-Out (ES)',
                         'note': 'Globales Opt-out-Handling via Engagement Studio'})
    elif has_fh and has_cr:
        # FH + CR → Custom Unsubscribe Form Pattern 3
        patterns.append({'pattern': 3, 'label': 'Custom Unsubscribe-Formular',
                         'note': 'Branded Abmeldeseite mit FH-Klick-Verarbeitung und CR-Tracking'})
    elif has_fh and not has_cr:
        patterns.append({'pattern': 3, 'label': 'Custom Unsubscribe-Formular (ohne CR)',
                         'note': 'FH verarbeitet Abmeldung, kein Custom Redirect für Tracking'})
    elif has_cr and not has_fh:
        patterns.append({'pattern': 14, 'label': 'Externer Abmeldelink (CR-only)',
                         'note': 'Custom Redirect ohne FH — möglicherweise externe Seite'})

    if has_ar:
        patterns.append({'pattern': 4, 'label': 'AR-Suppression',
                         'note': 'Automation Rule setzt Opt-out-Status oder fügt Suppression-Liste hinzu'})
    if has_es:
        patterns.append({'pattern': 11, 'label': 'ES Global Opt-Out Handler',
                         'note': 'Engagement Studio orchestriert Suppression und Hardbounce-Handling'})

    return patterns


def check_optout_propagation_chain(proc: dict, fields_data: list) -> dict:
    """
    Prüft die 6-gliedrige Opt-out-Propagation-Chain:
    1. Capture (FH oder CR vorhanden)
    2. State Write (Opted Out global vs. nur Listen-Entfernung)
    3. List Cleanup (Listenentfernung nachweisbar)
    4. SF Sync (Opted Out oder custom field synced)
    5. Send-time Suppression (ES Global Opt-Out Programm)
    6. Cross-asset Exclusion (Hardbounce-/Blockbounce-AR)
    """
    comps = proc.get('components', [])
    chain = {}
    issues = []

    # 1. Capture
    has_capture = any(c['type'] in ('formhandler', 'custom_redirect') for c in comps)
    chain['capture_asset'] = has_capture
    if not has_capture:
        issues.append({'level': 'warning', 'msg': 'Chain 1: Kein Capture-Asset (FH/CR) — Abmeldung nur systemseitig oder extern'})

    # 2. State Write — prüfe ob der Prozess ein globales Opted-Out/DNE auslöst
    # Wege: (a) AR direkt "Opted Out" setzen, (b) AR via Trigger-Feld,
    #        (c) FH-CA setzt Opted Out direkt, (d) FH-CA setzt Trigger-Feld → AR woanders
    global_optout_ar_names = {
        'optout if requested', 'opt.*out.*request', 'abmeld.*regel', 'unsubscribe.*rule',
        'set opted out', 'opted out',
    }
    optout_trigger_kws = {'optout', 'opt-out', 'abmeld', 'unsubscribe', 'austrag', 'do not email', 'opted out'}

    # (a) AR im Prozess mit opt-out-semantik
    global_optout_set = any(
        any(re.search(kw, c['name'], re.IGNORECASE) for kw in global_optout_ar_names)
        for c in comps if c['type'] == 'automation_rule'
    )
    # (b) Beliebige AR im Prozess (konservativ: AR = State Write)
    if not global_optout_set:
        global_optout_set = any(c['type'] == 'automation_rule' for c in comps)
    # (c/d) FH-Completion-Actions setzen Opted Out oder Trigger-Opt-Out-Feld
    if not global_optout_set:
        for c in comps:
            if c['type'] == 'formhandler':
                ca = c.get('completion_actions', [])
                ca_text = ' '.join(s(a) for a in ca).lower() if isinstance(ca, list) else s(ca).lower()
                if any(kw in ca_text for kw in optout_trigger_kws):
                    global_optout_set = True
                    break

    chain['global_optout_set'] = global_optout_set
    if not chain['global_optout_set']:
        issues.append({'level': 'warning',
                       'msg': 'Chain 2: Kein State-Write erkennbar — weder AR noch FH setzt Opted-Out oder Trigger-Feld'})

    # 3. List Cleanup — FH oder AR entfernt aus Liste (nachweisbar wenn FH + AR vorhanden)
    chain['list_cleanup'] = any(c['type'] in ('formhandler', 'automation_rule') for c in comps)
    if not chain['list_cleanup']:
        issues.append({'level': 'warning', 'msg': 'Chain 3: Keine Listenbereinigung nachweisbar'})

    # 4. SF Sync — Pardot `Opted Out` (Standardfeld) synct immer bi-direktional
    # Custom optout-Felder die final sind (kein "trigger"/"request"/"timestamp") prüfen
    chain['sf_sync'] = True  # Standard Opted Out always syncs
    for field in fields_data:
        fname = s(field.get('name', '')).lower()
        # Nur finale Opt-out-Felder (kein Trigger/Request/Timestamp/Hilfsfeld)
        if not any(k in fname for k in {'optout', 'opt-out'}):
            continue
        if any(k in fname for k in {'trigger', 'request', 'timestamp', 'datum', 'double'}):
            continue  # Hilfsfelder überspringen
        if not field.get('sf_field'):
            issues.append({'level': 'info',
                           'msg': f'Chain 4: Opt-out-Feld "{field.get("name")}" hat keinen SF-Sync — Consent-Record unvollständig in CRM'})

    # 5. Send-time Suppression — ES Global Opt-Out Programm vorhanden?
    chain['send_suppression'] = any(c['type'] == 'es' for c in comps)
    if not chain['send_suppression']:
        issues.append({'level': 'warning', 'msg': 'Chain 5: Kein globales ES Opt-out/Hardbounce-Programm erkennbar'})

    # 6. Cross-asset Exclusion — Hardbounce/Blockbounce AR
    chain['cross_asset_exclusion'] = any(
        'bounce' in c['name'].lower() or 'block' in c['name'].lower()
        for c in comps if c['type'] == 'automation_rule'
    )
    if not chain['cross_asset_exclusion']:
        issues.append({'level': 'info', 'msg': 'Chain 6: Kein Hardbounce/Blockbounce-AR in diesem Opt-out-Prozess erkennbar'})

    chain_score = sum(1 for v in chain.values() if v) / len(chain)
    return {'chain': chain, 'chain_issues': issues, 'chain_score': round(chain_score, 2)}


def detect_dsgvo_flags(proc: dict, brand: str, market: str,
                       fields_data: list, all_ars: list) -> list:
    """
    Erkennt DSGVO-Compliance-Risiken für DACH-Orgs.
    Gibt Liste von {level, flag, msg} zurück.
    """
    flags = []
    is_dach = brand in DACH_BRANDS or market in DACH_MARKETS
    if not is_dach:
        return flags  # Nur DACH prüfen

    mech  = proc.get('doi_mechanism', 'unknown')
    comps = proc.get('components', [])

    # SOI-only in DACH
    if mech == 'soi_only' and proc.get('process_type') == 'signup':
        flags.append({'level': 'error', 'flag': 'SOI_ONLY',
                      'msg': 'SOI-only in DACH-Org — DSGVO erfordert Double-Opt-In'})

    # Kein DOI-Timestamp-Feld
    optin_field_info = find_optin_fields_with_sf_sync(fields_data, brand)
    doi_fields_with_ts = [f for f in optin_field_info if 'double' in f['name'].lower() or 'doi' in f['name'].lower()]
    if doi_fields_with_ts and not any(f['has_timestamp_pair'] for f in doi_fields_with_ts):
        flags.append({'level': 'warning', 'flag': 'NO_DOI_TIMESTAMP',
                      'msg': 'Kein DOI-Timestamp-Feld gefunden — Einwilligungszeitpunkt nicht nachweisbar'})

    # Optin-Feld ohne SF-Sync — nur echte Consent-Felder (nicht Request/Trigger-Hilfsfelder)
    consent_fields_only = [
        f for f in optin_field_info
        if 'double' in f['name'].lower() or 'doi' in f['name'].lower()
        if 'request' not in f['name'].lower() and 'trigger' not in f['name'].lower()
        if 'timestamp' not in f['name'].lower() and 'datum' not in f['name'].lower()
    ]
    for f in consent_fields_only:
        if not f['synced']:
            flags.append({'level': 'warning', 'flag': 'NO_SF_SYNC',
                          'msg': f'Consent-Feld "{f["name"]}" nicht nach Salesforce synchronisiert'})

    # Scoring-triggered Opt-in
    for ar in all_ars:
        if _is_scoring_triggered_ar(ar):
            flags.append({'level': 'error', 'flag': 'SCORING_OPTIN',
                          'msg': f'AR "{s(ar.get("name",""))}" setzt Score/Grade als Opt-in-Auslöser — kein gültiger Consent'})

    # Fehlende Opt-in/Opt-out-Symmetrie (nur wenn Signup-Prozess)
    if proc.get('process_type') == 'signup':
        has_doi = mech in ('cr_based', 'fh_based', 'ar_based')
        optin_fields = proc.get('optin_fields', [])
        # Prüfe ob ein korrespondierendes Opt-out-Feld existiert
        for fi in optin_field_info:
            if any(oi in fi['name'] for oi in optin_fields):
                # Prüfe ob ein Opt-out-Pendant existiert (mit "optout", "trigger optout" etc.)
                base = re.sub(r'double|request|optin|opt-in', '', fi['name'], flags=re.IGNORECASE).strip()
                has_optout_field = any(
                    ('optout' in f.get('name', '').lower() or 'opt-out' in f.get('name', '').lower())
                    and base[:4].lower() in f.get('name', '').lower()
                    for f in fields_data
                )
                if not has_optout_field:
                    flags.append({'level': 'info', 'flag': 'NO_OPTOUT_FIELD_PAIR',
                                  'msg': f'Kein Opt-out-Gegenstück zu "{fi["name"]}" gefunden — Symmetrie prüfen'})
                break  # nur einmal

    return flags


# ─── Shared Component Filter ─────────────────────────────────────────────────

def _apply_component_filter(components: list, market: str) -> list:
    """
    Wendet Market-Filter + ProspectCount-Prune auf eine Komponenten-Liste an.
    Wird zweimal ausgeführt: nach der initialen Zusammenstellung und nach
    dem Widen-Step (damit auch nachträglich hinzugefügte Komponenten gefiltert werden).

    Regeln:
      (a) process_fh / ca-verlinkte → immer behalten
      (b) trigger-linked ARs → immer behalten
      (c) Alle anderen → nur wenn _name_market_ok (Market-Filter)
      (d) PC-Prune: found_via≠(process_fh|ca) mit PC=0 entfernen wenn bessere Alternative
          desselben Typs (FH oder Liste) mit PC>0 vorhanden ist
    """
    # Schritt (a-c): Market-Filter
    if market and market != 'UNKNOWN':
        market_u = market.upper()
        filtered = []
        seen_ids_types: set = set()
        for c in components:
            fv = c.get('found_via', 'name')
            keep = (
                fv in ('process_fh', 'ca')
                or c.get('role') == 'trigger_linked'
                or _name_market_ok(c.get('name', '').upper(), market_u)
            )
            key = (c['id'], c['type'])
            if keep and key not in seen_ids_types:
                filtered.append(c)
                seen_ids_types.add(key)
        components = filtered

    # Schritt (d): ProspectCount-Prune
    for asset_type in ('formhandler', 'list'):
        type_comps = [c for c in components if c['type'] == asset_type]
        max_pc = max((int(c.get('prospect_count') or 0) for c in type_comps), default=0)
        if max_pc > 0:
            components = [
                c for c in components
                if c['type'] != asset_type
                or int(c.get('prospect_count') or 0) > 0
                or c.get('found_via') in ('process_fh', 'ca')
                or c.get('role') == 'trigger_linked'
            ]

    return components


# ─── Main Analysis ───────────────────────────────────────────────────────────

def analyze_org(org: str) -> list:
    """
    Analysiert eine Org: Newsletter-Anmeldeprozesse + Opt-out-Prozesse.
    Jeder Prozess hat 'process_type': 'signup' | 'optout'.
    """
    data = load_all(org)
    org_brand        = ORG_BRAND_OVERRIDE.get(org.lower(), '')
    sub_brand_tokens = ORG_SUB_BRAND_TOKENS.get(org.lower(), {})

    fhs   = data['formhandlers']
    forms = data['forms']
    sl    = data['static_lists']
    dl    = data['dynamic_lists']
    es    = data['engagement_studio']
    et    = data['email_templates']
    cr    = data['custom_redirects']
    ars          = data['automation_rules']
    fields_data  = data.get('fields', [])

    # 1. Newsletter-FHs identifizieren
    nl_fhs = [fh for fh in fhs if is_nl_formhandler(fh)]

    # 2. Nach Brand+Market gruppieren
    groups = group_fh_by_process(nl_fhs, org_brand=org_brand, sub_brand_tokens=sub_brand_tokens)

    # 2b. Leere Vorlagen-Gruppen herausfiltern:
    # Eine Gruppe gilt als aktiv wenn mindestens EINER dieser Nachweise existiert:
    #   (a) Ein markt-nativer FH (Market-Code im Namen) mit PC>0 oder CAs
    #   (b) Eine markt-native Liste (Market-Code im Namen) mit PC>0
    #   (c) Ein markt-nativer FH in der Gruppe mit CAs (unabhängig von PC) → DOI-Confirm FHs
    # Verhindert dass UNKNOWN-Merge-FHs inaktive Markt-Vorlagen am Leben halten.
    all_lists = dl + sl
    def _group_has_market_evidence(group_fhs: list, market: str) -> bool:
        # PC=None bedeutet "nicht abrufbar" (unbekannt), NICHT "wirklich 0".
        # Unbekannte PC-Werte zählen als mögliche Aktivität.
        def _fh_active(fh: dict) -> bool:
            return (fh.get('prospect_count') is None
                    or _fh_prospect_count(fh) > 0
                    or bool(fh.get('completion_actions')))

        if market == 'UNKNOWN':
            return any(_fh_active(fh) for fh in group_fhs)

        market_u = market.upper()
        def _has_token(name: str) -> bool:
            name_u = name.upper()
            # Market-Code mit Bindestrich UND Unterstrich prüfen (z.B. DE-DE und DE_DE)
            for mv in [market_u, market_u.replace('-', '_')]:
                if re.search(r'(?<![A-Z])' + re.escape(mv) + r'(?![A-Z])', name_u):
                    return True
            return False
        # (a) Nativer FH mit Aktivität (oder unbekanntem PC)
        for fh in group_fhs:
            if _has_token(s(fh.get('name', ''))) and _fh_active(fh):
                return True
        # (b) Native Liste mit PC>0 oder unbekanntem PC
        for lst in all_lists:
            if _has_token(s(lst.get('name', ''))):
                if lst.get('prospect_count') is None or _fh_prospect_count(lst) > 0:
                    return True
        # (c) Kein markt-nativer Nachweis → Gruppe ist eine leere Vorlage
        return False
    groups = {k: v for k, v in groups.items() if _group_has_market_evidence(v, k[1])}

    # 2c. Versions-Split: Gruppen mit versionierten FHs (II, NEU, …) aufteilen.
    # Bedingung: ein FH wird nur als "neue Version" erkannt, wenn ein anderer FH in
    # derselben Gruppe denselben Basisnamen (ohne Versions-Suffix) trägt.
    # Verhindert Falsch-Splits bei technischen Versionsnummern in Asset-Beschreibungen
    # (z.B. "Datenservice-v2" ohne Basis-FH "Datenservice").
    groups_versioned: dict[tuple, list] = {}
    for (brand, market), group_fhs in groups.items():
        soi_by_version: dict[str, list] = {}
        doi_conf_shared: list = []
        for fh in group_fhs:
            role = classify_fh_optin_role(fh)
            if is_doi_confirm_role(role):
                doi_conf_shared.append(fh)
            else:
                v = _fh_version_key(s(fh.get('name', '')))
                soi_by_version.setdefault(v, []).append(fh)

        # Echter Versions-Split nur wenn: versioned FH hat Gegenstück ohne Suffix (Basisprozess)
        versioned_keys = [v for v in soi_by_version if v != '']
        base_names = {
            _VERSION_SUFFIX_RE.sub('', s(fh.get('name', ''))).strip().lower()
            for fh in soi_by_version.get('', [])
        }
        genuine_version_keys = [
            v for v in versioned_keys
            if any(
                _VERSION_SUFFIX_RE.sub('', s(fh.get('name', ''))).strip().lower() in base_names
                for fh in soi_by_version[v]
            )
        ]

        if not genuine_version_keys:
            # Keine echte Version → alle SOI-FHs in einer Gruppe
            all_soi = [fh for fhs in soi_by_version.values() for fh in fhs]
            groups_versioned[(brand, market, '')] = all_soi + doi_conf_shared
        else:
            # Basis-Gruppe (inkl. nicht-genuiner Versions-FHs)
            non_genuine = [
                fh for v, fhs in soi_by_version.items()
                if v not in genuine_version_keys
                for fh in fhs
            ]
            if non_genuine:
                groups_versioned[(brand, market, '')] = non_genuine + doi_conf_shared
            # Echte Versions-Gruppen
            for v in sorted(genuine_version_keys):
                groups_versioned[(brand, market, v)] = soi_by_version[v] + doi_conf_shared
    groups = groups_versioned

    processes = []

    for (brand, market, version), group_fhs in sorted(groups.items()):

        # 3. FHs nach Rolle trennen
        soi_fhs      = []
        doi_conf_fhs = []
        for fh in group_fhs:
            role = classify_fh_optin_role(fh)
            if is_doi_confirm_role(role):
                doi_conf_fhs.append(fh)
            else:
                soi_fhs.append(fh)

        # 4. SOI-Completion-Actions → Staging-Listen + DOI-E-Mails
        soi_parsed_ca = _aggregate_cas(soi_fhs)
        staging_lists = find_staging_lists(brand, market, soi_parsed_ca, sl, dl)
        doi_emails    = find_doi_emails(brand, market, soi_parsed_ca, et)

        # 5. DOI-Confirm-FH-Komponenten (mit Rolle)
        doi_conf_components = []
        doi_conf_parsed_ca = _aggregate_cas(doi_conf_fhs)
        for fh in doi_conf_fhs:
            comp = _make_component('formhandler', fh)
            fh_role = classify_fh_optin_role(fh)
            comp['role'] = fh_role  # doi_confirm oder doi_confirm_name
            comp['found_via'] = 'process_fh'
            doi_conf_components.append(comp)

        # 6. Subscriber-Listen: zuerst aus DOI-Confirm-CAs, dann SOI-FH-CAs, dann Keyword-Suche
        # Reihenfolge: DOI-Confirm-FH-CAs > SOI-FH-CAs > AR-CAs > Keyword-Suche
        subscriber_lists = _find_subscriber_lists_from_ca(doi_conf_parsed_ca, sl + dl)
        if not subscriber_lists:
            # SOI-FH-CAs: "Add to list" eines SOI-FH = direkter Verteiler bei reinem SOI
            subscriber_lists = _find_subscriber_lists_from_ca(soi_parsed_ca, sl + dl)
            # Staging-Listen wieder entfernen — SOI-FH-CAs können auf Staging zeigen
            staging_ids = {c['id'] for c in staging_lists}
            subscriber_lists = [c for c in subscriber_lists if c['id'] not in staging_ids]
        if not subscriber_lists:
            # AR-CAs: Signup-ARs können via "Add to list" direkt auf Subscriber-Listen zeigen
            # Rohe AR-Objekte ermitteln (haben completion_actions — Komponenten haben das nicht)
            signup_ar_names = {c['id'] for c in find_signup_ars(brand, market, ars)}
            raw_signup_ars  = [r for r in ars if s(r.get('id', '')) in signup_ar_names]
            subscriber_lists = _find_lists_from_ar_actions(
                raw_signup_ars, sl + dl,
                role_add='subscriber', role_remove='subscriber',
            )
        if not subscriber_lists:
            subscriber_lists = find_subscriber_lists(brand, market, dl, sl)

        # 7. CR-basierte Komponenten (Acme/Globex-Muster)
        confirm_crs = find_confirmation_crs(brand, market, cr)
        es_programs = find_es_programs(staging_lists, es)

        # 8a. SOI-FH-Komponenten (Kern des Prozesses — immer behalten)
        # Qualitätssignal: Wenn mind. ein FH PC>0 hat, sind PC=0-FHs Nebenkandidaten
        soi_max_pc = max((_fh_prospect_count(fh) for fh in soi_fhs), default=0)
        soi_components = []
        for fh in soi_fhs:
            comp = _make_component('formhandler', fh)
            fh_pc = _fh_prospect_count(fh)
            is_uat = _fh_is_uat(fh)
            # UAT-FHs und PC=0-FHs wenn bessere Kandidaten vorhanden → name-Match
            if is_uat or (fh_pc == 0 and soi_max_pc > 0):
                comp['found_via'] = 'name'
            else:
                comp['found_via'] = 'process_fh'
            soi_components.append(comp)

        # 8b. Pardot-Forms als zusätzliche Einstiegspunkte (Primary Pass)
        form_components = find_nl_forms(brand, market, forms)

        # 8c. Signup-ARs (Primary Pass — nur direkt passende)
        signup_ar_components = find_signup_ars(brand, market, ars)

        # 9. DOI-Mechanismus bestimmen
        doi_conf_ars_primary = find_doi_confirm_ars(brand, market, ars)
        if confirm_crs:
            doi_mechanism = 'cr_based'
        elif doi_conf_fhs:
            doi_mechanism = 'fh_based'
        elif doi_conf_ars_primary:
            doi_mechanism = 'ar_based'
        elif doi_emails:
            doi_mechanism = 'unknown'
        else:
            doi_mechanism = 'soi_only'

        # 10. Optin-Felder aus allen FHs sammeln
        all_optin_fields = []
        for fh in group_fhs:
            parsed = parse_completion_actions(fh.get('completion_actions', []))
            for fc in parsed['soi_field_changes'] + parsed['doi_field_changes']:
                if fc['field'] not in all_optin_fields:
                    all_optin_fields.append(fc['field'])

        # 11. Domain-Hint
        domain_hint = ''
        for fh in soi_fhs:
            d = extract_domain(s(fh.get('success_location', '')))
            if d:
                domain_hint = d
                break
        if not domain_hint:
            for c in confirm_crs:
                if c.get('domain'):
                    domain_hint = c['domain']
                    break

        # 12. Komponenten in Prozess-Reihenfolge zusammenstellen
        doi_conf_ar_comps = [_make_component('automation_rule', r) for r in doi_conf_ars_primary]
        for c in doi_conf_ar_comps:
            c['role']      = 'doi_confirm'
            c['found_via'] = 'name'

        # Signup-ARs deduplizieren: ARs die auch doi_confirm sind, nicht doppelt zeigen
        doi_conf_ar_ids = {c['id'] for c in doi_conf_ar_comps}
        signup_ar_components_dedup = [c for c in signup_ar_components
                                      if c['id'] not in doi_conf_ar_ids]

        if doi_mechanism == 'fh_based':
            # SOI-FH → DOI-E-Mail → DOIKlick-FH → Verteiler
            components = (form_components + soi_components + doi_emails +
                          doi_conf_components + doi_conf_ar_comps + subscriber_lists)
        elif doi_mechanism == 'ar_based':
            # FH → Staging → DOI-E-Mail → DOI-Confirm-AR → Verteiler
            components = (form_components + soi_components + signup_ar_components_dedup +
                          staging_lists + doi_emails + doi_conf_ar_comps + subscriber_lists)
        else:
            # CR-based / unknown / soi_only: FH → Staging → E-Mail → CR → ES → Verteiler
            components = (form_components + soi_components + signup_ar_components +
                          staging_lists + doi_emails + confirm_crs + es_programs + subscriber_lists)

        # 12b+c. Post-Filter (als Funktion — wird nach Widen-Step nochmals aufgerufen)
        components = _apply_component_filter(components, market)

        # 13. Prozess-ID + Titel (mit optionalem Versions-Suffix)
        version_suffix = f"_{version}" if version else ""
        proc_id = f"nl_{brand}_{market}{version_suffix}".replace(' ', '_')
        campaign_name = s(group_fhs[0].get('campaign', '')) if group_fhs else ''
        version_label = f" ({version})" if version else ""
        title = (f"Newsletter Anmeldung {brand} {market}{version_label}"
                 if market != 'UNKNOWN' else f"Newsletter Anmeldung {brand}{version_label}")

        # Discovery-Anker: die FHs die den Prozess ausgelöst haben
        discovery_anchors = [
            {'id': c['id'], 'type': c['type'], 'name': c['name']}
            for c in soi_components
            if c.get('found_via') == 'process_fh'
        ]

        proc = {
            'id':               proc_id,
            'title':            title,
            'brand':            brand,
            'market':           market,
            'campaign':         campaign_name,
            'domain_hint':      domain_hint,
            'process_type':     'signup',
            'doi_type':         'double_optin' if doi_mechanism != 'soi_only' else 'single_optin',
            'doi_mechanism':    doi_mechanism,
            'optin_fields':     all_optin_fields,
            'search_widened':   False,
            'genuine_incomplete': False,
            'discovery_anchors': discovery_anchors,
            'components':       components,
        }
        proc['completeness'] = check_completeness(proc)

        # Iterative Sucherweiterung auf 80%-Schwelle (wenn nötig)
        proc = _widen_component_search(
            proc, brand, market, soi_fhs, doi_conf_fhs, sl, dl, et, cr,
            forms=forms, ars=ars, es=es
        )

        # Post-Filter nach Widen: nachträglich eingefügte Komponenten ebenfalls prüfen
        proc['components'] = _apply_component_filter(proc['components'], market)

        # Pattern-Klassifikation + DSGVO-Flags (nach finalem Komponentenstand)
        proc['patterns']    = classify_optin_pattern(proc, ars)
        proc['dsgvo_flags'] = detect_dsgvo_flags(proc, brand, market, fields_data, ars)

        # Landing Pages: Signup-Confirmation + Preference Pages anhängen
        lp_comps = _match_lps_to_process(
            data.get('landing_pages', []), brand, market,
            roles=('signup_confirm', 'preference_page'),
        )
        existing_ids = {c['id'] for c in proc['components']}
        for c in lp_comps:
            if c['id'] not in existing_ids:
                proc['components'].append(c)
                existing_ids.add(c['id'])

        processes.append(proc)

    # Opt-out-Prozesse anhängen
    optout_procs = analyze_optout_processes(org, data)
    for proc in optout_procs:
        proc['patterns']         = classify_optout_pattern(proc)
        chain_result             = check_optout_propagation_chain(proc, fields_data)
        proc['optout_chain']     = chain_result['chain']
        proc['chain_issues']     = chain_result['chain_issues']
        proc['chain_score']      = chain_result['chain_score']
    processes += optout_procs

    # Kampagnenprozesse (Re-Engagement, Win-back etc.) anhängen
    campaign_procs = analyze_campaign_processes(org, data)
    # Deduplizieren: Prozesse mit gleicher ID wie ein Newsletter-Prozess nicht doppelt aufnehmen
    existing_ids = {p['id'] for p in processes}
    for proc in campaign_procs:
        if proc['id'] not in existing_ids:
            existing_ids.add(proc['id'])
            processes.append(proc)

    return processes


def load_status(org: str) -> dict:
    """Lädt gespeicherte User-Status-Annotationen."""
    path = BASE / 'output' / org / 'process_status.json'
    if path.exists():
        try:
            return json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            pass
    return {}


def save_status(org: str, status: dict):
    """Speichert User-Status-Annotationen."""
    path = BASE / 'output' / org / 'process_status.json'
    path.write_text(json.dumps(status, indent=2, ensure_ascii=False), encoding='utf-8')


def merge_status(processes: list, status: dict) -> list:
    """Merged gespeicherte User-Annotationen + Verify-State in die Prozesse."""
    for proc in processes:
        proc_status = status.get(proc['id'], {})
        # Verify-Metadaten auf Prozessebene
        proc['verified']        = bool(proc_status.get('_verified', False))
        proc['verified_at']     = proc_status.get('_verified_at', '')
        proc['verified_comps']  = proc_status.get('_verified_comps', [])
        proc['excluded_comps']  = proc_status.get('_excluded_comps', [])
        # User-Status pro Komponente
        for comp in proc['components']:
            comp_key = f"{comp['type']}_{comp['id']}"
            if comp_key in proc_status:
                comp['user_status'] = proc_status[comp_key]
    return processes


# ─── Process Discovery ───────────────────────────────────────────────────────

def discover_unmatched_processes(org: str, data: dict, existing_processes: list) -> list:
    """
    Findet Asset-Cluster die in keinem erkannten Prozess enthalten sind.
    Strategie (in Priorität):
      1. ES-Anchor:       Jedes ES ohne Prozess → Kandidat
      2. Folder-Anchor:   Folder mit ≥2 verschiedenen Asset-Typen
      3. Campaign-Anchor: Campaign mit ≥2 verschiedenen Asset-Typen

    Gibt eine sortierte Liste von Kandidaten zurück:
    [{id, title, cluster_type, cluster_key, asset_count, type_count, components}]
    """
    # ── 1. Genutzte IDs aus bestehenden Prozessen sammeln ──────────────────────
    used: dict = {}  # type → set of ids
    for proc in existing_processes:
        for comp in proc.get('components', []):
            t = comp.get('type', '')
            used.setdefault(t, set()).add(str(comp.get('id', '')))

    def _used(asset_type: str, item: dict) -> bool:
        return str(item.get('id', '')) in used.get(asset_type, set())

    # ── 2. Asset-Pools ─────────────────────────────────────────────────────────
    _type_pools = [
        ('es',           data.get('engagement_studio', [])),
        ('formhandler',  data.get('formhandlers', [])),
        ('automation_rule', data.get('automation_rules', [])),
        ('email',        data.get('email_templates', [])),
        ('dynamic_list', data.get('dynamic_lists', [])),
        ('static_list',  data.get('static_lists', [])),
        ('landing_page', data.get('landing_pages', [])),
    ]

    def _comps_of_type(asset_type: str, items: list) -> list:
        return [_make_component(asset_type, it) for it in items if not _used(asset_type, it)]

    # ── 3. ES-Anchor Kandidaten ────────────────────────────────────────────────
    candidates = []
    seen_clusters = set()  # (cluster_type, cluster_key) → deduplizieren

    unmatched_es = [it for it in data.get('engagement_studio', []) if not _used('es', it)]
    for es_item in unmatched_es:
        es_name   = s(es_item.get('name', ''))
        es_folder = s(es_item.get('folder', ''))
        es_camp   = s(es_item.get('campaign', ''))

        comps = [_make_component('es', es_item)]

        # Gleichen Folder/Campaign suchen — andere Asset-Typen
        for asset_type, pool in _type_pools:
            if asset_type == 'es':
                continue
            for it in pool:
                it_folder = s(it.get('folder', ''))
                it_camp   = s(it.get('campaign', ''))
                matched = (
                    (es_folder and it_folder and it_folder.lower() == es_folder.lower()) or
                    (es_camp   and it_camp   and it_camp.lower()   == es_camp.lower())
                )
                if matched:
                    comps.append(_make_component(asset_type, it))

        cid = f'discover_es_{es_item.get("id", es_name)}'
        seen_clusters.add(('es', es_name))
        candidates.append({
            'id':           cid,
            'title':        es_name or f'ES #{es_item.get("id", "?")}',
            'cluster_type': 'es',
            'cluster_key':  es_name,
            'components':   comps,
            'asset_count':  len(comps),
            'type_count':   len({c['type'] for c in comps}),
        })

    # ── 4. Folder-Anchor Kandidaten (ohne ES-Anker) ───────────────────────────
    folder_buckets: dict = {}
    for asset_type, pool in _type_pools:
        for it in pool:
            if _used(asset_type, it):
                continue
            folder = s(it.get('folder', ''))
            if not folder or folder.lower() in ('', 'default', 'uncategorized'):
                continue
            folder_buckets.setdefault(folder, []).append((asset_type, it))

    for folder, items in folder_buckets.items():
        if ('es', folder) in seen_clusters:
            continue
        type_set = {t for t, _ in items}
        if len(type_set) < 2:
            continue
        comps = [_make_component(t, it) for t, it in items]
        cid = f'discover_folder_{folder[:60]}'
        seen_clusters.add(('folder', folder))
        candidates.append({
            'id':           cid,
            'title':        folder,
            'cluster_type': 'folder',
            'cluster_key':  folder,
            'components':   comps,
            'asset_count':  len(comps),
            'type_count':   len(type_set),
        })

    # ── 5. Campaign-Anchor Kandidaten (nicht schon via ES oder Folder erfasst) ─
    campaign_buckets: dict = {}
    for asset_type, pool in _type_pools:
        for it in pool:
            if _used(asset_type, it):
                continue
            camp = s(it.get('campaign', ''))
            if not camp or camp.lower() in ('', 'default', 'uncategorized'):
                continue
            campaign_buckets.setdefault(camp, []).append((asset_type, it))

    for camp, items in campaign_buckets.items():
        if ('es', camp) in seen_clusters or ('folder', camp) in seen_clusters:
            continue
        type_set = {t for t, _ in items}
        if len(type_set) < 2:
            continue
        comps = [_make_component(t, it) for t, it in items]
        cid = f'discover_campaign_{camp[:60]}'
        candidates.append({
            'id':           cid,
            'title':        camp,
            'cluster_type': 'campaign',
            'cluster_key':  camp,
            'components':   comps,
            'asset_count':  len(comps),
            'type_count':   len(type_set),
        })

    # ── 6. Sortieren: type_count desc, asset_count desc ───────────────────────
    candidates.sort(key=lambda c: (-c['type_count'], -c['asset_count']))
    return candidates


# ─── CLI ─────────────────────────────────────────────────────────────────────

def list_orgs() -> list:
    out = BASE / 'output'
    if not out.exists():
        return []
    return [d.name for d in out.iterdir() if d.is_dir() and not d.name.startswith('_')]


def active_org() -> str:
    p = BASE / '.active-org'
    if p.exists():
        return p.read_text().strip()
    orgs = list_orgs()
    return orgs[0] if orgs else ''


if __name__ == '__main__':
    args = sys.argv[1:]
    as_json = '--json' in args
    args = [a for a in args if a != '--json']

    if '--all' in args:
        orgs = list_orgs()
    elif args:
        orgs = [args[0]]
    else:
        org = active_org()
        orgs = [org] if org else list_orgs()

    for org in orgs:
        processes = analyze_org(org)
        status    = load_status(org)
        processes = merge_status(processes, status)

        if as_json:
            print(json.dumps(processes, indent=2, ensure_ascii=False))
        else:
            print(f"\n{'='*60}")
            print(f"Org: {org}  ({len(processes)} Prozesse erkannt)")
            print('='*60)
            for p in processes:
                c = p['completeness']
                score_bar = '█' * round(c['score'] * 10) + '░' * (10 - round(c['score'] * 10))
                mech = p.get('doi_mechanism', '')
                fields = ', '.join(p.get('optin_fields', [])) or '—'
                print(f"\n  [{score_bar}] {p['title']}  (Score: {c['score']:.0%})")
                print(f"    Domain: {p['domain_hint'] or '—'}  DOI: {p['doi_type']}  Mechanismus: {mech}")
                print(f"    Optin-Felder: {fields}")
                print(f"    Komponenten ({len(p['components'])}):")
                for comp in p['components']:
                    role = f" [{comp.get('role','')}]" if comp.get('role') else ''
                    print(f"      {comp['type']:20s} {comp['id']:10s} {comp['name'][:50]}{role}")
                if c['issues']:
                    print(f"    Issues:")
                    for issue in c['issues']:
                        icon = '🔴' if issue['level'] == 'error' else '⚠️' if issue['level'] == 'warning' else 'ℹ️'
                        print(f"      {icon}  {issue['msg']}")
