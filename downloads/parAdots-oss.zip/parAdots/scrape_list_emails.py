"""
Pardot List Email Scraper — v5 API  (rewritten after field diagnostic)
=========================================================================
Pulls all list email send-jobs from /api/v5/objects/list-emails.

A "List Email" is the batch email send object in Pardot — one row per
broadcast (e.g. one Newsletter issue), not per recipient. Note this is the
SAME object queried by fetch_sent_emails_api.py ("Sent Emails") — there is
no separate "list email" vs "sent email" object in the v5 API. The two
sections differ only in scope: Sent Emails = isSent=true, last 12 months,
lean field set. List Emails (this scraper) = all list emails regardless of
send status, richer field set including recipient lists, sender/reply-to,
and per-send delivery stats.

Why this file was rewritten (2026-07-02): the previous LIST_FIELDS list used
14 field names that don't exist on this v5 object at all (status, scheduledAt,
listId, listName, emailTemplateName, senderAddress, senderName,
replyToAddress, totalQueued/Sent/Delivered/Opens/Clicks/Unsubscribes/Bounces,
salesforceId). A single invalid field name in a v5 `fields` param causes the
ENTIRE request to 400 ("Invalid parameter: fields ... unknown field: X").
pardot_api.paged_get() swallows non-200 responses silently (prints a warning,
returns nothing, no exception), so this produced a false "0 list emails"
that run_all.py logged as a success. See diagnose_list_emails_fields.py for
the verification process; field names below are confirmed live against the
v5 API (see output/<org>/diagnostics/list_emails_*.json).

Confirmed API constraints (official docs + live diagnostic):
  - No `status` field exists — only booleans `isSent`, `isPaused`,
    `isDeleted`. `scheduledTime` is write-only, can't be read back, so
    "Scheduled" vs "Draft" can no longer be distinguished via this API.
  - No flat `listId`/`listName` — the recipient lists come back as the
    `recipientLists` collection, which the v5 API explicitly forbids on the
    bulk Query endpoint ("Collections are not allowed to be selected for
    this operation"). Only available via a single-record Read
    (`GET .../list-emails/<id>`) — hence the extra per-record call below.
  - Same constraint applies to `senderOptions` / `replyToOptions` on Query
    (fetched via the same per-record Read call).
  - Stats (queued/sent/delivered/opens/clicks/bounces/unsubscribes) aren't on
    the object at all — separate per-record call to
    `GET .../list-emails/<id>/stats`, with a different field vocabulary than
    guessed originally (e.g. `hardBounced`/`softBounced` instead of
    `totalBounces`, `optOuts` instead of `totalUnsubscribes`, no `queued`).

Cost: this scraper now makes 2 extra API calls per list email (detail read +
stats), on top of the paged bulk query. For orgs with many list emails this
is measurably slower than the old (broken) single-pass version — accepted
trade-off for actually getting recipient lists, sender info, and real stats.

Output:
  pardot_list_emails.json
  pardot_list_emails.csv

Usage (standalone):
  python3 scrape_list_emails.py

Called from run_all.py:
  from scrape_list_emails import run
  run(page=page)
"""

from __future__ import annotations

import csv
import sys
from collections import Counter

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""

# Bulk query fields — every one of these has been confirmed valid live
# against the v5 API (no collections, no relationship fields — those need
# the per-record Read call in _fetch_detail()).
LIST_FIELDS = [
    "id", "name", "subject", "type",
    "isSent", "isPaused", "isDeleted", "clientType",
    "sentAt", "createdAt", "updatedAt",
    "campaignId", "folderId", "emailTemplateId", "trackerDomainId",
    "createdById", "updatedById",
]

# Fields only obtainable via a single-record Read (collections are rejected
# on the bulk Query endpoint).
DETAIL_FIELDS = ["recipientLists", "suppressionLists", "senderOptions", "replyToOptions"]

# Real stats field names, confirmed via GET .../list-emails/<id>/stats
# (see output/<org>/diagnostics/list_emails_stats_sample.json).
STATS_FIELDS = [
    "sent", "delivered", "deliveryRate",
    "opens", "uniqueOpens", "opensRate",
    "totalClicks", "uniqueClicks", "clickThroughRate", "uniqueClickThroughRate",
    "clickOpenRatio",
    "hardBounced", "softBounced",
    "optOuts", "optOutRate",
    "spamComplaints", "spamComplaintRate",
]


# ── Per-record enrichment (Read + stats) ──────────────────────────────────────

_warned_detail_failure = False
_warned_stats_failure  = False


def _fetch_detail(client: pardot_api.PardotClient, list_email_id) -> dict:
    """
    Single-record Read for the fields the bulk Query endpoint rejects
    (recipientLists / suppressionLists / senderOptions / replyToOptions).
    Not yet 100% confirmed these are readable at all on a single-record GET
    (only confirmed: they're rejected on the bulk Query endpoint) — this is
    coded defensively (raw request, quiet after first failure) so an
    unexpected 400 here degrades to blank fields instead of crashing the run.
    """
    global _warned_detail_failure
    url = f"{pardot_api.PARDOT_API_BASE}/objects/list-emails/{list_email_id}"
    try:
        resp = client.session.get(
            url, headers=client.headers(),
            params={"fields": ",".join(DETAIL_FIELDS)},
            timeout=pardot_api.DEFAULT_TIMEOUT,
        )
    except Exception as e:
        if not _warned_detail_failure:
            print(f"   ⚠️  Detail read errored (list email {list_email_id}): {e} "
                  f"— recipient list/sender fields will be blank for records where this recurs.")
            _warned_detail_failure = True
        return {}
    if resp.status_code != 200:
        if not _warned_detail_failure:
            print(f"   ⚠️  Detail read failed ({resp.status_code}) for list email {list_email_id}: "
                  f"{resp.text[:200]} — recipient list/sender fields will be blank for records where this recurs.")
            _warned_detail_failure = True
        return {}
    try:
        return resp.json()
    except Exception:
        return {}


def _fetch_stats(client: pardot_api.PardotClient, list_email_id) -> dict:
    """GET .../list-emails/<id>/stats — not exposed on the main object."""
    global _warned_stats_failure
    url = f"{pardot_api.PARDOT_API_BASE}/objects/list-emails/{list_email_id}/stats"
    try:
        resp = client.session.get(url, headers=client.headers(), timeout=pardot_api.DEFAULT_TIMEOUT)
    except Exception as e:
        if not _warned_stats_failure:
            print(f"   ⚠️  Stats call errored for list email {list_email_id}: {e}")
            _warned_stats_failure = True
        return {}
    if resp.status_code != 200:
        if not _warned_stats_failure:
            print(f"   ⚠️  Stats call failed ({resp.status_code}) for list email {list_email_id}: {resp.text[:200]}")
            _warned_stats_failure = True
        return {}
    try:
        return resp.json()
    except Exception:
        return {}


# ── Shaping ───────────────────────────────────────────────────────────────────

def _status_label(le: dict) -> str:
    if le.get("isDeleted"):
        return "Gelöscht"
    if le.get("isSent"):
        return "Gesendet"
    if le.get("isPaused"):
        return "Pausiert"
    return "Nicht gesendet"  # can't distinguish Draft vs Scheduled — scheduledTime isn't readable via v5


def shape_list_email(
    le: dict,
    detail: dict,
    stats: dict,
    folder_map: dict,
    campaign_map: dict,
) -> dict:
    folder_name   = (folder_map.get(le.get("folderId")) or {}).get("name", "")
    campaign_name = (campaign_map.get(le.get("campaignId")) or {}).get("name", "")

    recipient_lists  = detail.get("recipientLists") or []
    suppression_lists = detail.get("suppressionLists") or []
    sender_options   = detail.get("senderOptions") or []
    reply_to_options = detail.get("replyToOptions") or []
    sender     = sender_options[0] if sender_options else {}
    reply_to   = reply_to_options[0] if reply_to_options else {}

    return {
        "id":                 str(le.get("id", "")),
        "name":               le.get("name", "") or "",
        "status_label":       _status_label(le),
        "is_sent":            bool(le.get("isSent")),
        "is_paused":          bool(le.get("isPaused")),
        "subject":            le.get("subject", "") or "",
        "content_type":       le.get("type", "") or "",
        "sent_at":            le.get("sentAt", "") or "",
        "recipient_lists":    ", ".join(l.get("name", "") for l in recipient_lists if l.get("name")),
        "suppression_lists":  ", ".join(l.get("name", "") for l in suppression_lists if l.get("name")),
        "campaign":           campaign_name,
        "folder":             folder_name,
        "template_id":        str(le.get("emailTemplateId", "") or ""),
        "sender_address":     sender.get("address", "") or "",
        "sender_name":        sender.get("name", "") or "",
        "reply_to":           reply_to.get("address", "") or "",
        "sent_count":         stats.get("sent", 0) or 0,
        "delivered":          stats.get("delivered", 0) or 0,
        "delivery_rate_pct":  stats.get("deliveryRate"),
        "opens":              stats.get("opens", 0) or 0,
        "unique_opens":       stats.get("uniqueOpens", 0) or 0,
        "open_rate_pct":      stats.get("opensRate"),
        "total_clicks":       stats.get("totalClicks", 0) or 0,
        "unique_clicks":      stats.get("uniqueClicks", 0) or 0,
        "click_rate_pct":     stats.get("clickThroughRate"),
        "hard_bounced":       stats.get("hardBounced", 0) or 0,
        "soft_bounced":       stats.get("softBounced", 0) or 0,
        "opt_outs":           stats.get("optOuts", 0) or 0,
        "opt_out_rate_pct":   stats.get("optOutRate"),
        "spam_complaints":    stats.get("spamComplaints", 0) or 0,
        "client_type":        le.get("clientType", "") or "",
        "created_at":         le.get("createdAt", "") or "",
        "updated_at":         le.get("updatedAt", "") or "",
    }


# ── Export ────────────────────────────────────────────────────────────────────

def export_csv(results: list[dict]) -> None:
    headers = [
        "#", "Name", "ID", "Status", "Subject", "Sent At",
        "Recipient List(s)", "Suppression List(s)",
        "Campaign", "Folder", "Template ID",
        "Sender", "Sender Address", "Reply-To",
        "Sent", "Delivered", "Delivery Rate %",
        "Opens", "Unique Opens", "Open Rate %",
        "Clicks", "Unique Clicks", "Click Rate %",
        "Hard Bounces", "Soft Bounces", "Opt-Outs", "Opt-Out Rate %",
        "Spam Complaints", "Client Type", "Created At",
    ]
    rows = [
        [
            i + 1,
            r["name"], r["id"], r["status_label"], r["subject"], r["sent_at"],
            r["recipient_lists"], r["suppression_lists"],
            r["campaign"], r["folder"], r["template_id"],
            r["sender_name"], r["sender_address"], r["reply_to"],
            r["sent_count"], r["delivered"], r["delivery_rate_pct"] if r["delivery_rate_pct"] is not None else "",
            r["opens"], r["unique_opens"], r["open_rate_pct"] if r["open_rate_pct"] is not None else "",
            r["total_clicks"], r["unique_clicks"], r["click_rate_pct"] if r["click_rate_pct"] is not None else "",
            r["hard_bounced"], r["soft_bounced"], r["opt_outs"], r["opt_out_rate_pct"] if r["opt_out_rate_pct"] is not None else "",
            r["spam_complaints"], r["client_type"], r["created_at"],
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} rows)")


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV, _warned_detail_failure, _warned_stats_failure
    OUTPUT_JSON = utils.output_path("pardot_list_emails.json")
    OUTPUT_CSV  = utils.output_path("pardot_list_emails.csv")
    _warned_detail_failure = False
    _warned_stats_failure  = False

    print("\n📧 Pardot List Email Scraper (v5 API)")
    print("=" * 45)

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    print("📁 Pre-loading folders...")
    folder_map = pardot_api.lookup_map(client, "objects/folders", fields=["id", "name"])
    print(f"   ✅ {len(folder_map)} folder(s)")

    print("📋 Pre-loading campaigns...")
    campaign_map = pardot_api.lookup_map(client, "objects/campaigns", fields=["id", "name"])
    print(f"   ✅ {len(campaign_map)} campaign(s)")

    print("\n📨 Fetching list emails (bulk query)...")
    raw = list(pardot_api.paged_get(client, "objects/list-emails", fields=LIST_FIELDS))
    print(f"   ✅ {len(raw)} list email(s) found")

    if not raw:
        utils.save_json([], OUTPUT_JSON)
        export_csv([])
        return

    print(f"\n🔎 Enriching {len(raw)} list email(s) with recipient list / sender / stats "
          f"(2 extra API calls each — this is the slow part)...")
    results = []
    for i, le in enumerate(raw, 1):
        le_id = le.get("id")
        detail = _fetch_detail(client, le_id)
        stats  = _fetch_stats(client, le_id) if le.get("isSent") else {}
        results.append(shape_list_email(le, detail, stats, folder_map, campaign_map))
        if i % 50 == 0 or i == len(raw):
            print(f"   ... {i}/{len(raw)} enriched")

    utils.save_json(results, OUTPUT_JSON)
    export_csv(results)

    # ── Summary ───────────────────────────────────────────────────────────────
    status_counts = Counter(r["status_label"] for r in results)
    sent = [r for r in results if r["is_sent"] and r["delivered"]]

    print(f"\n── List Email summary ──────────────────────")
    for status, count in status_counts.most_common():
        print(f"   {status:20s}: {count}")
    if sent:
        avg_open  = round(sum(r["open_rate_pct"]  or 0 for r in sent) / len(sent), 1)
        avg_click = round(sum(r["click_rate_pct"] or 0 for r in sent) / len(sent), 1)
        print(f"\n   Avg open rate  (sent, delivered>0): {avg_open}%")
        print(f"   Avg click rate (sent, delivered>0): {avg_click}%")

    print(f"\n✅ List Email scrape complete — {len(results)} email(s).")


# ── Standalone ────────────────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
