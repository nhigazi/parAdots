"""
Pardot Preference Center Scraper
==================================
Captures the Preference Center configuration from Pardot Account Engagement.

The Preference Center is a system-level feature (not a Landing Page) that lets
prospects manage which newsletters/topics they want to receive. It is distinct
from forms and landing pages and has no dedicated browser-based list URL.

Two-pass strategy:
  Pass 1 — v5 API: GET /api/v5/objects/preference-centers
            Returns structured config if the endpoint exists (newer orgs).
  Pass 2 — Playwright page-scrape of <PARDOT_HOME>/preference-center/
            Fallback for orgs where the API endpoint returns 404 or 403.

Captured fields (per preference center):
  id, name, status, is_default, redirect_url, lists (topic list names),
  list_count, folder, campaign, tracker_domain, created_at, updated_at,
  source (api | page)

Output:
  pardot_preference_center.json
  pardot_preference_center.csv

Usage (standalone):
  python3 scrape_preference_center.py

Called from run_all.py:
  from scrape_preference_center import run
  run(page=page, client=pardot_client)
"""

from __future__ import annotations

import csv
import json
import re
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""   # set at run() time
OUTPUT_CSV  = ""
SCREENSHOTS = ""

# Tier A: gating by updated_at timestamp
CACHED_FIELDS = ["list_count"]

CSV_HEADERS = ["id", "name", "lists", "list_count", "folder", "campaign", "status", "is_default", "created_at", "updated_at", "source"]

# v5 API endpoint
API_ENDPOINT = "objects/preference-centers"

# v5 fields to request
LIST_FIELDS = [
    "id", "name", "isDefault", "redirectUrl", "status",
    "folderId", "campaignId", "salesforceId",
    "trackerDomainId", "createdAt", "updatedAt",
]

# Pardot UI list URL candidates, tried in order until one renders a real
# "Email Preference Page(s)" list (see _scrape_via_page). The original
# single URL ("/preference-center/") was verified against a live Umbrella
# org (screenshot) to land on a page with no extractable table — the
# UI's own navigation is "Account Engagement Email" → "Preferences Page",
# header text "Email Preference Pages", "+ Add Email Preferences Page"
# button. Pardot's admin object naming for this feature is inconsistent
# across API versions/orgs ("preference center" vs "email preference
# page"), so several plausible URLs are tried rather than guessing one.
# NOT yet re-verified against a live browser session — the next real scrape
# run should confirm which of these (if any) actually renders the table
# and drop the ones that don't.
UI_LIST_PATH_CANDIDATES = [
    "/emailPreferencePage/",
    "/email/preferences",
    "/preference-center/",
]

# Markers that confirm we've actually landed on the Email Preference Pages
# list (vs. a redirect to the dashboard or a 404/permission page).
LIST_PAGE_MARKERS = ("email preference page", "preferences page", "add email preferences page")


# ── API scraping ──────────────────────────────────────────────────────────────

def _fetch_via_api(client: pardot_api.PardotClient) -> list[dict] | None:
    """
    Try to pull preference centers from the v5 API.
    Returns a list of raw dicts, or None if the endpoint is unavailable.
    """
    import requests as _req

    url = f"{pardot_api.PARDOT_API_BASE}/{API_ENDPOINT}"
    resp = client.session.get(
        url,
        headers=client.headers(),
        params={"fields": ",".join(LIST_FIELDS), "limit": 200},
        timeout=pardot_api.DEFAULT_TIMEOUT,
    )
    if resp.status_code == 404:
        print(f"   ℹ️  /api/v5/{API_ENDPOINT} returned 404 — falling back to page scrape")
        return None
    if resp.status_code == 403:
        print(f"   ℹ️  /api/v5/{API_ENDPOINT} returned 403 (no permission) — falling back to page scrape")
        return None
    if resp.status_code != 200:
        print(f"   ⚠️  /api/v5/{API_ENDPOINT} returned {resp.status_code}: {resp.text[:200]}")
        return None

    body = resp.json()
    records = body.get("values", [])
    print(f"   ✅ API returned {len(records)} preference center(s)")
    return records


def _fetch_detail_via_api(
    client: pardot_api.PardotClient, pc_id: str | int
) -> dict | None:
    """Fetch full detail for one preference center (includes list associations)."""
    detail_fields = LIST_FIELDS + ["lists"]
    return pardot_api.get_one(client, API_ENDPOINT, pc_id, fields=detail_fields)


def _shape_api_record(
    record: dict,
    detail: dict | None,
    folder_map: dict,
    campaign_map: dict,
) -> dict:
    detail = detail or record
    folder_name   = (folder_map.get(record.get("folderId"))    or {}).get("name", "")
    campaign_name = (campaign_map.get(record.get("campaignId")) or {}).get("name", "")

    # Lists — v5 may return them as embedded objects or just IDs
    raw_lists = detail.get("lists") or record.get("lists") or []
    if isinstance(raw_lists, list):
        list_names = [
            (l.get("name") or str(l)) if isinstance(l, dict) else str(l)
            for l in raw_lists
        ]
    else:
        list_names = []

    return {
        "id":            str(record.get("id", "")),
        "name":          record.get("name", "") or "",
        "status":        record.get("status", "") or "",
        "is_default":    bool(record.get("isDefault", False)),
        "redirect_url":  record.get("redirectUrl", "") or "",
        "lists":         list_names,
        "list_count":    len(list_names),
        "folder":        folder_name,
        "campaign":      campaign_name,
        "salesforce_id": record.get("salesforceId") or "",
        "created_at":    record.get("createdAt", "") or "",
        "updated_at":    record.get("updatedAt", "") or "",
        "source":        "api",
    }


# ── Page scraping fallback ────────────────────────────────────────────────────

def _looks_like_list_page(lines: list[str]) -> bool:
    joined = " ".join(lines).lower()
    return any(marker in joined for marker in LIST_PAGE_MARKERS)


def _parse_list_table_rows(lines: list[str]) -> list[dict]:
    """
    Parse rows directly from the Email Preference Pages list table.

    The list page itself already shows everything the gap analysis needs
    (Name, Link, List Count, Updated) — confirmed from a live screenshot of
    a real org (Umbrella: 5 rows, columns NAME / LINK / LIST COUNT / UPDATED
    / ACTIONS). Going straight to per-row detail pages (the old approach)
    required guessing a detail-page URL pattern that was never verified; this
    reads the table that's already fully rendered on the list page instead.

    Playwright's innerText linearizes each table row as consecutive lines.
    We anchor on the link line (matches the tracker-domain preference-page
    URL, e.g. https://mcae.umbrella.de/emailPreference/e/epc/<id>/<token>)
    since that's the most distinctive line, then look one line back for the
    name and one-to-two lines forward for the list count and updated date.
    """
    link_re  = re.compile(r'^https?://\S+/emailPreference/', re.IGNORECASE)
    count_re = re.compile(r'^\d+$')

    rows: list[dict] = []
    for i, line in enumerate(lines):
        if not link_re.match(line):
            continue
        name = lines[i - 1] if i > 0 else ""
        list_count = 0
        updated_at = ""
        for j in range(i + 1, min(i + 4, len(lines))):
            if count_re.match(lines[j]):
                list_count = int(lines[j])
            elif re.match(r'^\d{2}[./]\d{2}[./]\d{2,4}', lines[j]):
                updated_at = lines[j]
        # Pull the preference-page ID out of the link, e.g. .../epc/1020672/TR...
        id_match = re.search(r'/emailPreference/[a-z]/[a-z]+/(\d+)', line, re.IGNORECASE)
        pc_id = id_match.group(1) if id_match else f"link-{len(rows)}"
        rows.append({
            "id":            pc_id,
            "name":          name,
            "status":        "",
            "is_default":    "default" in name.lower(),
            "redirect_url":  "",
            "lists":         [],
            "list_count":    list_count,
            "folder":        "",
            "campaign":      "",
            "salesforce_id": "",
            "created_at":    "",
            "updated_at":    updated_at,
            "source":        "page",
            "prospect_facing_link": line,
        })
    return rows


def _scrape_via_page(page) -> list[dict]:
    """
    Playwright fallback: navigate to the Email Preference Pages list and
    scrape available data from the UI. Tries each URL in
    UI_LIST_PATH_CANDIDATES until one actually renders the list (checked via
    _looks_like_list_page), instead of assuming the first guess is correct.
    """
    lines: list[str] = []
    candidate_lines: list[str] = []
    landed_url = None
    for candidate_path in UI_LIST_PATH_CANDIDATES:
        candidate_url = utils.pardot_url(candidate_path)
        print(f"   🌐 Navigating to {candidate_url}")
        utils.navigate(page, candidate_url)
        time.sleep(1.5)
        text = utils.get_page_text(page)
        candidate_lines = [l.strip() for l in text.splitlines() if l.strip()]
        if _looks_like_list_page(candidate_lines):
            lines = candidate_lines
            landed_url = candidate_url
            print(f"   ✅ Confirmed Email Preference Pages list at {candidate_url}")
            break
        print(f"   ℹ️  {candidate_url} did not render the expected list — trying next candidate")

    if landed_url is None:
        # None of the candidates confirmed the list page — use the last one
        # tried so screenshots/logs still show *something* for debugging.
        lines = candidate_lines
        print("   ⚠️  Could not confirm any candidate URL renders the Email Preference Pages list.")

    utils.screenshot(page, f"{SCREENSHOTS}/pc_list.png")

    # 1) Preferred: parse the rows directly off the list page (no detail-page
    #    URL guessing required — see _parse_list_table_rows).
    table_rows = _parse_list_table_rows(lines)
    if table_rows:
        print(f"   Parsed {len(table_rows)} preference page row(s) directly from the list table")
        return table_rows

    # 2) Fallback: collect IDs from page links using known URL patterns and
    #    visit each detail page (kept for orgs/UI versions where the list
    #    table doesn't linearize the way _parse_list_table_rows expects).
    ids_found = utils.collect_ids_from_page(page, r'/preference-center/(?:read|edit)/id/(\d+)')
    if not ids_found:
        ids_found = utils.collect_ids_from_page(page, r'/emailPreferencePage/(?:read|edit)/id/(\d+)')
    if not ids_found:
        ids_found = utils.collect_ids_from_page(page, r'preference-center[^"]*id[=/](\d+)')

    print(f"   Found {len(ids_found)} preference center link(s) on list page")

    results = []
    if ids_found:
        for item in ids_found:
            pc_id   = item["id"]
            pc_name = item.get("name", f"Preference Center {pc_id}")
            detail  = _scrape_pc_detail(page, pc_id, pc_name)
            results.append(detail)
            time.sleep(0.8)
    else:
        # No IDs found — try to parse what we can from the list page itself
        result = _parse_list_page(lines)
        if result:
            results.append(result)

    return results


def _scrape_pc_detail(page, pc_id: str, pc_name: str) -> dict:
    """Scrape the detail/edit page for one preference center."""
    for url_tmpl in [
        f"{utils.PARDOT_HOME}/preference-center/read/id/{pc_id}",
        f"{utils.PARDOT_HOME}/preference-center/edit/id/{pc_id}",
    ]:
        utils.navigate(page, url_tmpl)
        time.sleep(1.0)
        text = utils.get_page_text(page)
        if text and len(text) > 200:
            break

    utils.screenshot(page, f"{SCREENSHOTS}/pc_{pc_id}.png")
    lines = [l.strip() for l in text.splitlines() if l.strip()]

    def find_value(keywords):
        for i, line in enumerate(lines):
            if any(kw.lower() in line.lower() for kw in keywords):
                if ":" in line:
                    val = line.split(":", 1)[1].strip()
                    if val:
                        return val[:300]
                if i + 1 < len(lines):
                    return lines[i + 1][:300]
        return ""

    status       = find_value(["status", "published", "draft"])
    redirect_url = find_value(["redirect", "confirmation", "thank-you", "danke"])
    folder       = find_value(["folder", "ordner"])
    campaign     = find_value(["campaign", "kampagne"])

    # Detect "default" marker
    is_default = any("default" in l.lower() or "standard" in l.lower() for l in lines[:20])

    # Extract list names — look for list-like items in the page
    list_pattern = re.compile(r'(newsletter|nl |verteiler|liste|list)', re.IGNORECASE)
    list_candidates = [l for l in lines if list_pattern.search(l) and len(l) < 80]
    # Deduplicate
    seen_lc: set[str] = set()
    list_names: list[str] = []
    for c in list_candidates:
        lc = c.lower()
        if lc not in seen_lc:
            seen_lc.add(lc)
            list_names.append(c)

    return {
        "id":            pc_id,
        "name":          pc_name,
        "status":        status,
        "is_default":    is_default,
        "redirect_url":  redirect_url,
        "lists":         list_names[:20],
        "list_count":    len(list_names),
        "folder":        folder,
        "campaign":      campaign,
        "salesforce_id": "",
        "created_at":    "",
        "updated_at":    "",
        "source":        "page",
    }


def _parse_list_page(lines: list[str]) -> dict | None:
    """
    Last-resort parser: extract whatever we can from the preference center
    list page when no individual IDs were found.
    """
    # If the page says "no preference centers" or is empty content, return None
    no_content = any(
        phrase in " ".join(lines).lower()
        for phrase in ["no preference", "keine", "not configured", "not set up"]
    )
    if no_content or not lines:
        return None

    return {
        "id":         "unknown",
        "name":       "Preference Center (details not extractable)",
        "status":     "",
        "is_default": False,
        "redirect_url": "",
        "lists":      [],
        "list_count": 0,
        "folder":     "",
        "campaign":   "",
        "salesforce_id": "",
        "created_at": "",
        "updated_at": "",
        "source":     "page_partial",
        "raw_text":   "\n".join(lines[:40]),
    }


# ── Export ────────────────────────────────────────────────────────────────────

def export_csv(results: list[dict]) -> None:
    headers = [
        "#", "Name", "ID", "Status", "Is Default",
        "List Count", "Lists", "Redirect URL",
        "Folder", "Campaign", "Salesforce ID",
        "Created At", "Updated At", "Source",
    ]
    rows = [
        [
            i + 1,
            r["name"],
            r["id"],
            r.get("status", ""),
            "Yes" if r.get("is_default") else "No",
            r.get("list_count", 0),
            " | ".join(r.get("lists", [])),
            r.get("redirect_url", ""),
            r.get("folder", ""),
            r.get("campaign", ""),
            r.get("salesforce_id", ""),
            r.get("created_at", ""),
            r.get("updated_at", ""),
            r.get("source", ""),
        ]
        for i, r in enumerate(results)
    ]
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(headers)
        for row in rows:
            w.writerow(row)
    print(f"✅ Exported {OUTPUT_CSV} ({len(rows)} row(s))")


# ── Main orchestration ────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None,
        update: bool = False, max_age_days: int = 7, refresh_limit: int = 25,
        allow_prune: bool = False, dry_run: bool = False) -> None:
    global OUTPUT_JSON, OUTPUT_CSV, SCREENSHOTS
    OUTPUT_JSON = utils.output_path("pardot_preference_center.json")
    OUTPUT_CSV  = utils.output_path("pardot_preference_center.csv")
    SCREENSHOTS = utils.output_path("screenshots", "preference_center")
    utils.reset_screenshots(SCREENSHOTS)

    print("\n🎛️  Pardot Preference Center Scraper")
    print("=" * 45)

    # Build client from page if not supplied
    if client is None:
        if page is None:
            print("❌ run() needs either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    kind = "preference_center"
    started_at = utils.now_iso()
    ok_ids = set()

    # ── Tier A: Load previous output & set up gating ────────────────────────────
    cached: dict[str, dict] = {}
    if update:
        cached = utils.load_previous_output(kind)
        cached_hash = utils.manifest_entry(f"scrape_{kind}").get("shape_hash")
        if cached_hash and cached_hash != utils.shape_hash(CSV_HEADERS):
            print("   ⚠️  Output shape changed — ignoring cache, full scrape this run")
            cached = {}
        print(f"   [update] {len(cached)} cached record(s)")

    # ── Pass 1: v5 API ────────────────────────────────────────────────────────
    print("\n📡 Pass 1 — v5 API...")
    api_records = _fetch_via_api(client)

    results: list[dict] = []

    if api_records is not None:
        print("📁 Pre-loading folders & campaigns...")
        folder_map   = pardot_api.lookup_map(client, "objects/folders",   fields=["id","name"])
        campaign_map = pardot_api.lookup_map(client, "objects/campaigns",  fields=["id","name"])
        print(f"   ✅ {len(folder_map)} folder(s), {len(campaign_map)} campaign(s)")

        for i, record in enumerate(api_records, 1):
            pc_id   = record.get("id")
            pc_name = record.get("name", f"PC {pc_id}")
            print(f"   [{i}/{len(api_records)}] {pc_name} (id: {pc_id})", end="")

            if update and cached.get(pc_id, {}).get("updated_at") == record.get("updatedAt"):
                print(" [cached]")
                fresh = utils.merge_record_fields(cached.get(pc_id, {}), record, CACHED_FIELDS)
                results.append(fresh)
                continue

            print()
            detail = _fetch_detail_via_api(client, pc_id)
            shaped = _shape_api_record(record, detail, folder_map, campaign_map)
            results.append(shaped)
            ok_ids.add(pc_id)
            print(f"       → lists: {shaped['list_count']}, default: {shaped['is_default']}")

    # ── Pass 2: page scrape fallback ─────────────────────────────────────────
    if not results:
        if page is None:
            print("⚠️  API returned no data and no browser page available for fallback.")
            print("   Saving empty output.")
        else:
            print("\n🌐 Pass 2 — Playwright page scrape...")
            results = _scrape_via_page(page)

    # ── Output ────────────────────────────────────────────────────────────────
    if not results:
        print("\n⚠️  No preference center data found.")
        print("   This org may not have a Preference Center configured.")
        print("   → Best practice: configure a Preference Center to reduce opt-out rates.")
        results = []

    current_ids = {r["id"] for r in results}
    sweep_verified = api_records is not None

    merged = utils.merge_records(cached.values() if update else [], {r["id"]: r for r in results})
    prev = utils.manifest_entry(f"scrape_{kind}")
    record_count = prev.get("record_count", len(merged))
    merged, pruned = utils.apply_prune(
        merged, current_ids, sweep_verified=sweep_verified,
        record_count=record_count, allow_prune=allow_prune
    )

    results.sort(key=lambda r: int(r.get("id", 0)) if str(r.get("id", "")).isdigit() else str(r.get("id", "")))
    if dry_run:
        print(f"   [dry-run] would visit {len(ok_ids)} of {len(current_ids)} record(s)")
        print(f"   [dry-run] would merge {len(results)}, prune {len(pruned)}")
        print(f"   [dry-run] no files written")
    else:
        utils.save_json(merged, OUTPUT_JSON)
        export_csv(merged)

        print(f"\n✅ Preference Center scrape complete — {len(merged)} found.")
        if update and ok_ids:
            utils.mark_scraped(kind, ok_ids)
            utils.write_manifest(f"scrape_{kind}", started_at=started_at,
                                shape_hash_val=utils.shape_hash(CSV_HEADERS), record_count=len(merged))

    if merged:
        for r in merged:
            default_tag = " [DEFAULT]" if r.get("is_default") else ""
            print(f"   • {r['name']}{default_tag} — {r['list_count']} list(s), status: {r.get('status','?')}")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            client = pardot_api.client_from_page(page)
            run(page=page, client=client)
        finally:
            context.close()


if __name__ == "__main__":
    main()
