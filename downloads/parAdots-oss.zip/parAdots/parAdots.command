#!/usr/bin/env bash
# parAdots — one-click launcher (macOS)
# Double-click to start the local audit dashboard.
# The first start installs dependencies automatically (a few minutes);
# every later start opens straight away.
cd "$(dirname "$0")" || exit 1

# Best-effort: clear the "downloaded from the internet" quarantine flag
# from the package files so Python/Playwright aren't blocked.
xattr -dr com.apple.quarantine . 2>/dev/null || true

if [ ! -d ".venv" ]; then
  echo "First start — setting up parAdots. This can take a few minutes…"
  if ! bash ./setup.sh; then
    echo
    echo "Setup failed. Please make sure Python 3.10+ is installed, then try again."
    read -n 1 -s -r -p "Press any key to close…"
    exit 1
  fi
fi

echo "Starting parAdots → http://localhost:8765"
echo "(Keep this window open while you work; close it to stop the dashboard.)"
exec ./.venv/bin/python viewer.py
