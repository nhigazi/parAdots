"""
Pardot Prospect Aggregate Stats Scraper — v5 API
==================================================
Produces aggregate COUNT-only statistics from /api/v5/objects/prospects.

NO individual prospect records are stored — this scraper counts pages of
results to derive totals. Output is purely statistical.

Why this matters:
  • Consent expiry risk: knowing how many opted-in prospects per brand have
    had no email engagement in > 365 days is the first step toward building
    GDPR re-consent automation.
  • Sender reputation: high hard-bounce % flagged per brand.
  • CRM sync health: Lead vs Contact distribution reveals sync gaps.
  • Segmentation sanity: per-brand opted-in counts validate that list member
    counts (from scrape_list_memberships.py) add up correctly.

Segments counted (no PII stored):
  Global:
    - total prospects
    - opted-in (optedOut=false)
    - opted-out (optedOut=true)
    - hard bounced
    - CRM synced as Lead
    - CRM synced as Contact

  Per-brand (Corporation field values discovered from existing scraped data
  or from KNOWN_BRANDS fallback list):
    - opted-in count
    - opted-out count
    - total count

  The brand filter uses the `fields=id&companyEqualTo={brand}` approach.
  If the Corporation field name differs in your instance, set
  CORPORATION_FIELD_API_NAME in your .env or configs/{org}.env.

Performance note:
  For an instance with 55 000 prospects, counting is done with page
  size 200 (= ≤ 280 API calls per segment). The total runtime for all
  segments is typically 3–8 minutes — scheduled to run after the list
  scrapers, before the analysis pass.

Output:
  pardot_prospect_stats.json
  pardot_prospect_stats.csv

Usage (standalone):
  python3 scrape_prospect_stats.py

Called from run_all.py:
  from scrape_prospect_stats import run
  run(page=page)
"""

from __future__ import annotations

import csv
import json
import os
import sys
from datetime import datetime, timezone

from playwright.sync_api import sync_playwright

import pardot_api
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""

COUNT_PAGE_SIZE = 200

# Known multi-brand Corporation values — extended at runtime from scraped data
KNOWN_BRANDS: list[str] = ["Acme", "Globex", "Initech", "Globex Schweiz"]

# v5 API field name used for the Corporation filter — override via env if needed
CORPORATION_FIELD = os.getenv("CORPORATION_FIELD_API_NAME", "company")


# ── Counting helper ───────────────────────────────────────────────────────────

def _count_prospects(
    client: pardot_api.PardotClient,
    extra_params: dict | None = None,
    label: str = "",
) -> int:
    """
    Count prospects matching extra_params by paging through the endpoint
    with fields=id only (minimal payload).
    """
    endpoint = "objects/prospects"
    url      = f"{pardot_api.PARDOT_API_BASE}/{endpoint}"
    base_params = {"fields": "id", "limit": COUNT_PAGE_SIZE}
    if extra_params:
        base_params.update(extra_params)

    count      = 0
    next_token = None
    page_num   = 0

    while True:
        if next_token:
            page_params = {
                "nextPageToken": next_token,
                "fields": "id",
                "limit": COUNT_PAGE_SIZE,
            }
        else:
            page_params = dict(base_params)

        resp = client.session.get(
            url,
            headers=client.headers(),
            params=page_params,
            timeout=pardot_api.DEFAULT_TIMEOUT,
        )

        if resp.status_code == 400:
            # Some filter combinations (e.g. unsupported field names) return 400
            print(f"     ⚠️  400 Bad Request for '{label}' — filter may be unsupported")
            return -1
        if resp.status_code == 404:
            return 0
        if resp.status_code != 200:
            print(f"     ⚠️  {resp.status_code} for '{label}': {resp.text[:150]}")
            return -1

        body       = resp.json()
        values     = body.get("values", [])
        count     += len(values)
        next_token = body.get("nextPageToken")
        page_num  += 1

        # Print a progress dot every 10 pages (~2000 prospects)
        if page_num % 10 == 0:
            print(f"     … {count:,} so far", end="\r")

        if not next_token:
            break

    return count


# ── Brand list discovery ──────────────────────────────────────────────────────

def _discover_brands() -> list[str]:
    """
    Try to extract brand names from already-scraped data.
    Falls back to KNOWN_BRANDS if nothing useful is found.
    """
    brands: set[str] = set(KNOWN_BRANDS)

    # Pull corporation values from form handlers (field mappings include brand context)
    for filename in ("pardot_formhandlers.json", "pardot_automation_rules.json"):
        path = utils.output_path(filename)
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            # Look for brand-like strings in name fields
            for item in data if isinstance(data, list) else []:
                name = item.get("name", "")
                for known in ["ACM", "GLB", "INI", "Acme", "Globex", "Initech"]:
                    if known.lower() in name.lower():
                        brands.add(known if len(known) > 3 else name.split()[0])
        except Exception:
            pass

    return sorted(brands)


# ── Orchestration ─────────────────────────────────────────────────────────────

def run(page=None, client: pardot_api.PardotClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("pardot_prospect_stats.json")
    OUTPUT_CSV  = utils.output_path("pardot_prospect_stats.csv")

    print("\n🚀 Pardot Prospect Aggregate Stats Scraper (v5 API)")
    print("=" * 50)
    print("   NOTE: No individual prospect data is stored — counts only.\n")

    if client is None:
        if page is None:
            print("❌ run(): need either a logged-in `page` or an existing `client`.")
            sys.exit(1)
        client = pardot_api.client_from_page(page)

    scraped_at = datetime.now(timezone.utc).isoformat()

    # ── Global segments ───────────────────────────────────────────────────────
    print("📊 Counting global segments...")

    global_segments = [
        ("total",              {},                               "Total prospects"),
        ("opted_in",           {"optedOut": "false"},           "Opted-in"),
        ("opted_out",          {"optedOut": "true"},            "Opted-out"),
        ("hard_bounced",       {"isHardBounced": "true"},       "Hard bounced"),
        ("crm_lead",           {"isCrmLead": "true"},           "CRM Lead"),
        ("crm_contact",        {"isCrmContact": "true"},        "CRM Contact"),
        ("crm_unsynced",       {"isCrmLead": "false",
                                "isCrmContact": "false"},       "Not in CRM"),
    ]

    global_counts: dict[str, int] = {}
    for key, params, label in global_segments:
        print(f"   {label:<30}", end=" ")
        count = _count_prospects(client, params, label=label)
        global_counts[key] = count
        display = f"{count:,}" if count >= 0 else "N/A (filter unsupported)"
        print(f"→ {display}")

    # Derive opt-out rate
    total = global_counts.get("total", 0)
    opted_out = global_counts.get("opted_out", 0)
    opt_out_rate = round(opted_out / total * 100, 1) if total > 0 else 0.0
    hard_bounce = global_counts.get("hard_bounced", 0)
    bounce_rate = round(hard_bounce / total * 100, 1) if total > 0 else 0.0

    print(f"\n   Opt-out rate : {opt_out_rate}%")
    print(f"   Bounce rate  : {bounce_rate}%")

    # ── Per-brand segments ────────────────────────────────────────────────────
    print(f"\n🏷️  Counting per-brand segments (field: {CORPORATION_FIELD})...")
    brands = _discover_brands()
    print(f"   Brands to check: {', '.join(brands)}\n")

    brand_counts: list[dict] = []
    corporation_filter_supported = True

    for brand in brands:
        print(f"   {brand:<25}", end=" ")
        filter_param = {f"{CORPORATION_FIELD}EqualTo": brand}

        total_brand = _count_prospects(client, filter_param, label=f"{brand}/total")
        if total_brand == -1:
            corporation_filter_supported = False
            print(f"→ filter unsupported (skipping remaining brands)")
            break

        opted_in_brand  = _count_prospects(
            client, {**filter_param, "optedOut": "false"}, label=f"{brand}/opted-in"
        )
        opted_out_brand = _count_prospects(
            client, {**filter_param, "optedOut": "true"}, label=f"{brand}/opted-out"
        )

        brand_rate = round(opted_out_brand / total_brand * 100, 1) if total_brand > 0 else 0.0
        print(f"→ total={total_brand:,}  opted-in={opted_in_brand:,}  opted-out={opted_out_brand:,}  ({brand_rate}% opt-out)")

        brand_counts.append({
            "brand":        brand,
            "total":        total_brand,
            "opted_in":     opted_in_brand,
            "opted_out":    opted_out_brand,
            "opt_out_rate": brand_rate,
        })

    if not corporation_filter_supported:
        print(f"   ⚠️  Corporation filter not supported — brand breakdown unavailable.")
        print(f"       Set CORPORATION_FIELD_API_NAME in .env to the correct v5 field name.")

    # ── Build output ──────────────────────────────────────────────────────────
    result = {
        "scraped_at": scraped_at,
        "global": {
            **global_counts,
            "opt_out_rate_pct":  opt_out_rate,
            "hard_bounce_rate_pct": bounce_rate,
        },
        "by_brand": brand_counts,
        "notes": {
            "corporation_filter_supported": corporation_filter_supported,
            "corporation_field_used":       CORPORATION_FIELD,
            "data_type":                    "aggregate counts only — no PII stored",
        },
    }

    utils.save_json(result, OUTPUT_JSON)
    _export_csv(result)
    print(f"\n✅ Prospect stats scrape complete.")


def _export_csv(result: dict) -> None:
    g = result["global"]
    header_global = ["Segment", "Count", "Notes"]
    rows_global = [
        ["Total prospects",  g.get("total", "N/A"),    ""],
        ["Opted-in",         g.get("opted_in", "N/A"), ""],
        ["Opted-out",        g.get("opted_out", "N/A"), f"{g.get('opt_out_rate_pct', '')}%"],
        ["Hard bounced",     g.get("hard_bounced", "N/A"), f"{g.get('hard_bounce_rate_pct', '')}%"],
        ["CRM Lead",         g.get("crm_lead", "N/A"),    ""],
        ["CRM Contact",      g.get("crm_contact", "N/A"), ""],
        ["Not in CRM",       g.get("crm_unsynced", "N/A"), ""],
    ]

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)

        w.writerow(["=== GLOBAL SEGMENTS ===", "", ""])
        w.writerow(header_global)
        for row in rows_global:
            w.writerow(row)

        if result["by_brand"]:
            w.writerow([])
            w.writerow(["=== PER-BRAND BREAKDOWN ===", "", "", "", ""])
            w.writerow(["Brand", "Total", "Opted-In", "Opted-Out", "Opt-Out Rate %"])
            for b in result["by_brand"]:
                w.writerow([
                    b["brand"], b["total"], b["opted_in"],
                    b["opted_out"], b["opt_out_rate"],
                ])

    print(f"✅ Exported {OUTPUT_CSV}")


# ── Standalone entry point ────────────────────────────────────────────────────

def main() -> None:
    utils.load_org_config()
    utils.validate_credentials()

    with sync_playwright() as pw:
        context = utils.launch_context(pw, slow_mo=50)
        page    = context.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            context.close()


if __name__ == "__main__":
    main()
