"""
SF Scraper 8 — Task / Activity Follow-Up on MQL Leads
=======================================================
Answers: "Are sales actually following up on Pardot-scored / MQL Leads?"

Without this, a high Pardot lead score means nothing if those leads sit
untouched in a queue. This scraper measures the gap between marketing
hand-off and sales activity.

Captures (last 90 days by default):
  • Tasks created on Leads, grouped by subject and outcome
  • Leads with score > MQL_THRESHOLD that have zero tasks
  • Average time-to-first-contact for MQL Leads
  • Task types: Call, Email, Meeting, Other
  • Owner distribution of tasked vs untasked MQL Leads

MQL threshold defaults to 100 — override via MQL_SCORE_THRESHOLD in .env.
Pardot score field on Lead defaults to Pardot4__Score__c — override via
PARDOT_SCORE_FIELD in .env.

Output:
  sf_task_activity.json
  sf_task_activity.csv

Called from run_sf.py / run_all.py:
  from scrape_sf_task_activity import run
  run(page=page)
"""
from __future__ import annotations
import csv, json, sys, os
from datetime import datetime, timezone, timedelta
import salesforce_api as sf
import utils

OUTPUT_JSON = ""
OUTPUT_CSV  = ""

LOOKBACK_DAYS   = int(os.getenv("TASK_LOOKBACK_DAYS", "90"))
MQL_THRESHOLD   = int(os.getenv("MQL_SCORE_THRESHOLD", "100"))
SCORE_FIELD_CANDIDATES = [
    os.getenv("PARDOT_SCORE_FIELD",""),
    "Pardot4__Score__c",
    "Score__c",
    "Lead_Score__c",
]


def _find_score_field(client: sf.SalesforceClient) -> str | None:
    lead_fields = sf.field_names(client, "Lead")
    for f in SCORE_FIELD_CANDIDATES:
        if f and f in lead_fields:
            return f
    return None


def run(page=None, client: sf.SalesforceClient | None = None) -> None:
    global OUTPUT_JSON, OUTPUT_CSV
    OUTPUT_JSON = utils.output_path("sf_task_activity.json")
    OUTPUT_CSV  = utils.output_path("sf_task_activity.csv")

    print("\n🚀 SF Scraper 8 — Task/Activity Follow-Up on MQL Leads")
    print("=" * 55)

    if client is None:
        if page is None:
            print("❌ Need page or client"); sys.exit(1)
        client = sf.client_from_page(page)

    cutoff = (datetime.now(timezone.utc) - timedelta(days=LOOKBACK_DAYS)).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"   Lookback: {LOOKBACK_DAYS} days  |  MQL threshold: {MQL_THRESHOLD}\n")

    # ── Find score field ──────────────────────────────────────────────────────
    score_field = _find_score_field(client)
    if score_field:
        print(f"   Pardot score field: {score_field}")
    else:
        print("   ⚠️  No Pardot score field found on Lead — MQL counts unavailable")

    # ── Task breakdown by type ────────────────────────────────────────────────
    print("\n📞 Tasks on Leads (last 90 days)...")
    q_tasks = f"""
        SELECT TaskSubtype, Status, COUNT(Id) cnt
        FROM   Task
        WHERE  WhoId != null
          AND  Who.Type = 'Lead'
          AND  CreatedDate >= {cutoff}
        GROUP  BY TaskSubtype, Status
        ORDER  BY COUNT(Id) DESC
    """
    task_rows = sf.soql_all(client, q_tasks)
    task_dist = [
        {"subtype": r.get("TaskSubtype","Other"), "status": r.get("Status",""),
         "count": r.get("cnt") or r.get("expr0",0)}
        for r in task_rows
    ]
    total_tasks = sum(t["count"] for t in task_dist)
    print(f"   Total tasks on Leads: {total_tasks:,}")
    for t in task_dist[:10]:
        print(f"   {t['subtype']:<20} {t['status']:<20} {t['count']:,}")

    # ── MQL Lead follow-up ────────────────────────────────────────────────────
    mql_stats: dict = {"score_field": score_field, "threshold": MQL_THRESHOLD}

    if score_field:
        print(f"\n🎯 MQL Lead follow-up (score >= {MQL_THRESHOLD})...")
        mql_total = sf.soql_count(client,
            f"SELECT COUNT() FROM Lead "
            f"WHERE {score_field} >= {MQL_THRESHOLD} AND IsConverted = false"
        )

        # MQL Leads with at least one task in lookback window
        q_mql_tasked = f"""
            SELECT COUNT(DISTINCT WhoId) tasked_count
            FROM   Task
            WHERE  Who.Type = 'Lead'
              AND  CreatedDate >= {cutoff}
              AND  WhoId IN (
                SELECT Id FROM Lead
                WHERE  {score_field} >= {MQL_THRESHOLD}
                  AND  IsConverted = false
              )
        """
        # Note: COUNT(DISTINCT) is not always supported in SOQL aggregates
        # Use a subquery count approach instead
        mql_lead_ids_with_tasks = sf.soql_count(client,
            f"SELECT COUNT() FROM Lead "
            f"WHERE {score_field} >= {MQL_THRESHOLD} "
            f"AND IsConverted = false "
            f"AND Id IN (SELECT WhoId FROM Task WHERE CreatedDate >= {cutoff})"
        )
        mql_no_follow_up = mql_total - mql_lead_ids_with_tasks if (mql_total >= 0 and mql_lead_ids_with_tasks >= 0) else -1
        follow_up_rate   = round(mql_lead_ids_with_tasks / mql_total * 100, 1) if mql_total > 0 else 0.0

        print(f"   MQL Leads (score>={MQL_THRESHOLD}) : {mql_total:,}")
        print(f"   With task in {LOOKBACK_DAYS}d       : {mql_lead_ids_with_tasks:,}  ({follow_up_rate}%)")
        print(f"   ⚠️  No follow-up           : {mql_no_follow_up:,}")

        mql_stats.update({
            "mql_total":              mql_total,
            "mql_with_task":          mql_lead_ids_with_tasks,
            "mql_no_follow_up":       mql_no_follow_up,
            "follow_up_rate_pct":     follow_up_rate,
        })

        # ── Owner distribution of untouched MQL leads ─────────────────────────
        print("\n👤 Untouched MQL Lead owners (top 10)...")
        q_owners = f"""
            SELECT Owner.Name, COUNT(Id) cnt
            FROM   Lead
            WHERE  {score_field} >= {MQL_THRESHOLD}
              AND  IsConverted = false
              AND  Id NOT IN (SELECT WhoId FROM Task WHERE CreatedDate >= {cutoff})
            GROUP  BY Owner.Name
            ORDER  BY COUNT(Id) DESC
            LIMIT  10
        """
        owner_rows = sf.soql_all(client, q_owners)
        owner_dist = [
            {"owner": (r.get("Owner") or {}).get("Name","(unknown)"),
             "untouched_mql_count": r.get("cnt") or r.get("expr0",0)}
            for r in owner_rows
        ]
        mql_stats["untouched_by_owner"] = owner_dist
        for o in owner_dist[:5]:
            print(f"   {o['owner']:<35} {o['untouched_mql_count']:,}")
    else:
        mql_stats["note"] = "Score field not found — set PARDOT_SCORE_FIELD in .env"

    output = {
        "lookback_days":   LOOKBACK_DAYS,
        "task_distribution": task_dist,
        "total_tasks":       total_tasks,
        "mql_follow_up":     mql_stats,
    }

    utils.save_json(output, OUTPUT_JSON)
    _export_csv(output)
    print(f"\n✅ Task activity scrape complete.")


def _export_csv(output):
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)

        mql = output.get("mql_follow_up", {})
        w.writerow(["=== MQL FOLLOW-UP SUMMARY ==="])
        w.writerow(["Score field",     mql.get("score_field","N/A")])
        w.writerow(["MQL threshold",   mql.get("threshold","")])
        w.writerow(["MQL Leads total", mql.get("mql_total","N/A")])
        w.writerow(["With task",       mql.get("mql_with_task","N/A")])
        w.writerow(["No follow-up",    mql.get("mql_no_follow_up","N/A")])
        w.writerow(["Follow-up rate",  f"{mql.get('follow_up_rate_pct','')}%"])

        w.writerow([])
        w.writerow(["=== TASK DISTRIBUTION ==="])
        w.writerow(["Subtype","Status","Count"])
        for t in output.get("task_distribution",[]):
            w.writerow([t["subtype"], t["status"], t["count"]])

        if mql.get("untouched_by_owner"):
            w.writerow([])
            w.writerow(["=== UNTOUCHED MQL LEADS BY OWNER ==="])
            w.writerow(["Owner","Untouched MQL Leads"])
            for o in mql["untouched_by_owner"]:
                w.writerow([o["owner"], o["untouched_mql_count"]])

    print(f"✅ Exported {OUTPUT_CSV}")


def main():
    utils.load_org_config()
    utils.validate_credentials()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        ctx  = utils.launch_context(pw, slow_mo=50)
        page = ctx.new_page()
        page.set_viewport_size({"width": 1400, "height": 900})
        try:
            utils.login(page)
            run(page=page)
        finally:
            ctx.close()

if __name__ == "__main__":
    main()
