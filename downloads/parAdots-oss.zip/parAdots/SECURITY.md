# Security & data handling

- **Credentials never get committed.** `configs/*.env`, `*.storage_state.json` and Chrome
  profiles are git-ignored. The only committed config is the synthetic `configs/demo.env`.
- **Scraped data stays local.** Collected data is written under `output/<org>/`, git-ignored
  (except the synthetic `output/demo/`). Do not commit real org output.
- **Session-based auth.** parAdots reuses your logged-in browser session; it does not store your
  Salesforce password. Leave `SF_PASSWORD` blank when using session/CLI auth.
- **Before publishing**, run `python3 scripts/leak_scan.py` (add your real org names to its
  `CLIENT_TOKENS` list first).

## Reporting a vulnerability
Open a private security advisory or contact the maintainers before filing a public issue.
